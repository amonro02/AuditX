from flask import Blueprint, jsonify, request

from services.dashboard_service import (
    DashboardConfigError,
    filter_options,
    query_chart,
    query_table,
    source_metadata,
)


dashboard_bp = Blueprint("dashboard_api", __name__, url_prefix="/api/dashboard")


@dashboard_bp.get("/metadata")
def metadata():
    return jsonify(source_metadata())


@dashboard_bp.post("/query")
def query():
    try:
        return jsonify(query_chart(request.get_json(silent=True) or {}))
    except DashboardConfigError as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception as exc:
        return jsonify({"error": "Dashboard query failed", "detail": str(exc)}), 500


@dashboard_bp.post("/table")
def table():
    try:
        return jsonify(query_table(request.get_json(silent=True) or {}))
    except DashboardConfigError as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception as exc:
        return jsonify({"error": "Dashboard table query failed", "detail": str(exc)}), 500


@dashboard_bp.post("/filter-options")
def options():
    body = request.get_json(silent=True) or {}
    try:
        values = filter_options(
            body.get("source"),
            body.get("field"),
            body.get("filters") or [],
            int(body.get("limit", 100)),
        )
        return jsonify({"values": values})
    except DashboardConfigError as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception as exc:
        return jsonify({"error": "Dashboard filter query failed", "detail": str(exc)}), 500
