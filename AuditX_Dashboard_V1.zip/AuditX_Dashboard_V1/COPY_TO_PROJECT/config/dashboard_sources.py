"""AuditX Dashboard data-source whitelist.

This is the ONE backend file you normally edit when you want to expose a new
SQL Server view or add fields that the generic dashboard engine may consume.

IMPORTANT:
- Browser requests never send raw SQL.
- `view` and `column` values are trusted server-side configuration.
- The API only accepts source/field keys declared here.
"""

DASHBOARD_DEMO_MODE = True  # Set to False after mapping your real SQL views.

DASHBOARD_SOURCES = {
    "claims": {
        "label": "Claims",
        "view": "dbo.vw_AuditX_Claims_Dashboard",
        "fields": {
            "ClaimNumber": {"column": "ClaimNumber", "label": "Claim #", "type": "string", "role": "dimension"},
            "ClientCode": {"column": "ClientCode", "label": "Client", "type": "string", "role": "dimension"},
            "AuditProject": {"column": "AuditProject", "label": "Audit Project", "type": "string", "role": "dimension"},
            "FinancialYear": {"column": "FinancialYear", "label": "Financial Year", "type": "integer", "role": "dimension"},
            "Stage": {"column": "Stage", "label": "Stage", "type": "string", "role": "dimension"},
            "Status": {"column": "Status", "label": "Status", "type": "string", "role": "dimension"},
            "ClaimType": {"column": "ClaimType", "label": "Claim Type", "type": "string", "role": "dimension"},
            "ClaimDate": {"column": "ClaimDate", "label": "Claim Date", "type": "date", "role": "dimension"},
            "ClaimMonth": {"column": "ClaimMonth", "label": "Month", "type": "date", "role": "dimension"},
            "NetClaimAmount": {
                "column": "NetClaimAmount", "label": "Net Claim Amount", "type": "number", "role": "measure",
                "aggregations": ["SUM", "AVG", "MIN", "MAX"]
            },
            "WIPAmount": {
                "column": "WIPAmount", "label": "WIP", "type": "number", "role": "measure",
                "aggregations": ["SUM", "AVG", "MIN", "MAX"]
            },
            "InvoiceAmount": {
                "column": "InvoiceAmount", "label": "Invoice", "type": "number", "role": "measure",
                "aggregations": ["SUM", "AVG", "MIN", "MAX"]
            },
        },
    },
    "projects": {
        "label": "Audit Projects",
        "view": "dbo.vw_AuditX_Projects_Dashboard",
        "fields": {
            "AuditProject": {"column": "AuditProject", "label": "Audit Project", "type": "string", "role": "dimension"},
            "ClientCode": {"column": "ClientCode", "label": "Client", "type": "string", "role": "dimension"},
            "FinancialYear": {"column": "FinancialYear", "label": "Financial Year", "type": "integer", "role": "dimension"},
            "Stage": {"column": "Stage", "label": "Stage", "type": "string", "role": "dimension"},
            "Status": {"column": "Status", "label": "Status", "type": "string", "role": "dimension"},
            "WIPAmount": {
                "column": "WIPAmount", "label": "WIP", "type": "number", "role": "measure",
                "aggregations": ["SUM", "AVG", "MIN", "MAX"]
            },
        },
    },
}

# Demo rows make the Home screen render immediately before SQL Server is wired.
# They are intentionally small and are ignored when DASHBOARD_DEMO_MODE=False.
DEMO_DATA = {
    "claims": [
        {"ClaimNumber":"CHE_MX_2026_001","ClientCode":"Client A","AuditProject":"MEX_A_2026","FinancialYear":2026,"Stage":"Potential","Status":"Vendor","ClaimType":"Deductible/Co-pay","ClaimDate":"2026-01-12","ClaimMonth":"2026-01-01","NetClaimAmount":22800.00,"WIPAmount":12000.00,"InvoiceAmount":0.00},
        {"ClaimNumber":"CHE_MX_2026_002","ClientCode":"Client B","AuditProject":"MEX_B_2026","FinancialYear":2026,"Stage":"Vendor","Status":"Client Sign-off","ClaimType":"Overcharge","ClaimDate":"2026-02-10","ClaimMonth":"2026-02-01","NetClaimAmount":19481.30,"WIPAmount":10500.00,"InvoiceAmount":3000.00},
        {"ClaimNumber":"CHE_MX_2026_003","ClientCode":"Client A","AuditProject":"MEX_A_2026","FinancialYear":2026,"Stage":"Vendor","Status":"Potential","ClaimType":"Pricing","ClaimDate":"2026-03-15","ClaimMonth":"2026-03-01","NetClaimAmount":25637.63,"WIPAmount":16000.00,"InvoiceAmount":4500.00},
        {"ClaimNumber":"CHE_MX_2026_004","ClientCode":"Client C","AuditProject":"MEX_C_2026","FinancialYear":2026,"Stage":"Client Sign-off","Status":"Posting","ClaimType":"Duplicate","ClaimDate":"2026-04-08","ClaimMonth":"2026-04-01","NetClaimAmount":4838.40,"WIPAmount":2800.00,"InvoiceAmount":2000.00},
        {"ClaimNumber":"CHE_MX_2026_005","ClientCode":"Client B","AuditProject":"MEX_B_2026","FinancialYear":2026,"Stage":"Invoice","Status":"Invoice","ClaimType":"Rebate","ClaimDate":"2026-05-18","ClaimMonth":"2026-05-01","NetClaimAmount":13001.20,"WIPAmount":5100.00,"InvoiceAmount":7900.00},
        {"ClaimNumber":"CHE_MX_2026_006","ClientCode":"Client A","AuditProject":"MEX_A_2026","FinancialYear":2026,"Stage":"Posting","Status":"Posting","ClaimType":"Overcharge","ClaimDate":"2026-06-21","ClaimMonth":"2026-06-01","NetClaimAmount":38990.00,"WIPAmount":18000.00,"InvoiceAmount":12000.00},
        {"ClaimNumber":"CHE_MX_2026_007","ClientCode":"Client D","AuditProject":"MEX_D_2026","FinancialYear":2026,"Stage":"Potential","Status":"Vendor","ClaimType":"Pricing","ClaimDate":"2026-07-04","ClaimMonth":"2026-07-01","NetClaimAmount":55750.00,"WIPAmount":24000.00,"InvoiceAmount":13000.00},
        {"ClaimNumber":"CHE_MX_2026_008","ClientCode":"Client C","AuditProject":"MEX_C_2026","FinancialYear":2026,"Stage":"Vendor","Status":"Vendor","ClaimType":"Deductible/Co-pay","ClaimDate":"2026-08-13","ClaimMonth":"2026-08-01","NetClaimAmount":66990.00,"WIPAmount":30000.00,"InvoiceAmount":17000.00},
        {"ClaimNumber":"CHE_MX_2026_009","ClientCode":"Client A","AuditProject":"MEX_A_2026","FinancialYear":2026,"Stage":"Client Sign-off","Status":"Client Sign-off","ClaimType":"Duplicate","ClaimDate":"2026-09-02","ClaimMonth":"2026-09-01","NetClaimAmount":72200.00,"WIPAmount":35000.00,"InvoiceAmount":23000.00},
        {"ClaimNumber":"CHE_MX_2026_010","ClientCode":"Client D","AuditProject":"MEX_D_2026","FinancialYear":2026,"Stage":"Invoice","Status":"Invoice","ClaimType":"Other","ClaimDate":"2026-09-12","ClaimMonth":"2026-09-01","NetClaimAmount":48600.00,"WIPAmount":12000.00,"InvoiceAmount":36000.00},
        {"ClaimNumber":"CHE_MX_2026_011","ClientCode":"Client B","AuditProject":"MEX_B_2026","FinancialYear":2026,"Stage":"Posting","Status":"Posting","ClaimType":"Rebate","ClaimDate":"2026-09-20","ClaimMonth":"2026-09-01","NetClaimAmount":31500.00,"WIPAmount":14000.00,"InvoiceAmount":16000.00},
        {"ClaimNumber":"CHE_MX_2026_012","ClientCode":"Client C","AuditProject":"MEX_C_2026","FinancialYear":2026,"Stage":"Vendor","Status":"Vendor","ClaimType":"Overcharge","ClaimDate":"2026-09-28","ClaimMonth":"2026-09-01","NetClaimAmount":58880.00,"WIPAmount":26000.00,"InvoiceAmount":22000.00},
    ],
    "projects": [
        {"AuditProject":"MEX_A_2026","ClientCode":"Client A","FinancialYear":2026,"Stage":"Fieldwork","Status":"Active","WIPAmount":72000.00},
        {"AuditProject":"MEX_B_2026","ClientCode":"Client B","FinancialYear":2026,"Stage":"Claims","Status":"Active","WIPAmount":41600.00},
        {"AuditProject":"MEX_C_2026","ClientCode":"Client C","FinancialYear":2026,"Stage":"Review","Status":"Active","WIPAmount":76800.00},
        {"AuditProject":"MEX_D_2026","ClientCode":"Client D","FinancialYear":2026,"Stage":"Invoice","Status":"Active","WIPAmount":66000.00},
        {"AuditProject":"MEX_E_2025","ClientCode":"Client E","FinancialYear":2025,"Stage":"Closed","Status":"Closed","WIPAmount":0.00},
    ],
}
