from __future__ import annotations

import os
from collections import defaultdict
from datetime import date, datetime
from typing import Any, Iterable

from flask import current_app

from config.dashboard_sources import DASHBOARD_DEMO_MODE, DASHBOARD_SOURCES, DEMO_DATA

ALLOWED_AGGREGATIONS = {"SUM", "AVG", "MIN", "MAX", "COUNT", "COUNT_DISTINCT"}
ALLOWED_FILTER_OPS = {"eq", "neq", "in", "gte", "lte", "between", "contains"}


class DashboardConfigError(ValueError):
    pass


def _source(source_key: str) -> dict:
    source = DASHBOARD_SOURCES.get(source_key)
    if not source:
        raise DashboardConfigError(f"Unknown dashboard source: {source_key}")
    return source


def _field(source: dict, field_key: str) -> dict:
    field = source["fields"].get(field_key)
    if not field:
        raise DashboardConfigError(f"Field is not allowed: {field_key}")
    return field


def _q(identifier: str) -> str:
    # Only values from the server-side whitelist ever reach this helper.
    return ".".join(f"[{part.replace(']', ']]')}]" for part in identifier.split("."))


def _connection():
    """Return a pyodbc-compatible connection.

    Preferred integration: in app.py set
      app.config['DASHBOARD_CONNECTION_FACTORY'] = your_existing_get_connection

    Alternative: set DASHBOARD_SQL_CONNECTION_STRING in Flask config or env.
    """
    factory = current_app.config.get("DASHBOARD_CONNECTION_FACTORY")
    if callable(factory):
        return factory()

    conn_str = current_app.config.get("DASHBOARD_SQL_CONNECTION_STRING") or os.getenv("DASHBOARD_SQL_CONNECTION_STRING")
    if not conn_str:
        raise RuntimeError(
            "Dashboard SQL connection is not configured. Set app.config['DASHBOARD_CONNECTION_FACTORY'] "
            "or DASHBOARD_SQL_CONNECTION_STRING."
        )
    import pyodbc
    return pyodbc.connect(conn_str)


def source_metadata() -> dict:
    return {
        key: {
            "label": value.get("label", key),
            "fields": {
                fkey: {
                    "label": fval.get("label", fkey),
                    "type": fval.get("type", "string"),
                    "role": fval.get("role", "dimension"),
                    "aggregations": fval.get("aggregations", []),
                }
                for fkey, fval in value["fields"].items()
            },
        }
        for key, value in DASHBOARD_SOURCES.items()
    }


def _normalize_series(source: dict, payload: dict) -> list[dict]:
    incoming = payload.get("series")
    if not incoming:
        y = payload.get("y")
        if not y:
            raise DashboardConfigError("At least one Y/series field is required")
        incoming = [{
            "field": y,
            "aggregate": payload.get("aggregation", "SUM"),
            "label": payload.get("yLabel") or y,
        }]

    result = []
    for idx, item in enumerate(incoming[:3]):
        field_key = item.get("field")
        field = _field(source, field_key)
        agg = str(item.get("aggregate", "SUM")).upper()
        if agg not in ALLOWED_AGGREGATIONS:
            raise DashboardConfigError(f"Aggregation not allowed: {agg}")
        if agg not in {"COUNT", "COUNT_DISTINCT"}:
            allowed = field.get("aggregations", [])
            if field.get("role") != "measure" or (allowed and agg not in allowed):
                raise DashboardConfigError(f"Aggregation {agg} is not allowed for {field_key}")
        result.append({
            "field": field_key,
            "column": field["column"],
            "aggregate": agg,
            "label": item.get("label") or field.get("label", field_key),
            "format": item.get("format", "number"),
            "chart": item.get("chart"),
            "alias": f"s{idx}",
        })
    return result


def _normalize_filters(source: dict, filters: Iterable[dict] | None) -> list[dict]:
    out = []
    for raw in filters or []:
        field_key = raw.get("field")
        if not field_key:
            continue
        field = _field(source, field_key)
        op = raw.get("op", "eq")
        if op not in ALLOWED_FILTER_OPS:
            raise DashboardConfigError(f"Filter operation not allowed: {op}")
        value = raw.get("value")
        if value in (None, "", []):
            continue
        out.append({"field": field_key, "column": field["column"], "op": op, "value": value})
    return out


def _aggregate_expr(column: str, agg: str) -> str:
    qcol = _q(column)
    if agg == "COUNT_DISTINCT":
        return f"COUNT(DISTINCT {qcol})"
    if agg == "COUNT":
        return f"COUNT({qcol})"
    return f"{agg}({qcol})"


def _where_sql(filters: list[dict]) -> tuple[str, list[Any]]:
    clauses, params = [], []
    for f in filters:
        col, op, value = _q(f["column"]), f["op"], f["value"]
        if op == "eq":
            clauses.append(f"{col} = ?")
            params.append(value)
        elif op == "neq":
            clauses.append(f"{col} <> ?")
            params.append(value)
        elif op == "gte":
            clauses.append(f"{col} >= ?")
            params.append(value)
        elif op == "lte":
            clauses.append(f"{col} <= ?")
            params.append(value)
        elif op == "contains":
            clauses.append(f"{col} LIKE ?")
            params.append(f"%{value}%")
        elif op == "between":
            if not isinstance(value, (list, tuple)) or len(value) != 2:
                raise DashboardConfigError("between requires [min,max]")
            clauses.append(f"{col} BETWEEN ? AND ?")
            params.extend([value[0], value[1]])
        elif op == "in":
            values = value if isinstance(value, list) else [value]
            if not values:
                continue
            clauses.append(f"{col} IN ({','.join('?' for _ in values)})")
            params.extend(values)
    return (" WHERE " + " AND ".join(clauses)) if clauses else "", params


def query_chart(payload: dict) -> dict:
    source_key = payload.get("source")
    source = _source(source_key)
    x_key = payload.get("x")
    x_field = _field(source, x_key) if x_key else None
    series = _normalize_series(source, payload)
    filters = _normalize_filters(source, payload.get("filters"))
    limit = max(1, min(int(payload.get("limit", 50)), 500))
    order = str(payload.get("order", "desc")).lower()
    if order not in {"asc", "desc"}:
        order = "desc"

    if DASHBOARD_DEMO_MODE:
        rows = _demo_query(source_key, x_key, series, filters, limit, order)
    else:
        rows = _sql_query(source, x_field, series, filters, limit, order)

    return {
        "source": source_key,
        "x": x_key,
        "xType": x_field.get("type") if x_field else None,
        "series": [{k: s[k] for k in ("field", "label", "format", "chart", "alias")} for s in series],
        "rows": rows,
    }


def _sql_query(source: dict, x_field: dict | None, series: list[dict], filters: list[dict], limit: int, order: str) -> list[dict]:
    select_parts = []
    group_by = ""
    if x_field:
        select_parts.append(f"{_q(x_field['column'])} AS [x]")
        group_by = f" GROUP BY {_q(x_field['column'])}"
    for s in series:
        select_parts.append(f"{_aggregate_expr(s['column'], s['aggregate'])} AS [{s['alias']}] ")
    where, params = _where_sql(filters)
    order_by = ""
    if x_field:
        order_by = f" ORDER BY [{series[0]['alias']}] {order.upper()}"
    sql = f"SELECT TOP {limit} {', '.join(select_parts)} FROM {_q(source['view'])}{where}{group_by}{order_by}"

    conn = _connection()
    try:
        cur = conn.cursor()
        cur.execute(sql, params)
        cols = [d[0] for d in cur.description]
        return [_jsonify_row(dict(zip(cols, row))) for row in cur.fetchall()]
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _passes(row: dict, f: dict) -> bool:
    actual = row.get(f["field"])
    op, value = f["op"], f["value"]
    if op == "eq": return actual == value
    if op == "neq": return actual != value
    if op == "in": return actual in (value if isinstance(value, list) else [value])
    if op == "contains": return str(value).lower() in str(actual or "").lower()
    if op == "gte": return actual is not None and actual >= value
    if op == "lte": return actual is not None and actual <= value
    if op == "between": return actual is not None and value[0] <= actual <= value[1]
    return True


def _agg(values: list[Any], agg: str):
    clean = [v for v in values if v is not None]
    if agg == "COUNT": return len(clean)
    if agg == "COUNT_DISTINCT": return len(set(clean))
    if not clean: return 0
    nums = [float(v) for v in clean]
    if agg == "SUM": return sum(nums)
    if agg == "AVG": return sum(nums) / len(nums)
    if agg == "MIN": return min(nums)
    if agg == "MAX": return max(nums)
    return 0


def _demo_query(source_key: str, x_key: str | None, series: list[dict], filters: list[dict], limit: int, order: str) -> list[dict]:
    rows = [r for r in DEMO_DATA.get(source_key, []) if all(_passes(r, f) for f in filters)]
    if x_key:
        groups = defaultdict(list)
        for row in rows:
            groups[row.get(x_key)].append(row)
        out = []
        for x, items in groups.items():
            item = {"x": x}
            for s in series:
                item[s["alias"]] = _agg([r.get(s["field"]) for r in items], s["aggregate"])
            out.append(item)
        out.sort(key=lambda r: r.get(series[0]["alias"], 0) or 0, reverse=(order == "desc"))
        return [_jsonify_row(r) for r in out[:limit]]
    item = {}
    for s in series:
        item[s["alias"]] = _agg([r.get(s["field"]) for r in rows], s["aggregate"])
    return [_jsonify_row(item)]


def query_table(payload: dict) -> dict:
    source_key = payload.get("source")
    source = _source(source_key)
    field_keys = payload.get("fields") or []
    if not field_keys:
        raise DashboardConfigError("Table requires fields")
    fields = [(key, _field(source, key)) for key in field_keys[:12]]
    filters = _normalize_filters(source, payload.get("filters"))
    limit = max(1, min(int(payload.get("limit", 8)), 100))
    order_by_key = payload.get("orderBy")
    order = str(payload.get("order", "desc")).lower()
    if order not in {"asc", "desc"}: order = "desc"

    if DASHBOARD_DEMO_MODE:
        rows = [r.copy() for r in DEMO_DATA.get(source_key, []) if all(_passes(r, f) for f in filters)]
        if order_by_key:
            rows.sort(key=lambda r: (r.get(order_by_key) is not None, r.get(order_by_key)), reverse=(order == "desc"))
        rows = [{k: r.get(k) for k, _ in fields} for r in rows[:limit]]
    else:
        select = ", ".join(f"{_q(meta['column'])} AS [{key}]" for key, meta in fields)
        where, params = _where_sql(filters)
        order_clause = ""
        if order_by_key:
            order_meta = _field(source, order_by_key)
            order_clause = f" ORDER BY {_q(order_meta['column'])} {order.upper()}"
        sql = f"SELECT TOP {limit} {select} FROM {_q(source['view'])}{where}{order_clause}"
        conn = _connection()
        try:
            cur = conn.cursor(); cur.execute(sql, params)
            cols = [d[0] for d in cur.description]
            rows = [_jsonify_row(dict(zip(cols, row))) for row in cur.fetchall()]
        finally:
            try: conn.close()
            except Exception: pass
    return {
        "fields": [{"key": k, "label": m.get("label", k), "type": m.get("type", "string")} for k, m in fields],
        "rows": rows,
    }


def filter_options(source_key: str, field_key: str, filters: list[dict] | None = None, limit: int = 100) -> list[Any]:
    source = _source(source_key)
    field = _field(source, field_key)
    normalized = _normalize_filters(source, filters)
    limit = max(1, min(limit, 500))

    if DASHBOARD_DEMO_MODE:
        values = sorted({r.get(field_key) for r in DEMO_DATA.get(source_key, []) if r.get(field_key) is not None and all(_passes(r, f) for f in normalized)}, key=lambda x: str(x))
        return values[:limit]

    where, params = _where_sql(normalized)
    sql = f"SELECT DISTINCT TOP {limit} {_q(field['column'])} AS [value] FROM {_q(source['view'])}{where} ORDER BY [value]"
    conn = _connection()
    try:
        cur = conn.cursor(); cur.execute(sql, params)
        return [_jsonify_scalar(row[0]) for row in cur.fetchall()]
    finally:
        try: conn.close()
        except Exception: pass


def _jsonify_scalar(value: Any):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    try:
        # Decimal-like values
        if hasattr(value, "as_tuple"):
            return float(value)
    except Exception:
        pass
    return value


def _jsonify_row(row: dict) -> dict:
    return {k: _jsonify_scalar(v) for k, v in row.items()}
