(() => {
  const root = document.getElementById("auditxDashboard");
  const cfg = window.AUDITX_DASHBOARD;
  if (!root || !cfg) return;

  const state = {
    globalFilters: [],
    localFilters: {},
    metadata: {},
    charts: new Map(),
    chartOverrides: {}
  };

  const fmt = {
    integer: v => new Intl.NumberFormat(undefined, {maximumFractionDigits:0}).format(Number(v || 0)),
    number: v => new Intl.NumberFormat(undefined, {maximumFractionDigits:2}).format(Number(v || 0)),
    currencyCompact: v => new Intl.NumberFormat(undefined, {style:"currency",currency:"USD",notation:"compact",maximumFractionDigits:1}).format(Number(v || 0)),
    currency: v => new Intl.NumberFormat(undefined, {style:"currency",currency:"USD",maximumFractionDigits:2}).format(Number(v || 0)),
    date: v => v ? new Date(`${String(v).slice(0,10)}T00:00:00`).toLocaleDateString(undefined,{year:"numeric",month:"short",day:"2-digit"}) : ""
  };

  const icon = name => ({filter:"⌄", more:"⋯", refresh:"↻"}[name] || "•");

  async function api(path, body) {
    const r = await fetch(path, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body || {})});
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.detail || data.error || `HTTP ${r.status}`);
    return data;
  }

  function applicableGlobalFilters(source) {
    const fields = state.metadata[source]?.fields || {};
    return state.globalFilters.filter(f => fields[f.field]);
  }

  function allFilters(widget) {
    return [...applicableGlobalFilters(widget.source), ...(widget.filters || []), ...(state.localFilters[widget.id] || [])];
  }

  function shell(widget) {
    const localCount = (state.localFilters[widget.id] || []).length;
    const filterBtn = widget.localFilters?.length ? `<button type="button" class="adx-icon-btn" data-filter-widget="${widget.id}" title="Filter this widget">⌄${localCount ? `<span class="adx-badge">${localCount}</span>` : ""}</button>` : "";
    return `<section class="adx-panel ${widget.kind === "kpi" ? "adx-kpi" : ""} ${widget.accent ? `adx-${widget.accent}` : ""}" data-widget="${widget.id}" ${widget.grid ? `data-grid="${widget.grid}"` : ""}>
      <header class="adx-panel-head"><div><h3>${widget.title}</h3></div><div class="adx-panel-actions">${filterBtn}${widget.kind === "chart" ? `<button type="button" class="adx-icon-btn" data-chart-menu="${widget.id}" title="Chart type">${icon("more")}</button>` : ""}</div></header>
      <div class="adx-panel-body"><div class="adx-loading">Loading…</div></div>
    </section>`;
  }

  function renderShells() {
    const kpis = cfg.widgets.filter(w => w.kind === "kpi");
    const main = cfg.widgets.filter(w => w.kind !== "kpi");
    root.querySelector("#adxKpis").innerHTML = kpis.map(shell).join("");
    root.querySelector("#adxMainGrid").innerHTML = main.map(shell).join("");
  }

  async function renderAll() {
    const button = root.querySelector("#adxRefresh");
    button?.classList.add("is-spinning");
    await Promise.allSettled(cfg.widgets.map(renderWidget));
    button?.classList.remove("is-spinning");
    updateScopeText();
  }

  async function renderWidget(widget) {
    const panel = root.querySelector(`[data-widget="${widget.id}"]`);
    const body = panel?.querySelector(".adx-panel-body");
    if (!body) return;
    body.innerHTML = `<div class="adx-loading">Loading…</div>`;
    try {
      if (widget.kind === "kpi") return renderKpi(widget, body);
      if (widget.kind === "chart") return renderChart(widget, body);
      if (widget.kind === "table") return renderTable(widget, body);
      if (widget.kind === "attention") return renderAttention(widget, body);
    } catch (err) {
      body.innerHTML = `<div class="adx-error"><strong>Could not load</strong><span>${escapeHtml(err.message)}</span></div>`;
    }
  }

  async function renderKpi(widget, body) {
    const data = await api("/api/dashboard/query", {source:widget.source, series:widget.series, filters:allFilters(widget)});
    const s = data.series[0];
    const value = data.rows[0]?.[s.alias] ?? 0;
    body.innerHTML = `<div class="adx-kpi-value">${formatValue(value, s.format)}</div><div class="adx-kpi-foot">${s.label}</div><div class="adx-kpi-spark"><i></i><i></i><i></i><i></i><i></i></div>`;
  }

  function chooseChart(widget, data) {
    const override = state.chartOverrides[widget.id];
    if (override && override !== "auto") return override;
    if (widget.chart && widget.chart !== "auto") return widget.chart;
    if (data.xType === "date") return "line";
    if (data.rows.length <= 5 && data.series.length === 1) return "donut";
    return data.rows.length >= 8 ? "bar-horizontal" : "bar";
  }

  async function renderChart(widget, body) {
    const data = await api("/api/dashboard/query", {
      source:widget.source, x:widget.x, series:widget.series,
      filters:allFilters(widget), order:widget.order, limit:widget.limit
    });
    const chartType = chooseChart(widget, data);
    body.innerHTML = `<div class="adx-chart" aria-label="${escapeHtml(widget.title)}"></div>`;
    const el = body.firstElementChild;
    if (!window.echarts) throw new Error("ECharts is not loaded");
    const old = state.charts.get(widget.id); if (old) old.dispose();
    const chart = window.echarts.init(el, null, {renderer:"canvas"});
    state.charts.set(widget.id, chart);
    chart.setOption(buildOption(widget, data, chartType), true);
  }

  function buildOption(widget, data, type) {
    const labels = data.rows.map(r => prettyX(r.x, data.xType));
    const values = alias => data.rows.map(r => Number(r[alias] || 0));
    const common = {
      animationDuration: 350,
      textStyle:{fontFamily:"Inter, Segoe UI, Arial, sans-serif"},
      tooltip:{trigger:"axis", backgroundColor:"rgba(18,29,51,.94)", borderWidth:0, textStyle:{color:"#fff"}},
      legend:{top:0, right:4, itemWidth:9, itemHeight:9, textStyle:{fontSize:10,color:"#667085"}},
      grid:{left:44,right:18,top:data.series.length>1?34:18,bottom:32,containLabel:false}
    };

    if (type === "donut") {
      const s = data.series[0];
      return {
        ...common, tooltip:{trigger:"item"}, legend:{type:"scroll",orient:"vertical",right:0,top:"middle",textStyle:{fontSize:10,color:"#667085"}},
        series:[{name:s.label,type:"pie",radius:["45%","70%"],center:["34%","52%"],avoidLabelOverlap:true,
          itemStyle:{borderRadius:6,borderColor:"#fff",borderWidth:2}, label:{show:false},
          data:data.rows.map(r => ({name:prettyX(r.x,data.xType), value:Number(r[s.alias]||0)}))}]
      };
    }

    const horizontal = type === "bar-horizontal";
    const series = data.series.map((s, idx) => ({
      name:s.label,
      type:(s.chart || type) === "line" ? "line" : "bar",
      data:values(s.alias),
      smooth:true,
      symbolSize:5,
      barMaxWidth:22,
      itemStyle:{borderRadius:[6,6,2,2]},
      areaStyle:(s.chart || type) === "line" ? {opacity:.07} : undefined,
      yAxisIndex: data.series.length > 1 && idx > 0 && (s.chart === "line") ? 1 : 0
    }));

    if (horizontal) {
      return {...common, grid:{left:94,right:24,top:16,bottom:18}, xAxis:{type:"value",splitLine:{lineStyle:{color:"#EEF2F7"}},axisLabel:{fontSize:9,color:"#98A2B3"}}, yAxis:{type:"category",data:labels,axisTick:{show:false},axisLine:{show:false},axisLabel:{fontSize:10,color:"#475467"}}, series};
    }

    return {
      ...common,
      xAxis:{type:"category",data:labels,axisTick:{show:false},axisLine:{lineStyle:{color:"#E4E7EC"}},axisLabel:{fontSize:9,color:"#667085",hideOverlap:true}},
      yAxis:[
        {type:"value",splitLine:{lineStyle:{color:"#EEF2F7"}},axisLabel:{fontSize:9,color:"#98A2B3"}},
        {type:"value",show:data.series.length>1,splitLine:{show:false},axisLabel:{fontSize:9,color:"#98A2B3"}}
      ],
      series
    };
  }

  async function renderTable(widget, body) {
    const data = await api("/api/dashboard/table", {source:widget.source, fields:widget.fields, filters:allFilters(widget), orderBy:widget.orderBy, order:widget.order, limit:widget.limit});
    const meta = Object.fromEntries(data.fields.map(f => [f.key, f]));
    const head = widget.fields.map(f => `<th>${escapeHtml(meta[f]?.label || f)}</th>`).join("");
    const rows = data.rows.map(r => `<tr>${widget.fields.map(f => `<td>${formatTableCell(r[f], meta[f])}</td>`).join("")}</tr>`).join("");
    body.innerHTML = `<div class="adx-table-wrap"><table class="adx-table"><thead><tr>${head}</tr></thead><tbody>${rows || `<tr><td colspan="${widget.fields.length}">No records</td></tr>`}</tbody></table></div>`;
  }

  async function renderAttention(widget, body) {
    const items = await Promise.all(widget.items.map(async item => {
      const data = await api("/api/dashboard/query", {source:item.source, y:item.y, aggregation:item.aggregate, filters:[...applicableGlobalFilters(item.source), ...(item.filters||[])]});
      const s = data.series[0];
      return {...item, value:data.rows[0]?.[s.alias] || 0};
    }));
    body.innerHTML = `<div class="adx-attention">${items.map((i,idx) => `<div class="adx-att-row"><span class="adx-att-icon">${idx+1}</span><span class="adx-att-copy"><strong>${escapeHtml(i.label)}</strong><small>${escapeHtml(i.sublabel||"")}</small></span><b>${fmt.integer(i.value)}</b></div>`).join("")}</div>`;
  }

  function formatTableCell(value, meta) {
    if (meta?.key === "Status") return `<span class="adx-status">${escapeHtml(value ?? "")}</span>`;
    if (meta?.type === "date") return fmt.date(value);
    if (meta?.type === "number") return fmt.currency(value);
    return escapeHtml(value ?? "");
  }

  function formatValue(v, type) { return (fmt[type] || fmt.number)(v); }
  function prettyX(v, type) {
    if (type === "date" && v) return new Date(`${String(v).slice(0,10)}T00:00:00`).toLocaleDateString(undefined,{month:"short",year:"2-digit"});
    return String(v ?? "");
  }
  function escapeHtml(v) { return String(v ?? "").replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c])); }

  async function openFilterPanel(widget) {
    const modal = root.querySelector("#adxFilterModal");
    const title = modal.querySelector("[data-filter-title]");
    const fieldsWrap = modal.querySelector("[data-filter-fields]");
    const isGlobal = !widget;
    title.textContent = isGlobal ? "Dashboard filters" : `Filter · ${widget.title}`;
    const defs = isGlobal ? cfg.globalFilters : (widget.localFilters || []).map(field => ({source:widget.source, field, label:state.metadata[widget.source]?.fields?.[field]?.label || field}));
    const existing = isGlobal ? state.globalFilters : (state.localFilters[widget.id] || []);

    fieldsWrap.innerHTML = "";
    for (const def of defs) {
      const meta = state.metadata[def.source]?.fields?.[def.field] || {};
      const current = existing.find(f => f.field === def.field)?.value ?? "";
      const row = document.createElement("label"); row.className = "adx-filter-field";
      row.innerHTML = `<span>${escapeHtml(def.label || meta.label || def.field)}</span><select data-source="${def.source}" data-field="${def.field}"><option value="">All</option></select>`;
      fieldsWrap.appendChild(row);
      const select = row.querySelector("select");
      try {
        const res = await api("/api/dashboard/filter-options", {source:def.source, field:def.field, filters:[]});
        res.values.forEach(v => {
          const o = document.createElement("option"); o.value = String(v); o.textContent = String(v);
          if (String(v) === String(current)) o.selected = true;
          select.appendChild(o);
        });
      } catch (_) {}
    }

    modal.dataset.mode = isGlobal ? "global" : widget.id;
    modal.classList.add("is-open");
  }

  function applyFilterPanel() {
    const modal = root.querySelector("#adxFilterModal");
    const filters = [...modal.querySelectorAll("select[data-field]")].filter(s => s.value !== "").map(s => ({field:s.dataset.field, op:"eq", value:coerceValue(s.value)}));
    if (modal.dataset.mode === "global") state.globalFilters = filters;
    else state.localFilters[modal.dataset.mode] = filters;
    modal.classList.remove("is-open");
    renderAll();
  }

  function coerceValue(v) { return /^-?\d+(\.\d+)?$/.test(v) ? Number(v) : v; }

  function updateScopeText() {
    const scope = root.querySelector("#adxScope");
    const count = state.globalFilters.length;
    scope.textContent = count ? state.globalFilters.map(f => `${f.field}: ${f.value}`).join(" · ") : "All data";
    const badge = root.querySelector("#adxGlobalFilterCount");
    badge.textContent = count ? String(count) : ""; badge.hidden = !count;
  }

  function chartTypeMenu(widgetId, anchor) {
    const old = root.querySelector(".adx-chart-menu"); if (old) old.remove();
    const menu = document.createElement("div"); menu.className = "adx-chart-menu";
    ["auto","bar","bar-horizontal","line","donut"].forEach(t => {
      const b = document.createElement("button"); b.type="button"; b.textContent = t.replace("bar-horizontal","Horizontal bars").replace("auto","Auto");
      b.addEventListener("click", () => { state.chartOverrides[widgetId] = t; menu.remove(); renderWidget(cfg.widgets.find(w => w.id === widgetId)); });
      menu.appendChild(b);
    });
    anchor.parentElement.appendChild(menu);
  }

  async function init() {
    renderShells();
    try { state.metadata = await fetch("/api/dashboard/metadata").then(r => r.json()); } catch (_) { state.metadata = {}; }

    root.addEventListener("click", e => {
      const filter = e.target.closest("[data-filter-widget]");
      if (filter) return openFilterPanel(cfg.widgets.find(w => w.id === filter.dataset.filterWidget));
      const chartMenu = e.target.closest("[data-chart-menu]");
      if (chartMenu) return chartTypeMenu(chartMenu.dataset.chartMenu, chartMenu);
      if (e.target.closest("#adxOpenFilters")) return openFilterPanel(null);
      if (e.target.closest("#adxRefresh")) return renderAll();
      if (e.target.closest("[data-filter-close]")) root.querySelector("#adxFilterModal").classList.remove("is-open");
      if (e.target.closest("[data-filter-clear]")) root.querySelectorAll("#adxFilterModal select").forEach(s => s.value = "");
      if (e.target.closest("[data-filter-apply]")) applyFilterPanel();
    });

    const ro = new ResizeObserver(() => state.charts.forEach(c => c.resize()));
    ro.observe(root);
    await renderAll();
  }

  init();
})();
