/*
  THIS is the frontend file you will edit most often.
  Change source + X + Y + aggregation and the generic engine redraws the widget.
*/
window.AUDITX_DASHBOARD = {
  globalFilters: [
    { source: "claims", field: "ClientCode", label: "Client" },
    { source: "claims", field: "FinancialYear", label: "Financial Year" },
    { source: "claims", field: "AuditProject", label: "Audit Project" },
    { source: "claims", field: "Status", label: "Status" }
  ],

  widgets: [
    {
      id: "kpi-projects", kind: "kpi", title: "Audit Projects", source: "projects",
      series: [{ field: "AuditProject", aggregate: "COUNT_DISTINCT", label: "Projects", format: "integer" }],
      accent: "blue"
    },
    {
      id: "kpi-claims", kind: "kpi", title: "Active Claims", source: "claims",
      series: [{ field: "ClaimNumber", aggregate: "COUNT_DISTINCT", label: "Claims", format: "integer" }],
      accent: "green"
    },
    {
      id: "kpi-value", kind: "kpi", title: "Claim Value", source: "claims",
      series: [{ field: "NetClaimAmount", aggregate: "SUM", label: "Claim Value", format: "currencyCompact" }],
      accent: "purple"
    },
    {
      id: "kpi-wip", kind: "kpi", title: "WIP", source: "claims",
      series: [{ field: "WIPAmount", aggregate: "SUM", label: "WIP", format: "currencyCompact" }],
      accent: "cyan"
    },
    {
      id: "kpi-pending", kind: "kpi", title: "Pending Actions", source: "claims",
      series: [{ field: "ClaimNumber", aggregate: "COUNT_DISTINCT", label: "Pending", format: "integer" }],
      filters: [{ field: "Status", op: "in", value: ["Vendor", "Client Sign-off"] }],
      accent: "orange"
    },

    {
      id: "claims-stage", kind: "chart", title: "Claims by Stage", source: "claims",
      chart: "auto", x: "Stage",
      series: [{ field: "NetClaimAmount", aggregate: "SUM", label: "Claim Value", format: "currencyCompact" }],
      localFilters: ["ClientCode", "FinancialYear", "Status", "ClaimType"],
      order: "desc", limit: 8, grid: "a"
    },
    {
      id: "claims-time", kind: "chart", title: "Claims Over Time", source: "claims",
      chart: "line", x: "ClaimMonth",
      series: [
        { field: "NetClaimAmount", aggregate: "SUM", label: "Claim Value", format: "currencyCompact", chart: "bar" },
        { field: "ClaimNumber", aggregate: "COUNT_DISTINCT", label: "Claims", format: "integer", chart: "line" }
      ],
      localFilters: ["ClientCode", "FinancialYear", "AuditProject", "Status"],
      order: "asc", limit: 24, grid: "b"
    },
    {
      id: "attention", kind: "attention", title: "Attention", grid: "c",
      items: [
        { label: "Vendor approval", sublabel: "Claims awaiting vendor approval", source: "claims", y: "ClaimNumber", aggregate: "COUNT_DISTINCT", filters: [{field:"Status",op:"eq",value:"Vendor"}] },
        { label: "Client sign-off", sublabel: "Claims awaiting client sign-off", source: "claims", y: "ClaimNumber", aggregate: "COUNT_DISTINCT", filters: [{field:"Status",op:"eq",value:"Client Sign-off"}] },
        { label: "Posting", sublabel: "Claims in posting", source: "claims", y: "ClaimNumber", aggregate: "COUNT_DISTINCT", filters: [{field:"Status",op:"eq",value:"Posting"}] },
        { label: "Invoice", sublabel: "Claims in invoice", source: "claims", y: "ClaimNumber", aggregate: "COUNT_DISTINCT", filters: [{field:"Status",op:"eq",value:"Invoice"}] }
      ]
    },
    {
      id: "claims-type", kind: "chart", title: "Claims by Type", source: "claims",
      chart: "donut", x: "ClaimType",
      series: [{ field: "ClaimNumber", aggregate: "COUNT_DISTINCT", label: "Claims", format: "integer" }],
      localFilters: ["ClientCode", "FinancialYear", "AuditProject", "Status"],
      order: "desc", limit: 7, grid: "d"
    },
    {
      id: "wip-invoice", kind: "chart", title: "WIP vs Invoice", source: "claims",
      chart: "bar", x: "ClaimMonth",
      series: [
        { field: "WIPAmount", aggregate: "SUM", label: "WIP", format: "currencyCompact", chart: "bar" },
        { field: "InvoiceAmount", aggregate: "SUM", label: "Invoice", format: "currencyCompact", chart: "bar" }
      ],
      localFilters: ["ClientCode", "FinancialYear", "AuditProject"],
      order: "asc", limit: 24, grid: "e"
    },
    {
      id: "recent-claims", kind: "table", title: "Recent Claims", source: "claims",
      fields: ["ClaimNumber", "ClientCode", "ClaimDate", "NetClaimAmount", "Status"],
      orderBy: "ClaimDate", order: "desc", limit: 5,
      localFilters: ["ClientCode", "FinancialYear", "AuditProject", "Status"],
      grid: "f"
    }
  ]
};
