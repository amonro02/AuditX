# AuditX Dashboard V1 — instalación por copia

Esta primera versión está pensada para integrarse a tu AuditX actual **sin rehacer Planning ni Tracker**.

## Qué hace

- Home completo en **una sola pantalla**, sin scroll vertical del dashboard.
- 5 KPI compactos + 6 widgets.
- Motor genérico: para cambiar una gráfica normalmente editas solo:
  - `source`
  - `x`
  - `series[].field`
  - `aggregate`
  - `chart`
- `chart: "auto"` permite que el motor elija una visual razonable.
- Cada gráfica tiene filtro local por embudo.
- Home tiene un único botón **Filters** para filtros globales.
- Los filtros globales y locales se combinan automáticamente.
- El menú `⋯` de una gráfica permite probar Auto / Bars / Horizontal bars / Line / Donut sin cambiar código.
- Backend protegido por **whitelist** de vistas/campos; el navegador nunca manda SQL libre.
- Modo demo incluido para que funcione visualmente antes de conectar las vistas reales.

---

## 1. Copia estos archivos respetando rutas

Desde `COPY_TO_PROJECT/` hacia la raíz de tu proyecto AuditX:

```text
routes/dashboard.py
services/dashboard_service.py
config/dashboard_sources.py
templates/home.html
static/css/dashboard.css
static/js/dashboard-widgets.js
static/js/dashboard-engine.js
static/vendor/echarts.min.js
```

Si ya tienes un `templates/home.html` que no quieres sustituir, usa:

```text
templates/partials/home_dashboard_content.html
```

y copia solo su contenido dentro del bloque de tu Home actual.

---

## 2. Registra la API en app.py

Copia/adapta `INTEGRACION_APP_PY.txt`.

Mínimo:

```python
from routes.dashboard import dashboard_bp
app.register_blueprint(dashboard_bp)
```

Y reutiliza tu función actual de conexión:

```python
app.config["DASHBOARD_CONNECTION_FACTORY"] = get_connection
```

---

## 3. Primero pruébalo SIN SQL

La versión viene con:

```python
DASHBOARD_DEMO_MODE = True
```

Por lo tanto el Home debe pintar datos de ejemplo inmediatamente.

Esto sirve para validar:

- distribución;
- tamaños;
- ausencia de scroll;
- sidebar colapsado/expandido;
- filtros;
- comportamiento de las gráficas;
- tipo de gráfica.

---

## 4. Después conecta tus vistas reales

En:

```text
config/dashboard_sources.py
```

cambia:

```python
DASHBOARD_DEMO_MODE = False
```

Y ajusta solo las entradas `view` y `column`.

Ejemplo:

```python
"claims": {
    "view": "dbo.MI_VISTA_REAL_DE_CLAIMS",
    "fields": {
        "Stage": {
            "column": "MI_COLUMNA_STAGE",
            ...
        }
    }
}
```

**El nombre externo `Stage` puede quedarse igual**, aunque la columna real en SQL tenga otro nombre.

---

## 5. Cómo crear/cambiar una gráfica

Archivo:

```text
static/js/dashboard-widgets.js
```

Ejemplo mínimo:

```javascript
{
  id: "claims-stage",
  kind: "chart",
  title: "Claims by Stage",
  source: "claims",
  chart: "auto",
  x: "Stage",
  series: [
    {
      field: "NetClaimAmount",
      aggregate: "SUM",
      label: "Claim Value",
      format: "currencyCompact"
    }
  ]
}
```

Para cambiarla a Claims por Auditor en el futuro sería conceptualmente:

```javascript
x: "Auditor",
series: [{ field: "ClaimNumber", aggregate: "COUNT_DISTINCT" }]
```

Siempre que `Auditor` esté previamente autorizado en `dashboard_sources.py`.

---

## 6. Dos series en la misma gráfica

```javascript
series: [
  { field: "WIPAmount", aggregate: "SUM", label: "WIP", chart: "bar" },
  { field: "InvoiceAmount", aggregate: "SUM", label: "Invoice", chart: "line" }
]
```

El motor admite hasta 3 series por widget en esta V1.

---

## 7. Filtros locales

En cada widget:

```javascript
localFilters: ["ClientCode", "FinancialYear", "Status"]
```

Eso hace que el embudo se genere sin crear HTML específico para la gráfica.

---

## 8. Filtros globales

Al inicio de `dashboard-widgets.js`:

```javascript
globalFilters: [
  { source: "claims", field: "ClientCode", label: "Client" },
  { source: "claims", field: "FinancialYear", label: "Financial Year" }
]
```

Se muestran únicamente al pulsar **Filters**. No ocupan una fila permanente en Home.

---

## 9. Motor de gráficas local

Incluí un runtime local ligero y compatible con la parte de la API de ECharts que usa esta V1:

```text
static/vendor/echarts.min.js
```

Por tanto **no necesita Internet** para dibujar barras, barras horizontales, líneas, combinaciones y donut.

Si más adelante quieres funciones avanzadas de Apache ECharts, basta sustituir ese archivo por el `echarts.min.js` oficial 5.x; `dashboard-engine.js` no necesita cambiar.

---

## 10. Si el bloque de Jinja no se llama `content`

El `home.html` incluido usa:

```jinja2
{% block content %}
```

Si tu `base.html` usa otro bloque (por ejemplo `main`, `body`, etc.), no cambies tu base. Usa el partial:

```text
templates/partials/home_dashboard_content.html
```

y pega su contenido dentro del bloque correcto.

---

## 11. Qué NO modifica esta V1

- Planning.
- Tracker.
- Base de datos.
- Tus vistas existentes.
- Tu sidebar actual.
- La lógica de edición/alta/baja que ya tienes.

La integración agrega Home + API de dashboard.

---

## 12. Siguiente paso recomendado después de que lo veas funcionando

Cuando tengas el Home corriendo con datos demo, pásame el ZIP real de AuditX que estés ejecutando. Entonces se puede hacer una V2 integrada sobre tu estructura exacta, eliminando cualquier adaptación manual de imports, bloques Jinja, conexión SQL, rutas o estilos.
