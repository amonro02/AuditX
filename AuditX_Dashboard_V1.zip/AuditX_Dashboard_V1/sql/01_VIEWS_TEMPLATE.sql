/*
  AUDITX DASHBOARD V1 - TEMPLATE ONLY
  ----------------------------------
  This file is NOT meant to run as-is because I do not yet have your exact
  table/view names. It shows the contract expected by config/dashboard_sources.py.

  You have two valid options:
  A) Point dashboard_sources.py to views you ALREADY have.
  B) Create thin dashboard views that alias your real columns to the names below.
*/

/* Example expected shape for Claims:
CREATE VIEW dbo.vw_AuditX_Claims_Dashboard AS
SELECT
    ClaimNumber,
    ClientCode,
    AuditProject,
    FinancialYear,
    Stage,
    Status,
    ClaimType,
    CAST(ClaimDate AS date) AS ClaimDate,
    DATEFROMPARTS(YEAR(ClaimDate), MONTH(ClaimDate), 1) AS ClaimMonth,
    CAST(NetClaimAmount AS decimal(18,2)) AS NetClaimAmount,
    CAST(WIPAmount AS decimal(18,2)) AS WIPAmount,
    CAST(InvoiceAmount AS decimal(18,2)) AS InvoiceAmount
FROM dbo.YourRealClaimsSource;
*/

/* Example expected shape for Audit Projects:
CREATE VIEW dbo.vw_AuditX_Projects_Dashboard AS
SELECT
    AuditProject,
    ClientCode,
    FinancialYear,
    Stage,
    Status,
    CAST(WIPAmount AS decimal(18,2)) AS WIPAmount
FROM dbo.YourRealProjectSource;
*/
