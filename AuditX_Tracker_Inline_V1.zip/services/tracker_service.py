from __future__ import annotations
from datetime import datetime
from typing import Any, Dict, Optional

from config.tracker_config import COLUMN_LABELS, EDITABLE_FIELDS, HIDDEN_COLUMNS
from repositories.tracker_repository import fetch_page, fetch_record, update_field


class TrackerValidationError(Exception):
    def __init__(self, message, *, title='No se puede guardar el cambio', field='', value=None):
        super().__init__(message)
        self.title = title
        self.field = field
        self.value = value


def _norm(value: str) -> str:
    return (value or '').strip().lower()


def _field_rule(actual_column: str) -> Optional[Dict[str, Any]]:
    target = _norm(actual_column)
    for name, rule in EDITABLE_FIELDS.items():
        if _norm(name) == target:
            return dict(rule)
    return None


def _coerce(rule: Dict[str, Any], value: Any):
    kind = rule.get('type', 'text')
    if value == '':
        return None
    if kind == 'number':
        try:
            return float(value)
        except (TypeError, ValueError):
            raise TrackerValidationError('El valor debe ser numérico.', value=value)
    if kind == 'date':
        if value in (None, ''):
            return None
        try:
            return datetime.strptime(str(value)[:10], '%Y-%m-%d')
        except ValueError:
            raise TrackerValidationError('La fecha no tiene un formato válido.', value=value)
    if kind == 'checkbox':
        return 1 if str(value).lower() in {'1','true','yes','on'} else 0
    return value


def validate_business_rules(*, record, field, new_value):
    # V1: leave empty until the real Access rules are migrated.
    return


def build_column_meta(columns):
    hidden = {_norm(x) for x in HIDDEN_COLUMNS}
    out = []
    for col in columns:
        rule = _field_rule(col)
        label = COLUMN_LABELS.get(col, COLUMN_LABELS.get(_norm(col), col))
        out.append({
            'name': col,
            'label': label,
            'hidden': _norm(col) in hidden,
            'editable': rule is not None,
            'editor': (rule or {}).get('type', 'readonly'),
            'options': (rule or {}).get('options', []),
        })
    return out


def get_tracker_page(*, page, page_size, filters, sort_column, sort_direction):
    data = fetch_page(
        page=page,
        page_size=page_size,
        filters=filters,
        sort_column=sort_column,
        sort_direction=sort_direction,
    )
    data['column_meta'] = build_column_meta(data['columns'])
    return data


def save_tracker_cell(*, tracker_key, field, value, changed_by):
    record = fetch_record(tracker_key)
    if not record:
        raise TrackerValidationError(
            'El registro ya no existe o no está disponible.',
            title='No se encontró el registro', field=field, value=value,
        )

    actual = next((c for c in record if _norm(c) == _norm(field)), None)
    if not actual:
        raise TrackerValidationError('La columna seleccionada no existe en Tracker.', field=field, value=value)

    rule = _field_rule(actual)
    if not rule:
        raise TrackerValidationError('Este campo es de solo lectura.', field=actual, value=value)

    coerced = _coerce(rule, value)
    validate_business_rules(record=record, field=actual, new_value=coerced)
    return update_field(tracker_key, actual, coerced, changed_by=changed_by)
