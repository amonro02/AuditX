(() => {
  'use strict';

  const state = {
    page: 1, pageSize: 25, totalRows: 0, totalPages: 1,
    columns: [], columnMeta: [], rows: [], primaryKey: 'tracker_key',
    filters: {}, sortColumn: null, sortDirection: 'ASC', requestId: 0,
    hiddenColumns: new Set(), draftHiddenColumns: new Set(),
  };
  const $ = (id) => document.getElementById(id);
  const els = {};

  document.addEventListener('DOMContentLoaded', () => {
    Object.assign(els, {
      head: $('trackerHead'), body: $('trackerBody'), table: $('trackerTable'),
      loading: $('trackerLoading'), empty: $('trackerEmpty'), prev: $('trackerPrev'),
      next: $('trackerNext'), pageInfo: $('trackerPageInfo'), pageSize: $('trackerPageSize'),
      totalCounter: $('trackerTotalCounter'), columnsCounter: $('trackerColumnsCounter'),
      filterCounter: $('trackerFilterCounter'), clearFilters: $('trackerClearFilters'),
      configureView: $('trackerConfigureView'), exportExcel: $('trackerExportExcel'),
      validationBackdrop: $('trackerValidationBackdrop'), validationTitle: $('trackerValidationTitle'),
      validationMessage: $('trackerValidationMessage'), validationDetails: $('trackerValidationDetails'),
      validationField: $('trackerValidationField'), validationValue: $('trackerValidationValue'),
      validationClose: $('trackerValidationClose'), columnsBackdrop: $('trackerColumnsBackdrop'),
      columnsList: $('trackerColumnsList'), columnsAll: $('trackerColumnsAll'),
      columnsCancel: $('trackerColumnsCancel'), columnsApply: $('trackerColumnsApply'),
    });
    bindStaticEvents();
    loadSavedView();
    refreshTracker();
  });

  function bindStaticEvents() {
    els.prev.addEventListener('click', () => { if (state.page > 1) { state.page--; refreshTracker(); } });
    els.next.addEventListener('click', () => { if (state.page < state.totalPages) { state.page++; refreshTracker(); } });
    els.pageSize.addEventListener('change', () => { state.pageSize = Number(els.pageSize.value || 25); state.page = 1; refreshTracker(); });
    els.clearFilters.addEventListener('click', () => { state.filters = {}; state.page = 1; refreshTracker(); });
    els.configureView.addEventListener('click', openColumnsModal);
    els.columnsCancel.addEventListener('click', closeColumnsModal);
    els.columnsApply.addEventListener('click', applyColumnsModal);
    els.columnsAll.addEventListener('click', () => { state.draftHiddenColumns.clear(); renderColumnsModal(); });
    els.validationClose.addEventListener('click', closeValidationModal);
    els.validationBackdrop.addEventListener('click', e => { if (e.target === els.validationBackdrop) closeValidationModal(); });
    els.columnsBackdrop.addEventListener('click', e => { if (e.target === els.columnsBackdrop) closeColumnsModal(); });
    els.exportExcel.addEventListener('click', exportExcel);
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        if (!els.validationBackdrop.hidden) closeValidationModal();
        if (!els.columnsBackdrop.hidden) closeColumnsModal();
      }
    });
  }

  async function refreshTracker() {
    const requestId = ++state.requestId;
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: String(state.page), page_size: String(state.pageSize),
        filters: JSON.stringify(state.filters), sort_direction: state.sortDirection,
      });
      if (state.sortColumn) params.set('sort_column', state.sortColumn);
      const response = await fetch(`/api/tracker/data?${params}`, { headers: {Accept: 'application/json'}, cache: 'no-store' });
      const result = await response.json();
      if (requestId !== state.requestId) return;
      if (!response.ok || result.ok === false) throw new Error(result.message || 'Unable to load Tracker.');

      state.page = Number(result.page || 1);
      state.pageSize = Number(result.page_size || 25);
      state.totalRows = Number(result.total_rows || 0);
      state.totalPages = Math.max(1, Number(result.total_pages || 1));
      state.columns = result.columns || [];
      state.columnMeta = result.column_meta || [];
      state.rows = result.rows || [];
      state.primaryKey = result.primary_key || 'tracker_key';
      state.sortColumn = result.sort_column || state.sortColumn;
      state.sortDirection = result.sort_direction || state.sortDirection;
      render();
    } catch (error) {
      showValidationModal({title: 'No se pudo cargar Tracker', message: error.message || String(error)});
    } finally {
      if (requestId === state.requestId) setLoading(false);
    }
  }

  function visibleMeta() {
    return state.columnMeta.filter(meta => !meta.hidden && !state.hiddenColumns.has(meta.name.toLowerCase()));
  }

  function render() { renderHeader(); renderBody(); updateToolbar(); }

  function renderHeader() {
    const metas = visibleMeta();
    els.head.replaceChildren();
    const titleRow = document.createElement('tr');
    titleRow.className = 'tracker-column-row';
    metas.forEach(meta => {
      const th = document.createElement('th');
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'tracker-column-title'; button.textContent = meta.label || meta.name;
      if (state.sortColumn && state.sortColumn.toLowerCase() === meta.name.toLowerCase()) button.textContent += state.sortDirection === 'DESC' ? ' ↓' : ' ↑';
      button.addEventListener('click', () => {
        if (state.sortColumn && state.sortColumn.toLowerCase() === meta.name.toLowerCase()) state.sortDirection = state.sortDirection === 'ASC' ? 'DESC' : 'ASC';
        else { state.sortColumn = meta.name; state.sortDirection = 'ASC'; }
        state.page = 1; refreshTracker();
      });
      th.appendChild(button); titleRow.appendChild(th);
    });

    const filterRow = document.createElement('tr'); filterRow.className = 'tracker-filter-row';
    metas.forEach(meta => {
      const th = document.createElement('th');
      const wrap = document.createElement('div'); wrap.className = 'tracker-filter-wrap';
      const icon = document.createElement('span'); icon.className = 'tracker-filter-icon'; icon.textContent = '≡';
      const input = document.createElement('input'); input.type = 'text'; input.placeholder = 'Filter'; input.value = state.filters[meta.name] || '';
      let timer = null;
      input.addEventListener('input', () => {
        clearTimeout(timer);
        timer = setTimeout(() => {
          const value = input.value.trim();
          if (value) state.filters[meta.name] = value; else delete state.filters[meta.name];
          state.page = 1; refreshTracker();
        }, 350);
      });
      wrap.append(icon, input); th.appendChild(wrap); filterRow.appendChild(th);
    });
    els.head.append(titleRow, filterRow);
  }

  function renderBody() {
    els.body.replaceChildren();
    const metas = visibleMeta();
    state.rows.forEach(row => {
      const tr = document.createElement('tr');
      const key = getRowValue(row, state.primaryKey); tr.dataset.trackerKey = key == null ? '' : String(key);
      metas.forEach(meta => {
        const td = document.createElement('td'); td.dataset.column = meta.name;
        const value = getRowValue(row, meta.name);
        if (meta.editable) { td.classList.add('tracker-cell-editable'); td.appendChild(createEditor(meta, value, tr)); }
        else { td.classList.add('tracker-cell-readonly'); td.textContent = value == null ? '' : String(value); td.title = td.textContent; }
        tr.appendChild(td);
      });
      els.body.appendChild(tr);
    });
    els.empty.hidden = state.rows.length !== 0; els.table.hidden = state.rows.length === 0;
  }

  function createEditor(meta, value, tr) {
    const kind = meta.editor || 'text';
    let input;
    if (kind === 'select') {
      input = document.createElement('select');
      const empty = document.createElement('option'); empty.value = ''; empty.textContent = ''; input.appendChild(empty);
      (meta.options || []).forEach(v => { const o = document.createElement('option'); o.value = String(v); o.textContent = String(v); input.appendChild(o); });
      input.value = value == null ? '' : String(value);
    } else {
      input = document.createElement('input');
      if (kind === 'date') { input.type = 'date'; input.value = toDateInputValue(value); }
      else if (kind === 'number') { input.type = 'number'; input.step = 'any'; input.value = value == null ? '' : String(value); }
      else if (kind === 'checkbox') { input.type = 'checkbox'; input.checked = Boolean(value); }
      else { input.type = 'text'; input.value = value == null ? '' : String(value); }
    }
    input.className = 'tracker-inline-editor'; input.dataset.original = currentValue(input, kind); input.autocomplete = 'off';
    if (['select','date','checkbox'].includes(kind)) input.addEventListener('change', () => saveEditor(input, tr, meta));
    else {
      input.addEventListener('keydown', e => {
        if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
        if (e.key === 'Escape') { e.preventDefault(); setEditorValue(input, kind, input.dataset.original || ''); input.blur(); }
      });
      input.addEventListener('blur', () => { if (currentValue(input, kind) !== input.dataset.original) saveEditor(input, tr, meta); });
    }
    return input;
  }

  async function saveEditor(input, tr, meta) {
    if (input.dataset.saving === '1') return;
    const key = tr.dataset.trackerKey, previous = input.dataset.original, value = currentValue(input, meta.editor);
    if (!key) { showValidationModal({title:'No se puede guardar el cambio', message:'La fila no contiene tracker_key.', field:meta.label || meta.name, value}); setEditorValue(input, meta.editor, previous); return; }
    input.dataset.saving = '1'; input.disabled = true; input.closest('td')?.classList.add('is-saving');
    try {
      const response = await fetch(`/api/tracker/${encodeURIComponent(key)}`, {
        method:'PATCH', headers:{'Content-Type':'application/json', Accept:'application/json'}, body:JSON.stringify({field:meta.name, value})
      });
      const result = await response.json();
      if (!response.ok || result.ok === false) {
        showValidationModal({title:result.title || 'No se puede guardar el cambio', message:result.message || 'The value was not saved.', field:result.field || meta.label || meta.name, value:result.value ?? value});
        setEditorValue(input, meta.editor, previous); input.closest('td')?.classList.add('is-save-error'); return;
      }
      setEditorValue(input, meta.editor, result.value ?? value); input.dataset.original = currentValue(input, meta.editor);
      const td = input.closest('td'); td?.classList.add('is-saved'); setTimeout(() => td?.classList.remove('is-saved'), 900);
    } catch (error) {
      setEditorValue(input, meta.editor, previous);
      showValidationModal({title:'No fue posible guardar el cambio', message:error.message || String(error), field:meta.label || meta.name, value});
    } finally {
      input.disabled = false; input.dataset.saving = '0'; const td = input.closest('td'); td?.classList.remove('is-saving'); setTimeout(() => td?.classList.remove('is-save-error'), 1400);
    }
  }

  function currentValue(input, kind) { return kind === 'checkbox' ? (input.checked ? '1' : '0') : (input.value ?? ''); }
  function setEditorValue(input, kind, value) {
    if (kind === 'checkbox') input.checked = Boolean(value) && String(value) !== '0';
    else if (kind === 'date') input.value = toDateInputValue(value);
    else input.value = value == null ? '' : String(value);
  }
  function toDateInputValue(value) { if (!value) return ''; const m = String(value).match(/^(\d{4}-\d{2}-\d{2})/); return m ? m[1] : ''; }
  function getRowValue(row, name) { if (Object.prototype.hasOwnProperty.call(row, name)) return row[name]; const key = Object.keys(row).find(k => k.toLowerCase() === String(name).toLowerCase()); return key ? row[key] : null; }

  function updateToolbar() {
    const active = Object.values(state.filters).filter(v => String(v || '').trim()).length;
    els.filterCounter.textContent = active ? `🔎 ${active} filtered` : '🔎 No filters';
    els.totalCounter.textContent = `📊 ${Number(state.totalRows).toLocaleString()} total`;
    els.columnsCounter.textContent = `🧩 ${visibleMeta().length} columns`;
    els.pageInfo.textContent = `Page ${Number(state.page).toLocaleString()} of ${Number(state.totalPages).toLocaleString()}`;
    els.prev.disabled = state.page <= 1; els.next.disabled = state.page >= state.totalPages || state.totalRows === 0; els.pageSize.value = String(state.pageSize);
  }
  function setLoading(v) { els.loading.hidden = !v; }

  function showValidationModal({title, message, field='', value=''}) {
    els.validationTitle.textContent = title || 'No se puede guardar el cambio';
    els.validationMessage.textContent = message || 'The change could not be saved.';
    const details = Boolean(field || value); els.validationDetails.hidden = !details;
    els.validationField.textContent = field || '—'; els.validationValue.textContent = value == null || value === '' ? '—' : String(value);
    els.validationBackdrop.hidden = false; document.body.classList.add('tracker-modal-open'); setTimeout(() => els.validationClose.focus(), 0);
  }
  function closeValidationModal() { els.validationBackdrop.hidden = true; document.body.classList.remove('tracker-modal-open'); }

  function loadSavedView() {
    try { const raw = localStorage.getItem('auditx_tracker_hidden_columns'); const list = raw ? JSON.parse(raw) : []; state.hiddenColumns = new Set(Array.isArray(list) ? list.map(x => String(x).toLowerCase()) : []); }
    catch (_) { state.hiddenColumns = new Set(); }
  }
  function saveView() { localStorage.setItem('auditx_tracker_hidden_columns', JSON.stringify([...state.hiddenColumns])); }
  function openColumnsModal() { state.draftHiddenColumns = new Set(state.hiddenColumns); renderColumnsModal(); els.columnsBackdrop.hidden = false; document.body.classList.add('tracker-modal-open'); }
  function closeColumnsModal() { els.columnsBackdrop.hidden = true; document.body.classList.remove('tracker-modal-open'); }
  function renderColumnsModal() {
    els.columnsList.replaceChildren();
    state.columnMeta.forEach(meta => {
      if (meta.hidden) return;
      const label = document.createElement('label'); label.className = 'tracker-column-option';
      const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = !state.draftHiddenColumns.has(meta.name.toLowerCase());
      cb.addEventListener('change', () => { const key = meta.name.toLowerCase(); if (cb.checked) state.draftHiddenColumns.delete(key); else state.draftHiddenColumns.add(key); });
      const text = document.createElement('span'); text.textContent = meta.label || meta.name;
      label.append(cb, text);
      if (meta.editable) { const badge = document.createElement('em'); badge.textContent = 'Editable'; label.appendChild(badge); }
      els.columnsList.appendChild(label);
    });
  }
  function applyColumnsModal() { state.hiddenColumns = new Set(state.draftHiddenColumns); saveView(); closeColumnsModal(); render(); }
  function exportExcel() {
    const params = new URLSearchParams({filters:JSON.stringify(state.filters), sort_direction:state.sortDirection});
    if (state.sortColumn) params.set('sort_column', state.sortColumn);
    window.location.href = `/api/tracker/export?${params}`;
  }
})();
