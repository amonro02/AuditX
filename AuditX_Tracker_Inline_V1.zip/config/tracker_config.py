from __future__ import annotations
import os

TRACKER_PRIMARY_KEY = os.getenv('TRACKER_PRIMARY_KEY', 'tracker_key').strip()
TRACKER_SOURCE = os.getenv('TRACKER_SOURCE', '').strip()
TRACKER_SOURCE_CANDIDATES = [
    'dbo.Tracker',
    'dbo.tracker',
    'dbo.vw_Tracker',
    'dbo.Dyn_437_Tracker',
]
TRACKER_UPDATE_TARGET = os.getenv('TRACKER_UPDATE_TARGET', '').strip()

DEFAULT_PAGE_SIZE = 25
MAX_PAGE_SIZE = 200
EXPORT_MAX_ROWS = 100_000

HIDDEN_COLUMNS = {'tracker_key'}

# Only fields listed here can be edited.
# Supported types: text, number, date, select, checkbox.
EDITABLE_FIELDS = {
    'task_start_date': {'type': 'date'},
    'task_end_date': {'type': 'date'},
    'task_status': {'type': 'text'},
    'remisión': {'type': 'text'},
    'remision': {'type': 'text'},
    'claimed_value': {'type': 'number'},
    'user id': {'type': 'text'},
    'user_id': {'type': 'text'},
    'comentario auditor': {'type': 'text'},
    'comentario_auditor': {'type': 'text'},
    'competencia': {'type': 'text'},
    'año anterior prgx': {'type': 'text'},
    'ano anterior prgx': {'type': 'text'},
    'campos 1': {'type': 'text'},
    'campos 2': {'type': 'text'},
}

COLUMN_LABELS = {
    'tracker_key': 'Tracker Key',
    'task_start_date': 'Start Date',
    'task_end_date': 'End Date',
    'task_status': 'Status',
    'claimed_value': 'Claimed Value',
}

# Real Access rules will be migrated later.
ENABLE_SAMPLE_RULES = False
