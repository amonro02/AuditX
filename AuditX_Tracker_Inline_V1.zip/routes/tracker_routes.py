from __future__ import annotations
import io, json
from datetime import datetime
from flask import Blueprint, jsonify, request, session, send_file

from config.tracker_config import DEFAULT_PAGE_SIZE, EXPORT_MAX_ROWS, MAX_PAGE_SIZE
from repositories.tracker_repository import fetch_all_filtered, get_metadata, tracker_connection
from services.tracker_service import TrackerValidationError, build_column_meta, get_tracker_page, save_tracker_cell

tracker_api_bp = Blueprint('tracker_api', __name__, url_prefix='/api/tracker')


def _int_arg(name, default):
    try:
        return int(request.args.get(name, default))
    except (TypeError, ValueError):
        return default


def _filters_arg():
    try:
        value = json.loads(request.args.get('filters', '{}'))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _current_username():
    return (
        session.get('user_name') or session.get('username') or
        session.get('user_email') or session.get('email') or 'AuditX'
    )


@tracker_api_bp.get('/health')
def tracker_health():
    try:
        with tracker_connection() as conn:
            meta = get_metadata(conn)
        return jsonify(ok=True, **meta, column_meta=build_column_meta(meta['columns']))
    except Exception as exc:
        return jsonify(ok=False, message=str(exc)), 500


@tracker_api_bp.get('/data')
def tracker_data():
    page = max(1, _int_arg('page', 1))
    page_size = max(1, min(_int_arg('page_size', DEFAULT_PAGE_SIZE), MAX_PAGE_SIZE))
    try:
        data = get_tracker_page(
            page=page,
            page_size=page_size,
            filters=_filters_arg(),
            sort_column=request.args.get('sort_column') or None,
            sort_direction=request.args.get('sort_direction', 'ASC'),
        )
        return jsonify(ok=True, **data)
    except Exception as exc:
        return jsonify(ok=False, title='No se pudo cargar Tracker', message=str(exc)), 500


@tracker_api_bp.patch('/<tracker_key>')
def tracker_update_cell(tracker_key):
    payload = request.get_json(silent=True) or {}
    field = str(payload.get('field', '')).strip()
    value = payload.get('value')
    if not field:
        return jsonify(ok=False, title='No se puede guardar el cambio', message='No se recibió el campo a actualizar.'), 400
    try:
        result = save_tracker_cell(
            tracker_key=tracker_key,
            field=field,
            value=value,
            changed_by=_current_username(),
        )
        return jsonify(ok=True, message='Cambio guardado.', **result)
    except TrackerValidationError as exc:
        return jsonify(ok=False, validation=True, title=exc.title, message=str(exc), field=exc.field or field, value=exc.value), 400
    except Exception as exc:
        return jsonify(
            ok=False,
            title='No fue posible guardar el cambio',
            message='SQL Server no pudo actualizar el registro. El valor anterior se conservará.',
            technical_detail=str(exc),
        ), 500


@tracker_api_bp.get('/export')
def tracker_export():
    try:
        from openpyxl import Workbook
        data = fetch_all_filtered(
            filters=_filters_arg(),
            sort_column=request.args.get('sort_column') or None,
            sort_direction=request.args.get('sort_direction', 'ASC'),
            max_rows=EXPORT_MAX_ROWS,
        )
        wb = Workbook(write_only=True)
        ws = wb.create_sheet('Tracker')
        ws.append(data['columns'])
        for row in data['rows']:
            ws.append(row)
        buff = io.BytesIO()
        wb.save(buff)
        buff.seek(0)
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        return send_file(
            buff,
            as_attachment=True,
            download_name=f'Tracker_{stamp}.xlsx',
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        )
    except ImportError:
        return jsonify(ok=False, title='Export Excel no disponible', message='Instala openpyxl: pip install openpyxl'), 500
    except Exception as exc:
        return jsonify(ok=False, title='No se pudo exportar Tracker', message=str(exc)), 500
