AUDITX TRACKER INLINE V1
========================

Esta V1 convierte Tracker en un Datasheet web estilo Access:
- tabla por cliente;
- tracker_key como llave única;
- paginación real SQL (25/50/100);
- filtros por columna;
- contador total real;
- ordenamiento;
- Configure View;
- Export Excel;
- edición directa en celda;
- guardado inmediato en SQL;
- modal propio de AuditX para errores/validaciones;
- NO usa alert() del navegador;
- NO usa modal para editar una fila;
- NO usa doble clic.

COPIA
-----
Copia cada carpeta del ZIP sobre la raíz de AuditX respetando rutas.
Luego aplica PATCH_MAIN_PY.txt.

PRIMERA PRUEBA
--------------
1. Detén Flask con Ctrl+C y vuelve a iniciar main.py.
2. Abre:
   http://127.0.0.1:5000/api/tracker/health
3. Debe regresar ok=true y detectar una fuente con tracker_key.
4. Después abre:
   http://127.0.0.1:5000/tracker

FUENTE SQL
----------
Busca en este orden:
- TRACKER_SOURCE de .env
- dbo.Tracker
- dbo.tracker
- dbo.vw_Tracker
- dbo.Dyn_437_Tracker

Si conoces la tabla exacta agrega en .env:
TRACKER_SOURCE=dbo.NombreReal

Si lees de una view pero actualizas una tabla:
TRACKER_SOURCE=dbo.vw_Tracker
TRACKER_UPDATE_TARGET=dbo.Tracker

CONEXIÓN POR CLIENTE
--------------------
El repository intenta reutilizar:
- config.session.get_current_client_db()
- database.connection.get_tracker_connection()
- get_client_connection()
- get_connection()
- get_followup_connection()

Si tu conexión usa otro helper, cambia SOLO:
repositories/tracker_repository.py -> get_tracker_connection()

CAMPOS EDITABLES
----------------
Por seguridad, solo se editan los campos listados en:
config/tracker_config.py -> EDITABLE_FIELDS

Los demás aparecen de solo lectura.
tracker_key siempre queda protegido y puede estar oculto.

GUARDADO
--------
- date/select/checkbox: al cambiar.
- text/number: Enter o salir de la celda.
- Esc: restaura el valor anterior.
- si SQL rechaza: restaura el valor anterior y muestra modal.

MÁS DE 10,000 REGISTROS
-----------------------
No se cargan todos. Usa COUNT_BIG + OFFSET/FETCH en SQL Server.

REGLAS DE ACCESS
----------------
No inventé las reglas todavía.
Se agregan progresivamente en:
services/tracker_service.py -> validate_business_rules()

y combos/listas en:
config/tracker_config.py -> EDITABLE_FIELDS

Ejemplo futuro:
'task_status': {
    'type': 'select',
    'options': ['Sin iniciar', 'En proceso', 'Pendiente', 'Con claim']
}

Después podemos agregar combos dependientes, auto-poblado de User ID/user_name,
Massive Update, Import Template, Download Planner y el resto del Tracker de Access.

EXPORT EXCEL
------------
Requiere openpyxl:
pip install openpyxl
