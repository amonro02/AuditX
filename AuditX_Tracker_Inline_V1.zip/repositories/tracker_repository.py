from __future__ import annotations

import importlib
import inspect
import os
import re
from contextlib import contextmanager
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Dict, List, Optional, Sequence, Tuple

from config.tracker_config import (
    TRACKER_PRIMARY_KEY,
    TRACKER_SOURCE,
    TRACKER_SOURCE_CANDIDATES,
    TRACKER_UPDATE_TARGET,
)

_IDENTIFIER_RE = re.compile(r'^[A-Za-z0-9_ #ÁÉÍÓÚÜÑáéíóúüñ.-]+$')


def _quote_identifier(name: str) -> str:
    if not name or not _IDENTIFIER_RE.match(name):
        raise ValueError(f'Unsafe SQL identifier: {name!r}')
    return '[' + name.replace(']', ']]') + ']'


def _split_object_name(value: str) -> Tuple[str, str]:
    raw = (value or '').strip().replace('[', '').replace(']', '')
    parts = [p.strip() for p in raw.split('.') if p.strip()]
    if len(parts) == 1:
        return 'dbo', parts[0]
    if len(parts) == 2:
        return parts[0], parts[1]
    raise ValueError(f'Invalid SQL object name: {value!r}')


def _quote_object(value: str) -> str:
    schema, name = _split_object_name(value)
    return f'{_quote_identifier(schema)}.{_quote_identifier(name)}'


def _get_current_client_db():
    try:
        mod = importlib.import_module('config.session')
        fn = getattr(mod, 'get_current_client_db', None)
        if callable(fn):
            return fn()
    except Exception:
        pass
    return None


def _looks_like_connection(value: Any) -> bool:
    return value is not None and callable(getattr(value, 'cursor', None))


def _call_connection_factory(fn, current_db):
    try:
        sig = inspect.signature(fn)
    except Exception:
        sig = None

    if sig is not None:
        params = list(sig.parameters.values())
        required = [
            p for p in params
            if p.default is inspect._empty
            and p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
        ]
        if not required:
            try:
                return fn()
            except TypeError:
                pass

        if isinstance(current_db, dict):
            accepted = {k: v for k, v in current_db.items() if k in sig.parameters}
            if accepted:
                try:
                    return fn(**accepted)
                except TypeError:
                    pass

        if current_db is not None and not isinstance(current_db, dict):
            for key in ('database', 'db', 'database_name', 'client_db'):
                if key in sig.parameters:
                    try:
                        return fn(**{key: current_db})
                    except TypeError:
                        pass

        if current_db is not None:
            try:
                return fn(current_db)
            except TypeError:
                pass

    return fn()


def get_tracker_connection():
    '''Resolve the SQL Server connection for the CURRENT CLIENT.'''
    current_db = _get_current_client_db()

    if _looks_like_connection(current_db):
        return current_db

    if isinstance(current_db, dict):
        direct = current_db.get('connection')
        if _looks_like_connection(direct):
            return direct
        conn_str = current_db.get('connection_string') or current_db.get('odbc_connection_string')
        if conn_str:
            import pyodbc
            return pyodbc.connect(conn_str)

    explicit = os.getenv('TRACKER_ODBC_CONNECTION_STRING', '').strip()
    if explicit:
        import pyodbc
        return pyodbc.connect(explicit)

    try:
        db_module = importlib.import_module('database.connection')
    except Exception as exc:
        raise RuntimeError(
            'AuditX could not import database.connection. Tracker needs a client-scoped SQL connection.'
        ) from exc

    for name in (
        'get_tracker_connection',
        'get_client_connection',
        'get_connection',
        'get_followup_connection',
    ):
        fn = getattr(db_module, name, None)
        if not callable(fn):
            continue
        try:
            conn = _call_connection_factory(fn, current_db)
            if _looks_like_connection(conn):
                return conn
        except Exception:
            continue

    raise RuntimeError(
        'Tracker could not obtain a SQL connection for the current client. '
        'Adapt only get_tracker_connection() in repositories/tracker_repository.py.'
    )


@contextmanager
def tracker_connection():
    conn = get_tracker_connection()
    try:
        yield conn
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _json_value(value: Any):
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.isoformat(timespec='seconds')
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, Decimal):
        return format(value, 'f')
    if isinstance(value, bytes):
        return value.hex()
    return value


def _cursor_columns(cursor) -> List[str]:
    return [str(col[0]) for col in (cursor.description or [])]


def _resolve_actual_column(columns: Sequence[str], requested: str) -> Optional[str]:
    wanted = (requested or '').strip().lower()
    return next((col for col in columns if col.lower() == wanted), None)


def _candidate_sources() -> List[str]:
    result: List[str] = []
    if TRACKER_SOURCE:
        result.append(TRACKER_SOURCE)
    for item in TRACKER_SOURCE_CANDIDATES:
        if item and item.lower() not in {x.lower() for x in result}:
            result.append(item)
    return result


def resolve_source(conn) -> Tuple[str, List[str]]:
    last_error = None
    for source in _candidate_sources():
        try:
            cur = conn.cursor()
            cur.execute(f'SELECT TOP 0 * FROM {_quote_object(source)}')
            columns = _cursor_columns(cur)
            cur.close()
            if _resolve_actual_column(columns, TRACKER_PRIMARY_KEY):
                return source, columns
        except Exception as exc:
            last_error = exc
    details = f' Last SQL error: {last_error}' if last_error else ''
    raise RuntimeError(
        f'No Tracker source was found with primary key {TRACKER_PRIMARY_KEY!r}. '
        f'Configure TRACKER_SOURCE in .env.{details}'
    )


def resolve_update_target(source: str) -> str:
    return TRACKER_UPDATE_TARGET or source


def get_metadata(conn) -> Dict[str, Any]:
    source, columns = resolve_source(conn)
    key = _resolve_actual_column(columns, TRACKER_PRIMARY_KEY)
    return {
        'source': source,
        'update_target': resolve_update_target(source),
        'columns': columns,
        'primary_key': key,
    }


def _build_where(columns: Sequence[str], filters: Dict[str, Any]):
    clauses, params = [], []
    for requested, raw in (filters or {}).items():
        value = '' if raw is None else str(raw).strip()
        if not value:
            continue
        actual = _resolve_actual_column(columns, requested)
        if not actual:
            continue
        clauses.append(f'CONVERT(NVARCHAR(4000), {_quote_identifier(actual)}) LIKE ?')
        params.append(f'%{value}%')
    return ((' WHERE ' + ' AND '.join(clauses)) if clauses else ''), params


def fetch_page(*, page: int, page_size: int, filters: Dict[str, Any], sort_column=None, sort_direction='ASC'):
    with tracker_connection() as conn:
        meta = get_metadata(conn)
        source, columns, key = meta['source'], meta['columns'], meta['primary_key']
        actual_sort = _resolve_actual_column(columns, sort_column or '') or key
        direction = 'DESC' if str(sort_direction).upper() == 'DESC' else 'ASC'
        where_sql, filter_params = _build_where(columns, filters)
        cur = conn.cursor()
        cur.execute(f'SELECT COUNT_BIG(*) FROM {_quote_object(source)}{where_sql}', filter_params)
        total_rows = int(cur.fetchone()[0] or 0)
        total_pages = max(1, (total_rows + page_size - 1) // page_size)
        page = max(1, min(page, total_pages))
        offset = (page - 1) * page_size
        sql = (
            f'SELECT * FROM {_quote_object(source)}{where_sql} '
            f'ORDER BY {_quote_identifier(actual_sort)} {direction} '
            f'OFFSET ? ROWS FETCH NEXT ? ROWS ONLY'
        )
        cur.execute(sql, [*filter_params, offset, page_size])
        result_columns = _cursor_columns(cur)
        rows = [
            {result_columns[i]: _json_value(row[i]) for i in range(len(result_columns))}
            for row in cur.fetchall()
        ]
        cur.close()
        return {
            'source': source,
            'primary_key': key,
            'columns': result_columns,
            'rows': rows,
            'page': page,
            'page_size': page_size,
            'total_rows': total_rows,
            'total_pages': total_pages,
            'sort_column': actual_sort,
            'sort_direction': direction,
        }


def fetch_record(tracker_key: Any):
    with tracker_connection() as conn:
        meta = get_metadata(conn)
        cur = conn.cursor()
        cur.execute(
            f'SELECT TOP 1 * FROM {_quote_object(meta["source"])} '
            f'WHERE {_quote_identifier(meta["primary_key"])} = ?',
            tracker_key,
        )
        row = cur.fetchone()
        if not row:
            cur.close()
            return None
        columns = _cursor_columns(cur)
        data = {columns[i]: _json_value(row[i]) for i in range(len(columns))}
        cur.close()
        return data


def update_field(tracker_key: Any, field: str, value: Any, *, changed_by=''):
    with tracker_connection() as conn:
        meta = get_metadata(conn)
        columns = meta['columns']
        actual_field = _resolve_actual_column(columns, field)
        if not actual_field:
            raise KeyError(f'Column {field!r} does not exist in Tracker.')

        set_parts = [f'{_quote_identifier(actual_field)} = ?']
        params: List[Any] = [value]

        changed_on = next((_resolve_actual_column(columns, x) for x in ('Changed On', 'ChangedOn', 'changed_on') if _resolve_actual_column(columns, x)), None)
        changed_by_col = next((_resolve_actual_column(columns, x) for x in ('Changed By', 'ChangedBy', 'changed_by') if _resolve_actual_column(columns, x)), None)

        if changed_on and changed_on.lower() != actual_field.lower():
            set_parts.append(f'{_quote_identifier(changed_on)} = GETDATE()')
        if changed_by_col and changed_by_col.lower() != actual_field.lower():
            set_parts.append(f'{_quote_identifier(changed_by_col)} = ?')
            params.append(changed_by or 'AuditX')

        params.append(tracker_key)
        sql = (
            f'UPDATE {_quote_object(meta["update_target"])} '
            f'SET {", ".join(set_parts)} '
            f'WHERE {_quote_identifier(meta["primary_key"])} = ?'
        )
        cur = conn.cursor()
        try:
            cur.execute(sql, params)
            if cur.rowcount == 0:
                conn.rollback()
                raise LookupError(f'Tracker record {tracker_key!r} was not found.')
            conn.commit()
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
        finally:
            try:
                cur.close()
            except Exception:
                pass

    record = fetch_record(tracker_key)
    return {
        'tracker_key': tracker_key,
        'field': actual_field,
        'value': None if not record else record.get(actual_field),
        'record': record,
    }


def fetch_all_filtered(*, filters, sort_column=None, sort_direction='ASC', max_rows=100_000):
    with tracker_connection() as conn:
        meta = get_metadata(conn)
        columns, key = meta['columns'], meta['primary_key']
        actual_sort = _resolve_actual_column(columns, sort_column or '') or key
        direction = 'DESC' if str(sort_direction).upper() == 'DESC' else 'ASC'
        where_sql, params = _build_where(columns, filters)
        cur = conn.cursor()
        cur.execute(
            f'SELECT TOP {int(max_rows)} * FROM {_quote_object(meta["source"])}{where_sql} '
            f'ORDER BY {_quote_identifier(actual_sort)} {direction}',
            params,
        )
        result_columns = _cursor_columns(cur)
        rows = [[_json_value(row[i]) for i in range(len(result_columns))] for row in cur.fetchall()]
        cur.close()
        return {'columns': result_columns, 'rows': rows, 'source': meta['source']}
