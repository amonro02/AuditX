import getpass
import json
import os
import subprocess

from flask import (
    Blueprint,
    abort,
    jsonify,
    render_template,
    request,
    session,
)

from config.planning_entities import PLANNING_ENTITIES
from repositories.planning_repository import (
    create_planning_record,
    delete_planning_record,
    get_planning_data,
    get_planning_entity_config,
    get_planning_lookup,
    get_planning_record,
    update_planning_record,
)

print(">>>>>>>>>>> planing rout.py cargado")

planning_bp = Blueprint(
    "planning",
    __name__,
)


def _normalize_user(value):
    if not value:
        return None

    value = str(value).strip()

    if not value:
        return None

    if "\\" in value:
        value = value.split("\\")[-1]

    if "@" in value:
        value = value.split("@")[0]

    return value.strip() or None


def get_current_audit_username():
    override = _normalize_user(
        os.getenv("AUDITX_USER_OVERRIDE")
    )

    if override:
        return override

    candidates = [
        request.environ.get("REMOTE_USER"),
        request.headers.get("X-Remote-User"),
        request.headers.get("Remote-User"),
        request.headers.get("X-Forwarded-User"),
        request.headers.get("X-MS-CLIENT-PRINCIPAL-NAME"),
        session.get("network_username"),
        session.get("sam_account_name"),
        session.get("user_login"),
        session.get("login"),
    ]

    for candidate in candidates:
        user = _normalize_user(candidate)
        if user:
            return user

    try:
        whoami = subprocess.check_output(
            ["whoami"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()

        user = _normalize_user(whoami)

        if user:
            return user
    except Exception:
        pass

    for key in (
        "username",
        "user_name",
        "user",
        "userKey",
        "user_key",
    ):
        user = _normalize_user(
            session.get(key)
        )

        if user:
            return user

    return _normalize_user(
        getpass.getuser()
    ) or "AuditX"


@planning_bp.route(
    "/planning/<entity>",
    methods=["GET"],
)
def planning_catalog(entity):
    config = PLANNING_ENTITIES.get(entity)

    if not config:
        abort(404)

    title = config.get(
        "title",
        entity,
    )

    return render_template(
        "pages/catalog.html",
        current_module=title,
        table_title=title,
        entity=entity,
    )


@planning_bp.route(
    "/api/planning/<entity>",
    methods=["GET"],
)
def api_planning(entity):
    top = request.args.get("top")
    page = request.args.get("page")
    page_size = request.args.get("page_size")
    sort_column = request.args.get("sort_column")
    sort_direction = request.args.get("sort_direction")
    quick_filter_column = request.args.get("quick_filter_column")
    quick_filter_text = request.args.get("quick_filter_text")

    filters = {}
    raw_filters = request.args.get("filters")
    if raw_filters:
        try:
            decoded = json.loads(raw_filters)
            if isinstance(decoded, dict):
                filters = decoded
        except (TypeError, ValueError, json.JSONDecodeError):
            filters = {}

    result = get_planning_data(
        entity,
        top=top,
        page=page,
        page_size=page_size,
        filters=filters,
        sort_column=sort_column,
        sort_direction=sort_direction,
        quick_filter_column=quick_filter_column,
        quick_filter_text=quick_filter_text,
    )

    status = 200 if result.get("ok") else 400
    response = jsonify(result)
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    return response, status


@planning_bp.route(
    "/api/planning/<entity>/<int:key>",
    methods=["GET"],
)
def api_get_planning_record(entity, key):
    result = get_planning_record(
        entity,
        key,
    )

    status = 200 if result.get("ok") else 400

    return jsonify(result), status


@planning_bp.route(
    "/api/planning/config/<entity>",
    methods=["GET"],
)
def api_planning_config(entity):
    result = get_planning_entity_config(
        entity
    )

    status = 200 if result.get("ok") else 404

    return jsonify(result), status


@planning_bp.route(
    "/api/planning/lookup/<lookup_name>",
    methods=["GET"],
)
def api_planning_lookup(lookup_name):
    parent_value = request.args.get(
        "parent_value"
    )

    result = get_planning_lookup(
        lookup_name,
        parent_value=parent_value,
    )

    status = 200 if result.get("ok") else 400

    return jsonify(result), status


@planning_bp.route(
    "/api/planning/<entity>",
    methods=["POST"],
)
def api_create_planning(entity):
    data = request.get_json(
        silent=True
    ) or {}

    values = data.get(
        "values",
        {},
    )

    added_by = get_current_audit_username()

    result = create_planning_record(
        entity=entity,
        values=values,
        added_by=added_by,
    )

    status = 200 if result.get("ok") else 400

    return jsonify(result), status


@planning_bp.route(
    "/api/planning/<entity>/<int:key>",
    methods=["PUT"],
)
def api_update_planning(entity, key):
    data = request.get_json(
        silent=True
    ) or {}

    values = data.get(
        "values",
        {},
    )

    changed_by = get_current_audit_username()

    result = update_planning_record(
        entity=entity,
        key=key,
        values=values,
        changed_by=changed_by,
    )

    status = 200 if result.get("ok") else 400

    return jsonify(result), status




@planning_bp.route(
    "/api/planning/<entity>/<int:key>",
    methods=["DELETE"],
)
def api_delete_planning(entity, key):
    changed_by = get_current_audit_username()

    result = delete_planning_record(
        entity=entity,
        key=key,
        changed_by=changed_by,
    )

    status = 200 if result.get("ok") else 400

    return jsonify(result), status


@planning_bp.route(
    "/api/planning/whoami",
    methods=["GET"],
)
def api_planning_whoami():
    return jsonify({
        "ok": True,
        "user": get_current_audit_username(),
    })

# ============================================================
# v12 - HR/Users alias + Audit Project Planning Duplicate
# ============================================================
from repositories.planning_repository import (
    duplicate_audit_project_planning,
    get_duplicate_projects,
)


@planning_bp.route("/planning/hr/users", methods=["GET"])
def planning_hr_users():
    return render_template(
        "pages/planning_users.html",
        current_module="Users",
        table_title="Users",
        entity="users",
    )


@planning_bp.route("/planning/audit-project-planning/duplicate", methods=["GET"])
def planning_audit_project_planning_duplicate():
    return render_template(
        "pages/planning_duplicate.html",
        current_module="Audit Project Planning",
        table_title="Duplicate Audit Project Planning",
        entity="audit-project-planning",
    )


@planning_bp.route("/api/planning/duplicate/projects", methods=["GET"])
def api_planning_duplicate_projects():
    client_key = request.args.get("client_key")
    if not client_key:
        return jsonify({"ok": False, "message": "Client is required.", "items": []}), 400

    result = get_duplicate_projects(client_key)
    response = jsonify(result)
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    return response, (200 if result.get("ok") else 400)


@planning_bp.route("/api/planning/audit-project-planning/duplicate", methods=["POST"])
def api_duplicate_audit_project_planning():
    data = request.get_json(silent=True) or {}
    rows = data.get("rows") or []

    if not rows:
        return jsonify({"ok": False, "message": "Select at least one Audit Project."}), 400

    result = duplicate_audit_project_planning(
        rows=rows,
        changed_by=get_current_audit_username(),
    )
    return jsonify(result), 200
