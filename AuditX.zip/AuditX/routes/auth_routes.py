
"""

    Módulo: session
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:
            Gestiona el flujo de autenticación de usuarios, incluyendo inicio de sesión, validación de credenciales, configuración
            y verificación de doble factor (2FA), manejo de sesiones y cierre de sesión.

            login() → muestra la pantalla de inicio de sesión.
            api_login_email() → valida el correo del usuario e inicia el flujo de autenticación.
            two_factor_setup() / api_2fa_setup() → configura el segundo factor.
            api_2fa_verify_setup() → valida la activación del 2FA.
            login_verify() → valida el código 2FA durante el acceso.
            login_required() → protege rutas que requieren usuario autenticado.
            logout() → limpia la sesión del usuario.
            dashboard() → controla el acceso al área principal.

"""


from functools import wraps
from repositories.user_repository import get_user_by_email
from flask import (
    Blueprint,
    render_template,
    request,
    jsonify,
    session,
    redirect,
    url_for
) 
from services.auth_service import (
    validate_login_email,
    generate_2fa_setup,
    verify_totp,
    verify_login_2fa,
)
from repositories.user_repository import (   
    save_user_2fa
)

auth_bp = Blueprint("auth", __name__)
 
 
def login_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("auth.login"))
 
        return view(*args, **kwargs)
 
    return wrapped_view
 
 
@auth_bp.route("/")
def root():
    return redirect(url_for("auth.login"))
 
 
@auth_bp.route("/2fa/login", endpoint="two_factor_login")
def two_factor_login():
    if not session.get("pending_2fa_email"):
        return redirect(url_for("auth.login"))
 
    return render_template("2fa_login.html")
 
 
@auth_bp.route("/api/login-email", methods=["POST"])
def api_login_email():
    try:
        data = request.get_json(silent=True) or {}
        email = (data.get("email") or "").strip().lower()
 
        if not email:
            return jsonify({
                "success": False,
                "message": "Enter your email."
            }), 400
 
        user = validate_login_email(email)
 
        if not user:
            return jsonify({
                "success": False,
                "message": "User not found or inactive."
            }), 401
 
        #Soporta dict o pyodbc.Row
        def get_value(obj, key, index=None):
            if isinstance(obj, dict):
                return obj.get(key)
            if hasattr(obj, key):
                return getattr(obj, key)
            if index is not None:
                try:
                    return obj[index]
                except Exception:
                    return None
            return None
 
        user_id = get_value(user, "UserID", 0)
        user_email = get_value(user, "Email", 1)
        two_factor_enabled = get_value(user, "TwoFactorEnabled", 6)
 
        session.clear()
        session["pending_2fa_email"] = user_email or email
        session["pending_2fa_user_id"] = user_id
 
        if two_factor_enabled:
            return jsonify({
                "success": True,
                "redirect": url_for("auth.two_factor_login")
            })
 
        return jsonify({
            "success": True,
            "redirect": url_for("auth.two_factor_setup")
        })
 
    except Exception as e:
        print("ERROR api_login_email:", repr(e))
        return jsonify({
            "success": False,
            "message": "Server error"
        }), 500
 
 
@auth_bp.route("/verify_2fa")
def verify_2fa_alias():
    return redirect(url_for("auth.two_factor_login"))

@auth_bp.route("/2fa/setup")
def two_factor_setup():
    if "pending_2fa_email" not in session:
        return redirect(url_for("auth.login"))
 
    return render_template("2fa_setup.html")
 
 
@auth_bp.route("/api/2fa/setup", methods=["GET"])
def api_2fa_setup():
    email = session.get("pending_2fa_email")
 
    if not email:
        return jsonify({
            "success": False,
            "message": "Session expired. Please login again."
        }), 401
 
    setup = generate_2fa_setup(email)
 
    session["pending_2fa_secret"] = setup["secret"]
 
    return jsonify({
        "success": True,
        "qr_code": setup["qr_code"]
    })
 
 
@auth_bp.route("/api/2fa/verify-setup", methods=["POST"])
def api_2fa_verify_setup():
    try:
        data = request.get_json(silent=True) or {}
        code = (data.get("code") or "").strip()
 
        email = session.get("pending_2fa_email")
        secret = session.get("pending_2fa_secret")
 
        if not email or not secret:
            return jsonify({
                "success": False,
                "redirect": url_for("auth.login"),
                "message": "Session expired"
            }), 401
 
        import pyotp
        totp = pyotp.TOTP(secret)
 
        if not totp.verify(code, valid_window=1):
            return jsonify({
                "success": False,
                "message": "Invalid verification code"
            }), 400
 
        #LOGIN DIRECTO SIN DB
        session.clear()
        session["user_id"] = 1
        session["user_email"] = email
        session["user_name"] = "Armando"
        session["user_role"] = "Admin"
 
        return jsonify({
            "success": True,
            "redirect": "/home"
        })
 
    except Exception as e:
        print("ERROR 2FA:", e)
        return jsonify({
            "success": False,
            "message": "Server error verifying 2FA"
        }), 500
    
 
@auth_bp.route("/api/2fa/login-verify", methods=["POST"])
def login_verify():
 
    email = session.get("pending_2fa_email")
 
    if not email:
        return jsonify({
            "success": False,
            "redirect": "/login",
            "message": "Session expired"
        }), 401
 
    data = request.get_json()
    code = data.get("code")
 
    user = get_user_by_email(email)  
 
    if not user:
        return jsonify({
            "success": False,
            "redirect": "/login"
        }), 401
 
    if not verify_totp(user, code):
        return jsonify({
            "success": False,
            "message": "Invalid code"
        }), 401
 
    session.clear()
 
    session["user_id"] = user["UserID"]
    session["user_email"] = user["Email"]
    session["user_name"] = user["FullName"]
    session["user_role"] = user["Role"]
 
    return jsonify({
        "success": True,
        "redirect": "/home"
    })
 
 
@auth_bp.route("/home")
def dashboard():
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
 
    return render_template(
            "pages/coming_soon.html",
            current_module="Home"
        )

@auth_bp.route("/login", endpoint="login")
def login():
    return render_template("login.html")
 
@auth_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))