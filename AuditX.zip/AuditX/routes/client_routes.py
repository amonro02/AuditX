
"""

    Módulo: session
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:
            Gestiona el flujo de autenticación de usuarios, incluyendo inicio de sesión, validación de credenciales, configuración
            y verificación de doble factor (2FA), manejo de sesiones y cierre de sesión.

            login() → muestra la pantalla de inicio de sesión.
            api_login_email() → valida el correo del usuario e inicia el flujo de autenticación.
            two_factor_setup() / api_2fa_setup() → configura el segundo factor.
            api_2fa_verify_setup() → valida la activación del 2FA.
            login_verify() → valida el código 2FA durante el acceso.
            login_required() → protege rutas que requieren usuario autenticado.
            logout() → limpia la sesión del usuario.
            dashboard() → controla el acceso al área principal.

"""

from flask import Blueprint, jsonify, request, session
from repositories.client_repository import (
    get_clients_by_user,
    get_client_for_user,
    get_last_selected_client,
    mark_client_as_selected
)
 
client_bp = Blueprint("client_bp", __name__)
 
 
def get_session_user_key():
    return session.get("user_key") or session.get("user_id")
 
 
@client_bp.route("/api/clients", methods=["GET"])
def api_get_clients():
    try:
        user_key = get_session_user_key()
 
        if not user_key:
            return jsonify({
                "success": False,
                "message": "User not authenticated"
            }), 401
 
        clients = get_clients_by_user(user_key)
 
        return jsonify({
            "success": True,
            "clients": clients,
            "currentClient": {
                "clientKey": session.get("client_key"),
                "clientName": session.get("client_name")
            } if session.get("client_key") else None
        })
 
    except Exception as e:
        print("ERROR /api/clients:", str(e))
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500
 
 
@client_bp.route("/api/clients/current", methods=["GET"])
def api_get_current_client():
    try:
        user_key = get_session_user_key()
 
        if not user_key:
            return jsonify({
                "success": False,
                "message": "User not authenticated"
            }), 401
 
        if session.get("client_key"):
            return jsonify({
                "success": True,
                "client": {
                    "clientKey": session.get("client_key"),
                    "clientName": session.get("client_name")
                }
            })
 
        client = get_last_selected_client(user_key)
 
        if not client:
            return jsonify({
                "success": True,
                "client": None
            })
 
        session["client_key"] = client.get("clientKey")
        session["client_name"] = client.get("clientName")
        session["client_sql_server"] = client.get("sqlServer")
        session["client_sql_database"] = client.get("sqlDatabase")
 
        return jsonify({
            "success": True,
            "client": {
                "clientKey": client.get("clientKey"),
                "clientName": client.get("clientName")
            }
        })
 
    except Exception as e:
        print("ERROR /api/clients/current:", str(e))
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500
 
 
@client_bp.route("/api/clients/select", methods=["POST"])
def api_select_client():
    try:
        user_key = get_session_user_key()
        data = request.get_json(silent=True) or {}
 
        client_key = data.get("clientKey")
 
        if not user_key:
            return jsonify({
                "success": False,
                "message": "User not authenticated"
            }), 401
 
        if not client_key:
            return jsonify({
                "success": False,
                "message": "ClientKey is required"
            }), 400
 
        client = get_client_for_user(user_key, client_key)
 
        if not client:
            return jsonify({
                "success": False,
                "message": f"Client not found or not allowed: {client_key}"
            }), 404
 
        mark_client_as_selected(user_key, client_key)
 
        session["client_key"] = client.get("clientKey")
        session["client_name"] = client.get("clientName")
        session["client_sql_server"] = client.get("sqlServer")
        session["client_sql_database"] = client.get("sqlDatabase")
 
        return jsonify({
            "success": True,
            "message": "Client selected",
            "client": {
                "clientKey": client.get("clientKey"),
                "clientName": client.get("clientName")
            }
        })
 
    except Exception as e:
        print("ERROR /api/clients/select:", str(e))
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500