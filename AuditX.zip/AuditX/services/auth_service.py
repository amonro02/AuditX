"""

    Módulo: auth_service
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:
         Gestiona la lógica de autenticación de usuarios, incluyendo validación de acceso, configuración y verificación de doble
         factor (2FA), generación de códigos QR, validación de tokens y control de intentos fallidos de inicio de sesión.

            validate_login_email() → valida si el usuario puede iniciar sesión.
            generate_2fa_setup() → genera la clave secreta y el código QR para configurar 2FA.
            verify_totp() → valida códigos temporales generados por la aplicación autenticadora.
            activate_user_2fa() → activa el segundo factor después de verificarlo.
            verify_login_2fa() → valida el código 2FA durante el inicio de sesión.
            is_user_locked() → valida si el usuario está bloqueado temporalmente.
            register_failed_attempt() / reset_attempts() → gestionan intentos fallidos y reinicio del contador.

"""

import base64
from datetime import datetime, timedelta
 
import io
import base64
import pyotp
import qrcode
 
 
from repositories.user_repository import (
    get_user_by_email,
    save_user_2fa,
    update_user_attempts,
    reset_user_attempts,
)
 
 
APP_NAME = "AuditX"
 
 
def validate_login_email(email):
    if not email:
        return {
            "success": False,
            "message": "Email is required."
        }
 
    user = get_user_by_email(email)
 
    if not user:
        return {
            "success": False,
            "message": "User not found."
        }
 
    if not user["IsActive"]:
        return {
            "success": False,
            "message": "User is inactive."
        }
 
     #Bloqueo preparado, pero desactivado por ahora.
    if is_user_locked(user):
        return {
             "success": False,
             "message": "User is temporarily locked."
         }
 
    if not user["TwoFactorEnabled"]:
        return {
            "success": True,
            "requires_2fa_setup": True,
            "requires_2fa_login": False,
            "user": user,
        }
 
    return {
        "success": True,
        "requires_2fa_setup": False,
        "requires_2fa_login": True,
        "user": user,
    }
 
 
def generate_2fa_setup(email):
    secret = pyotp.random_base32()
 
    issuer = APP_NAME
    uri = pyotp.totp.TOTP(secret).provisioning_uri(
        name=email,
        issuer_name=issuer
    )
 
    img = qrcode.make(uri)
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
 
    qr_base64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
 
    return {
        "secret": secret,
        "qr_code": f"data:image/png;base64,{qr_base64}"
    }
 
 
def verify_totp(secret, code):
    if not secret or not code:
        return False
 
    totp = pyotp.TOTP(secret)
 
    return totp.verify(
        str(code).strip(),
        valid_window=1
    )
 
 
 
def activate_user_2fa(email, secret, code):
    is_valid = verify_totp(secret, code)
 
    if not is_valid:
        return {
            "success": False,
            "message": "Invalid verification code."
        }
 
    save_user_2fa(email, secret)
 
    return {
        "success": True,
        "message": "Two-factor authentication enabled."
    }
 
 
def verify_login_2fa(email, code):
    user = get_user_by_email(email)
 
    if not user:
        return {
            "success": False,
            "message": "User not found."
        }
 
    secret = user["TwoFactorSecret"]
 
    is_valid = verify_totp(secret, code)
 
    if not is_valid:
         #Bloqueo preparado, desactivado por ahora.
         register_failed_attempt(user)
 
         return {
            "success": False,
            "message": "Invalid verification code."
        }
 
    #Bloqueo preparado, desactivado por ahora.
    reset_attempts(user)
 
    return {
        "success": True,
        "user": user,
    }
 
 
def is_user_locked(user):
    locked_until = user.get("LockedUntil")
 
    if not locked_until:
        return False
 
    return datetime.now() < locked_until
 
 
def register_failed_attempt(user):
    attempts = int(user.get("FailedAttempts") or 0) + 1
    locked_until = None
 
    if attempts >= 5:
        locked_until = datetime.now() + timedelta(minutes=15)
 
    update_user_attempts(
        user["Email"],
        attempts,
        locked_until
    )
 
 
def reset_attempts(user):
    reset_user_attempts(user["Email"])