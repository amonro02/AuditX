"""

    Módulo: login_service
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:
         Gestiona la validación de información básica del usuario, verificando la existencia del correo electrónico y coordinando 
         la consulta mediante el repositorio correspondiente.

        validate_user_email():
                Limpia y normaliza el correo recibido.
                Valida que exista un correo informado.
                Consulta el usuario mediante login_repository.
                Devuelve una respuesta estructurada indicando éxito o error.

"""
from repositories.login_repository import find_user_by_email
 
 
def validate_user_email(email: str):
    email = (email or "").strip()
 
    if not email:
        return {
            "ok": False,
            "message": "Please enter an email."
        }
 
    user = find_user_by_email(email)
 
    if not user:
        return {
            "ok": False,
            "message": "User does not exist."
        }
 
    return {
        "ok": True,
        "user": user
    }