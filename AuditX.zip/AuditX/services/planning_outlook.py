"""
planning_outlook.py
-------------------
Outlook notification helper for AuditX / Planning.

Modes controlled by .env:

    OUTLOOK_AUTO_SEND=false
    OUTLOOK_OPEN_DRAFT=false

Behavior:
    AUTO_SEND=true
        -> sends the Outlook message immediately.

    AUTO_SEND=false + OPEN_DRAFT=false
        -> saves the message silently in Outlook Drafts.

    AUTO_SEND=false + OPEN_DRAFT=true
        -> saves the message in Drafts and opens it for review.

The Planning transaction is NOT rolled back if Outlook is unavailable.
The caller receives a warning and can show it in the UI.

Expected project dependency:
    database.connection.get_planning_connection

Requires on Windows:
    pip install pywin32 python-dotenv
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from html import escape
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    load_dotenv = None

try:
    import win32com.client  # type: ignore
except ImportError:  # pragma: no cover
    win32com = None

try:
    import pythoncom  # type: ignore
except ImportError:  # pragma: no cover
    pythoncom = None

try:
    # Import the connection directly to avoid a circular import when
    # planning_repository imports this module after a save/duplicate.
    from database.connection import get_planning_connection
except ImportError:  # pragma: no cover
    get_planning_connection = None


if load_dotenv:
    load_dotenv()


# ============================================================
# Configuration
# ============================================================

OUTLOOK_ENABLED = os.getenv("OUTLOOK_ENABLED", "true")
OUTLOOK_AUTO_SEND = os.getenv("OUTLOOK_AUTO_SEND", "false")
OUTLOOK_OPEN_DRAFT = os.getenv("OUTLOOK_OPEN_DRAFT", "false")
OUTLOOK_LOG_FILE = os.getenv("OUTLOOK_LOG_FILE", "logs/planning_outlook.log").strip()

# Optional sender/account selector. Leave blank to use the default Outlook account.
OUTLOOK_SEND_FROM = os.getenv("OUTLOOK_SEND_FROM", "").strip()

# Optional test override.
# If populated, every message goes ONLY to this address and CC is cleared.
# Example:
#   OUTLOOK_TEST_RECIPIENT=armando@company.com
OUTLOOK_TEST_RECIPIENT = os.getenv("OUTLOOK_TEST_RECIPIENT", "").strip()


def _env_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().lower() in {
        "1",
        "true",
        "yes",
        "y",
        "on",
        "enabled",
    }


def _auto_send_enabled() -> bool:
    return _env_bool(os.getenv("OUTLOOK_AUTO_SEND", OUTLOOK_AUTO_SEND), False)


def _outlook_enabled() -> bool:
    return _env_bool(os.getenv("OUTLOOK_ENABLED", OUTLOOK_ENABLED), True)


def _open_draft_enabled() -> bool:
    return _env_bool(os.getenv("OUTLOOK_OPEN_DRAFT", OUTLOOK_OPEN_DRAFT), False)


def _log_outlook(message: str) -> None:
    """Best-effort local diagnostic log. Never blocks Planning SQL work."""
    try:
        path = os.getenv("OUTLOOK_LOG_FILE", OUTLOOK_LOG_FILE).strip() or "logs/planning_outlook.log"
        folder = os.path.dirname(path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        from datetime import datetime as _dt
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(f"{_dt.now().isoformat(timespec='seconds')} | {message}\n")
    except Exception:
        pass


# ============================================================
# Result model
# ============================================================

@dataclass
class OutlookResult:
    ok: bool
    email_mode: str
    sent: bool = False
    draft: bool = False
    opened: bool = False
    to: Optional[List[str]] = None
    cc: Optional[List[str]] = None
    subject: str = ""
    warning: str = ""
    message: str = ""

    def as_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok,
            "email_mode": self.email_mode,
            "sent": self.sent,
            "draft": self.draft,
            "opened": self.opened,
            "to": self.to or [],
            "cc": self.cc or [],
            "subject": self.subject,
            "warning": self.warning,
            "message": self.message,
        }


# ============================================================
# General helpers
# ============================================================

def _clean_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _dedupe_emails(values: Iterable[Any]) -> List[str]:
    result: List[str] = []
    seen = set()

    for value in values:
        email = _clean_text(value)
        if not email:
            continue

        pieces = email.replace(",", ";").replace("|", ";").split(";")

        for piece in pieces:
            addr = piece.strip()
            if not addr:
                continue

            key = addr.lower()
            if key in seen:
                continue

            seen.add(key)
            result.append(addr)

    return result


def _row_to_dict(cursor, row) -> Dict[str, Any]:
    columns = [col[0] for col in cursor.description]
    return dict(zip(columns, row))


def _first_present(data: Dict[str, Any], names: Sequence[str], default: Any = "") -> Any:
    lowered = {str(k).lower(): v for k, v in data.items()}

    for name in names:
        if name in data:
            return data[name]

        value = lowered.get(name.lower())
        if value is not None:
            return value

    return default


def _safe_close(cursor=None, conn=None) -> None:
    try:
        if cursor is not None:
            cursor.close()
    except Exception:
        pass

    try:
        if conn is not None:
            conn.close()
    except Exception:
        pass


# ============================================================
# Database helpers
# ============================================================

def _connection():
    if get_planning_connection is None:
        raise RuntimeError(
            "Could not import get_planning_connection from "
            "database.connection."
        )
    return get_planning_connection()


def _fetch_planning_record(planning_key: Any) -> Dict[str, Any]:
    if planning_key in (None, ""):
        return {}

    conn = None
    cursor = None

    try:
        conn = _connection()
        cursor = conn.cursor()

        candidates = [
            (
                "dbo.vw_AuditProjectPlanning",
                [
                    "audit_project_planning_key",
                    "AuditProjectPlanningID",
                    "Key",
                ],
            ),
            (
                "dbo.audit_project_planning",
                [
                    "audit_project_planning_key",
                ],
            ),
        ]

        for table_name, key_names in candidates:
            try:
                cursor.execute(f"SELECT TOP 0 * FROM {table_name}")
                columns = [col[0] for col in cursor.description]
            except Exception:
                continue

            available = {str(c).lower(): c for c in columns}
            key_column = None

            for candidate in key_names:
                if candidate.lower() in available:
                    key_column = available[candidate.lower()]
                    break

            if not key_column:
                continue

            try:
                cursor.execute(
                    f"SELECT TOP 1 * FROM {table_name} WHERE [{key_column}] = ?",
                    planning_key,
                )
                row = cursor.fetchone()
                if row:
                    return _row_to_dict(cursor, row)
            except Exception:
                continue

        return {}

    finally:
        _safe_close(cursor, conn)


def _fetch_user_emails_by_keys(user_keys: Sequence[Any]) -> List[str]:
    keys = [_clean_text(x) for x in user_keys if _clean_text(x)]
    if not keys:
        return []

    conn = None
    cursor = None
    emails: List[str] = []

    def collect(rows, columns):
        for row in rows:
            data = dict(zip(columns, row))
            emails.extend(
                _dedupe_emails([
                    _first_present(
                        data,
                        [
                            "User_Email", "user_email", "Email", "email",
                            "Responsible_Email", "AuditorEmail",
                        ],
                    )
                ])
            )

    try:
        conn = _connection()
        cursor = conn.cursor()

        csv_keys = ",".join(keys)

        # 1) Exact legacy Access source.
        try:
            cursor.execute("SELECT * FROM dbo.F_User(?)", csv_keys)
            rows = cursor.fetchall()
            columns = [col[0] for col in cursor.description]
            collect(rows, columns)
            if emails:
                return _dedupe_emails(emails)
        except Exception as exc:
            _log_outlook(f"F_User lookup failed: {exc}")

        placeholders = ",".join("?" for _ in keys)

        # 2) Web Planning user view (confirmed by the Users module).
        for table_name, key_candidates in [
            ("dbo.VW_User", ["Key", "user_key"]),
            ("dbo.vw_user_control", ["user_key", "Key"]),
            ("dbo.[user]", ["user_key", "Key"]),
        ]:
            try:
                cursor.execute(f"SELECT TOP 0 * FROM {table_name}")
                columns = [col[0] for col in cursor.description]
                lowered = {str(c).lower(): c for c in columns}
                key_col = next((lowered[k.lower()] for k in key_candidates if k.lower() in lowered), None)
                if not key_col:
                    continue

                cursor.execute(
                    f"SELECT * FROM {table_name} WHERE [{key_col}] IN ({placeholders})",
                    *keys,
                )
                rows = cursor.fetchall()
                columns = [col[0] for col in cursor.description]
                collect(rows, columns)
                if emails:
                    return _dedupe_emails(emails)
            except Exception as exc:
                _log_outlook(f"User email lookup failed in {table_name}: {exc}")

        return _dedupe_emails(emails)

    finally:
        _safe_close(cursor, conn)



def _fetch_copy_all_emails() -> List[str]:
    conn = None
    cursor = None
    emails: List[str] = []

    try:
        conn = _connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT *
            FROM dbo.vw_user_control
            WHERE type_of_user_key = 1
            """
        )

        rows = cursor.fetchall()
        columns = [col[0] for col in cursor.description]

        for row in rows:
            data = dict(zip(columns, row))
            emails.extend(
                _dedupe_emails(
                    [
                        _first_present(
                            data,
                            [
                                "User_Email",
                                "Email",
                                "Responsible_Email",
                            ],
                        )
                    ]
                )
            )

        return _dedupe_emails(emails)

    except Exception:
        return []

    finally:
        _safe_close(cursor, conn)


def _fetch_manager_copy_emails() -> List[str]:
    windows_user = os.getenv("USERNAME", "").strip()
    if not windows_user:
        return []

    conn = None
    cursor = None

    try:
        conn = _connection()
        cursor = conn.cursor()

        manager_id = None

        try:
            cursor.execute(
                """
                SELECT TOP 1 ManagerID
                FROM dbo.P_Auditors
                WHERE AuditorNetworkUserID = ?
                """,
                windows_user,
            )
            row = cursor.fetchone()
            if row:
                manager_id = row[0]
        except Exception:
            pass

        if manager_id in (None, "", 0, "0"):
            return []

        cursor.execute(
            """
            SELECT *
            FROM dbo.vw_user_control
            WHERE type_of_user_key = 2
              AND user_key = ?
            """,
            manager_id,
        )

        rows = cursor.fetchall()
        columns = [col[0] for col in cursor.description]

        emails: List[str] = []
        for row in rows:
            data = dict(zip(columns, row))
            emails.extend(
                _dedupe_emails(
                    [
                        _first_present(
                            data,
                            [
                                "Responsible_Email",
                                "User_Email",
                                "Email",
                            ],
                        )
                    ]
                )
            )

        return _dedupe_emails(emails)

    except Exception:
        return []

    finally:
        _safe_close(cursor, conn)


# ============================================================
# Planning notification content
# ============================================================

def _normalize_planning_values(
    planning_key: Any,
    values: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    db_values = _fetch_planning_record(planning_key)

    result: Dict[str, Any] = {}
    result.update(db_values or {})
    result.update(values or {})

    return result


def _planning_names(data: Dict[str, Any]) -> Dict[str, str]:
    return {
        "key": _clean_text(
            _first_present(
                data,
                [
                    "audit_project_planning_key",
                    "AuditProjectPlanningID",
                    "Key",
                    "key",
                ],
            )
        ),
        "region": _clean_text(
            _first_present(data, ["Region Name", "region_name", "RegionName", "Region"])
        ),
        "client": _clean_text(
            _first_present(data, ["Client Name", "client_name", "ClientName", "Client"])
        ),
        "project": _clean_text(
            _first_present(
                data,
                ["Audit Project", "Audit Project Name", "audit_project_name", "AuditProjectName"],
            )
        ),
        "audit_scope": _clean_text(
            _first_present(data, ["Audit Scope", "audit_scope", "AuditScope"])
        ),
        "audit_lead": _clean_text(
            _first_present(data, ["Audit Lead", "audit_lead", "AuditLead"])
        ),
        "responsible": _clean_text(
            _first_present(data, ["Responsible", "responsible"])
        ),
        "start_date": _clean_text(
            _first_present(data, ["Start Date", "planned_start_audit_date", "start_date"])
        ),
        "end_date": _clean_text(
            _first_present(data, ["End Date", "planned_end_audit_date", "end_date"])
        ),
        "budget": _clean_text(
            _first_present(data, ["Budget", "yearly_budget_value_local_currency", "budget"])
        ),
        "budget_usd": _clean_text(
            _first_present(data, ["Budget USD", "yearly_budget_value_usd", "budget_usd"])
        ),
        "status": _clean_text(
            _first_present(data, ["Status", "status", "app_status", "app_status_key"])
        ),
        "comment": _clean_text(
            _first_present(data, ["Comment", "as_comment", "comment"])
        ),
    }


def _planning_user_keys(data: Dict[str, Any]) -> Tuple[Any, Any]:
    audit_lead_key = _first_present(
        data,
        ["audit_lead_key", "AuditLeadID", "audit_lead_id"],
        None,
    )

    responsible_key = _first_present(
        data,
        ["responsible_key", "ResponsibleID", "responsible_id"],
        None,
    )

    return audit_lead_key, responsible_key


def _subject_for_action(action: str, client_name: str) -> str:
    client = client_name or "client"
    action = action.lower().strip()

    if action in {"create", "add", "insert", "duplicate"}:
        return f"A new {client} project has been added to the Planning"

    if action in {"delete", "remove"}:
        return f"A {client} project has been removed from the Planning"

    if action in {"update", "edit"}:
        return f"A {client} project has been updated in the Planning"

    return f"{client} Planning notification"


def _title_for_action(action: str) -> str:
    action = action.lower().strip()

    if action in {"create", "add", "insert"}:
        return "Audit Project Planning created"

    if action == "duplicate":
        return "Audit Project Planning duplicated"

    if action in {"delete", "remove"}:
        return "Audit Project Planning removed"

    if action in {"update", "edit"}:
        return "Audit Project Planning updated"

    return "Audit Project Planning notification"


def _build_planning_html(action: str, data: Dict[str, Any]) -> str:
    values = _planning_names(data)

    rows = [
        ("Planning Key", values["key"]),
        ("Region", values["region"]),
        ("Client", values["client"]),
        ("Audit Project", values["project"]),
        ("Audit Scope", values["audit_scope"]),
        ("Audit Lead", values["audit_lead"]),
        ("Responsible", values["responsible"]),
        ("Start Date", values["start_date"]),
        ("End Date", values["end_date"]),
        ("Budget", values["budget"]),
        ("Budget USD", values["budget_usd"]),
        ("Status", values["status"]),
        ("Comment", values["comment"]),
    ]

    row_html = "".join(
        f"""
        <tr>
            <td style="padding:7px 10px;border-bottom:1px solid #ece7ef;
                       font-weight:600;color:#4b235e;width:180px;">
                {escape(label)}
            </td>
            <td style="padding:7px 10px;border-bottom:1px solid #ece7ef;
                       color:#242424;">
                {escape(value or "-")}
            </td>
        </tr>
        """
        for label, value in rows
    )

    title = escape(_title_for_action(action))

    return f"""
    <html>
      <body style="font-family:Segoe UI,Arial,sans-serif;
                   font-size:13px;color:#242424;background:#ffffff;">
        <div style="max-width:760px;margin:0 auto;border:1px solid #dfd8e5;
                    border-radius:12px;overflow:hidden;">
          <div style="padding:18px 22px;
                      background:linear-gradient(90deg,#24104f,#6d1f84,#741541);
                      color:white;">
            <div style="font-size:19px;font-weight:700;">{title}</div>
            <div style="font-size:12px;opacity:.85;margin-top:4px;">
              AuditX · Planning
            </div>
          </div>

          <div style="padding:20px 22px;">
            <p style="margin-top:0;">
              The Planning record was processed successfully.
            </p>

            <table style="width:100%;border-collapse:collapse;
                          border:1px solid #ece7ef;border-radius:8px;">
              {row_html}
            </table>

            <p style="margin:18px 0 0;color:#666;font-size:11px;">
              This is an automated notification generated by AuditX.
            </p>
          </div>
        </div>
      </body>
    </html>
    """


# ============================================================
# Outlook
# ============================================================

def _set_send_account(mail, outlook) -> None:
    send_from = os.getenv("OUTLOOK_SEND_FROM", OUTLOOK_SEND_FROM).strip()
    if not send_from:
        return

    try:
        for account in outlook.Session.Accounts:
            smtp = _clean_text(getattr(account, "SmtpAddress", ""))
            display = _clean_text(getattr(account, "DisplayName", ""))

            if send_from.lower() in {smtp.lower(), display.lower()}:
                mail._oleobj_.Invoke(
                    64209,
                    0,
                    8,
                    0,
                    account,
                )
                return
    except Exception:
        return


def _dispatch_outlook_message(
    recipients: Sequence[str],
    cc: Sequence[str],
    subject: str,
    html_body: str,
) -> Dict[str, Any]:
    recipients = _dedupe_emails(recipients)
    cc = _dedupe_emails(cc)

    to_lower = {x.lower() for x in recipients}
    cc = [x for x in cc if x.lower() not in to_lower]

    test_recipient = os.getenv(
        "OUTLOOK_TEST_RECIPIENT",
        OUTLOOK_TEST_RECIPIENT,
    ).strip()

    if test_recipient:
        recipients = [test_recipient]
        cc = []

    if not _outlook_enabled():
        result = OutlookResult(
            ok=True,
            email_mode="disabled",
            sent=False,
            draft=False,
            to=recipients,
            cc=cc,
            subject=subject,
            message="Planning saved successfully. Outlook notification is disabled by configuration.",
        ).as_dict()
        _log_outlook(f"DISABLED | TO={recipients} | CC={cc} | {subject}")
        return result

    if not recipients:
        result = OutlookResult(
            ok=False,
            email_mode="not_created",
            sent=False,
            draft=False,
            to=[],
            cc=cc,
            subject=subject,
            warning="No valid Outlook recipient was found for this Planning notification.",
            message="Planning was saved, but no notification recipient was available.",
        ).as_dict()
        _log_outlook(f"NO_RECIPIENT | CC={cc} | {subject}")
        return result

    if win32com is None or pythoncom is None:
        missing = []
        if win32com is None:
            missing.append("win32com")
        if pythoncom is None:
            missing.append("pythoncom")
        warning = "pywin32 is not available (missing: " + ", ".join(missing) + ")."
        _log_outlook(f"UNAVAILABLE | {warning}")
        return OutlookResult(
            ok=False,
            email_mode="outlook_unavailable",
            sent=False,
            draft=False,
            to=recipients,
            cc=cc,
            subject=subject,
            warning=warning,
            message="Planning was saved, but Outlook integration is unavailable.",
        ).as_dict()

    com_initialized = False
    outlook = None
    mail = None

    try:
        # Flask handles requests on worker threads. Outlook COM must be
        # initialized explicitly on EACH thread; otherwise pywin32 commonly
        # raises 'CoInitialize has not been called' and no Draft is created.
        pythoncom.CoInitialize()
        com_initialized = True

        outlook = win32com.client.Dispatch("Outlook.Application")
        namespace = outlook.GetNamespace("MAPI")
        mail = outlook.CreateItem(0)

        mail.To = ";".join(recipients)
        mail.CC = ";".join(cc)
        mail.Subject = subject
        mail.HTMLBody = html_body

        _set_send_account(mail, outlook)

        auto_send = _auto_send_enabled()
        open_draft = _open_draft_enabled()

        if auto_send:
            mail.Send()
            result = OutlookResult(
                ok=True,
                email_mode="sent",
                sent=True,
                draft=False,
                opened=False,
                to=recipients,
                cc=cc,
                subject=subject,
                message="Planning saved successfully. Outlook notification sent successfully.",
            ).as_dict()
            _log_outlook(f"SENT | TO={recipients} | CC={cc} | {subject}")
            return result

        # Save explicitly to the current Outlook profile. CreateItem + Save is
        # the supported Outlook mechanism for a normal Draft item.
        mail.Save()
        entry_id = _clean_text(getattr(mail, "EntryID", ""))

        # Touch the Drafts folder so failures caused by a missing/unavailable
        # Outlook profile are surfaced here instead of silently later.
        drafts_folder = namespace.GetDefaultFolder(16)  # olFolderDrafts
        drafts_name = _clean_text(getattr(drafts_folder, "Name", "Drafts")) or "Drafts"

        if open_draft:
            mail.Display(False)
            result = OutlookResult(
                ok=True,
                email_mode="draft_opened",
                sent=False,
                draft=True,
                opened=True,
                to=recipients,
                cc=cc,
                subject=subject,
                message=f"Planning saved successfully. Outlook notification saved in {drafts_name} and opened.",
            ).as_dict()
        else:
            result = OutlookResult(
                ok=True,
                email_mode="draft",
                sent=False,
                draft=True,
                opened=False,
                to=recipients,
                cc=cc,
                subject=subject,
                message=f"Planning saved successfully. Outlook notification saved in {drafts_name}.",
            ).as_dict()

        result["entry_id"] = entry_id
        result["drafts_folder"] = drafts_name
        _log_outlook(
            f"DRAFT | opened={open_draft} | entry_id={entry_id or '-'} | "
            f"TO={recipients} | CC={cc} | {subject}"
        )
        return result

    except Exception as exc:
        warning = f"{type(exc).__name__}: {exc}"
        _log_outlook(f"ERROR | {warning} | TO={recipients} | CC={cc} | {subject}")
        return OutlookResult(
            ok=False,
            email_mode="outlook_error",
            sent=False,
            draft=False,
            to=recipients,
            cc=cc,
            subject=subject,
            warning=warning,
            message=(
                "Planning was saved, but Outlook could not create/send "
                f"the notification: {warning}"
            ),
        ).as_dict()

    finally:
        # Release request-thread COM state. The saved Draft / sent message
        # remains owned by Outlook after the COM references are released.
        try:
            mail = None
            outlook = None
        except Exception:
            pass
        if com_initialized:
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass



# ============================================================
# Public function used by Planning service/routes
# ============================================================

def notify_audit_project_planning(
    action: str,
    key: Any,
    values: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Create the Audit Project Planning Outlook notification.

    TO:
        Audit Lead + Responsible

    CC:
        1) users in vw_user_control with type_of_user_key = 1
        2) manager-copy rule from P_Auditors / vw_user_control where available

    OUTLOOK_AUTO_SEND=true
        Sends immediately.

    OUTLOOK_AUTO_SEND=false
        Saves as Draft.

    OUTLOOK_OPEN_DRAFT=true
        In Draft mode, opens the Outlook window after saving.
    """
    action = _clean_text(action).lower() or "update"

    data = _normalize_planning_values(key, values)
    names = _planning_names(data)

    if not names["key"] and key not in (None, ""):
        data["audit_project_planning_key"] = key
        names["key"] = _clean_text(key)

    audit_lead_key, responsible_key = _planning_user_keys(data)

    recipients = _fetch_user_emails_by_keys(
        [audit_lead_key, responsible_key]
    )

    _log_outlook(
        f"PREPARE | action={action} | key={names['key'] or key} | "
        f"lead={audit_lead_key} | responsible={responsible_key} | TO={recipients}"
    )

    cc = _dedupe_emails(
        _fetch_copy_all_emails()
        + _fetch_manager_copy_emails()
    )

    subject = _subject_for_action(action, names["client"])
    html_body = _build_planning_html(action, data)

    result = _dispatch_outlook_message(
        recipients=recipients,
        cc=cc,
        subject=subject,
        html_body=html_body,
    )

    result["action"] = action
    result["planning_key"] = names["key"] or _clean_text(key)
    result["client_name"] = names["client"]
    result["audit_project"] = names["project"]

    return result


# ============================================================
# Optional compatibility aliases
# ============================================================

def notify_planning_create(
    key: Any,
    values: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return notify_audit_project_planning("create", key, values)


def notify_planning_update(
    key: Any,
    values: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return notify_audit_project_planning("update", key, values)


def notify_planning_delete(
    key: Any,
    values: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return notify_audit_project_planning("delete", key, values)


def notify_planning_duplicate(
    key: Any,
    values: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return notify_audit_project_planning("duplicate", key, values)


__all__ = [
    "notify_audit_project_planning",
    "notify_planning_create",
    "notify_planning_update",
    "notify_planning_delete",
    "notify_planning_duplicate",
]
