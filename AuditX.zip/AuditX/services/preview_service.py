"""

    Módulo: preview_service
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:
          Gestiona la lógica de negocio para cargar una muestra de información de una lista de datos seleccionada, validando parámetros
          y preparando la respuesta para su consumo.

          load_preview_data():
                Valida que exista un data_list_id.
                Controla la cantidad de registros solicitados (top).
                Llama al repositorio preview_repository.
                Normaliza la respuesta con columnas y filas.
                Maneja errores de consulta.

"""

from repositories.preview_repository import get_preview_data
 
 
def load_preview_data(data_list_id: int, top: int = 100):
    """
    Returns preview data for the selected DataList.
    """
    if not data_list_id:
        return {
            "ok": False,
            "message": "data_list_id is required"
        }
 
    if top is None or top <= 0:
        top = 100
 
    try:
        result = get_preview_data(data_list_id, top)
 
        return {
            "ok": True,
            "columns": result.get("columns", []),
            "rows": result.get("rows", [])
        }
    except Exception as exc:
        return {
            "ok": False,
            "message": str(exc)
        }