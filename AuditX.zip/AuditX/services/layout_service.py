"""

    Módulo: layout_service
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:
         Gestiona la lógica de negocio para las preferencias de visualización del usuario, incluyendo carga, almacenamiento,
         actualización y restablecimiento de layouts, columnas visibles, filtros y paginación.

            load_user_layout() → recupera la configuración guardada de una vista.
            save_user_layout() → guarda la configuración completa del usuario.
            save_user_columns() → actualiza únicamente las columnas visibles.
            save_user_filters() → guarda filtros y tamaño de página.
            reset_user_layout() → restaura la configuración de la vista.

"""

from repositories.layout_repository import (
    get_user_preview_layout,
    save_user_preview_layout,
    save_visible_columns,
    save_filters,
    reset_user_preview_layout
)
 
 
def load_user_layout(user_key: str, data_list_id: int):
    if not user_key:
        user_key = "default_user"
 
    layout = get_user_preview_layout(user_key, data_list_id)
 
    return {
        "ok": True,
        "exists": layout.get("exists", False),
        "layout": layout.get("columns", []),
        "columns": layout.get("columns", []),
        "filters": layout.get("filters", []),
        "pageSize": layout.get("pageSize", 25)
    }
 
 
def save_user_layout(data: dict):
    user_key = data.get("userKey") or "default_user"
    data_list_id = data.get("dataListId")
    columns = data.get("columns") or data.get("visibleColumns") or []
    filters = data.get("filters") or []
    page_size = data.get("pageSize") or 25
 
    if not data_list_id:
        return {
            "ok": False,
            "message": "DataListID is required."
        }
 
    save_user_preview_layout(
        user_key=user_key,
        data_list_id=int(data_list_id),
        visible_columns=columns,
        filters=filters,
        page_size=int(page_size)
    )
 
    return {
        "ok": True,
        "message": "Layout saved successfully."
    }
 
 
def save_user_columns(data: dict):
    user_key = data.get("userKey") or "default_user"
    data_list_id = data.get("dataListId")
    columns = data.get("columns") or []
 
    if not data_list_id:
        return {
            "ok": False,
            "message": "DataListID is required."
        }
 
    save_visible_columns(
        user_key=user_key,
        data_list_id=int(data_list_id),
        visible_columns=columns
    )
 
    return {
        "ok": True,
        "message": "Columns saved successfully."
    }
 
 
def save_user_filters(data: dict):
    user_key = data.get("userKey") or "default_user"
    data_list_id = data.get("dataListId")
    filters = data.get("filters") or []
    page_size = data.get("pageSize") or 25
 
    if not data_list_id:
        return {
            "ok": False,
            "message": "DataListID is required."
        }
 
    save_filters(
        user_key=user_key,
        data_list_id=int(data_list_id),
        filters=filters,
        page_size=int(page_size)
    )
 
    return {
        "ok": True,
        "message": "Filters saved successfully."
    }
 
 
def reset_user_layout(user_key: str, data_list_id: int):
    if not user_key:
        user_key = "default_user"
 
    reset_user_preview_layout(user_key, int(data_list_id))
 
    return {
        "ok": True,
        "message": "Layout reset successfully."
    }