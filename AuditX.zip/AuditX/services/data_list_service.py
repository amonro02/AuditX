"""

    Módulo: data_list_service
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:
          Gestiona la lógica de consulta de proyectos, reportes y listas de datos, validando los parámetros requeridos y coordinando el
          acceso a la información mediante los repositorios correspondientes.

            load_projects() → obtiene los proyectos disponibles.
            load_reports() → obtiene los reportes asociados a un proyecto.
            load_data_lists() → obtiene las listas de datos asociadas a un reporte.
            load_data_list_meta() → obtiene la información detallada de una lista de datos.

"""


from repositories.data_list_repository import (
    get_projects,
    get_reports_by_project_id,
    get_data_lists_by_report_list_id,
    get_data_list_by_id
)
 
 
def load_projects(server: str, database: str):
    return {"ok": True, "rows": get_projects(server,database)}
 
 
def load_reports(project_id: int,server: str, database: str):
    if not project_id:
        return {"ok": False, "message": "project_id is required"}
 
    return {"ok": True, "rows": get_reports_by_project_id(project_id,server,database)}
 
def load_data_lists(report_list_id: int,server: str, database: str):
    if not report_list_id:
        return {"ok": False, "message": "report_list_id is required"}
 
    return {"ok": True, "rows": get_data_lists_by_report_list_id(report_list_id,server,database)}
 
 
def load_data_list_meta(data_list_id: int):
    if not data_list_id:
        return {"ok": False, "message": "data_list_id is required"}
 
    row = get_data_list_by_id(data_list_id)
    if not row:
        return {"ok": False, "message": "DataList not found"}
 
    return {"ok": True, "row": row}