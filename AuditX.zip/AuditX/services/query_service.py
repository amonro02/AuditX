"""

    Módulo: query_service
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:
        Gestiona la lógica de ejecución de consultas sobre listas de datos, incluyendo la carga de columnas disponibles, aplicación de
        filtros y preparación de resultados para su consumo por la aplicación.

        load_query_fields():
            Obtiene las columnas disponibles de una tabla.
            Valida que exista una lista de datos.
            Devuelve los campos disponibles para construir filtros o vistas.
        execute_query():
            Ejecuta consultas dinámicas.
            Envía filtros y límite de registros.
            Devuelve columnas, filas y metadata de la consulta.
            Maneja errores de ejecución.

"""

from repositories.query_repository import get_table_columns, run_dynamic_query
 
 
def load_query_fields(data_list_id: int):
    if not data_list_id:
        return {"ok": False, "message": "data_list_id is required", "columns": []}
 
    try:
        cols = get_table_columns(data_list_id)
        return {"ok": True, "columns": cols}
 
    except Exception as e:
        print("load_query_fields error:", e)
        return {"ok": False, "message": str(e), "columns": []}
 
 
def execute_query(data_list_id: int, filters: list = None, top=None):
    if not data_list_id:
        return {
            "ok": False,
            "message": "data_list_id is required",
            "columns": [],
            "rows": []
        }
 
    try:
        result = run_dynamic_query(
            data_list_id=data_list_id,
            filters=filters or [],
            top=top
        )
 
        return {
            "ok": True,
            "columns": result.get("columns", []),
            "rows": result.get("rows", []),
            "server": result.get("server", ""),
            "database": result.get("database", ""),
            "tableName": result.get("tableName", ""),
            "sql": result.get("sql", "")
        }
 
    except Exception as e:
        print("execute_query error:", e)
 
        return {
            "ok": False,
            "message": str(e),
            "columns": [],
            "rows": []
        }
 