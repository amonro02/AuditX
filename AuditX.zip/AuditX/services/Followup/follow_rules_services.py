from __future__ import annotations
 
from typing import Any
 
from database.connection import Database
from database.db_config import DB_CONFIG_AUDITFOLLOWUP
 
 
class FollowUpRulesService:
    """
    Consulta y selecciona las reglas activas de seguimiento.
 
    Prioridad:
        1. Regla específica del proyecto.
        2. Regla general del cliente, con ProjectID NULL.
        3. Menor valor de Priority.
        4. Mayor DaysWithoutReply aplicable.
    """
 
    def __init__(self, db: Database | None = None):
        self.db = db or Database(
            DB_CONFIG_AUDITFOLLOWUP
        )
 
    def get_rules(
        self,
        client_id: int,
        project_id: int | None = None
    ) -> list[dict[str, Any]]:
        """
        Devuelve todas las reglas activas aplicables al cliente
        y proyecto indicado.
        """
 
        if client_id in (None, ""):
            raise ValueError(
                "ClientID es obligatorio para consultar reglas."
            )
 
        sql = """
            SELECT
                RuleID,
                ClientID,
                ProjectID,
                RuleCode,
                RuleName,
                CurrentStatus,
                DaysWithoutReply,
                TemplateCode,
                OverrideSendMode,
                NextStatus,
                Priority,
                IsEnabled
            FROM dbo.FollowUpRules
            WHERE ClientID = ?
              AND IsEnabled = 1
              AND (
                    ProjectID = ?
                    OR ProjectID IS NULL
                  )
            ORDER BY
                CASE
                    WHEN ProjectID = ? THEN 0
                    WHEN ProjectID IS NULL THEN 1
                    ELSE 2
                END,
                ISNULL(Priority, 999999) ASC,
                ISNULL(DaysWithoutReply, 0) DESC,
                RuleID ASC;
        """
 
        return self.db.fetch_all(
            sql,
            (
                int(client_id),
                project_id,
                project_id
            )
        )
 
    def find_matching_rule(
        self,
        client_id: int,
        project_id: int | None,
        current_status: str,
        days_without_reply: int = 0
    ) -> dict[str, Any] | None:
        """
        Selecciona la mejor regla aplicable al estado actual y
        a los días transcurridos sin respuesta.
 
        Ejemplo:
            Si DaysWithoutReply de la regla es 8, la regla aplica
            cuando el caso tiene 8 días o más sin respuesta.
        """
 
        if client_id in (None, ""):
            raise ValueError(
                "ClientID es obligatorio para buscar una regla."
            )
 
        normalized_status = str(
            current_status or ""
        ).strip().lower()
 
        normalized_days = max(
            int(days_without_reply or 0),
            0
        )
 
        if not normalized_status:
            return None
 
        sql = """
            SELECT TOP 1
                RuleID,
                ClientID,
                ProjectID,
                RuleCode,
                RuleName,
                CurrentStatus,
                DaysWithoutReply,
                TemplateCode,
                OverrideSendMode,
                NextStatus,
                Priority,
                IsEnabled
            FROM dbo.FollowUpRules
            WHERE ClientID = ?
              AND IsEnabled = 1
              AND (
                    ProjectID = ?
                    OR ProjectID IS NULL
                  )
              AND LOWER(LTRIM(RTRIM(CurrentStatus))) = ?
              AND ISNULL(DaysWithoutReply, 0) <= ?
            ORDER BY
                CASE
                    WHEN ProjectID = ? THEN 0
                    WHEN ProjectID IS NULL THEN 1
                    ELSE 2
                END,
                ISNULL(Priority, 999999) ASC,
                ISNULL(DaysWithoutReply, 0) DESC,
                RuleID ASC;
        """
 
        return self.db.fetch_one(
            sql,
            (
                int(client_id),
                project_id,
                normalized_status,
                normalized_days,
                project_id
            )
        )
 
    def get_effective_rule(
        self,
        client_id: int,
        project_id: int | None,
        current_status: str,
        days_without_reply: int = 0
    ) -> dict[str, Any] | None:
        """
        Devuelve la regla normalizada para que EmailService pueda
        utilizarla directamente.
        """
 
        rule = self.find_matching_rule(
            client_id=client_id,
            project_id=project_id,
            current_status=current_status,
            days_without_reply=days_without_reply
        )
 
        if not rule:
            return None
 
        return {
            **rule,
            "TemplateCode": (
                rule.get("TemplateCode")
                or "FIRST_EMAIL"
            ),
            "OverrideSendMode": (
                str(
                    rule.get("OverrideSendMode")
                    or ""
                ).strip().upper()
                or None
            ),
            "NextStatus": (
                rule.get("NextStatus")
                or current_status
            ),
            "DaysWithoutReply": int(
                rule.get("DaysWithoutReply")
                or 0
            ),
            "Priority": int(
                rule.get("Priority")
                or 999999
            )
        }