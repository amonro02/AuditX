from __future__ import annotations

from datetime import datetime
from decimal import Decimal, InvalidOperation
from html import escape
from pathlib import Path
from typing import Any

from database.connection import Database
from database.db_config import DB_CONFIG_AUDITFOLLOWUP
from utils.Followup.gender_utils import get_greeting


class TemplateService:
    """
    Servicio encargado de:

    1. Consultar plantillas desde dbo.EmailTemplates.
    2. Seleccionar la plantilla específica del proyecto o la general.
    3. Preparar los datos para placeholders.
    4. Construir la tabla HTML de múltiples claims.
    5. Reemplazar placeholders.
    6. Utilizar archivos HTML como respaldo.
    7. Generar un template default cuando no existe otro.
    """

    RAW_HTML_KEYS = {
        "CLAIMS_TABLE",
        "CLAIMS_TABLE_HTML",
        "USER_SIGNATURE",
        "SIGNATURE",
        "SIGNATURE_HTML",
        "OUTLOOK_SIGNATURE",
        "OUTLOOK_SIGNATURE_HTML",
    }

    def __init__(
        self,
        base_dir: str | Path | None = None,
        db: Database | None = None,
    ):
        """
        Args:
            base_dir:
                Carpeta donde se encuentran los templates HTML
                utilizados como respaldo.

            db:
                Instancia opcional de Database para inyección
                de dependencias o pruebas.
        """

        self.base_dir = (
            Path(base_dir)
            if base_dir
            else Path.cwd() / "templates"
        )

        # Las plantillas pertenecen a PRGX_AUDITFOLLOWUP.
        self.db = db or Database(
            DB_CONFIG_AUDITFOLLOWUP
        )

    # =========================================================
    # TEMPLATE DESDE SQL
    # =========================================================

    def get_template(
        self,
        client_id: int,
        project_id: int | None,
        template_code: str,
    ) -> dict[str, Any] | None:
        """
        Recupera la mejor plantilla activa.

        Prioridad:
            1. Plantilla específica del cliente y proyecto.
            2. Plantilla general del cliente con ProjectID NULL.
            3. Plantilla marcada como default.
            4. Plantilla más reciente.
        """

        if client_id in (None, ""):
            raise ValueError(
                "ClientID es obligatorio para buscar el template."
            )

        normalized_template_code = str(
            template_code or ""
        ).strip()

        if not normalized_template_code:
            raise ValueError(
                "TemplateCode es obligatorio."
            )

        sql = """
            SELECT TOP 1
                TemplateID,
                ClientID,
                ProjectID,
                TemplateCode,
                TemplateName,
                SubjectTemplate,
                BodyTemplate,
                TemplateType,
                IsDefault,
                IsEnabled
            FROM dbo.EmailTemplates
            WHERE ClientID = ?
              AND TemplateCode = ?
              AND IsEnabled = 1
              AND (
                    ProjectID = ?
                    OR ProjectID IS NULL
                  )
            ORDER BY
                CASE
                    WHEN ProjectID = ? THEN 0
                    WHEN ProjectID IS NULL THEN 1
                    ELSE 2
                END,
                CASE
                    WHEN IsDefault = 1 THEN 0
                    ELSE 1
                END,
                TemplateID DESC;
        """

        return self.db.fetch_one(
            sql,
            (
                int(client_id),
                normalized_template_code,
                project_id,
                project_id,
            ),
        )

    # =========================================================
    # RENDER DEL TEMPLATE SQL
    # =========================================================

    def render_sql_template(
        self,
        client_id: int,
        project_id: int | None,
        template_code: str,
        data: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """
        Obtiene y procesa una plantilla almacenada en SQL.

        Devuelve siempre:
            template_id
            template_code
            subject
            body
            body_html
            source
        """

        prepared_data = self.prepare_template_data(
            data
        )

        template = self.get_template(
            client_id=client_id,
            project_id=project_id,
            template_code=template_code,
        )

        if not template:
            subject = self.build_default_subject(
                prepared_data
            )

            body = self.default_template(
                prepared_data
            )

            return {
                "template_id": None,
                "template_code": template_code,
                "subject": subject,
                "body": body,
                "body_html": body,
                "source": "DEFAULT",
            }

        subject_template = str(
            template.get("SubjectTemplate")
            or ""
        )

        body_template = str(
            template.get("BodyTemplate")
            or ""
        )

        subject = self.replace_placeholders(
            subject_template,
            prepared_data,
        )

        body = self.replace_placeholders(
            body_template,
            prepared_data,
        )

        return {
            "template_id": template.get("TemplateID"),
            "template_code": template.get(
                "TemplateCode"
            ),
            "template_name": template.get(
                "TemplateName"
            ),
            "template_type": template.get(
                "TemplateType"
            ),
            "subject": subject,
            "body": body,
            "body_html": body,
            "source": "SQL",
        }

    # =========================================================
    # PREPARACIÓN DE DATOS
    # =========================================================

    def prepare_template_data(
        self,
        data: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """
        Prepara los valores que utilizarán los placeholders.

        Soporta:
            - Un caso principal.
            - Múltiples claims.
            - Varios proyectos.
            - Total de claims.
            - Saludo según género.
            - Diferentes nombres de campos.
        """

        prepared = dict(data or {})

        language = self.first_non_empty(
            prepared,
            "Language",
            "language",
            "EmailLanguage",
            "email_language",
            "TemplateLanguage",
            "template_language",
        ) or "en"

        claims = (
            prepared.get("claims")
            or prepared.get("Claims")
            or prepared.get("CLAIMS_LIST")
            or []
        )

        if not isinstance(claims, list):
            claims = []

        claims_table_html = (
            self.build_claims_table_html(claims)
        )

        claim_numbers = self.get_claim_numbers_text(
            claims
        )

        project_text = self.get_project_text(
            prepared,
            claims,
        )

        total_amount = self.get_total_claim_amount(
            claims
        )

        currency = self.get_currency(
            prepared,
            claims,
        )

        contact_name = self.first_non_empty(
            prepared,
            "ContactName",
            "contact_name",
            "VendorContactName",
            "vendor_contact_name",
        )

        contact_gender = self.first_non_empty(
            prepared,
            "ContactGender",
            "contact_gender",
            "Gender",
            "gender",
        )

        greeting = self.build_greeting(
            contact_name=contact_name,
            contact_gender=contact_gender,
            language=language
        )

        vendor_name = self.first_non_empty(
            prepared,
            "VendorName",
            "Vendor",
            "vendor_name",
            "vendor",
        )

        vendor_number = self.first_non_empty(
            prepared,
            "VendorNumber",
            "vendor_number",
        )

        client_name = self.first_non_empty(
            prepared,
            "ClientName",
            "client_name",
        )

        category_name = self.first_non_empty(
            prepared,
            "CategoryName",
            "category_name",
        )

        email_to = self.first_non_empty(
            prepared,
            "EmailTo",
            "email_to",
            "To",
            "to",
        )

        email_cc = self.first_non_empty(
            prepared,
            "EmailCC",
            "email_cc",
            "CC",
            "cc",
        )

        current_date = datetime.now()
        total_formatted = self.format_money(
            total_amount,
            currency,
        )

        first_claim = claims[0] if claims else {}

        first_claim_number = self.first_non_empty(
            first_claim,
            "ClaimNumber",
            "ClaimCode",
            "claim_number",
            "claim_code",
        )

        first_claim_amount = self.first_non_empty(
            first_claim,
            "ClaimAmount",
            "Amount",
            "claim_amount",
            "amount",
        )

        prepared.update({
            #Lenguaje
            "LANGUAGE": language,
            "Language": language,
            "EMAIL_LANGUAGE": language,
            "EmailLanguage": language,
        
            "GREETING": greeting,
            "Greeting": greeting,
            # Fecha
            "CURRENT_DATE": current_date.strftime(
                "%B %d, %Y"
            ),
            "CurrentDate": current_date.strftime(
                "%B %d, %Y"
            ),
            "CURRENT_YEAR": current_date.year,
            "CurrentYear": current_date.year,

            # Contacto
            "GREETING": greeting,
            "Greeting": greeting,
            "CONTACT_NAME": contact_name,
            "ContactName": contact_name,
            "CONTACT_GENDER": contact_gender,
            "ContactGender": contact_gender,

            # Cliente
            "CLIENT_NAME": client_name,
            "ClientName": client_name,

            # Proyecto
            "PROJECT_NAME": project_text,
            "ProjectName": project_text,
            "PROJECT": project_text,
            "Project": project_text,

            # Categoría
            "CATEGORY_NAME": category_name,
            "CategoryName": category_name,

            # Vendor
            "VENDOR_NAME": vendor_name,
            "VendorName": vendor_name,
            "VENDOR": vendor_name,
            "Vendor": vendor_name,
            "VENDOR_NUMBER": vendor_number,
            "VendorNumber": vendor_number,

            # Correos
            "EMAIL_TO": email_to,
            "EmailTo": email_to,
            "EMAIL_CC": email_cc,
            "EmailCC": email_cc,

            # Claims
            "CLAIM_COUNT": len(claims),
            "ClaimCount": len(claims),
            "CLAIM_NUMBER": claim_numbers,
            "ClaimNumber": (
                claim_numbers
                or first_claim_number
                or ""
            ),
            "CLAIM_NUMBERS": claim_numbers,
            "ClaimNumbers": claim_numbers,
            "CLAIMS": claim_numbers,
            "CLAIMS_TABLE": claims_table_html,
            "CLAIMS_TABLE_HTML": claims_table_html,
            "ClaimsTable": claims_table_html,
            "ClaimsTableHTML": claims_table_html,

            # Primer claim, para templates legacy
            "CLAIM_AMOUNT": (
                first_claim_amount or ""
            ),
            "ClaimAmount": (
                first_claim_amount or ""
            ),

            # Total
            "TOTAL_CLAIM_AMOUNT": total_formatted,
            "TotalClaimAmount": total_formatted,
            "TOTAL_AMOUNT": total_formatted,
            "TotalAmount": total_formatted,

            # Moneda
            "CURRENCY": currency,
            "Currency": currency,

            # Lista original
            "claims": claims,
            "Claims": claims,
        })

        return prepared

    # =========================================================
    # CLAIMS
    # =========================================================

    def build_claims_table_html(
        self,
        claims: list[dict[str, Any]],
    ) -> str:
        """
        Genera la tabla HTML que contiene todos los claims.
        """

        if not claims:
            return """
                <p style="
                    font-family:Segoe UI, Arial, sans-serif;
                    font-size:13px;
                ">
                    No claims were registered.
                </p>
            """

        rows: list[str] = []

        for index, claim in enumerate(
            claims,
            start=1,
        ):
            claim_number = escape(
                str(
                    self.first_non_empty(
                        claim,
                        "ClaimNumber",
                        "ClaimCode",
                        "claim_number",
                        "claim_code",
                    )
                    or ""
                )
            )

            project_name = escape(
                str(
                    self.first_non_empty(
                        claim,
                        "ProjectName",
                        "Project",
                        "project_name",
                        "project",
                    )
                    or ""
                )
            )

            description = escape(
                str(
                    self.first_non_empty(
                        claim,
                        "Description",
                        "ClaimDescription",
                        "description",
                        "claim_description",
                    )
                    or ""
                )
            )

            currency = str(
                self.first_non_empty(
                    claim,
                    "Currency",
                    "currency",
                )
                or ""
            ).strip()

            amount_value = self.first_non_empty(
                claim,
                "ClaimAmount",
                "Amount",
                "claim_amount",
                "amount",
            )

            amount_text = self.format_money(
                amount_value,
                currency,
            )

            rows.append(
                f"""
                <tr>
                    <td style="
                        border:1px solid #B7B7B7;
                        padding:6px;
                        text-align:center;
                    ">
                        {index}
                    </td>

                    <td style="
                        border:1px solid #B7B7B7;
                        padding:6px;
                    ">
                        {claim_number}
                    </td>

                    <td style="
                        border:1px solid #B7B7B7;
                        padding:6px;
                    ">
                        {project_name}
                    </td>

                    <td style="
                        border:1px solid #B7B7B7;
                        padding:6px;
                        text-align:right;
                        white-space:nowrap;
                    ">
                        {escape(amount_text)}
                    </td>

                    <td style="
                        border:1px solid #B7B7B7;
                        padding:6px;
                    ">
                        {description}
                    </td>
                </tr>
                """
            )

        return f"""
            <table
                cellpadding="0"
                cellspacing="0"
                role="presentation"
                style="
                    border-collapse:collapse;
                    width:100%;
                    font-family:Segoe UI, Arial, sans-serif;
                    font-size:13px;
                "
            >
                <thead>
                    <tr style="
                        background-color:#D9EAD3;
                        font-weight:bold;
                    ">
                        <th style="
                            border:1px solid #B7B7B7;
                            padding:6px;
                        ">
                            #
                        </th>

                        <th style="
                            border:1px solid #B7B7B7;
                            padding:6px;
                        ">
                            Claim
                        </th>

                        <th style="
                            border:1px solid #B7B7B7;
                            padding:6px;
                        ">
                            Project
                        </th>

                        <th style="
                            border:1px solid #B7B7B7;
                            padding:6px;
                        ">
                            Amount
                        </th>

                        <th style="
                            border:1px solid #B7B7B7;
                            padding:6px;
                        ">
                            Description
                        </th>
                    </tr>
                </thead>

                <tbody>
                    {''.join(rows)}
                </tbody>
            </table>
        """

    def get_claim_numbers_text(
        self,
        claims: list[dict[str, Any]],
    ) -> str:
        numbers: list[str] = []

        for claim in claims:
            claim_number = self.first_non_empty(
                claim,
                "ClaimNumber",
                "ClaimCode",
                "claim_number",
                "claim_code",
            )

            if claim_number in (None, ""):
                continue

            claim_number_text = str(
                claim_number
            ).strip()

            if (
                claim_number_text
                and claim_number_text not in numbers
            ):
                numbers.append(claim_number_text)

        return ", ".join(numbers)

    def get_project_text(
        self,
        data: dict[str, Any],
        claims: list[dict[str, Any]],
    ) -> str:
        """
        Devuelve:
            - Nombre del proyecto, cuando solo existe uno.
            - Multiple projects, cuando existen varios.
            - Proyecto del caso, si los claims no lo contienen.
        """

        project_names: list[str] = []

        for claim in claims:
            project_name = self.first_non_empty(
                claim,
                "ProjectName",
                "Project",
                "project_name",
                "project",
            )

            if project_name in (None, ""):
                continue

            project_name_text = str(
                project_name
            ).strip()

            if (
                project_name_text
                and project_name_text
                not in project_names
            ):
                project_names.append(
                    project_name_text
                )

        if len(project_names) > 1:
            return "Multiple projects"

        if len(project_names) == 1:
            return project_names[0]

        return str(
            self.first_non_empty(
                data,
                "ProjectName",
                "Project",
                "project_name",
                "project",
            )
            or ""
        ).strip()

    def get_total_claim_amount(
        self,
        claims: list[dict[str, Any]],
    ) -> Decimal:
        total = Decimal("0")

        for claim in claims:
            amount = self.first_non_empty(
                claim,
                "ClaimAmount",
                "Amount",
                "claim_amount",
                "amount",
            )

            if amount in (None, ""):
                continue

            try:
                total += Decimal(
                    str(amount).replace(",", "")
                )
            except (
                InvalidOperation,
                TypeError,
                ValueError,
            ):
                continue

        return total

    def get_currency(
        self,
        data: dict[str, Any],
        claims: list[dict[str, Any]],
    ) -> str:
        currency = self.first_non_empty(
            data,
            "Currency",
            "currency",
        )

        if currency:
            return str(currency).strip()

        for claim in claims:
            currency = self.first_non_empty(
                claim,
                "Currency",
                "currency",
            )

            if currency:
                return str(currency).strip()

        return ""

    # =========================================================
    # PLACEHOLDERS
    # =========================================================

    def replace_placeholders(
        self,
        text: str,
        data: dict[str, Any] | None,
    ) -> str:
        """
        Reemplaza placeholders con los formatos:

            {{FIELD}}
            {FIELD}
            [[FIELD]]
            %FIELD%

        Los valores normales se escapan para evitar romper HTML.

        Los campos contenidos en RAW_HTML_KEYS se insertan
        directamente porque ya contienen HTML seguro generado
        por la aplicación.
        """

        result = str(text or "")
        values = data or {}

        for key, value in values.items():
            key_text = str(key)
            key_upper = key_text.upper()

            if value is None:
                replacement = ""

            elif key_upper in self.RAW_HTML_KEYS:
                replacement = str(value)

            elif isinstance(
                value,
                (list, dict, tuple, set),
            ):
                # Las estructuras Python no deben aparecer
                # literalmente dentro del correo.
                replacement = ""

            else:
                replacement = escape(
                    str(value)
                )

            placeholder_variants = (
                "{{" + key_text + "}}",
                "{" + key_text + "}",
                "[[" + key_text + "]]",
                "%" + key_text + "%",
            )

            for placeholder in placeholder_variants:
                result = result.replace(
                    placeholder,
                    replacement,
                )

        return result

    # =========================================================
    # SOPORTE PARA ARCHIVOS HTML ANTERIORES
    # =========================================================

    def render_file_template(
        self,
        case: dict[str, Any] | None,
        template_name: str = "followup_default.html",
    ) -> str:
        """
        Renderiza un archivo HTML desde la carpeta templates.

        Se conserva para compatibilidad con la versión anterior.
        """

        prepared_data = self.prepare_template_data(
            case
        )

        path = self.base_dir / template_name

        if not path.exists():
            return self.default_template(
                prepared_data
            )

        content = path.read_text(
            encoding="utf-8"
        )

        return self.replace_placeholders(
            content,
            prepared_data,
        )

    def render_step(
        self,
        case: dict[str, Any] | None,
        step: int,
    ) -> str:
        """
        Mantiene la asignación de templates HTML por etapa.
        """

        mapping = {
            1: "initial_notification.html",
            5: "second_notification.html",
            6: "third_notification.html",
            7: "escalation_commercial.html",
            8: "authorization_request.html",
            9: "final_application.html",
        }

        template_name = mapping.get(
            int(step or 0),
            "followup_default.html",
        )

        return self.render_file_template(
            case=case,
            template_name=template_name,
        )

    # =========================================================
    # TEMPLATE DEFAULT
    # =========================================================

    def build_default_subject(
        self,
        data: dict[str, Any],
    ) -> str:
        """
        Genera un asunto de respaldo.
        """

        year = str(
            self.first_non_empty(
                data,
                "CURRENT_YEAR",
                "CurrentYear",
            )
            or datetime.now().year
        ).strip()

        vendor = str(
            self.first_non_empty(
                data,
                "VENDOR_NAME",
                "VendorName",
                "Vendor",
            )
            or ""
        ).strip()

        project = str(
            self.first_non_empty(
                data,
                "PROJECT_NAME",
                "ProjectName",
                "Project",
            )
            or ""
        ).strip()

        claims = str(
            self.first_non_empty(
                data,
                "CLAIM_NUMBERS",
                "ClaimNumbers",
                "ClaimNumber",
            )
            or ""
        ).strip()

        parts = [
            value
            for value in (
                year,
                "Follow-up",
                vendor,
                project,
                claims,
            )
            if value
        ]

        return " - ".join(parts)

    def default_template(
        self,
        case: dict[str, Any] | None,
    ) -> str:
        """
        Template de respaldo cuando no existe una plantilla SQL
        ni un archivo HTML.
        """

        prepared = self.prepare_template_data(
            case
        )

        greeting = str(
            prepared.get("GREETING")
            or "Dear Sir or Madam,"
        )

        claims_table = str(
            prepared.get("CLAIMS_TABLE_HTML")
            or ""
        )

        return f"""
            <div style="
                font-family:Segoe UI, Arial, sans-serif;
                font-size:13px;
                color:#222222;
            ">
                <p>{greeting}</p>

                <p>
                    We are following up regarding the following
                    claim information:
                </p>

                {claims_table}

                <p>
                    Please review the information and provide us
                    with an update at your earliest convenience.
                </p>

                <p>
                    Thank you.
                </p>
            </div>
        """

    # =========================================================
    # FUNCIONES AUXILIARES
    # =========================================================

    @staticmethod
    def first_non_empty(
        data: dict[str, Any] | None,
        *keys: str,
    ) -> Any:
        """
        Devuelve el primer campo existente y no vacío.
        """

        source = data or {}

        for key in keys:
            value = source.get(key)

            if value is None:
                continue

            if isinstance(value, str):
                if value.strip():
                    return value

                continue

            return value

        return None

    @staticmethod
    def format_money(
        value: Any,
        currency: str | None = None,
    ) -> str:
        """
        Formatea un monto.

        Ejemplo:
            USD 1,250.00
        """

        if value in (None, ""):
            amount_text = "0.00"

        else:
            try:
                amount = Decimal(
                    str(value).replace(",", "")
                )

                amount_text = f"{amount:,.2f}"

            except (
                InvalidOperation,
                TypeError,
                ValueError,
            ):
                amount_text = str(value)

        currency_text = str(
            currency or ""
        ).strip()

        if currency_text:
            return (
                f"{currency_text} {amount_text}"
            )

        return amount_text

    @staticmethod
    def build_greeting(
        contact_name: Any,
        contact_gender: Any = None,
        language: str = "en",
    ) -> str:
        selected_language = str(
            language or "en"
        ).strip().lower()
    
        try:
            return get_greeting(
                contact_name=contact_name,
                contact_gender=contact_gender,
                language=selected_language,
            )
    
        except Exception:
            name = str(
                contact_name or ""
            ).strip()
    
            first_name = (
                name.split()[0]
                if name
                else ""
            )
    
            if selected_language.startswith("es"):
                if first_name:
                    return f"Estimado(a) {first_name}:"
    
                return "Estimado(a):"
    
            if first_name:
                return f"Dear {first_name},"
    
            return "Dear Sir or Madam,"
    
