from services.Followup.template_service import TemplateService
from services.Followup.email_settings_service import EmailSettingsService
from services.Followup.outlook_service import OutlookService
 
 
class EmailService:
 
    def __init__(self):
        self.template_service = TemplateService()
        self.settings_service = EmailSettingsService()
        self.outlook_service = OutlookService()
 
    def send_first_email(
        self,
        case: dict,
        current_user: dict,
        claims: list[dict] | None = None,
        send_mode: str = "DRAFT"
    ):
        claims = claims or case.get("claims", [])
 
        settings = self.settings_service.get_email_settings(
            case.get("ClientID"),
            case.get("ProjectID")
        )
 
        template_code = "FIRST_EMAIL"
 
        if settings and settings.get("DefaultTemplateCode"):
            template_code = settings["DefaultTemplateCode"]
 
        data = {
            **case,
 
            # Múltiples claims
            "claims": claims,
            "Claims": claims,

            #Languaje
            "Language": settings.get("LanguageCode", "en"),
             
            # Usuario actual
            "sender_name": current_user.get("FullName", ""),
            "sender_title": current_user.get("Role", ""),
            "sender_email": current_user.get("Email", ""),
        }
 
        rendered = self.template_service.render_sql_template(
            client_id=case.get("ClientID"),
            project_id=case.get("ProjectID"),
            template_code=template_code,
            data=data
        )
 
        if not rendered:
            raise ValueError(
                f"No se pudo renderizar el template {template_code}."
            )
 
        final_send_mode = (
            settings.get("SendMode")
            if settings and settings.get("SendMode")
            else send_mode
        )
 
        return self.outlook_service.create_new_email(
            client_id=case.get("ClientID"),
            project_id=case.get("ProjectID"),
            to=case.get("EmailTo", ""),
            cc=case.get("EmailCC", ""),
            subject=rendered.get("subject", ""),
            html=rendered.get("body", ""),
            mode=final_send_mode
        )