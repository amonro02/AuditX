import re
import unicodedata
from database.connection import Database


class ResponseClassifier:
    """
    Clasifica respuestas del proveedor con reglas SQL multidioma.
    No usa IA externa.
    """

    def __init__(self):
        self.db = Database()

    def normalize(self, text):
        text = text or ""
        text = text.lower()
        text = unicodedata.normalize("NFKD", text)
        text = "".join(c for c in text if not unicodedata.combining(c))
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    def latest_reply_only(self, body):
        text = body or ""
        markers = [
            "\nfrom:", "\nde:", "\nsent:", "\nenviado:",
            "\nto:", "\npara:", "\ncc:",
            "\nsubject:", "\nasunto:",
            "-----original message-----", "-----mensaje original-----"
        ]
        lower = text.lower()
        cuts = [lower.find(m) for m in markers if lower.find(m) > 0]
        if cuts:
            text = text[:min(cuts)]
        return text.strip()

    def snippet(self, text, limit=700):
        return re.sub(r"\s+", " ", text or "").strip()[:limit]

    def load_rules(self):
        return self.db.fetch_all("""
            SELECT ResponseType, LanguageCode, Phrase, Score
            FROM dbo.ResponseKeywordRules
            WHERE IsActive = 1
            ORDER BY
                CASE WHEN ResponseType = 'Negative' THEN 1
                     WHEN ResponseType = 'Positive' THEN 2
                     ELSE 3 END,
                Score DESC
        """) or []

    def classify(self, body):
        raw_latest = self.latest_reply_only(body)
        text = self.normalize(raw_latest)

        if not text:
            return {
                "response_type": "NoResponse",
                "confidence": 0,
                "language": None,
                "matched_phrase": None,
                "snippet": ""
            }

        best = {
            "response_type": "NeedsReview",
            "confidence": 0,
            "language": None,
            "matched_phrase": None,
            "snippet": self.snippet(raw_latest)
        }

        for r in self.load_rules():
            phrase = self.normalize(r.get("Phrase"))
            if phrase and phrase in text:
                score = int(r.get("Score") or 0)
                if score > best["confidence"]:
                    best = {
                        "response_type": r.get("ResponseType"),
                        "confidence": score,
                        "language": r.get("LanguageCode"),
                        "matched_phrase": r.get("Phrase"),
                        "snippet": self.snippet(raw_latest)
                    }
                if r.get("ResponseType") == "Negative" and score >= 90:
                    return best

        if best["confidence"] < 70:
            best["response_type"] = "NeedsReview"
            best["confidence"] = max(best["confidence"], 40)

        return best
