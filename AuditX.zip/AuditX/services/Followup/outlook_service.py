import os
import time
import win32com.client

from pathlib import Path
from datetime import datetime
from utils.Followup.outlook_signature import load_outlook_signature

class OutlookService:
    def __init__(self):
        self.outlook = None
        self.namespace = None
        self.accounts = []
        self.selected_account = None
        self.connected = False
        self.last_error = ""

    def connect(self):
        try:
            try:
                self.outlook = win32com.client.GetActiveObject("Outlook.Application")
            except Exception:
                os.startfile("outlook:")
                time.sleep(3)
                self.outlook = win32com.client.Dispatch("Outlook.Application")

            self.namespace = self.outlook.GetNamespace("MAPI")
            self.accounts = self.get_accounts()
            if self.accounts:
                self.selected_account = self.accounts[0].get("object")
            self.connected = True
            self.last_error = ""
            return self.accounts
        except Exception as e:
            self.connected = False
            self.last_error = str(e)
            raise

    def ensure_connected(self):
        if not self.connected or self.outlook is None or self.namespace is None:
            self.connect()

    def get_accounts(self):
        accounts = []
        try:
            for acc in self.outlook.Session.Accounts:
                smtp = str(getattr(acc, "SmtpAddress", "") or "").lower().strip()
                if smtp:
                    accounts.append({
                        "smtp": smtp,
                        "display_name": str(getattr(acc, "DisplayName", "") or ""),
                        "object": acc
                    })
        except Exception:
            pass
        return accounts

    def set_account_by_smtp(self, smtp):
        smtp = (smtp or "").lower().strip()
        for acc in self.accounts:
            if acc.get("smtp") == smtp:
                self.selected_account = acc.get("object")
                return True
        return False

    def selected_account_text(self):
        try:
            if not self.selected_account:
                return "No account"
            smtp = str(getattr(self.selected_account, "SmtpAddress", "") or "")
            display = str(getattr(self.selected_account, "DisplayName", "") or "")
            return f"{display} <{smtp}>"
        except Exception:
            return "No account"

    def find_latest_email_by_subject(self, subject, max_items=500):
        self.ensure_connected()
        if not subject:
            return None

        subject_norm = str(subject).lower().strip()
        found = []

        for folder_id in (6, 5):  # Inbox, Sent Items
            try:
                items = self.namespace.GetDefaultFolder(folder_id).Items
                try:
                    items.Sort("[ReceivedTime]", True)
                except Exception:
                    pass

                limit = min(items.Count, max_items)
                for i in range(1, limit + 1):
                    try:
                        item = items.Item(i)
                        item_subject = str(getattr(item, "Subject", "") or "").lower()
                        if subject_norm in item_subject:
                            found.append(item)
                    except Exception:
                        continue
            except Exception:
                continue

        if not found:
            return None

        found.sort(key=self.item_date_safe, reverse=True)
        return found[0]

    def item_date_safe(self, item):
        for attr in ("ReceivedTime", "SentOn", "CreationTime"):
            try:
                value = getattr(item, attr)
                if value:
                    return value
            except Exception:
                pass
        return datetime(1900, 1, 1)

    def item_date(self, item):
        return self.item_date_safe(item)

    def item_body(self, item):
        try:
            return str(getattr(item, "Body", "") or "")
        except Exception:
            return ""

    def sender(self, item):
        for attr in ("SenderEmailAddress", "SenderName"):
            try:
                value = getattr(item, attr)
                if value:
                    return str(value)
            except Exception:
                pass
        return ""

    def parse_attachments(self, folder_path=None, files_text=None):
        paths = []

        if files_text:
            for raw in str(files_text).split(";"):
                raw = raw.strip().strip('"')
                if raw and Path(raw).exists():
                    paths.append(str(Path(raw)))

        if folder_path:
            folder = Path(str(folder_path).strip().strip('"'))
            if folder.exists() and folder.is_dir():
                for p in folder.iterdir():
                    if p.is_file():
                        paths.append(str(p))

        seen, result = set(), []
        for p in paths:
            key = p.lower()
            if key not in seen:
                result.append(p)
                seen.add(key)
        return result

    def create_new_email(
        self,
        to,
        cc,
        subject,
        html,
        attachments=None,
        mode=None,
        bcc=None,
        account=None,
        signature=None
    ):
    
        self.ensure_connected()

        if signature is None:
            signature = load_outlook_signature() or ""
    
        final_html = (html or "") + signature
    
        mail = self.outlook.CreateItem(0)
    
        mail.To = to or ""
        mail.CC = cc or ""
        mail.BCC = bcc or ""
    
        mail.Subject = subject or ""
        mail.bodyFormat = 2
        mail.HTMLBody = final_html

        # Configuración del mensaje
        mail.Importance = 2  # 0=Baja, 1=Normal, 2=Alta
        mail.ReadReceiptRequested = False
        mail.OriginatorDeliveryReportRequested = False


    
        try:

            if account:
                self.set_account_by_smtp(account)

            if self.selected_account:
                mail.SendUsingAccount = self.selected_account
    
        except Exception:
            pass
    
        for file_path in attachments or []:
    
            try:
    
                if file_path and Path(file_path).exists():
                    mail.Attachments.Add(str(file_path))
    
            except Exception:
                pass
    
        if str(mode).lower() == "send":
    
            mail.Send()
    
            return "sent", getattr(mail, "EntryID", None)
    
        mail.Save()
    
        return "draft", getattr(mail, "EntryID", None)
    
    def reply_all(
        self,
        item,
        html,
        mode=None,
        account=None,
        signature=None        
    ):
    
        self.ensure_connected()
        
        if signature is None:
            signature = load_outlook_signature() or ""
    
        reply = item.ReplyAll()
    
        try:

            if account:
                self.set_account_by_smtp(account)

            if self.selected_account:
                reply.SendUsingAccount = self.selected_account
    
        except Exception:
            pass
    
        final_html = (
            (html or "")
            + signature
            + "<br>"
            + str(getattr(reply, "HTMLBody", "") or "")
        )
    
        reply.HTMLBody = final_html
    
        if str(mode).lower() == "send":
    
            reply.Send()
    
            return "sent", getattr(reply, "EntryID", None)
    
        reply.Save()
    
        return "draft", getattr(reply, "EntryID", None)
    