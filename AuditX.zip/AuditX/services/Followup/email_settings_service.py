from __future__ import annotations
 
from typing import Any
 
from database.connection import Database
from database.db_config import DB_CONFIG_AUDITFOLLOWUP
 
 
class EmailSettingsService:
    """
    Obtiene la configuración de correo correspondiente
    al cliente y proyecto seleccionados.
 
    Prioridad:
        1. Configuración específica del cliente y proyecto.
        2. Configuración general del cliente, con ProjectID NULL.
    """
 
    def __init__(self, db: Database | None = None):
        # Se permite inyectar una conexión para pruebas.
        # Por defecto utiliza PRGX_AUDITFOLLOWUP.
        self.db = db or Database(
            DB_CONFIG_AUDITFOLLOWUP
        )
 
    def get_email_settings(
        self,
        client_id: int,
        project_id: int | None = None
    ) -> dict[str, Any] | None:
        """
        Recupera la configuración activa de correo.
 
        Args:
            client_id:
                Identificador obligatorio del cliente.
 
            project_id:
                Identificador opcional del proyecto.
 
        Returns:
            Diccionario con la configuración encontrada
            o None cuando no existe configuración activa.
        """
 
        if client_id in (None, ""):
            raise ValueError(
                "ClientID es obligatorio para obtener "
                "la configuración del correo."
            )
 
        sql = """
            SELECT TOP 1
                EmailSettingID,
                ClientID,
                ProjectID,
                SendMode,
                DefaultTemplateCode,
                SignatureName,
                AutoSendEnabled,
                IsEnabled
            FROM dbo.EmailSettings
            WHERE ClientID = ?
              AND IsEnabled = 1
              AND (
                    ProjectID = ?
                    OR ProjectID IS NULL
                  )
            ORDER BY
                CASE
                    WHEN ProjectID = ? THEN 0
                    ELSE 1
                END,
                EmailSettingID DESC;
        """
 
        return self.db.fetch_one(
            sql,
            (
                int(client_id),
                project_id,
                project_id
            )
        )
 
    def get_effective_settings(
        self,
        client_id: int,
        project_id: int | None = None
    ) -> dict[str, Any]:
        """
        Devuelve siempre una configuración utilizable.
 
        Si no existe un registro en EmailSettings,
        devuelve valores seguros por defecto.
        """
 
        settings = self.get_email_settings(
            client_id=client_id,
            project_id=project_id
        )
 
        if not settings:
            return {
                "EmailSettingID": None,
                "ClientID": client_id,
                "ProjectID": project_id,
                "SendMode": "DRAFT",
                "DefaultTemplateCode": "FIRST_EMAIL",
                "SignatureName": None,
                "AutoSendEnabled": False,
                "IsEnabled": True
            }
 
        return {
            **settings,
            "SendMode": (
                settings.get("SendMode")
                or "DRAFT"
            ).upper(),
            "DefaultTemplateCode": (
                settings.get("DefaultTemplateCode")
                or "FIRST_EMAIL"
            ),
            "AutoSendEnabled": bool(
                settings.get("AutoSendEnabled", False)
            )
        }    