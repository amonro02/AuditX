initGlobalUI();
 
function initGlobalUI() {
    initSidebarToggle();
    initUserMenu();
}
 
function initSidebarToggle() {
    const btn = document.getElementById("toggleSidebar");
    const sidebar = document.getElementById("sidebar");
 
    if (!btn || !sidebar) return;
 
    btn.addEventListener("click", () => {
        sidebar.classList.toggle("collapsed");
    });
}
 
function initUserMenu() {
    const userBtn = document.getElementById("userMenuBtn");
    const menu = document.getElementById("userMenu");
 
    if (!userBtn || !menu) return;
 
    userBtn.addEventListener("click", () => {
        menu.classList.toggle("open");
    });
 
    document.addEventListener("click", (e) => {
        if (!userBtn.contains(e.target)) {
            menu.classList.remove("open");
        }
    });
} 

let globalLoadingTimer = null;
let globalLoadingStart = null;
 
window.showGlobalLoading = function (
  title = "Loading...",
  subtitle = "AuditX is processing your request"
) {
  const modal = document.getElementById("globalLoadingModal");
  const text = document.getElementById("globalLoadingText");
  const sub = document.getElementById("globalLoadingSubtitle");
  const time = document.getElementById("globalLoadingTime");
 
  if (!modal) return;
 
  if (text) text.textContent = title;
  if (sub) sub.textContent = subtitle;
  if (time) time.textContent = "00:00";
 
  globalLoadingStart = Date.now();
  clearInterval(globalLoadingTimer);
 
  globalLoadingTimer = setInterval(() => {
    const sec = Math.floor((Date.now() - globalLoadingStart) / 1000);
    const mm = String(Math.floor(sec / 60)).padStart(2, "0");
    const ss = String(sec % 60).padStart(2, "0");
    if (time) time.textContent = `${mm}:${ss}`;
  }, 300);
 
  modal.classList.remove("hidden");
};
 
window.hideGlobalLoading = function () {
  const modal = document.getElementById("globalLoadingModal");
 
  clearInterval(globalLoadingTimer);
  globalLoadingTimer = null;
  globalLoadingStart = null;
 
  if (modal) modal.classList.add("hidden");
};
