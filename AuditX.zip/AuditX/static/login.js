console.log("LOGIN JS LOADED");
 
document.addEventListener("DOMContentLoaded", () => {
    console.log("DOM READY LOGIN");
 
    const form = document.getElementById("loginForm");
 
    if (!form) {
        console.error("loginForm not found");
        return;
    }
 
    form.addEventListener("submit", async (event) => {
        event.preventDefault();
 
        console.log("🔥 CLICK DETECTED");
 
        const emailInput = document.getElementById("email");
        const message = document.getElementById("loginMessage");
        const button = document.getElementById("btnLogin");
 
        const email = emailInput.value.trim();
 
        if (!email) {
            showMessage(message, "Enter your email.", "error");
            return;
        }
 
        button.disabled = true;
        button.textContent = "Checking...";
 
        try {
            const response = await fetch("/api/login-email", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ email })
            });
 
            const data = await response.json();
 
            console.log("📦 Response:", data);
 
            if (!response.ok || data.success !== true) {
                showMessage(message, data.message || "Login error.", "error");
                return;
            }
 
            window.location.href = data.redirect;
 
        } catch (error) {
            console.error("LOGIN ERROR:", error);
            showMessage(message, "Connection error.", "error");
        } finally {
            button.disabled = false;
            button.textContent = "Continue";
        }
    });
});
 
function showMessage(element, text, type) {
    if (!element) return;
    element.textContent = text;
    element.className = `message ${type}`;
}