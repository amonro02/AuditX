 
import "/static/js/pages/data_download/index.js";
 
console.warn("⚠️ datadownload.js es legacy. Usa modules.");


