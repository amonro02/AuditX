function togglePlanningMenu() {
 
    const planningMenu =
        document.querySelector(".planning-menu");
 
    const toggle =
        document.getElementById("planningToggle");
 
    if (!planningMenu || !toggle) {
        return;
    }
 
    planningMenu.classList.toggle("open");
 
    const isOpen =
        planningMenu.classList.contains("open");
 
    toggle.setAttribute(
        "aria-expanded",
        isOpen ? "true" : "false"
    );
}
 
 
/* Abrir automáticamente cuando
   estamos dentro de Planning */
 
document.addEventListener("DOMContentLoaded", function () {
 
    const currentPath =
        window.location.pathname.toLowerCase();
 
    if (currentPath.startsWith("/planning")) {
 
        const planningMenu =
            document.querySelector(".planning-menu");
 
        const toggle =
            document.getElementById("planningToggle");
 
        if (planningMenu && toggle) {
 
            planningMenu.classList.add("open");
 
            toggle.setAttribute(
                "aria-expanded",
                "true"
            );
        }
    }
});
 