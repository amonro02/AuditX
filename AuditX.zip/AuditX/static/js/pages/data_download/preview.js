// pages/data_download/preview.js
 
import { state } from "./state.js";
 
export function renderPreview(columns, rows) {
    state.previewColumns = columns || [];
    state.previewRows = rows || [];
    state.page = 1;
    state.pageSize = state.pageSize || 10;
    state.columnFilters = state.columnFilters || {};
    state.selectedRowKeys = new Set();
 
    if (!state.visibleColumns || !state.visibleColumns.length) {
        state.visibleColumns = state.previewColumns.slice(0, 8);
    }
 
    renderPreviewTable();
    updatePageInfo();
}
 
export function getFilteredRows() {
    const rows = state.previewRows || [];
    const columns = state.previewColumns || [];
    const filters = state.columnFilters || {};
 
    return rows.filter(row => {
        return Object.entries(filters).every(([col, cfg]) => {
            if (!cfg) return true;
 
            const idx = columns.indexOf(col);
            if (idx < 0) return true;
 
            const rawValue = row[idx];
            const cell = String(rawValue ?? "").toLowerCase();
 
            const mode = cfg.mode || "contains";
            const value = String(cfg.value ?? "").toLowerCase();
            const value2 = String(cfg.value2 ?? "").toLowerCase();
 
            if (!value && !["is_null", "is_not_null"].includes(mode)) return true;
 
            switch (mode) {
                case "equals":
                    return cell === value;
 
                case "not_equals":
                    return cell !== value;
 
                case "contains":
                    return cell.includes(value);
 
                case "starts_with":
                    return cell.startsWith(value);
 
                case "ends_with":
                    return cell.endsWith(value);
 
                case "greater":
                    return Number(cell) > Number(value);
 
                case "less":
                    return Number(cell) < Number(value);
 
                case "greater_equal":
                    return Number(cell) >= Number(value);
 
                case "less_equal":
                    return Number(cell) <= Number(value);
 
                case "between":
                    return Number(cell) >= Number(value) && Number(cell) <= Number(value2);
 
                case "is_null":
                    return rawValue === null || rawValue === undefined || rawValue === "";
 
                case "is_not_null":
                    return rawValue !== null && rawValue !== undefined && rawValue !== "";
 
                default:
                    return cell.includes(value);
            }
        });
    });
}
 
export function renderPreviewTable() {
    const box = document.getElementById("previewTable");
    if (!box) return;
 
    const allColumns = state.previewColumns || [];
    const filteredRows = getFilteredRows();
 
    const visibleColumns =
        state.visibleColumns && state.visibleColumns.length
            ? state.visibleColumns
            : allColumns.slice(0, 8);
 
    const pageSize = state.pageSize || 10;
    const totalRows = state.previewRows?.length || 0;
    const totalPages = Math.max(1, Math.ceil(filteredRows.length / pageSize));
 
    if (!state.page || state.page < 1) state.page = 1;
    if (state.page > totalPages) state.page = totalPages;
 
    const currentPage = state.page;
    const start = (currentPage - 1) * pageSize;
    const pageRows = filteredRows.slice(start, start + pageSize);
 
    let html = "";
 
    html += `<table class="preview-table">`;
 
    html += `<colgroup>`;
    html += `<col class="col-check">`;
 
    visibleColumns.forEach(col => {
        const width = getColumnWidth(col, pageRows, allColumns);
        html += `<col style="width:${width}px;">`;
    });
 
    html += `</colgroup>`;
 
    html += `<thead>`;
 
    html += `<tr>`;
    html += `<th class="check-col">✓</th>`;
 
    visibleColumns.forEach(col => {
        html += `<th title="${escapeHtml(col)}">${escapeHtml(col)}</th>`;
    });
 
    html += `</tr>`;
 
    html += `<tr class="filter-row">`;
    html += `<th class="check-col"></th>`;
 
    visibleColumns.forEach(col => {
        const cfg = state.columnFilters?.[col] || {
            mode: "contains",
            value: "",
            value2: ""
        };
 
        const isBetween = cfg.mode === "between";
        const isNullMode = cfg.mode === "is_null" || cfg.mode === "is_not_null";
 
        html += `
            <th>
                <div class="excel-filter-wrap" data-col="${escapeHtml(col)}">
                    <button
                        class="excel-filter-btn"
                        type="button"
                        data-col="${escapeHtml(col)}"
                        title="Filter options">
                        ${getFilterIcon(cfg.mode)}
                    </button>
 
                    <div class="excel-filter-inputs ${isBetween ? "is-between" : ""}">
                        ${
                            isBetween
                                ? `
                                    <input
                                        class="excel-filter-value"
                                        data-type="from"
                                        data-col="${escapeHtml(col)}"
                                        value="${escapeHtml(cfg.value || "")}"
                                        placeholder="Min"
                                    >
                                    <input
                                        class="excel-filter-value"
                                        data-type="to"
                                        data-col="${escapeHtml(col)}"
                                        value="${escapeHtml(cfg.value2 || "")}"
                                        placeholder="Max"
                                    >
                                `
                                : isNullMode
                                    ? ``
                                    : `
                                        <input
                                            class="excel-filter-value"
                                            data-col="${escapeHtml(col)}"
                                            value="${escapeHtml(cfg.value || "")}"
                                            placeholder="Filter"
                                        >
                                    `
                        }
                    </div>
                </div>
            </th>
        `;
    });
 
    html += `</tr>`;
    html += `</thead>`;
 
    html += `<tbody>`;
 
    pageRows.forEach((row, rowIndex) => {
        html += `<tr>`;
 
    const rowKey = getRowKey(row, start + rowIndex);
    const isChecked = state.selectedRowKeys?.has(rowKey);
    
    html += `
        <td class="check-col">
            <input
                type="checkbox"
                class="row-check"
                data-row-index="${start + rowIndex}"
            >
        </td>
    `;
 
        visibleColumns.forEach(col => {
            const idx = allColumns.indexOf(col);
            const value = Array.isArray(row) ? row[idx] : row[col];
 
            html += `<td title="${escapeHtml(formatCell(value))}">
                ${escapeHtml(formatCell(value))}
            </td>`;
        });
 
        html += `</tr>`;
    });
 
    if (!pageRows.length) {
        html += `
            <tr>
                <td colspan="${visibleColumns.length + 1}" class="empty-preview">
                    No records found
                </td>
            </tr>
        `;
    }
 
    html += `</tbody>`;
    html += `</table>`;
 
    box.innerHTML = html;
    
    bindPreviewFilterEvents();
    bindRowSelectionEvents();
    
    updateCounters(
        filteredRows.length,
        totalRows,
        visibleColumns.length,
        totalPages
    );
    
    updatePageInfo();
}

export function updatePageInfo() {
    const filteredRows = getFilteredRows();
    const pageSize = state.pageSize || 10;
    const totalPages = Math.max(1, Math.ceil(filteredRows.length / pageSize));
 
    if (!state.page || state.page < 1) {
        state.page = 1;
    }
 
    if (state.page > totalPages) {
        state.page = totalPages;
    }
 
    setText("previewPageInfo", `Page ${state.page} of ${totalPages}`);
    setText("previewPageCounter", `📄 Page ${state.page} / ${totalPages}`);
 
    const totalRows = (state.previewRows || []).length;
    const visibleColumns = (state.visibleColumns || []).length;
 
    updateCounters(
        filteredRows.length,
        totalRows,
        visibleColumns,
        totalPages
    );
}
 
function updateCounters(filteredRows, totalRows, visibleColumns, totalPages) {
    const hasFilters = Object.values(state.columnFilters || {}).some(cfg => {
        return cfg &&
            (
                cfg.value ||
                cfg.value2 ||
                cfg.mode === "is_null" ||
                cfg.mode === "is_not_null"
            );
    });

    const columnsCount = Array.isArray(state.visibleColumns)
    ? state.visibleColumns.length
    : 0;
 
    setText(
        "previewFilteredCounter",
        hasFilters ? `🔎 ${formatNumber(filteredRows)} filtered` : "🔎 No filters"
    );
 
    setText(
        "previewTotalCounter",
        `📊 ${formatNumber(totalRows)} total`
    );
 
    setText(
        "previewColumnsCounter",
        `☘️ ${formatNumber(columnsCount)} columns`
    );
 
    setText(
        "previewPageCounter",
        `📄 Page ${state.page || 1} / ${totalPages || 1}`
    );
}
 
function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}
 
function formatCell(value) {
    if (value === null || value === undefined) return "";
 
    const text = String(value);
 
    if (text.includes("GMT")) {
        const d = new Date(text);
        if (!isNaN(d.getTime())) {
            return d.toLocaleDateString("es-MX", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric"
            });
        }
    }
 
    return text;
}

function formatNumber(n) {
    return Number(n || 0).toLocaleString("en-US");
}
 
function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function bindPreviewFilterEvents() {
    document.querySelectorAll(".excel-filter-btn").forEach(btn => {
        btn.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();
 
            const col = btn.dataset.col;
            const rect = btn.getBoundingClientRect();
            const menu = getOrCreateFilterMenu();
 
            menu.dataset.col = col;
            menu.style.left = `${rect.left}px`;
            menu.style.top = `${rect.bottom + 4}px`;
 
            menu.classList.toggle("excel-menu-hidden");
        };
    });
 
    document.querySelectorAll(".excel-filter-value").forEach(input => {
 
    input.onkeydown = (e) => {
        if (e.key !== "Enter") return;
 
        e.preventDefault();
 
        const col = input.dataset.col;
        const type = input.dataset.type;
 
        if (!state.columnFilters[col]) {
            state.columnFilters[col] = {
                mode: "contains",
                value: "",
                value2: ""
            };
        }
 
        if (type === "from") {
            state.columnFilters[col].value = input.value;
        } else if (type === "to") {
            state.columnFilters[col].value2 = input.value;
        } else {
            state.columnFilters[col].value = input.value;
        }
 
        state.page = 1;
        renderPreviewTable();
        updatePageInfo();
    };
 
});


    const menu = getOrCreateFilterMenu();
 
    menu.querySelectorAll("button").forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
 
            const col = menu.dataset.col;
            const mode = btn.dataset.mode;
 
            state.columnFilters[col] = {
                mode,
                value: "",
                value2: ""
            };
 
            menu.classList.add("excel-menu-hidden");
 
            state.page = 1;
            renderPreviewTable();
            updatePageInfo();
        };
    });
 
    document.onclick = () => {
        getOrCreateFilterMenu().classList.add("excel-menu-hidden");
    };
}

function getOrCreateFilterMenu() {
    let menu = document.getElementById("floatingFilterMenu");
 
    if (!menu) {
        menu = document.createElement("div");
        menu.id = "floatingFilterMenu";
        menu.className = "floating-filter-menu excel-menu-hidden";
 
        menu.innerHTML = `
            <button type="button" data-mode="contains">☰ Contains</button>
            <button type="button" data-mode="eq">= Equal</button>
            <button type="button" data-mode="neq">≠ Not equal</button>
            <button type="button" data-mode="gt">&gt; Greater</button>
            <button type="button" data-mode="lt">&lt; Less</button>
            <button type="button" data-mode="gte">≥ Greater or equal</button>
            <button type="button" data-mode="lte">≤ Less or equal</button>
            <button type="button" data-mode="between">⇄ Between</button>
            <button type="button" data-mode="is_null">∅ Is null</button>
            <button type="button" data-mode="is_not_null">● Not null</button>
        `;
 
        document.body.appendChild(menu);
    }
 
    return menu;
}

function getColumnWidth(col, rows, allColumns) {
    const idx = allColumns.indexOf(col);
 
    const headerLen = String(col || "").length;
 
    let maxLen = headerLen;
 
    rows.slice(0, 50).forEach(row => {
        const value = Array.isArray(row) ? row[idx] : row[col];
        maxLen = Math.max(maxLen, String(value ?? "").length);
    });
 
    if (maxLen <= 6) return 75;
    if (maxLen <= 10) return 95;
    if (maxLen <= 16) return 120;
    if (maxLen <= 25) return 155;
 
    return 190;
}

function getFilterIcon(mode) {
    const icons = {
        contains: "☰",
        eq: "=",
        neq: "≠",
        gt: ">",
        lt: "<",
        gte: "≥",
        lte: "≤",
        between: "⇄",
        is_null: "Ø",
        is_not_null: "●"
    };
 
    return icons[mode || "contains"] || "☰";
}

function bindRowSelectionEvents() {
    if (!state.selectedRowKeys) {
        state.selectedRowKeys = new Set();
    }
 
    document.querySelectorAll(".row-check").forEach(chk => {
        chk.addEventListener("change", () => {
            const key = chk.dataset.rowKey;
 
            if (!key) return;
 
            if (chk.checked) {
                state.selectedRowKeys.add(key);
            } else {
                state.selectedRowKeys.delete(key);
            }
 
            console.log("Selected rows:", state.selectedRowKeys.size);
        });
    });
}

function getRowKey(row, index) {
    const cols = state.previewColumns || [];
 
    const values = cols.slice(0, 5).map(col => {
        const idx = cols.indexOf(col);
        return Array.isArray(row) ? row[idx] : row[col];
    });
 
    return `${index}_${values.join("|")}`;
}


