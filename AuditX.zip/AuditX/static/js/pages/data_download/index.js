import { state } from "./state.js";
import { openExportModal, closeExportModal, confirmExport } from "./export_excel.js";
import {
    addEmptyFilter,
    clearQueryBuilder,
    renderFilters,
    updateGeneratedSql
} from "./query_builder.js"; 
import {
    renderPreview,
    renderPreviewTable,
    updatePageInfo,
    getFilteredRows
} from "./preview.js";

let processingInterval = null;
let processingStartTime = null;
 
document.addEventListener("DOMContentLoaded", () => {
    initDataDownload();
});
 
async function initDataDownload() {
    state.currentUserKey = state.currentUserKey || "default_user";
    state.top = 1000;
    state.page = 1;
    state.pageSize = state.pageSize || 25;
    state.columnFilters = {};
    state.visibleColumns = [];
    state.filters = [];
 
    bindEvents();
    initPreviewCounters();
    resetQueryUI();
    resetPreviewUI();
 
    await loadProjects();
}
 
/* =========================================================
   EVENTS
========================================================= */
 


function bindEvents() {
    const btnLoadFields = document.getElementById("btnLoadFields");
    const btnAddFilter = document.getElementById("btnAddFilter");
    const btnClearQuery = document.getElementById("btnClearQuery");
    const btnRunQuery = document.getElementById("btnRunQuery");
 
    console.log("QB buttons:", {
        btnLoadFields,
        btnAddFilter,
        btnClearQuery,
        btnRunQuery
    });
 
    btnLoadFields?.addEventListener("click", async () => {
        console.log("Load fields clicked");
 
        if (!state.selectedDataListId) {
            alert("Select a Data List first.");
            return;
        }
 
        await loadQueryFields(state.selectedDataListId);
        renderFilters();
        updateGeneratedSql();
        bindEvents();
        initPreviewUI(); 
    });
 
    btnAddFilter?.addEventListener("click", async () => {
        console.log("Add filter clicked");
 
        if (!state.selectedDataListId) {
            alert("Select a Data List first.");
            return;
        }
 
        if (!state.availableColumns || !state.availableColumns.length) {
            await loadQueryFields(state.selectedDataListId);
        }
 
        addEmptyFilter();
        renderFilters();
        updateGeneratedSql();
    });
 
    btnClearQuery?.addEventListener("click", () => {
        console.log("Clear query clicked");
 
        clearQueryBuilder();
        state.filters = [];
 
        renderFilters();
        updateGeneratedSql();
    });
 
    document.getElementById("btnRunQuery")?.addEventListener("click", async () => {

       
        showGlobalLoading("Running Query Builder", "AuditX is preparing your preview");
        
        try {
        await runQuery(true);
        } finally {
        hideGlobalLoading();
        }
    });
 
    document.getElementById("queryTop")?.addEventListener("input", (e) => {
        state.top = e.target.value;
        updateGeneratedSql();
    });
    
    document.getElementById("pageSizeSelect")?.addEventListener("change", (e) => {
        state.pageSize = parseInt(e.target.value, 10) || 25;
        state.page = 1;
 
        renderPreviewTable();
        updatePageInfo();
    });
 
    document.getElementById("btnPrevPage")?.addEventListener("click", () => {
        if (state.page > 1) {
            state.page--;
            renderPreviewTable();
            updatePageInfo();
        }
    });
 
    document.getElementById("btnNextPage")?.addEventListener("click", () => {
        const totalPages = Math.max(
            1,
            Math.ceil(getFilteredRows().length / (state.pageSize || 25))
        );
 
        if (state.page < totalPages) {
            state.page++;
            renderPreviewTable();
            updatePageInfo();
        }
    });
 
    document.getElementById("btnClearPreviewFilters")?.addEventListener("click", async () => {
        state.columnFilters = {};
        state.page = 1;
 
        renderPreviewTable();
        updatePageInfo();
 
        if (typeof saveCurrentPreviewFilters === "function") {
            await saveCurrentPreviewFilters();
        }
    });
 
    document.getElementById("btnHidePreview")?.addEventListener("click", () => {
        const tableWrap = document.querySelector(".preview-table-container");
        const footer = document.querySelector(".preview-footer");
        const btn = document.getElementById("btnHidePreview");
 
        tableWrap?.classList.toggle("hidden");
        footer?.classList.toggle("hidden");
 
        if (btn) {
           btn.innerHTML = tableWrap?.classList.contains("hidden")
                ? `<span>👁</span> Show`
                : `<span>🙈</span> Hide`;  

        }
    });
 
    // =========================
    // CONFIGURE VIEW
    // =========================
    
    document.getElementById("btnConfigureView")?.addEventListener("click", () => {
        openViewConfig();
    });
    
    document.getElementById("btnCloseViewConfig")?.addEventListener("click", () => {
        closeViewConfig();
    });
        
    document.getElementById("btnSaveView")?.addEventListener("click", async () => {
        await saveViewConfig();
    });

    const searchInput = document.getElementById("columnSearchInput");
    
    searchInput?.addEventListener("input", () => {
        renderColumnChecklist();
    });
    
    document.getElementById("btnClearColumnSearch")?.addEventListener("click", () => {
        if (searchInput) searchInput.value = "";
        renderColumnChecklist();
    });

    document.getElementById("btnSelectAllColumns")?.addEventListener("click", () => {
        setColumnChecklistSelection(state.availableColumns || []);
    });
    
    document.getElementById("btnClearAllColumns")?.addEventListener("click", () => {
        setColumnChecklistSelection([]);
    });
    
    document.getElementById("btnSelectFirst8Columns")?.addEventListener("click", () => {
        setColumnChecklistSelection((state.availableColumns || []).slice(0, 8));
    });
    
    document.getElementById("btnResetViewConfig")?.addEventListener("click", () => {
        setColumnChecklistSelection((state.availableColumns || []).slice(0, 8));
        state.columnFilters = {};
        state.pageSize = 25;
    
        const pageSizeSelect = document.getElementById("pageSizeSelect");
        if (pageSizeSelect) pageSizeSelect.value = "25";
    });    
    
    
    // =========================
    // EXPORT
    // =========================  
 
    document.getElementById("btnExportExcel")?.addEventListener("click", () => {
        openExportModal();
    });
    
    document.getElementById("btnCancelExport")?.addEventListener("click", () => {
        closeExportModal();
    });
    
    document.getElementById("btnConfirmExport")?.addEventListener("click", () => {
        confirmExport();
    });
    
    document.querySelectorAll("input[name='exportType']").forEach(radio => {
        radio.addEventListener("change", () => {
            document.querySelectorAll(".export-option-card").forEach(card => {
                card.classList.remove("selected");
            });
    
            radio.closest(".export-option-card")?.classList.add("selected");
        });
    });
    

}

/* =========================================================
   PROJECTS
========================================================= */
async function loadProjects() {
    try {
        const res = await fetch("/api/projects");
        const data = await res.json();
 
        console.log("PROJECTS API:", data);
 
        if (!res.ok || data.success === false || data.ok === false) {
            alert(data.message || "Error loading projects.");
            return;
        }
 
        const rows = data.projects || data.rows || [];
 
        const box = document.getElementById("projectsList");
        if (!box) return;
 
        box.innerHTML = "";
 
        rows.forEach(item => {
            const projectId = item.ProjectID || item.projectId;
            const projectName = item.ProjectName || item.projectName;
 
            const div = document.createElement("div");
            div.className = "dd-item";
            div.textContent = projectName;
            div.dataset.projectId = projectId;
 
            div.addEventListener("click", async () => {
                document
                    .querySelectorAll("#projectsList .dd-item")
                    .forEach(x => x.classList.remove("active", "selected"));
 
                div.classList.add("active");
 
                state.selectedProjectId = projectId;
                state.selectedProject = projectName;
                state.selectedReportListId = null;
                state.selectedReport = null;
                state.selectedDataListId = null;
 
                clearList("reportsList");
                clearList("dataLists");
 
                resetDataListState();
                resetQueryUI();
                resetPreviewUI();
 
                await loadReports(projectId);
            });
 
            box.appendChild(div);
        });
 
    } catch (err) {
        console.error("loadProjects error:", err);
        alert("Error loading projects.");
    }
}

 
/* =========================================================
   REPORTS
========================================================= */
 
async function loadReports(projectId) {
    try {
        const res = await fetch(`/api/reports?projectId=${encodeURIComponent(projectId)}`);
        const data = await res.json();
 
        if (!data.ok) {
            alert(data.message || "Error loading reports.");
            return;
        }
 
        const box = document.getElementById("reportsList");
        if (!box) return;
 
        box.innerHTML = "";
 
        (data.rows || []).forEach(item => {
            const div = document.createElement("div");
            div.className = "dd-item";
            div.textContent = item.reportName;
            div.dataset.reportListId = item.reportListId;
 
            div.addEventListener("click", async () => {
                document
                    .querySelectorAll("#reportsList .dd-item")
                    .forEach(x => x.classList.remove("active", "selected"));
 
                div.classList.add("active");
 
                state.selectedReportListId = item.reportListId;
                state.selectedReport = item.reportName;
 
                state.selectedDataListId = null;
 
                clearList("dataLists");
 
                resetDataListState();
                resetQueryUI();
                resetPreviewUI();
 
                await loadDataLists(item.reportListId);
            });
 
            box.appendChild(div);
        });
 
    } catch (err) {
        console.error("loadReports error:", err);
        alert("Error loading reports.");
    }
}
 
/* =========================================================
   DATA LISTS
========================================================= */
 
async function loadDataLists(reportListId) {
    try {
        const res = await fetch(`/api/data-lists?reportListId=${encodeURIComponent(reportListId)}`);
        const data = await res.json();
 
        if (!data.ok) {
            alert(data.message || "Error loading data lists.");
            return;
        }
 
        const box = document.getElementById("dataLists");
        if (!box) return;
 
        box.innerHTML = "";
 
        (data.rows || []).forEach(item => {
            const div = document.createElement("div");
            div.className = "dd-item";
            div.textContent = item.tableName;
            div.dataset.dataListId = item.dataListId;
 
            div.addEventListener("click", async () => {
                document
                    .querySelectorAll("#dataLists .dd-item")
                    .forEach(x => x.classList.remove("active", "selected"));
 
                div.classList.add("active");
 
                state.selectedDataListId = item.dataListId;
 
                state.filters = [];
                state.columnFilters = {};
                state.top = 1000;
                state.page = 1;
 
                state.selectedTable = null;
                state.selectedServer = null;
                state.selectedDatabase = null;
 
                state.availableColumns = [];
                state.previewColumns = [];
                state.previewRows = [];
                state.visibleColumns = [];
 
                resetQueryUI();
                resetPreviewUI();
 
                await loadDataListMeta(item.dataListId);
                await loadQueryFields(item.dataListId);
                await loadViewLayout(item.dataListId);
 
                renderFilters();
                updateGeneratedSql();
 
                showGlobalLoading("Load preview ...",""); 
                try {
                    await loadDataListMeta(item.dataListId);
                    await loadQueryFields(item.dataListId);
                    await loadViewLayout(item.dataListId);
            
                    state.page = 1;
                    await runQuery(false);
                } finally {
                    hideGlobalLoading();
                }

            });
 
            box.appendChild(div);
        });
 
    } catch (err) {
        console.error("loadDataLists error:", err);
        alert("Error loading data lists.");
    }
}
 
/* =========================================================
   METADATA / FIELDS
========================================================= */
 
async function loadDataListMeta(dataListId) {
    try {
        const res = await fetch(`/api/data-list-meta/${encodeURIComponent(dataListId)}`);
        const data = await res.json();
 
        if (!data.ok) {
            alert(data.message || "DataList metadata not found.");
            return;
        }
 
        const row = data.row?.row || data.row || {};
        
        state.selectedTable =
            row.tableName ||
            row.SQL_TableName ||
            row.LinkedTableName ||
            row.TableName ||
            "";
        
        state.selectedServer = row.server || row.SQL_Server || "";
        state.selectedDatabase = row.database || row.SQL_Database || "";
        
        console.log("TABLE SELECTED:", state.selectedTable);
        
        const tableInput = document.getElementById("selectedTable");
        
        if (tableInput) {
            tableInput.value = state.selectedTable;
        }

    } catch (err) {
        console.error("loadDataListMeta error:", err);
        alert("Error loading DataList metadata.");
    }
}

async function loadQueryFields(dataListId) {
    try {
        const res = await fetch(`/api/query-fields/${encodeURIComponent(dataListId)}`);
        const data = await res.json();
 
        if (!data.ok) {
            alert(data.message || "Could not load fields.");
            return;
        }
 
        state.availableColumns = data.columns || [];
 
    } catch (err) {
        console.error("loadQueryFields error:", err);
        alert("Error loading fields.");
    }
}
 
/* =========================================================
   LAYOUT CONFIGURATION
========================================================= */
 async function loadViewLayout(dataListId) {
    try {
        const url = `/api/layout/load/${encodeURIComponent(dataListId)}?userKey=${encodeURIComponent(state.currentUserKey || "anonymous")}`;
        const res = await fetch(url);
 
        if (!res.ok) {
            console.warn("Layout endpoint failed.");
            state.visibleColumns = state.availableColumns.slice(0, 8);
            state.columnFilters = {};
            state.pageSize = 25;
            return;
        }
 
        const data = await res.json();
 
        if (data.ok && Array.isArray(data.layout) && data.layout.length) {
            // layout guardado
            state.visibleColumns = data.layout;
        } else {
            // SIN layout → primeras 8 columnas
            state.visibleColumns = (state.availableColumns || data.columns || []).slice(0, 8);
        }
        
        // limpieza de seguridad
        state.visibleColumns = state.visibleColumns.filter(col =>
            (state.availableColumns || data.columns || []).includes(col)
        );
        
        if (data.ok && Array.isArray(data.filters)) {
            state.columnFilters = convertSavedFiltersToColumnFilters(data.filters);
        } else {
            state.columnFilters = {};
        }
 
        if (data.ok && data.pageSize) {
            state.pageSize = Number(data.pageSize) || 25;
 
            const pageSizeSelect = document.getElementById("pageSize");
            if (pageSizeSelect) pageSizeSelect.value = String(state.pageSize);
        }
 
    } catch (err) {
        console.error("loadViewLayout error:", err);
        state.visibleColumns = state.availableColumns.slice(0, 8);
        state.columnFilters = {};
        state.pageSize = 25;
    }
}
 
 
function convertSavedFiltersToColumnFilters(filters) {
    const result = {};
 
    (filters || []).forEach(f => {
        if (!f.field) return;
 
        result[f.field] = {
            mode: f.mode || f.operator || "contains",
            value: f.value || "",
            value2: f.value2 || ""
        };
    });
 
    return result;
}
 
function openViewConfig() {
    const modal = document.getElementById("viewConfigModal");
    const box = document.getElementById("columnChecklist");
 
    if (!modal || !box) return;
 
    box.innerHTML = "";
 
    const columns = state.availableColumns?.length
        ? state.availableColumns
        : state.previewColumns;
 
    const visible = state.visibleColumns?.length
        ? state.visibleColumns
        : columns.slice(0, 8);
 
    columns.forEach(col => {
        const label = document.createElement("label");
        label.className = "check-row";
 
        const checked = visible.includes(col) ? "checked" : "";
 
        label.innerHTML = `
            <input type="checkbox" value="${escapeHtml(col)}" ${checked}>
            <span>${escapeHtml(col)}</span>
        `;
 
        box.appendChild(label);
    });
 
    modal.classList.remove("hidden");
}
 
function closeViewConfig() {
    document.getElementById("viewConfigModal")?.classList.add("hidden");
}
 
async function saveViewConfig() {
    const checked = document.querySelectorAll(
        "#columnChecklist input[type='checkbox']:checked"
    );
 
    const selectedColumns = Array.from(checked).map(x => x.value);
 
    if (!selectedColumns.length) {
        alert("Select at least one column.");
        return;
    }
 
    state.visibleColumns = selectedColumns;
    state.page = 1;
 
    try {
        const res = await fetch("/api/layout/save-columns", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                userKey: state.currentUserKey || "anonymous",
                dataListId: state.selectedDataListId,
                columns: state.visibleColumns
            })
        });
 
        const data = await res.json();
 
        if (!data.ok) {
            alert(data.message || "Could not save view configuration.");
            return;
        }
 
        closeViewConfig();
 
        renderPreviewTable();
        updatePageInfo();
 
        const columnsCounter = document.getElementById("previewColumnsCounter");
        if (columnsCounter) {
            columnsCounter.textContent = `🧩 ${state.visibleColumns.length} columns`;
        }
 
    } catch (err) {
        console.error("saveViewConfig error:", err);
        alert("Error saving view configuration.");
    }
}
 
/* =========================================================
   RUN QUERY / PREVIEW
========================================================= */
 async function runQuery(showModal = true) {
    if (!state.selectedDataListId) {
        alert("Select a Data List first.");
        return;
    }
 
    const topInput = document.getElementById("queryTop");
    const rawTop = topInput ? String(topInput.value || "").trim() : "";
 
    let top = null;
 
    if (rawTop !== "") {
        top = Math.max(1, parseInt(rawTop, 10) || 1);
    }
 
    state.top = rawTop;
 
    updateGeneratedSql();
 
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 120000);
 
    try {
        const res = await fetch("/api/query-design-preview", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            signal: controller.signal,
            body: JSON.stringify({
                dataListId: state.selectedDataListId,
                filters: state.filters || [],
                top: top
            })
        });
 
        clearTimeout(timeoutId);
 
        const data = await res.json();
 
        if (!data.ok) {
            alert(data.message || "Query error");
            return;
        }
 
        state.previewColumns = data.columns || [];
        state.previewRows = data.rows || [];
        state.page = 1;
 
        renderPreview(data.columns || [], data.rows || []);
 
    } catch (err) {
        clearTimeout(timeoutId);
 
        if (err.name === "AbortError") {
            alert("The query took longer than 120 seconds and was cancelled.");
        } else {
            console.error("runQuery error:", err);
            alert("Error running query.");
        }
 
    } finally {
        if (showModal) {
            hideGlobalLoading();
        }
    }
}

/* =========================================================
   SAVE FILTERS
========================================================= */

async function saveCurrentPreviewFilters() {
    if (!state.selectedDataListId) return;
 
    const filters = Object.entries(state.columnFilters || {})
        .filter(([field, cfg]) => cfg && (cfg.value || cfg.value2 || cfg.mode === "is_null" || cfg.mode === "is_not_null"))
        .map(([field, cfg]) => ({
            field: field,
            mode: cfg.mode || "contains",
            value: cfg.value || "",
            value2: cfg.value2 || ""
        }));
 
    try {
        await fetch("/api/layout/save-filters", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                userKey: state.currentUserKey || "anonymous",
                dataListId: state.selectedDataListId,
                filters: filters,
                pageSize: state.pageSize || 25
            })
        });
    } catch (err) {
        console.error("saveCurrentPreviewFilters error:", err);
    }
}
 
/* =========================================================
   EXPORT
========================================================= */
 
 
function getBaseExportRows() {
    return state.filteredPreviewRows?.length
        ? state.filteredPreviewRows
        : state.previewRows || [];
}
 
 
 
 
function getExportFileName() {
    const input = document.getElementById("exportFileName");
    let name = input?.value?.trim();
 
    if (!name) {
        name = `AuditX_${new Date().toISOString().slice(0,10)}`;
    }
 
    if (!name.toLowerCase().endsWith(".xlsx")) {
        name += ".xlsx";
    }
 
    return name;
}
 
/* =========================================================
   RESET / HELPERS
========================================================= */
 
function resetDataListState() {
    state.selectedDataListId = null;
    state.selectedTable = null;
    state.selectedServer = null;
    state.selectedDatabase = null;
 
    state.availableColumns = [];
    state.filters = [];
    state.top = 1000;
 
    state.previewColumns = [];
    state.previewRows = [];
    state.visibleColumns = [];
    state.columnFilters = {};
 
    state.page = 1;
}
 
function resetQueryUI() {
    const selectedTable = document.getElementById("selectedTable");
    const queryTop = document.getElementById("queryTop");
    const generatedSql = document.getElementById("generatedSql");
 
    if (selectedTable) selectedTable.value = "";
    if (queryTop) queryTop.value = "1000";
    if (generatedSql) generatedSql.textContent = "SELECT TOP 1000 * FROM ...";
 
    state.top = 1000;
 
    renderFilters();
    updateGeneratedSql();
}
 
function resetPreviewUI() {
    const previewTable = document.getElementById("previewTable");
    const pageInfo = document.getElementById("pageInfo");
 
    if (previewTable) previewTable.innerHTML = "";
    if (pageInfo) pageInfo.textContent = "Page 1 of 1";
 
    setCounter("previewFilteredCounter", "0 filtered");
    setCounter("previewTotalCounter", "0 total");
    setCounter("previewColumnCounter", "0 columns");
    setCounter("previewPageCounter", "Page 1 / 1");
}
 
function clearList(id) {
    const el = document.getElementById(id);
    if (el) el.innerHTML = "";
}
 
function setCounter(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
}
 
function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function initPreviewUI() {
    const stats = {
        filtered: 0,
        total: 0,
        columns: 0,
        page: "Page 1 / 1"
    };
 
    updatePreviewStats(stats);
}

function updatePreviewStats({ filtered, total, columns, page }) {
    document.getElementById("statFiltered").textContent = filtered || 0;
    document.getElementById("statTotal").textContent = total || 0;
    document.getElementById("statColumns").textContent = columns || 0;
    document.getElementById("statPage").textContent = page || "Page 1 / 1";
}

function initPreviewCounters() {
    const filtered = document.getElementById("previewFilteredCounter");
    const total = document.getElementById("previewTotalCounter");
    const columns = document.getElementById("previewColumnCounter");
    const page = document.getElementById("previewPageCounter");
 
    if (filtered) filtered.textContent = "🔎 No filters";
    if (total) total.textContent = "📊 0 total";
    if (columns) columns.textContent = "🧩 0 columns";
    if (page) page.textContent = "📄 Page 1 / 1";
}

function setColumnChecklistSelection(selectedColumns) {
    const selected = new Set(selectedColumns || []);
 
    document
        .querySelectorAll("#columnChecklist input[type='checkbox']")
        .forEach(input => {
            input.checked = selected.has(input.value);
        });
}

function renderColumnChecklist() {
    const list = document.getElementById("columnChecklist");
    if (!list) return;
 
    const search = (document.getElementById("columnSearchInput")?.value || "")
        .toLowerCase()
        .trim();
 
    const allColumns = state.availableColumns || [];
 
    // filtro en tiempo real
    const columns = allColumns.filter(col =>
        String(col).toLowerCase().includes(search)
    );
 
    list.innerHTML = "";
 
    columns.forEach(col => {
        const checked = (state.visibleColumns || []).includes(col);
 
        const item = document.createElement("label");
        item.className = "column-check-item";
 
        item.innerHTML = `
            <input type="checkbox" value="${col}" ${checked ? "checked" : ""}>
            <span>${col}</span>
        `;
 
        list.appendChild(item);
    });
 
    // mantener estado de selección
    list.querySelectorAll("input[type='checkbox']").forEach(input => {
        input.addEventListener("change", () => {
            const col = input.value;
 
            if (!Array.isArray(state.visibleColumns)) {
                state.visibleColumns = [];
            }
 
            if (input.checked) {
                if (!state.visibleColumns.includes(col)) {
                    state.visibleColumns.push(col);
                }
            } else {
                state.visibleColumns = state.visibleColumns.filter(c => c !== col);
            }
        });
    });
}


searchInput.addEventListener("input", () => {
    renderColumnChecklist();
});