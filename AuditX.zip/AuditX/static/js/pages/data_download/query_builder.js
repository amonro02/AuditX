import { state } from "./state.js";
 
export function addEmptyFilter() {
    state.filters = state.filters || [];
 
    state.filters.push({
        connector: state.filters.length === 0 ? "" : "AND",
        field: "",
        operator: "=",
        value: "",
        value2: ""
    });
}
 
export function clearQueryBuilder() {
    state.filters = [];
}
 
export function renderFilters() {
    const box = document.getElementById("filtersBox");
    if (!box) return;
 
    box.innerHTML = "";
 
    if (!state.filters || state.filters.length === 0) {
        box.innerHTML = `<div class="qb-empty">No filters added. Use +</div>`;
        return;
    }
 
    state.filters.forEach((filter, index) => {
        const row = document.createElement("div");
        row.className = "qb-row";
 
        const connectorHtml = index === 0
            ? `<div class="qb-connector-placeholder"></div>`
            : `
                <select class="qb-connector" data-index="${index}">
                    <option value="AND" ${filter.connector === "AND" ? "selected" : ""}>AND</option>
                    <option value="OR" ${filter.connector === "OR" ? "selected" : ""}>OR</option>
                </select>
            `;
 
        row.innerHTML = `
            ${connectorHtml}
 
            <select class="qb-field" data-index="${index}">
                <option value="">Field</option>
            </select>
 
            <select class="qb-operator" data-index="${index}">
                <option value="=" ${filter.operator === "=" ? "selected" : ""}>=</option>
                <option value="<>" ${filter.operator === "<>" ? "selected" : ""}>≠</option>
                <option value=">" ${filter.operator === ">" ? "selected" : ""}>></option>
                <option value="<" ${filter.operator === "<" ? "selected" : ""}><</option>
                <option value=">=" ${filter.operator === ">=" ? "selected" : ""}>≥</option>
                <option value="<=" ${filter.operator === "<=" ? "selected" : ""}>≤</option>
                <option value="LIKE" ${filter.operator === "LIKE" ? "selected" : ""}>LIKE</option>
                <option value="BETWEEN" ${filter.operator === "BETWEEN" ? "selected" : ""}>BTW</option>
                <option value="IN" ${filter.operator === "IN" ? "selected" : ""}>IN</option>
                <option value="IS NULL" ${filter.operator === "IS NULL" ? "selected" : ""}>NULL</option>
                <option value="IS NOT NULL" ${filter.operator === "IS NOT NULL" ? "selected" : ""}>NNULL</option>
            </select>
 
            <input
                class="qb-value"
                data-index="${index}"
                placeholder="Value"
                value="${escapeHtml(filter.value || "")}"
                ${isNullOperator(filter.operator) ? "disabled" : ""}
            >
 
            <input
                class="qb-value2 ${filter.operator === "BETWEEN" ? "" : "hidden"}"
                data-index="${index}"
                placeholder="Value 2"
                value="${escapeHtml(filter.value2 || "")}"
            >
 
            <button type="button" class="qb-remove" data-index="${index}">×</button>
        `;
 
        const fieldSelect = row.querySelector(".qb-field");
 
        (state.availableColumns || []).forEach(col => {
            const opt = document.createElement("option");
            opt.value = col;
            opt.textContent = col;
 
            if (filter.field === col) {
                opt.selected = true;
            }
 
            fieldSelect.appendChild(opt);
        });
 
        box.appendChild(row);
    });
 
    bindFilterEvents();
}
 
function bindFilterEvents() {
    document.querySelectorAll(".qb-connector").forEach(el => {
        el.addEventListener("change", () => {
            const index = Number(el.dataset.index);
            state.filters[index].connector = el.value;
            updateGeneratedSql();
        });
    });
 
    document.querySelectorAll(".qb-field").forEach(el => {
        el.addEventListener("change", () => {
            const index = Number(el.dataset.index);
            state.filters[index].field = el.value;
            updateGeneratedSql();
        });
    });
 
    document.querySelectorAll(".qb-operator").forEach(el => {
        el.addEventListener("change", () => {
            const index = Number(el.dataset.index);
            const filter = state.filters[index];
 
            filter.operator = el.value;
 
            if (isNullOperator(filter.operator)) {
                filter.value = "";
                filter.value2 = "";
            }
 
            if (filter.operator !== "BETWEEN") {
                filter.value2 = "";
            }
 
            renderFilters();
            updateGeneratedSql();
        });
    });
 
    document.querySelectorAll(".qb-value").forEach(el => {
        el.addEventListener("input", () => {
            const index = Number(el.dataset.index);
            state.filters[index].value = el.value;
            updateGeneratedSql();
        });
    });
 
    document.querySelectorAll(".qb-value2").forEach(el => {
        el.addEventListener("input", () => {
            const index = Number(el.dataset.index);
            state.filters[index].value2 = el.value;
            updateGeneratedSql();
        });
    });
 
    document.querySelectorAll(".qb-remove").forEach(el => {
        el.addEventListener("click", () => {
            const index = Number(el.dataset.index);
 
            state.filters.splice(index, 1);
 
            if (state.filters.length > 0) {
                state.filters[0].connector = "";
            }
 
            renderFilters();
            updateGeneratedSql();
        });
    });
}
 
export function updateGeneratedSql() {
    const sqlBox = document.getElementById("generatedSql");
    if (!sqlBox) return;
 
    const table = state.selectedTable || "...";
 
    const rawTop = String(state.top || "").trim();
 
    const useTop = rawTop !== "" && !isNaN(rawTop);
 
    let sql = useTop
        ? `SELECT TOP ${rawTop} * FROM ${table}`
        : `SELECT * FROM ${table}`;
 
    const validFilters = (state.filters || []).filter(f => {
        if (!f.field || !f.operator) return false;
 
        if (f.operator === "IS NULL" || f.operator === "IS NOT NULL") return true;
 
        if (f.operator === "BETWEEN") {
            return f.value !== "" && f.value2 !== "";
        }
 
        return f.value !== "";
    });
 
    if (validFilters.length > 0) {
        const where = validFilters.map((f, index) => {
            const prefix = index === 0 ? "" : ` ${f.connector || "AND"} `;
            const field = `[${f.field}]`;
 
            if (f.operator === "IS NULL" || f.operator === "IS NOT NULL") {
                return `${prefix}${field} ${f.operator}`;
            }
 
            if (f.operator === "BETWEEN") {
                return `${prefix}${field} BETWEEN '${escapeSql(f.value)}' AND '${escapeSql(f.value2)}'`;
            }
 
            if (f.operator === "IN") {
                return `${prefix}${field} IN (${buildInValues(f.value)})`;
            }
 
            if (f.operator === "LIKE") {
                return `${prefix}${field} LIKE '%${escapeSql(f.value)}%'`;
            }
 
            return `${prefix}${field} ${f.operator} '${escapeSql(f.value)}'`;
        }).join("");
 
        sql += ` WHERE ${where}`;
    }
 
    sqlBox.textContent = sql;
}
 
function isNullOperator(operator) {
    return operator === "IS NULL" || operator === "IS NOT NULL";
}
 
function buildInValues(value) {
    return String(value || "")
        .split(",")
        .map(v => v.trim())
        .filter(Boolean)
        .map(v => `'${escapeSql(v)}'`)
        .join(", ");
}
 
function escapeSql(value) {
    return String(value ?? "").replaceAll("'", "''");
}
 
function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}