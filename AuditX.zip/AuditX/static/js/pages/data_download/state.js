// pages/data_download/state.js
 
export const EXCEL_MAX_ROWS_PER_SHEET = 1048576;
 
export const state = {
    selectedProjectId: null,
    selectedProject: null,
 
    selectedReportListId: null,
    selectedReport: null,
 
    selectedDataListId: null,
    selectedTable: null,
    selectedServer: null,
    selectedDatabase: null,
 
    availableColumns: [],
    filters: [],
    top: 1000,
 
    previewColumns: [],
    previewRows: [],
    visibleColumns: [],
    columnFilters: {},
 
    page: 1,
    pageSize: 10,
 
    currentUserKey: "default_user",

};

export const CONFIG = {
    EXCEL_MAX_ROWS_PER_SHEET: 1000000 
};