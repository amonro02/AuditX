// pages/data_download/filters.js
 
import { state } from "./state.js";
 
export function addFilter(filter) {
    state.filters.push(filter);
}
 
export function clearFilters() {
    state.filters = [];
}