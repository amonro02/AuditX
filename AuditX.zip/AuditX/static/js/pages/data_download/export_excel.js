// pages/data_download/export_excel.js
 
import { CONFIG, state } from "./state.js";
import { getFilteredRows } from "./preview.js";
 
const maxRows = CONFIG.EXCEL_MAX_ROWS_PER_SHEET;
 
/* =========================
   MODAL
========================= */
 
export function openExportModal() {
    const modal = document.getElementById("exportModal");
    const fileInput = document.getElementById("exportFileName");
    const largeBox = document.getElementById("largeExportSettings");
    const dateSelect = document.getElementById("exportDateColumn");
 
    if (fileInput) {
        fileInput.value = getExportFileName(false);
    }
 
    document.querySelectorAll("input[name='exportType']").forEach(radio => {
        radio.checked = radio.value === "visible_all_rows";
    });
 
    refreshExportCards();
 
    if (dateSelect) {
        dateSelect.innerHTML = `<option value="">Select date column...</option>`;
 
        getDateColumns().forEach(col => {
            const opt = document.createElement("option");
            opt.value = col;
            opt.textContent = col;
            dateSelect.appendChild(opt);
        });
    }
 
    if (largeBox) {
        const totalRows = (state.previewRows || []).length;
        const isLarge = totalRows >= maxRows;
        largeBox.classList.toggle("hidden", !isLarge);
    }
 
    if (modal) {
        modal.classList.remove("hidden");
        modal.style.display = "flex";
    }
}
 
export function closeExportModal() {
    const modal = document.getElementById("exportModal");
 
    if (modal) {
        modal.classList.add("hidden");
        modal.style.display = "none";
    }
}
 
export function confirmExport() {
    const mode =
        document.querySelector("input[name='exportType']:checked")?.value ||
        "visible_all_rows";
 
    const largeBox = document.getElementById("largeExportSettings");
    const isLargeExport = largeBox && !largeBox.classList.contains("hidden");
 
    if (isLargeExport) {
        const splitMode = document.getElementById("exportSplitMode")?.value || "year";
        const dateColumn = document.getElementById("exportDateColumn")?.value || "";
 
        if (!dateColumn) {
            alert("Select a date column for large export.");
            return;
        }
 
        console.log("LARGE EXPORT SPLIT:", splitMode);
        console.log("LARGE EXPORT DATE COLUMN:", dateColumn);
 
        exportExcel(mode, {
            splitMode,
            dateColumn
        });
 
        return;
    }
 
    exportExcel(mode, null);
}
 
/* =========================
   EXPORT MAIN
========================= */
 
export function exportExcel(mode, partitionOptions = null) {
    const allColumns = state.previewColumns || [];
 
    const visibleColumns =
        state.visibleColumns && state.visibleColumns.length
            ? state.visibleColumns
            : allColumns.slice(0, 8);
 
    let columns = [];
    let rows = [];
 
    switch (mode) {
        case "all_columns_all_rows":
            columns = allColumns;
            rows = state.previewRows || [];
            break;
 
        case "visible_all_rows":
            columns = visibleColumns;
            rows = state.previewRows || [];
            break;
 
        case "visible_filtered_rows":
            columns = visibleColumns;
            rows = getFilteredRows();
            break;
 
        case "all_columns_filtered_rows":
            columns = allColumns;
            rows = getFilteredRows();
            break;
 
        case "visible_current_page":
            columns = visibleColumns;
            rows = getCurrentPageRows();
            break;
 
        case "all_columns_current_page":
            columns = allColumns;
            rows = getCurrentPageRows();
            break;
 
        case "selected_rows":
            columns = visibleColumns;
            rows = getSelectedRowsOnlyFromScreen();
            break;
 
        default:
            columns = visibleColumns;
            rows = state.previewRows || [];
            break;
    }
 
    console.log("EXPORT MODE:", mode);
    console.log("ROWS TO EXPORT:", rows.length);
    console.log("PARTITION OPTIONS:", partitionOptions);
 
    if (!rows.length) {
        alert("No data to export.");
        return;
    }
 
    const dataObjects = rowsToObjects(columns, rows);
 
    if (partitionOptions) {
        exportLargeExcelByPeriod(dataObjects, columns, partitionOptions);
        return;
    }
 
    exportSingleSheet(dataObjects, columns);
}
 
/* =========================
   ROW HELPERS
========================= */
 
function getCurrentPageRows() {
    const rows = getFilteredRows();
    const pageSize = state.pageSize || 25;
    const page = state.page || 1;
    const start = (page - 1) * pageSize;
 
    return rows.slice(start, start + pageSize);
}
 
function getSelectedRowsOnlyFromScreen() {
    const filteredRows = getFilteredRows();
    const checked = Array.from(document.querySelectorAll(".row-check:checked"));
 
    return checked
        .map(chk => Number(chk.dataset.rowIndex))
        .filter(idx => !Number.isNaN(idx))
        .map(idx => filteredRows[idx])
        .filter(Boolean);
}
 
function rowsToObjects(columns, rows) {
    const allColumns = state.previewColumns || [];
 
    return rows.map(row => {
        const obj = {};
 
        columns.forEach(col => {
            const idx = allColumns.indexOf(col);
 
            if (Array.isArray(row)) {
                obj[col] = idx >= 0 ? row[idx] : "";
            } else {
                obj[col] = row[col] ?? "";
            }
        });
 
        return obj;
    });
}
 
/* =========================
   NORMAL EXPORT
========================= */
 
function exportSingleSheet(data, columns) {
    const workbook = XLSX.utils.book_new();
    const sheet = XLSX.utils.json_to_sheet(data);
 
    applyWorksheetStyle(sheet, columns);
 
    XLSX.utils.book_append_sheet(workbook, sheet, "Data");
    XLSX.writeFile(workbook, getExportFileName(true));
 
    closeExportModal();
}
 
/* =========================
   LARGE EXPORT SPLIT
========================= */
 
function exportLargeExcelByPeriod(data, columns, options) {
    const splitMode = options?.splitMode || "year";
    const dateColumn = options?.dateColumn;
 
    if (!dateColumn) {
        alert("Select a date column.");
        return;
    }
 
    const workbook = XLSX.utils.book_new();
    const groups = buildPeriodGroups(data, dateColumn, splitMode);
 
    console.log("GROUPS CREATED:", Array.from(groups.keys()));
 
    for (const [sheetName, rows] of groups.entries()) {
        const safeName = safeSheetName(sheetName);
        const sheetData = rows.length ? rows : [emptyRow(columns)];
 
        const sheet = XLSX.utils.json_to_sheet(sheetData);
        applyWorksheetStyle(sheet, columns);
 
        XLSX.utils.book_append_sheet(workbook, sheet, safeName);
    }
 
    XLSX.writeFile(workbook, getExportFileName(true));
    closeExportModal();
}
 
function buildPeriodGroups(data, dateColumn, splitMode) {
    const expectedSheets = getExpectedSheets(splitMode);
    const groups = new Map();
 
    expectedSheets.forEach(sheet => {
        groups.set(sheet, []);
    });
 
    data.forEach(row => {
        const key = getPeriodKey(row[dateColumn], splitMode);
 
        if (!groups.has(key)) {
            groups.set(key, []);
        }
 
        groups.get(key).push(row);
    });
 
    return groups;
}
 
function getPeriodKey(value, splitMode) {
    const d = parseDateValue(value);
 
    if (!d) {
        return getDefaultSheet(splitMode);
    }
 
    const month = d.getMonth() + 1;
 
    if (splitMode === "month") {
        return `Month_${String(month).padStart(2, "0")}`;
    }
 
    if (splitMode === "quarter") {
        return `Q${Math.ceil(month / 3)}`;
    }
 
    if (splitMode === "four_months") {
        return `Block_${Math.ceil(month / 4)}`;
    }
 
    if (splitMode === "semester") {
        return month <= 6 ? "Semester_1" : "Semester_2";
    }
 
    return "All_Data";
}
 
function getExpectedSheets(splitMode) {
    if (splitMode === "month") {
        return [
            "Month_01",
            "Month_02",
            "Month_03",
            "Month_04",
            "Month_05",
            "Month_06",
            "Month_07",
            "Month_08",
            "Month_09",
            "Month_10",
            "Month_11",
            "Month_12"
        ];
    }
 
    if (splitMode === "quarter") {
        return ["Q1", "Q2", "Q3", "Q4"];
    }
 
    if (splitMode === "four_months") {
        return ["Block_1", "Block_2", "Block_3"];
    }
 
    if (splitMode === "semester") {
        return ["Semester_1", "Semester_2"];
    }
 
    return ["All_Data"];
}
 
function getDefaultSheet(splitMode) {
    if (splitMode === "month") return "Month_01";
    if (splitMode === "quarter") return "Q1";
    if (splitMode === "four_months") return "Block_1";
    if (splitMode === "semester") return "Semester_1";
 
    return "All_Data";
}
 
function parseDateValue(value) {
    if (!value) return null;
 
    if (value instanceof Date && !Number.isNaN(value.getTime())) {
        return value;
    }
 
    const text = String(value).trim();
 
    // dd/mm/yyyy o dd-mm-yyyy
    const mx = text.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
    if (mx) {
        const day = Number(mx[1]);
        const month = Number(mx[2]);
        const year = Number(mx[3]);
 
        const d = new Date(year, month - 1, day);
        return Number.isNaN(d.getTime()) ? null : d;
    }
 
    // yyyy-mm-dd o yyyy/mm/dd
    const iso = text.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/);
    if (iso) {
        const year = Number(iso[1]);
        const month = Number(iso[2]);
        const day = Number(iso[3]);
 
        const d = new Date(year, month - 1, day);
        return Number.isNaN(d.getTime()) ? null : d;
    }
 
    const parsed = new Date(text);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
}
 
/* =========================
   DATE COLUMNS
========================= */
 
function getDateColumns() {
    const columns = state.previewColumns || [];
 
    return columns.filter(col => {
        const name = String(col || "").toLowerCase();
 
        return (
            name.includes("date") ||
            name.includes("fecha") ||
            name.includes("_dt") ||
            name.endsWith("dt") ||
            name.startsWith("dt_")
        );
    });
}
 
/* =========================
   UTILS
========================= */
 
function emptyRow(columns) {
    const obj = {};
 
    columns.forEach(col => {
        obj[col] = "";
    });
 
    return obj;
}
 
function applyWorksheetStyle(sheet, columns) {
    if (!sheet || !columns) return;
 
    sheet["!cols"] = columns.map(col => ({
        wch: Math.max(12, Math.min(35, String(col).length + 5))
    }));
}
 
function safeSheetName(name) {
    return String(name || "Sheet")
        .replace(/[\\/?*[\]:]/g, "_")
        .substring(0, 31);
}
 
function getExportFileName(withExtension = true) {
    const input = document.getElementById("exportFileName");
 
    let name = input?.value?.trim();
 
    if (!name) {
        const today = new Date().toISOString().slice(0, 10);
        name = `AuditX_DataDownload_${today}`;
    }
 
    name = name.replace(/[\\/:*?"<>|]/g, "_");
 
    if (withExtension && !name.toLowerCase().endsWith(".xlsx")) {
        name += ".xlsx";
    }
 
    return name;
}
 
/* =========================
   UI
========================= */
 
function refreshExportCards() {
    document.querySelectorAll(".export-option-card").forEach(card => {
        card.classList.remove("selected");
    });
 
    document.querySelector("input[name='exportType']:checked")
        ?.closest(".export-option-card")
        ?.classList.add("selected");
}
 
document.querySelectorAll("input[name='exportType']").forEach(radio => {
    radio.addEventListener("change", refreshExportCards);
});
 