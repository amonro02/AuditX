import { state } from "../data_download/state.js";

import {
    renderPreview,
    renderPreviewTable,
    updatePageInfo,
    getFilteredRows
} from "../data_download/preview.js";

import {
    openExportModal,
    closeExportModal,
    confirmExport
} from "../data_download/export_excel.js";


let planningEntity = null;
let planningEntityConfig = null;

let planningFormMode = null; // "create" | "update"
let planningEditingKey = null;
let planningEditingRow = null;

const entityConfigCache = new Map();
const lookupCache = new Map();

let planningSelectedRowKey = null;
let planningSort = {
    column: null,
    direction: null
};
let planningPreviewObserver = null;

// v13.4.1 - Audit Project Planning uses real SQL Server pagination with ORIGINAL shared preview UI.
// The shared Data Download renderer still draws the current page, but the
// authoritative page/filter/count state lives here and SQL only returns the
// requested slice.
const planningServerPaging = {
    enabled: false,
    page: 1,
    pageSize: 25,
    totalRows: 0,
    totalPages: 1,
    loading: false,
    requestId: 0,
    filterSignature: "",
    filterWatchTimer: null,
    filterDebounceTimer: null,
    quickFilterColumn: "",
    quickFilterText: "",
};


document.addEventListener("DOMContentLoaded", () => {
    initPlanning();
});


async function initPlanning() {

    const page =
        document.getElementById("planningPage");

    if (!page) return;

    planningEntity =
        page.dataset.entity;

    try {

        planningEntityConfig =
            await loadEntityConfig(planningEntity);

        planningServerPaging.enabled =
            Boolean(planningEntityConfig?.server_side_paging);
        planningServerPaging.page = 1;
        planningServerPaging.pageSize =
            Number(planningEntityConfig?.server_page_size || 25);

        // Planning always starts at 25 rows. The user can change it afterwards.
        state.pageSize = planningServerPaging.enabled
            ? planningServerPaging.pageSize
            : 25;
        state.page = 1;
        state.columnFilters = {};

        await refreshPlanningPreview(true);

        bindPlanningPreviewEvents(planningEntity);
        bindPlanningRowDoubleClick();
        bindPlanningRowSelection();
        ensurePlanningNewButton();
        ensurePlanningDuplicateButton();
        hidePlanningOnlyToolbarActions();
        startPlanningPreviewObserver();
        startPlanningServerFilterWatcher();

        const pageSize =
            document.getElementById("pageSizeSelect");

        if (pageSize) {
            pageSize.value =
                String(state.pageSize || 25);
        }

    }
    catch (error) {

        console.error(
            "Planning init error:",
            error
        );

    }

}


async function loadEntityConfig(entity) {

    if (entityConfigCache.has(entity)) {
        return entityConfigCache.get(entity);
    }

    const response =
        await fetch(
            `/api/planning/config/${encodeURIComponent(entity)}`
        );

    const result =
        await response.json();

    if (!response.ok || result.ok === false) {
        throw new Error(
            result.message ||
            "Unable to load Planning configuration."
        );
    }

    entityConfigCache.set(entity, result);

    return result;

}


async function refreshPlanningPreview(initialLoad = false) {

    if (isPlanningServerPaged()) {
        return refreshPlanningServerPreview(initialLoad);
    }

    const response =
        await fetch(
            `/api/planning/${encodeURIComponent(planningEntity)}?_=${Date.now()}`,
            { cache: "no-store" }
        );

    const result =
        await response.json();

    if (!response.ok || result.ok === false) {
        throw new Error(
            result.message ||
            "Unable to load Planning data."
        );
    }

    const columns = result.columns || [];
    const rows = result.rows || [];

    state.previewColumns = columns;
    state.availableColumns = columns;
    state.previewRows = rows;

    if (planningSort.column && planningSort.direction) {
        sortPlanningRowsInPlace(
            planningSort.column,
            planningSort.direction
        );
    }

    if (initialLoad) {

        state.visibleColumns =
            loadPlanningView(
                planningEntity,
                columns
            );

        state.columnFilters = {};
        state.selectedRowKeys = new Set();
        state.page = 1;
        state.pageSize = state.pageSize || 25;

        renderPreview(columns, state.previewRows);
        afterPlanningPreviewRender();

        return;
    }

    const filtered =
        getFilteredRows();

    const totalPages =
        Math.max(
            1,
            Math.ceil(
                filtered.length /
                (state.pageSize || 25)
            )
        );

    if (state.page > totalPages) {
        state.page = totalPages;
    }

    renderPreviewTable();
    updatePageInfo();
    afterPlanningPreviewRender();

}


function isPlanningServerPaged() {
    return Boolean(
        planningServerPaging.enabled &&
        planningEntityConfig?.server_side_paging
    );
}


function planningSerializableFilterValue(value) {
    if (value instanceof Set) {
        return [...value].map(planningSerializableFilterValue);
    }

    if (Array.isArray(value)) {
        return value.map(planningSerializableFilterValue);
    }

    if (value && typeof value === "object") {
        const output = {};
        Object.entries(value).forEach(([key, item]) => {
            output[key] = planningSerializableFilterValue(item);
        });
        return output;
    }

    return value;
}


function getPlanningServerFilters() {
    return planningSerializableFilterValue(
        state.columnFilters || {}
    );
}


function getPlanningServerFilterSignature() {
    try {
        return JSON.stringify(getPlanningServerFilters());
    }
    catch {
        return "{}";
    }
}


async function refreshPlanningServerPreview(initialLoad = false) {
    const requestId = ++planningServerPaging.requestId;
    planningServerPaging.loading = true;

    const params = new URLSearchParams();
    params.set("page", String(planningServerPaging.page || 1));
    params.set("page_size", String(planningServerPaging.pageSize || 25));
    params.set("filters", JSON.stringify(getPlanningServerFilters()));
    params.set("_", String(Date.now()));

    if (planningSort.column && planningSort.direction) {
        params.set("sort_column", planningSort.column);
        params.set("sort_direction", planningSort.direction);
    }

    if (
        planningServerPaging.quickFilterColumn &&
        planningServerPaging.quickFilterText.trim()
    ) {
        params.set(
            "quick_filter_column",
            planningServerPaging.quickFilterColumn
        );
        params.set(
            "quick_filter_text",
            planningServerPaging.quickFilterText.trim()
        );
    }

    try {
        const response = await fetch(
            `/api/planning/${encodeURIComponent(planningEntity)}?${params.toString()}`,
            { cache: "no-store" }
        );

        const result = await response.json();

        if (requestId !== planningServerPaging.requestId) {
            return;
        }

        if (!response.ok || result.ok === false) {
            throw new Error(
                result.message ||
                "Unable to load Planning data."
            );
        }

        const columns = result.columns || [];
        const rows = result.rows || [];

        planningServerPaging.page = Number(result.page || 1);
        planningServerPaging.pageSize = Number(result.page_size || 25);
        planningServerPaging.totalRows = Number(result.total_rows || 0);
        planningServerPaging.totalPages = Math.max(
            1,
            Number(result.total_pages || 1)
        );

        state.previewColumns = columns;
        state.availableColumns = columns;
        state.previewRows = rows;

        // The shared preview component must always render page 1 of the rows
        // currently returned by SQL. planningServerPaging.page is the real page.
        state.page = 1;
        state.pageSize = planningServerPaging.pageSize;

        if (initialLoad) {
            state.visibleColumns = loadPlanningView(
                planningEntity,
                columns
            );
            state.columnFilters = state.columnFilters || {};
            state.selectedRowKeys = new Set();
            renderPreview(columns, rows);
        }
        else {
            renderPreviewTable();
            updatePageInfo();
        }

        planningServerPaging.filterSignature =
            getPlanningServerFilterSignature();

        afterPlanningPreviewRender();
        updatePlanningServerPagerUI();
    }
    finally {
        if (requestId === planningServerPaging.requestId) {
            planningServerPaging.loading = false;
        }
    }
}


function updatePlanningServerPagerUI() {
    if (!isPlanningServerPaged()) return;

    const page = planningServerPaging.page || 1;
    const pageSize = planningServerPaging.pageSize || 25;
    const total = planningServerPaging.totalRows || 0;
    const totalPages = planningServerPaging.totalPages || 1;

    const totalCounter = document.getElementById("previewTotalCounter");
 
    if (totalCounter) {
        const label = `${Number(total).toLocaleString()} total`;
    
        if (!totalCounter.dataset.originalIcon) {
            const originalText = (totalCounter.textContent || "").trim();
    
            const match = originalText.match(
                /^(.+?)\s+[\d,.]+\s+total$/i
            );
    
            if (match && match[1]) {
                totalCounter.dataset.originalIcon = match[1].trim();
            }
        }
    
        const elementChildren = Array.from(totalCounter.children);
    
        if (elementChildren.length > 0) {
    
            let valueNode =
                totalCounter.querySelector(".planning-total-text");
    
            if (!valueNode) {
                valueNode = document.createElement("span");
                valueNode.className = "planning-total-text";
    
                Array.from(totalCounter.childNodes).forEach(node => {
                    if (node.nodeType === Node.TEXT_NODE) {
                        node.remove();
                    }
                });
    
                totalCounter.appendChild(valueNode);
            }
    
            valueNode.textContent = ` ${label}`;
    
        } else {
    
            const icon =
                totalCounter.dataset.originalIcon || "📊";
    
            totalCounter.textContent = `${icon} ${label}`;
        }
    }

    const previous = document.getElementById("btnPrevPage");
    const next = document.getElementById("btnNextPage");

    if (previous) previous.disabled = page <= 1;
    if (next) next.disabled = page >= totalPages || total === 0;

    const select = document.getElementById("pageSizeSelect");
    if (select) select.value = String(pageSize);

    // Keep the ORIGINAL Data Download pager layout exactly as it is.
    // We only replace the text inside the existing center badge.
    const text = `Page ${page.toLocaleString()} of ${totalPages.toLocaleString()}`;

    let info =
        document.getElementById("pageInfo") ||
        document.getElementById("previewPageInfo") ||
        document.querySelector("#planningPage .page-info") ||
        document.querySelector("#planningPage .preview-page-info") ||
        document.querySelector("#planningPage .pagination-info");

    // In the shared Data Download component the page badge may not have
    // a stable id/class. In that case, use the existing element located
    // between Prev and Next instead of creating a new control.
    const host = previous?.parentElement || next?.parentElement;
    if (!info && host && previous && next && previous.parentElement === host && next.parentElement === host) {
        let candidate = previous.nextElementSibling;
        while (candidate && candidate !== next) {
            if (!candidate.matches("button, select, input")) {
                info = candidate;
                break;
            }
            candidate = candidate.nextElementSibling;
        }
    }

    if (info) {
        info.textContent = text;
    }

    // Remove the v13.4 fallback badge if it was created by a previous cached JS.
    document.getElementById("planningServerPageInfo")?.remove();

    // Keep the existing Preview total badge accurate without changing its layout.
    // The shared Data Download component calculates this badge from the rows
    // currently loaded in the browser (for example "100 total"). With
    // server-side paging that number is only the current SQL page, so replace
    // ONLY the text in the existing badge with SQL Server's real COUNT_BIG.
    updatePlanningServerTotalBadge(total);

    // Some shared preview handlers update their counters after render. Re-apply
    // the authoritative total on the next paint without creating new controls.
    requestAnimationFrame(() => updatePlanningServerTotalBadge(total));
}


function updatePlanningServerTotalBadge(total) {
    if (!isPlanningServerPaged()) return;

    const page = document.getElementById("planningPage");
    if (!page) return;

    const expected = `${Number(total || 0).toLocaleString()} total`;
    const totalPattern = /^\s*[\d,.]+\s+total\s*$/i;

    // Search the complete Planning page because the original shared preview
    // template does not expose a stable id/class for the total badge. Prefer
    // the smallest matching element so the icon/outer badge structure remains
    // untouched.
    const matches = Array.from(
        page.querySelectorAll("span, strong, b, div, button")
    ).filter(el => totalPattern.test((el.textContent || "").trim()));

    if (!matches.length) return;

    const totalNode = matches.sort((a, b) =>
        a.querySelectorAll("*").length - b.querySelectorAll("*").length
    )[0];

    // Preserve any icon inside the badge and replace only its text node.
    const walker = document.createTreeWalker(
        totalNode,
        NodeFilter.SHOW_TEXT
    );

    let textNode = walker.nextNode();
    while (textNode) {
        if (totalPattern.test((textNode.nodeValue || "").trim())) {
            const leading = (textNode.nodeValue.match(/^\s*/) || [""])[0];
            const trailing = (textNode.nodeValue.match(/\s*$/) || [""])[0];
            textNode.nodeValue = `${leading}${expected}${trailing}`;
            return;
        }
        textNode = walker.nextNode();
    }

    // Fallback for a badge whose text is split across nodes. This is still the
    // original badge; no extra UI element is created.
    totalNode.textContent = expected;
}

function startPlanningServerFilterWatcher() {
    if (!isPlanningServerPaged()) return;

    if (planningServerPaging.filterWatchTimer) {
        clearInterval(planningServerPaging.filterWatchTimer);
    }

    planningServerPaging.filterSignature =
        getPlanningServerFilterSignature();

    planningServerPaging.filterWatchTimer = setInterval(() => {
        const signature = getPlanningServerFilterSignature();

        if (signature === planningServerPaging.filterSignature) {
            return;
        }

        planningServerPaging.filterSignature = signature;

        if (planningServerPaging.filterDebounceTimer) {
            clearTimeout(planningServerPaging.filterDebounceTimer);
        }

        planningServerPaging.filterDebounceTimer = setTimeout(async () => {
            planningServerPaging.page = 1;
            try {
                await refreshPlanningPreview(false);
            }
            catch (error) {
                console.error("Planning server filter error:", error);
            }
        }, 250);
    }, 250);
}


function ensurePlanningServerQuickFilter() {
    if (!isPlanningServerPaged()) return;

    const columns = state.previewColumns || [];
    if (!columns.length) return;

    let shell = document.getElementById("planningServerQuickFilter");
    if (!shell) {
        shell = document.createElement("div");
        shell.id = "planningServerQuickFilter";
        shell.className = "planning-server-filter";
        shell.innerHTML = `
            <span class="planning-server-filter-label">Search all records</span>
            <select id="planningServerFilterColumn" aria-label="Planning server filter column"></select>
            <input id="planningServerFilterText" type="search" placeholder="Type to search the full view..." autocomplete="off">
            <button id="planningServerFilterApply" type="button">Search</button>
            <button id="planningServerFilterClear" type="button" class="is-secondary">Clear</button>
        `;

        const toolbar =
            document.querySelector("#planningPage .preview-header") ||
            document.querySelector("#planningPage .preview-toolbar") ||
            document.querySelector("#planningPage .preview-right")?.parentElement;

        if (toolbar) {
            toolbar.insertAdjacentElement("afterend", shell);
        }
        else {
            document.getElementById("planningPage")?.prepend(shell);
        }
    }

    const select = document.getElementById("planningServerFilterColumn");
    const input = document.getElementById("planningServerFilterText");
    const apply = document.getElementById("planningServerFilterApply");
    const clear = document.getElementById("planningServerFilterClear");

    if (select) {
        const current = planningServerPaging.quickFilterColumn;
        select.innerHTML = columns
            .map(column => `<option value="${escapeHtml(String(column))}">${escapeHtml(String(column))}</option>`)
            .join("");

        const preferred =
            current ||
            columns.find(column => /region/i.test(String(column))) ||
            columns.find(column => /client/i.test(String(column))) ||
            columns[0];

        select.value = preferred;
        planningServerPaging.quickFilterColumn = select.value;

        if (select.dataset.bound !== "1") {
            select.dataset.bound = "1";
            select.addEventListener("change", () => {
                planningServerPaging.quickFilterColumn = select.value;
            });
        }
    }

    if (input) {
        input.value = planningServerPaging.quickFilterText || "";
        if (input.dataset.bound !== "1") {
            input.dataset.bound = "1";
            input.addEventListener("keydown", async event => {
                if (event.key !== "Enter") return;
                event.preventDefault();
                planningServerPaging.quickFilterText = input.value.trim();
                planningServerPaging.page = 1;
                await refreshPlanningPreview(false);
            });
        }
    }

    if (apply && apply.dataset.bound !== "1") {
        apply.dataset.bound = "1";
        apply.addEventListener("click", async () => {
            planningServerPaging.quickFilterColumn = select?.value || "";
            planningServerPaging.quickFilterText = input?.value?.trim() || "";
            planningServerPaging.page = 1;
            await refreshPlanningPreview(false);
        });
    }

    if (clear && clear.dataset.bound !== "1") {
        clear.dataset.bound = "1";
        clear.addEventListener("click", async () => {
            if (input) input.value = "";
            planningServerPaging.quickFilterText = "";
            planningServerPaging.page = 1;
            await refreshPlanningPreview(false);
        });
    }
}


function ensurePlanningNewButton() {

    if (!planningEntityConfig?.allow_create) return;

    let button =
        document.getElementById("btnNewPlanning");

    if (!button) {

        button =
            document.createElement("button");

        button.id = "btnNewPlanning";
        button.type = "button";
        button.className = "planning-new-btn";

    }

    button.textContent =
        `＋ New ${planningEntityConfig.title}`;

    button.onclick =
        openPlanningCreateModal;

    const exportButton =
        document.getElementById("btnExportExcel");

    const host =
        exportButton?.parentElement ||
        document.querySelector(
            "#planningPage .preview-right"
        ) ||
        document.querySelector(
            "#planningPage .preview-header"
        );

    if (!host) {
        console.warn(
            "Planning toolbar host not found."
        );
        return;
    }

    if (
        exportButton &&
        exportButton.parentElement === host
    ) {
        host.insertBefore(
            button,
            exportButton
        );
    }
    else if (button.parentElement !== host) {
        host.appendChild(button);
    }

}



function bindPlanningRowDoubleClick() {

    if (!planningEntityConfig?.allow_update) return;

    const table =
        document.getElementById("previewTable");

    if (!table) return;

    table.addEventListener(
        "dblclick",
        async event => {

            if (
                event.target.closest(
                    ".filter-row, " +
                    ".excel-filter-wrap, " +
                    ".excel-filter-btn, " +
                    "input, button, select, textarea"
                )
            ) {
                return;
            }

            const rowElement =
                event.target.closest("tbody tr");

            if (!rowElement) return;

            const checkbox =
                rowElement.querySelector(".row-check");

            if (!checkbox) return;

            const rowIndex =
                Number(checkbox.dataset.rowIndex);

            if (Number.isNaN(rowIndex)) return;

            const rows =
                getFilteredRows();

            const row =
                rows[rowIndex];

            if (!row) return;

            await openPlanningUpdateModal(row);

        }
    );

}


async function openPlanningCreateModal() {

    planningFormMode = "create";
    planningEditingKey = null;
    planningEditingRow = null;

    await openDynamicModal(null);

}


async function openPlanningUpdateModal(row) {

    planningFormMode = "update";

    const key =
        getPlanningRowValue(
            row,
            planningEntityConfig.view_key
        );

    if (
        key === null ||
        key === undefined ||
        String(key).trim() === ""
    ) {
        console.warn(
            "Unable to open Planning record because its key was not found.",
            planningEntityConfig.view_key,
            row
        );
        return;
    }

    planningEditingKey = key;

    /*
       Always fetch the complete row from the VIEW before editing.
       This avoids problems when the Preview only shows 8 columns,
       when columns were reordered, or when the VIEW uses key/Key
       with different capitalization.
    */
    try {

        const response =
            await fetch(
                `/api/planning/${encodeURIComponent(planningEntity)}/${encodeURIComponent(key)}`
            );

        const result =
            await response.json();

        if (
            response.ok &&
            result.ok !== false &&
            Array.isArray(result.columns) &&
            Array.isArray(result.row)
        ) {

            const fullRow = {};

            result.columns.forEach(
                (column, index) => {
                    fullRow[column] =
                        result.row[index] ?? "";
                }
            );

            planningEditingRow = fullRow;

            await openDynamicModal(fullRow);
            return;

        }

    }
    catch (error) {

        console.warn(
            "Unable to fetch complete Planning row. Falling back to Preview row.",
            error
        );

    }

    planningEditingRow = row;
    await openDynamicModal(row);

}


async function openDynamicModal(row) {

    clearPlanningEditStatus();

    const title =
        document.getElementById("planningEditTitle");

    const subtitle =
        document.getElementById("planningEditSubtitle");

    const icon =
        document.getElementById("planningEditIcon");

    const btnContinue =
        document.getElementById("btnUpdateContinue");

    const btnExit =
        document.getElementById("btnUpdateExit");

    const btnDelete =
        document.getElementById("btnDeletePlanning");

    const card =
        document.getElementById("planningEditCard");

    if (btnDelete) {
        btnDelete.classList.toggle(
            "hidden",
            planningFormMode !== "update" ||
            !planningEntityConfig?.allow_delete
        );
    }

    if (planningFormMode === "create") {

        if (title) {
            title.textContent =
                `New ${planningEntityConfig.title}`;
        }

        if (subtitle) {
            subtitle.textContent =
                `Enter the information for the new ${planningEntityConfig.title.toLowerCase()}.`;
        }

        if (icon) icon.textContent = "＋";
        if (btnContinue) btnContinue.textContent = "Save and New";
        if (btnExit) btnExit.textContent = "✓ Save and Exit";

    }
    else {

        if (title) {
            title.textContent =
                `Update ${planningEntityConfig.title}`;
        }

        if (subtitle) {
            subtitle.textContent =
                `Update the selected ${planningEntityConfig.title.toLowerCase()} information.`;
        }

        if (icon) icon.textContent = "✎";
        if (btnContinue) btnContinue.textContent = "Update and Continue";
        if (btnExit) btnExit.textContent = "✓ Update and Exit";

    }

    if (card) {

        card.classList.remove(
            "size-medium",
            "size-large",
            "size-xlarge"
        );

        const size =
            planningEntityConfig.modal_width || "large";

        card.classList.add(`size-${size}`);

    }

    await buildDynamicFields(row);

    document
        .getElementById("planningEditModal")
        ?.classList.remove("hidden");

    focusFirstEditableField();

}


async function buildDynamicFields(row) {

    const container =
        document.getElementById("planningDynamicFields");

    if (!container) return;

    container.innerHTML = "";

    const fields =
        planningEntityConfig.fields || [];

    for (const field of fields) {

        if (
            planningFormMode === "create" &&
            field.show_on_create === false
        ) {
            continue;
        }

        const value =
            row
                ? getPlanningFieldRowValue(row, field)
                : (field.default ?? "");

        const wrapper =
            createFieldWrapper(field);

        const control =
            createFieldControl(field, value);

        wrapper.appendChild(control);
        if (field.type === "date") {
            decoratePlanningDateField(wrapper, control, value);
        }
        container.appendChild(wrapper);

    }

    for (const field of fields) {

        if (field.type !== "lookup") continue;

        if (
            planningFormMode === "create" &&
            field.show_on_create === false
        ) {
            continue;
        }

        const currentValue =
            row
                ? getPlanningFieldRowValue(row, field)
                : (field.default ?? "");

        await populateLookupControl(
            field,
            currentValue
        );

    }

    bindDynamicFieldRelations();
    syncAllDerivedPlanningFields();

}


function createFieldWrapper(field) {

    const wrapper =
        document.createElement("div");

    wrapper.className =
        "planning-dynamic-field";

    if (field.required || field.highlight_required) {
        wrapper.classList.add("is-required");
    }

    const span =
        Math.max(
            1,
            Math.min(
                4,
                Number(field.span || 1)
            )
        );

    if (span > 1) {
        wrapper.classList.add(`span-${span}`);
    }

    const label =
        document.createElement("label");

    label.textContent =
        field.label || field.view_field;

    if (field.required) {

        const required =
            document.createElement("span");

        required.className =
            "planning-required";

        required.textContent = "*";

        label.appendChild(required);

    }

    wrapper.appendChild(label);

    return wrapper;

}


function createFieldControl(field, value) {

    const type =
        field.type || "text";

    let control;

    if (type === "textarea") {

        control =
            document.createElement("textarea");

        control.rows = 3;

    }
    else if (type === "lookup" || type === "choice") {

        control =
            document.createElement("select");

        if (type === "lookup") {
            const loading =
                document.createElement("option");

            loading.value = "";
            loading.textContent = "Loading...";

            control.appendChild(loading);
        }
        else {
            for (const item of (field.choices || [])) {
                const option = document.createElement("option");
                option.value = item.value ?? "";
                option.textContent = item.label ?? item.value ?? "";
                control.appendChild(option);
            }
        }

    }
    else {

        control =
            document.createElement("input");

        if (type === "number") {
            control.type = "number";
        }
        else if (type === "money") {
            control.type = "text";
            control.inputMode = "decimal";
            control.placeholder = "0.00";
            control.autocomplete = "off";
        }
        else if (type === "date") {
            // Visible value is always DD-MMM-YYYY; a hidden native date input
            // supplies the browser calendar picker.
            control.type = "text";
            control.autocomplete = "off";
            control.readOnly = true;
            control.classList.add("planning-medium-date-input");
        }
        else if (type === "checkbox") {
            control.type = "checkbox";
        }
        else {
            control.type = "text";
        }

    }

    setControlMetadata(control, field);

    if (type === "checkbox") {
        control.checked = Boolean(value);
    }
    else if (type === "date") {
        const iso = planningDateToIso(value) || "";
        control.dataset.isoValue = iso;
        control.value = iso ? planningMediumDate(iso) : "";
    }
    else if (type === "money") {
        control.value = formatPlanningMoney(value, field.decimals ?? 2);
    }
    else if (type === "choice") {
        let choiceValue = value ?? "";
        const existing = [...control.options].some(option => String(option.value) === String(choiceValue));
        if (!existing && String(choiceValue).toUpperCase() === "Y") {
            const yesOption = [...control.options].find(option => String(option.textContent).trim().toLowerCase() === "yes");
            if (yesOption) choiceValue = yesOption.value;
        }
        else if (!existing && String(choiceValue).toUpperCase() === "N") {
            const noOption = [...control.options].find(option => String(option.textContent).trim().toLowerCase() === "no");
            if (noOption) choiceValue = noOption.value;
        }
        control.value = choiceValue;
    }
    else if (type !== "lookup") {
        control.value = value ?? "";
    }

    if (
        type === "readonly" ||
        type === "display" ||
        field.readonly
    ) {
        control.readOnly = true;
    }

    if (field.required) {
        control.required = true;
    }

    return control;

}


function setControlMetadata(control, field) {

    control.dataset.planningField = "1";
    control.dataset.viewField = field.view_field;
    control.dataset.fieldType = field.type || "text";

    if (field.transform) {
        control.dataset.transform = field.transform;
    }

    if (field.display_format) {
        control.dataset.displayFormat = field.display_format;
    }

    if (field.min_length !== undefined && field.min_length !== null) {
        control.dataset.minLengthRule = String(field.min_length);
    }

    if (field.max_length !== undefined && field.max_length !== null) {
        control.dataset.maxLengthRule = String(field.max_length);
    }

    if (field.min !== undefined && field.min !== null) {
        control.dataset.minRule = String(field.min);
    }

    if (field.max !== undefined && field.max !== null) {
        control.dataset.maxRule = String(field.max);
    }

    if (field.after_or_equal) {
        control.dataset.afterOrEqual = field.after_or_equal;
    }

    if (field.before_or_equal) {
        control.dataset.beforeOrEqual = field.before_or_equal;
    }

    if (field.derived_from) {
        control.dataset.derivedFrom = field.derived_from;
    }

    if (field.derive) {
        control.dataset.derive = field.derive;
    }

    if (field.decimals !== undefined && field.decimals !== null) {
        control.dataset.decimals = String(field.decimals);
    }

    if (field.lookup) {
        control.dataset.lookup = field.lookup;
    }

    if (field.depends_on) {
        control.dataset.dependsOn = field.depends_on;
    }

    if (field.extra_target) {
        control.dataset.extraTarget = field.extra_target;
    }

    if (field.extra_targets) {
        control.dataset.extraTargets = JSON.stringify(field.extra_targets);
    }

}


async function populateLookupControl(
    field,
    selectedValue
) {

    const select =
        findFieldControl(field.view_field);

    if (!select || select.tagName !== "SELECT") return;

    const parentValue =
        field.depends_on
            ? getFieldValue(field.depends_on)
            : null;

    // A child lookup should remain empty until its parent has a value.
    if (field.depends_on && (parentValue === null || parentValue === undefined || parentValue === "")) {
        select.innerHTML = "";

        const waiting = document.createElement("option");
        waiting.value = "";
        waiting.textContent = "-- Select previous field first --";
        select.appendChild(waiting);
        select.disabled = false;
        delete select.dataset.lookupError;
        return;
    }

    let items = [];

    try {
        items = await loadLookupItems(
            field.lookup,
            parentValue
        );

        select.disabled = false;
        delete select.dataset.lookupError;
    }
    catch (error) {
        // v8: one bad lookup must NOT stop the entire New/Edit modal.
        console.error(
            `Planning lookup failed: ${field.lookup}`,
            error
        );

        select.innerHTML = "";

        const failed = document.createElement("option");
        failed.value = "";
        failed.textContent = "-- Unable to load options --";
        select.appendChild(failed);

        select.disabled = true;
        select.dataset.lookupError = "1";
        select.title = error?.message || `Unable to load ${field.lookup}`;

        return;
    }

    select.innerHTML = "";

    const empty =
        document.createElement("option");

    empty.value = "";
    empty.textContent =
        field.required
            ? "-- Select --"
            : "-- None --";

    select.appendChild(empty);

    for (const item of items) {

        const option =
            document.createElement("option");

        option.value =
            String(item.value);

        option.dataset.extra =
            item.extra ?? "";

        option.dataset.extras =
            JSON.stringify(item.extras || {});

        option.textContent =
            field.show_extra_in_label && item.extra
                ? `${item.label} (${item.extra})`
                : item.label;

        select.appendChild(option);

    }

    if (
        selectedValue !== null &&
        selectedValue !== undefined &&
        selectedValue !== ""
    ) {
        const wanted = String(selectedValue).trim();

        // Prefer the real stored key when the VIEW exposes it.
        select.value = wanted;

        // Several legacy Planning VIEWs expose only the display text (for
        // example Audit Lead name or Ctx Code) while the lookup option value is
        // the underlying key.  In Update mode, fall back to matching the visible
        // option label so the control and its dependent descriptive fields are
        // populated instead of appearing blank.
        if (!select.value && wanted) {
            const normalizedWanted = wanted.toLocaleUpperCase();

            const matchingOption = [...select.options].find(option => {
                const label = String(option.textContent || "").trim();
                const normalizedLabel = label.toLocaleUpperCase();
                const extra = String(option.dataset.extra || "").trim();

                return (
                    normalizedLabel === normalizedWanted ||
                    normalizedLabel.startsWith(`${normalizedWanted} (`) ||
                    extra.toLocaleUpperCase() === normalizedWanted
                );
            });

            if (matchingOption) {
                select.value = matchingOption.value;
            }
        }
    }

    updateLookupExtraTarget(select);

}

async function loadLookupItems(
    lookupName,
    parentValue = null
) {

    const cacheKey =
        `${lookupName}|${parentValue ?? ""}`;

    if (lookupCache.has(cacheKey)) {
        return lookupCache.get(cacheKey);
    }

    let url =
        `/api/planning/lookup/${encodeURIComponent(lookupName)}`;

    if (
        parentValue !== null &&
        parentValue !== undefined &&
        parentValue !== ""
    ) {
        url +=
            `?parent_value=${encodeURIComponent(parentValue)}`;
    }

    const response =
        await fetch(url);

    const result =
        await response.json();

    if (!response.ok || result.ok === false) {
        throw new Error(
            result.message ||
            `Unable to load ${lookupName}.`
        );
    }

    const items =
        result.items || [];

    lookupCache.set(cacheKey, items);

    return items;

}


function bindDynamicFieldRelations() {

    const fields =
        planningEntityConfig.fields || [];

    for (const field of fields) {

        const control =
            findFieldControl(field.view_field);

        if (!control) continue;

        if (field.transform === "uppercase") {

            control.addEventListener(
                "input",
                () => {
                    const start = control.selectionStart;
                    const end = control.selectionEnd;
                    control.value = control.value.toUpperCase();

                    try {
                        control.setSelectionRange(start, end);
                    }
                    catch {
                        // Some controls do not support selection ranges.
                    }
                }
            );

        }
        else if (field.transform === "lowercase") {

            control.addEventListener(
                "input",
                () => {
                    control.value = control.value.toLowerCase();
                }
            );

        }

        if (field.type === "money") {

            control.addEventListener(
                "focus",
                () => {
                    control.value = stripPlanningMoney(control.value);
                }
            );

            control.addEventListener(
                "blur",
                () => {
                    if (!control.value.trim()) return;
                    control.value = formatPlanningMoney(
                        control.value,
                        field.decimals ?? 2
                    );
                }
            );

        }

        control.addEventListener(
            "input",
            () => clearControlInvalid(control)
        );

        control.addEventListener(
            "change",
            () => {
                clearControlInvalid(control);
                syncDerivedPlanningFields(field.view_field);
            }
        );

        if (field.type === "lookup") {

            control.addEventListener(
                "change",
                async () => {

                    updateLookupExtraTarget(control);

                    await refreshLookupDependents(
                        field.view_field
                    );

                }
            );

        }

    }

}



async function refreshLookupDependents(parentField) {

    const fields =
        planningEntityConfig.fields || [];

    const dependents =
        fields.filter(
            field =>
                field.type === "lookup" &&
                field.depends_on === parentField
        );

    for (const dependent of dependents) {
        await populateLookupControl(
            dependent,
            ""
        );

        await refreshLookupDependents(
            dependent.view_field
        );
    }
}


function updateLookupExtraTarget(select) {

    const option =
        select.options[select.selectedIndex];

    const targetField =
        select.dataset.extraTarget;

    if (targetField) {
        const target =
            findFieldControl(targetField);

        if (target) {
            target.value =
                option?.dataset.extra || "";
        }
    }

    let targetMap = {};

    try {
        targetMap = JSON.parse(
            select.dataset.extraTargets || "{}"
        );
    }
    catch {
        targetMap = {};
    }

    let extras = {};

    try {
        extras = JSON.parse(
            option?.dataset.extras || "{}"
        );
    }
    catch {
        extras = {};
    }

    for (const [extraName, viewField] of Object.entries(targetMap)) {
        const target = findFieldControl(viewField);
        if (target) {
            target.value = extras[extraName] ?? "";
        }
    }
}


async function savePlanningRecord(continueAfterSave) {

    clearPlanningEditStatus();

    const validation =
        collectDynamicValues();

    if (!validation.ok) {

        setPlanningEditStatus(
            "error",
            "Validation error",
            validation.message
        );

        validation.control?.focus();

        return;

    }

    const values =
        validation.values;

    setPlanningSaving(true);

    try {

        let url;
        let method;

        if (planningFormMode === "create") {

            url =
                `/api/planning/${encodeURIComponent(planningEntity)}`;

            method = "POST";

        }
        else {

            url =
                `/api/planning/${encodeURIComponent(planningEntity)}/${encodeURIComponent(planningEditingKey)}`;

            method = "PUT";

        }

        const response =
            await fetch(
                url,
                {
                    method,
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({ values })
                }
            );

        let result;

        try {
            result =
                await response.json();
        }
        catch {
            throw new Error(
                "The server returned an invalid response."
            );
        }

        if (!response.ok || result.ok === false) {
            throw new Error(
                result.message ||
                "Unable to save record."
            );
        }

        await refreshPlanningPreview(false);

        if (
            result.key !== null &&
            result.key !== undefined &&
            result.key !== ""
        ) {
            await goToPlanningRecord(result.key);
        }

        if (planningFormMode === "create") {

            setPlanningEditStatus(
                "success",
                "Record created",
                result.warning
                    ? `${result.message || `${planningEntityConfig.title} was created successfully.`} ${result.warning}`
                    : (result.message || (result.key
                        ? `${planningEntityConfig.title} ${result.key} was created successfully.`
                        : `${planningEntityConfig.title} was created successfully.`))
            );

            if (continueAfterSave) {

                planningEditingKey = null;
                planningEditingRow = null;

                await buildDynamicFields(null);
                focusFirstEditableField();

                return;

            }

        }
        else {

            setPlanningEditStatus(
                "success",
                "Changes saved",
                result.message || `${planningEntityConfig.title} ${planningEditingKey} was updated successfully.`
            );

            if (continueAfterSave) {
                return;
            }

        }

        setTimeout(
            () => {
                closePlanningEditModal();
                clearPlanningEditStatus();
            },
            700
        );

    }
    catch (error) {

        console.error(
            "Planning save error:",
            error
        );

        setPlanningEditStatus(
            "error",
            "Unable to save",
            error.message ||
            "An unexpected error occurred."
        );

    }
    finally {

        setPlanningSaving(false);

    }

}


async function deletePlanningRecord() {

    if (
        planningFormMode !== "update" ||
        !planningEditingKey ||
        !planningEntityConfig?.allow_delete
    ) {
        return;
    }

    const confirmed = await showPlanningConfirm({
        title: `Delete ${planningEntityConfig.title}?`,
        message: `You are in the process of deleting ${planningEntityConfig.title} ${planningEditingKey}. Do you want to continue?`,
        confirmText: "Delete",
        danger: true
    });

    if (!confirmed) return;

    clearPlanningEditStatus();
    setPlanningSaving(true);

    try {
        const response = await fetch(
            `/api/planning/${encodeURIComponent(planningEntity)}/${encodeURIComponent(planningEditingKey)}`,
            { method: "DELETE" }
        );

        const result = await response.json();

        if (!response.ok || result.ok === false) {
            throw new Error(
                result.message || "Unable to delete record."
            );
        }

        planningSelectedRowKey = null;
        closePlanningEditModal();
        await refreshPlanningPreview(false);
        await showPlanningNotice({
            title: "Record removed",
            message: result.warning
                ? `${result.message || "Record removed successfully."} ${result.warning}`
                : (result.message || "Record removed successfully."),
            type: result.warning ? "warning" : "success"
        });
    }
    catch (error) {
        setPlanningEditStatus(
            "error",
            "Unable to delete",
            error.message || "An unexpected error occurred."
        );
    }
    finally {
        setPlanningSaving(false);
    }
}


function collectDynamicValues() {

    const values = {};
    const parsedDates = {};
    const fields =
        planningEntityConfig.fields || [];

    clearAllControlInvalid();

    for (const field of fields) {

        if (
            planningFormMode === "create" &&
            field.show_on_create === false
        ) {
            continue;
        }

        if (
            field.type === "readonly" ||
            field.type === "display"
        ) {
            continue;
        }

        const control =
            findFieldControl(field.view_field);

        if (!control) continue;

        let value;

        if (field.type === "checkbox") {
            value = Boolean(control.checked);
        }
        else {
            value = control.value;
        }

        const isBlank =
            value === null ||
            value === undefined ||
            (
                typeof value === "string" &&
                value.trim() === ""
            );

        if (field.required && isBlank) {
            markControlInvalid(control);
            return {
                ok: false,
                message:
                    `${field.label || field.view_field} is mandatory.`,
                control,
            };
        }

        if (field.type === "number" || field.type === "money") {

            if (isBlank) {
                value = null;
            }
            else {
                const numericText =
                    field.type === "money"
                        ? stripPlanningMoney(value)
                        : value;

                value = Number(numericText);

                if (Number.isNaN(value)) {
                    markControlInvalid(control);
                    return {
                        ok: false,
                        message:
                            `${field.label || field.view_field} must be numeric.`,
                        control,
                    };
                }

                if (
                    field.min !== null &&
                    field.min !== undefined &&
                    value < Number(field.min)
                ) {
                    markControlInvalid(control);
                    return {
                        ok: false,
                        message:
                            `${field.label || field.view_field} must be at least ${field.min}.`,
                        control,
                    };
                }

                if (
                    field.max !== null &&
                    field.max !== undefined &&
                    value > Number(field.max)
                ) {
                    markControlInvalid(control);
                    return {
                        ok: false,
                        message:
                            `${field.label || field.view_field} must be at most ${field.max}.`,
                        control,
                    };
                }

                if (field.type === "money") {
                    control.value = formatPlanningMoney(
                        value,
                        field.decimals ?? 2
                    );
                }
            }

        }
        else if (field.type === "lookup") {

            value =
                isBlank
                    ? null
                    : (
                        Number.isNaN(Number(value))
                            ? value
                            : Number(value)
                    );

        }
        else if (field.type === "date") {

            if (isBlank) {
                value = null;
            }
            else {
                const parsed =
                    parsePlanningDate(control.dataset.isoValue || value);

                if (!parsed) {
                    markControlInvalid(control);
                    return {
                        ok: false,
                        message:
                            `${field.label || field.view_field} must contain a valid date.`,
                        control,
                    };
                }

                parsedDates[field.view_field] = parsed;
                value = planningDateToIso(parsed);
                control.dataset.isoValue = value;
                control.value = planningMediumDate(parsed);
            }

        }
        else if (typeof value === "string") {

            value = value.trim();

            if (field.transform === "uppercase") {
                value = value.toUpperCase();
                control.value = value;
            }
            else if (field.transform === "lowercase") {
                value = value.toLowerCase();
                control.value = value;
            }

            if (
                field.min_length !== null &&
                field.min_length !== undefined &&
                value.length < Number(field.min_length)
            ) {
                markControlInvalid(control);
                return {
                    ok: false,
                    message:
                        `${field.label || field.view_field} must contain at least ${field.min_length} characters.`,
                    control,
                };
            }

            if (
                field.max_length !== null &&
                field.max_length !== undefined &&
                value.length > Number(field.max_length)
            ) {
                markControlInvalid(control);
                return {
                    ok: false,
                    message:
                        `${field.label || field.view_field} cannot exceed ${field.max_length} characters.`,
                    control,
                };
            }

            if (field.pattern && value) {
                try {
                    const regex = new RegExp(field.pattern);
                    if (!regex.test(value)) {
                        markControlInvalid(control);
                        return {
                            ok: false,
                            message:
                                field.pattern_message ||
                                `${field.label || field.view_field} has an invalid format.`,
                            control,
                        };
                    }
                }
                catch (error) {
                    console.warn(
                        "Invalid Planning regex:",
                        field.pattern,
                        error
                    );
                }
            }

        }

        values[field.view_field] = value;

    }

    /* Cross-field date validation */
    for (const field of fields) {

        const current =
            parsedDates[field.view_field];

        if (!current) continue;

        if (field.after_or_equal) {
            const other = parsedDates[field.after_or_equal];

            if (other && current.getTime() < other.getTime()) {
                const control = findFieldControl(field.view_field);
                markControlInvalid(control);

                return {
                    ok: false,
                    message:
                        `${field.label || field.view_field} cannot be earlier than ${field.after_or_equal}.`,
                    control,
                };
            }
        }

        if (field.before_or_equal) {
            const other = parsedDates[field.before_or_equal];

            if (other && current.getTime() > other.getTime()) {
                const control = findFieldControl(field.view_field);
                markControlInvalid(control);

                return {
                    ok: false,
                    message:
                        `${field.label || field.view_field} cannot be later than ${field.before_or_equal}.`,
                    control,
                };
            }
        }

    }

    return {
        ok: true,
        values,
    };

}



function findFieldControl(viewField) {

    const controls =
        document.querySelectorAll(
            '[data-planning-field="1"]'
        );

    for (const control of controls) {
        if (
            control.dataset.viewField ===
            String(viewField)
        ) {
            return control;
        }
    }

    return null;

}


function getFieldValue(viewField) {

    const control =
        findFieldControl(viewField);

    if (!control) return null;

    if (control.type === "checkbox") {
        return Boolean(control.checked);
    }

    return control.value;

}


function findPlanningColumnIndex(columnName) {

    const columns =
        state.previewColumns || [];

    const wanted =
        String(columnName ?? "")
            .trim()
            .toLowerCase();

    if (!wanted) return -1;

    return columns.findIndex(
        column =>
            String(column ?? "")
                .trim()
                .toLowerCase() === wanted
    );

}


function getPlanningRowValue(row, columnName) {

    if (!row || !columnName) return "";

    /*
       Object rows are used by the authoritative GET before Update.
       Resolve object properties case-insensitively too.
    */
    if (!Array.isArray(row)) {

        if (
            Object.prototype.hasOwnProperty.call(
                row,
                columnName
            )
        ) {
            return row[columnName] ?? "";
        }

        const wanted =
            String(columnName)
                .trim()
                .toLowerCase();

        const actualKey =
            Object.keys(row).find(
                key =>
                    String(key)
                        .trim()
                        .toLowerCase() === wanted
            );

        return actualKey
            ? (row[actualKey] ?? "")
            : "";
    }

    const index =
        findPlanningColumnIndex(
            columnName
        );

    if (index < 0) return "";

    return row[index] ?? "";

}


function getPlanningFieldRowValue(row, field) {

    const sourceFields = field.source_fields || [];

    // For lookups, prefer the stored database key when the record endpoint
    // provides it.  Legacy VIEWs often expose only the display label, which
    // cannot reliably repopulate a select during Update.
    const keyLikeSources =
        field.type === "lookup"
            ? sourceFields.filter(name => /(^|_)key$/i.test(String(name).replace(/\s+/g, "_")))
            : [];

    const candidates = [
        ...(field.type === "lookup" && field.column ? [field.column] : []),
        ...keyLikeSources,
        field.view_field,
        ...sourceFields.filter(name => !keyLikeSources.includes(name))
    ].filter((value, index, array) =>
        value && array.indexOf(value) === index
    );

    for (const candidate of candidates) {
        if (!candidate) continue;

        const value =
            getPlanningRowValue(
                row,
                candidate
            );

        if (
            value !== "" &&
            value !== null &&
            value !== undefined
        ) {
            return value;
        }
    }

    return "";
}


const PLANNING_MONTHS = {
    jan: 0,
    feb: 1,
    mar: 2,
    apr: 3,
    may: 4,
    jun: 5,
    jul: 6,
    aug: 7,
    sep: 8,
    oct: 9,
    nov: 10,
    dec: 11,
};

const PLANNING_MONTH_LABELS = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];


function parsePlanningDate(value) {

    if (!value) return null;

    if (value instanceof Date) {
        return Number.isNaN(value.getTime())
            ? null
            : new Date(
                value.getFullYear(),
                value.getMonth(),
                value.getDate()
            );
    }

    const text =
        String(value).trim();

    /* DD-MMM-YYYY */
    let match =
        text.match(
            /^(\d{1,2})-([A-Za-z]{3})-(\d{4})$/
        );

    if (match) {
        const day = Number(match[1]);
        const month = PLANNING_MONTHS[match[2].toLowerCase()];
        const year = Number(match[3]);

        if (month === undefined) return null;

        const parsed = new Date(year, month, day);

        if (
            parsed.getFullYear() !== year ||
            parsed.getMonth() !== month ||
            parsed.getDate() !== day
        ) {
            return null;
        }

        return parsed;
    }

    /* ISO: YYYY-MM-DD or YYYY-MM-DDTHH:mm:ss */
    match =
        text.match(
            /^(\d{4})-(\d{2})-(\d{2})(?:[T\s].*)?$/
        );

    if (match) {
        const year = Number(match[1]);
        const month = Number(match[2]) - 1;
        const day = Number(match[3]);
        const parsed = new Date(year, month, day);

        if (
            parsed.getFullYear() !== year ||
            parsed.getMonth() !== month ||
            parsed.getDate() !== day
        ) {
            return null;
        }

        return parsed;
    }

    /* MM/DD/YYYY accepted for compatibility with old Access input */
    match =
        text.match(
            /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/
        );

    if (match) {
        const month = Number(match[1]) - 1;
        const day = Number(match[2]);
        const year = Number(match[3]);
        const parsed = new Date(year, month, day);

        if (
            parsed.getFullYear() !== year ||
            parsed.getMonth() !== month ||
            parsed.getDate() !== day
        ) {
            return null;
        }

        return parsed;
    }

    return null;

}


function planningMediumDate(value) {

    const parsed =
        parsePlanningDate(value);

    if (!parsed) {
        return value
            ? String(value)
            : "";
    }

    const day =
        String(parsed.getDate()).padStart(2, "0");

    const month =
        PLANNING_MONTH_LABELS[parsed.getMonth()];

    const year =
        parsed.getFullYear();

    return `${day}-${month}-${year}`;

}


function planningDateToIso(value) {

    const parsed =
        parsePlanningDate(value);

    if (!parsed) return null;

    const year =
        String(parsed.getFullYear());

    const month =
        String(parsed.getMonth() + 1).padStart(2, "0");

    const day =
        String(parsed.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;

}


function stripPlanningMoney(value) {
    return String(value ?? "")
        .replace(/,/g, "")
        .replace(/\s/g, "")
        .trim();
}


function formatPlanningMoney(value, decimals = 2) {

    if (value === null || value === undefined || value === "") {
        return "";
    }

    const numeric = Number(stripPlanningMoney(value));

    if (Number.isNaN(numeric)) {
        return String(value);
    }

    return numeric.toLocaleString("en-US", {
        minimumFractionDigits: Number(decimals ?? 2),
        maximumFractionDigits: Number(decimals ?? 2),
    });
}


function syncAllDerivedPlanningFields() {
    const fields = planningEntityConfig?.fields || [];
    const sources = new Set(
        fields
            .map(field => field.derived_from)
            .filter(Boolean)
    );

    for (const source of sources) {
        syncDerivedPlanningFields(source);
    }
}


function syncDerivedPlanningFields(sourceField) {

    const fields = planningEntityConfig?.fields || [];

    for (const field of fields) {
        if (field.derived_from !== sourceField) continue;

        const source = findFieldControl(sourceField);
        const target = findFieldControl(field.view_field);

        if (!source || !target) continue;

        if (field.derive === "year") {
            const parsed = parsePlanningDate(source.value);
            target.value = parsed ? String(parsed.getFullYear()) : "";
        }
    }
}


function markControlInvalid(control) {

    control?.classList.add(
        "planning-field-invalid"
    );

    control
        ?.closest(".planning-dynamic-field")
        ?.classList.add(
            "has-validation-error"
        );

}


function clearControlInvalid(control) {

    control?.classList.remove(
        "planning-field-invalid"
    );

    control
        ?.closest(".planning-dynamic-field")
        ?.classList.remove(
            "has-validation-error"
        );

}


function clearAllControlInvalid() {

    document
        .querySelectorAll(
            ".planning-field-invalid"
        )
        .forEach(
            control => {
                control.classList.remove(
                    "planning-field-invalid"
                );
            }
        );

    document
        .querySelectorAll(
            ".planning-dynamic-field.has-validation-error"
        )
        .forEach(
            wrapper => {
                wrapper.classList.remove(
                    "has-validation-error"
                );
            }
        );

}


async function goToPlanningRecord(key) {

    if (
        key === null ||
        key === undefined ||
        String(key).trim() === ""
    ) {
        return false;
    }

    if (isPlanningServerPaged()) {
        const keyColumn =
            planningEntityConfig?.view_key || "Key";

        const rowHasKey =
            row => String(getPlanningRowValue(row, keyColumn)) === String(key);

        let currentRows = state.previewRows || [];
        let found = currentRows.some(rowHasKey);

        if (!found) {
            // A newly created record sorts to the first page by Key DESC.
            // Clear filters that could hide it and reload directly from SQL.
            state.columnFilters = {};
            planningSort = { column: null, direction: null };
            planningServerPaging.page = 1;
            planningServerPaging.quickFilterText = "";
            const quickInput = document.getElementById("planningServerFilterText");
            if (quickInput) quickInput.value = "";
            await refreshPlanningPreview(false);
            currentRows = state.previewRows || [];
            found = currentRows.some(rowHasKey);
        }

        if (!found) {
            console.warn("Planning record was saved but was not found on the first server page:", key);
            return false;
        }

        planningSelectedRowKey = String(key);
        renderPreviewTable();
        updatePageInfo();
        afterPlanningPreviewRender();
        return true;
    }

    const keyColumn =
        planningEntityConfig?.view_key || "Key";

    const keyIndex =
        findPlanningColumnIndex(
            keyColumn
        );

    if (keyIndex < 0) {
        console.warn(
            "Planning key column not found:",
            keyColumn,
            state.previewColumns
        );
        return false;
    }

    const rowHasKey =
        row =>
            String(
                getPlanningRowValue(
                    row,
                    keyColumn
                )
            ) === String(key);

    let rows =
        getFilteredRows();

    let rowIndex =
        rows.findIndex(
            rowHasKey
        );

    /*
       If filters hide the newly inserted record, clear them.
    */
    if (rowIndex < 0) {

        const allRows =
            state.previewRows || [];

        const exists =
            allRows.some(
                rowHasKey
            );

        if (exists) {

            state.columnFilters = {};

            rows =
                getFilteredRows();

            rowIndex =
                rows.findIndex(
                    rowHasKey
                );
        }
    }

    /*
       Preview normally loads TOP 1000. If the record is outside
       that window, fetch it by key and append it to Preview.
    */
    if (rowIndex < 0) {

        try {

            const response =
                await fetch(
                    `/api/planning/${encodeURIComponent(planningEntity)}/${encodeURIComponent(key)}`
                );

            const result =
                await response.json();

            if (
                response.ok &&
                result.ok !== false &&
                Array.isArray(result.row)
            ) {

                const allRows =
                    state.previewRows || [];

                const alreadyExists =
                    allRows.some(
                        rowHasKey
                    );

                if (!alreadyExists) {
                    state.previewRows = [
                        ...allRows,
                        result.row
                    ];
                }

                if (
                    planningSort.column &&
                    planningSort.direction
                ) {
                    sortPlanningRowsInPlace(
                        planningSort.column,
                        planningSort.direction
                    );
                }

                rows =
                    getFilteredRows();

                rowIndex =
                    rows.findIndex(
                        rowHasKey
                    );

            }

        }
        catch (error) {

            console.warn(
                "Unable to fetch saved Planning record:",
                error
            );

        }

    }

    if (rowIndex < 0) {

        console.warn(
            "Planning record was saved but was not found in Preview:",
            key
        );

        return false;

    }

    const pageSize =
        state.pageSize || 25;

    state.page =
        Math.floor(
            rowIndex / pageSize
        ) + 1;

    planningSelectedRowKey =
        String(key);

    renderPreviewTable();
    updatePageInfo();
    afterPlanningPreviewRender();

    return true;

}


function bindPlanningRowSelection() {

    const table =
        document.getElementById("previewTable");

    if (!table) return;

    if (table.dataset.planningSelectionBound === "1") {
        return;
    }

    table.dataset.planningSelectionBound = "1";

    table.addEventListener(
        "click",
        event => {

            if (
                event.target.closest(
                    ".filter-row, " +
                    ".excel-filter-wrap, " +
                    ".excel-filter-btn, " +
                    "input, button, select, textarea"
                )
            ) {
                return;
            }

            const rowElement =
                event.target.closest("tbody tr");

            if (!rowElement) return;

            const checkbox =
                rowElement.querySelector(".row-check");

            if (!checkbox) return;

            const rowIndex =
                Number(checkbox.dataset.rowIndex);

            if (Number.isNaN(rowIndex)) return;

            const rows =
                getFilteredRows();

            const row =
                rows[rowIndex];

            if (!row) return;

            const key =
                getPlanningRowValue(
                    row,
                    planningEntityConfig?.view_key || "Key"
                );

            /*
               Never select an empty key. Previously, if the VIEW used
               "key" while config used "Key", every empty key matched
               and all visible rows could turn pink.
            */
            if (
                key === null ||
                key === undefined ||
                String(key).trim() === ""
            ) {
                return;
            }

            planningSelectedRowKey =
                String(key);

            applyPlanningSelectedRowHighlight();

        }
    );

}


function applyPlanningSelectedRowHighlight() {

    const table =
        document.getElementById("previewTable");

    if (!table) return;

    table
        .querySelectorAll("tbody tr")
        .forEach(
            row => row.classList.remove("planning-row-selected")
        );

    if (
        planningSelectedRowKey === null ||
        planningSelectedRowKey === undefined
    ) {
        return;
    }

    const rows =
        getFilteredRows();

    table
        .querySelectorAll("tbody tr")
        .forEach(
            rowElement => {

                const checkbox =
                    rowElement.querySelector(".row-check");

                if (!checkbox) return;

                const rowIndex =
                    Number(checkbox.dataset.rowIndex);

                if (Number.isNaN(rowIndex)) return;

                const row = rows[rowIndex];
                if (!row) return;

                const key =
                    getPlanningRowValue(
                        row,
                        planningEntityConfig?.view_key || "Key"
                    );

                if (
                    key !== null &&
                    key !== undefined &&
                    String(key).trim() !== "" &&
                    String(key) ===
                    String(planningSelectedRowKey)
                ) {
                    rowElement.classList.add("planning-row-selected");
                }

            }
        );

}


function startPlanningPreviewObserver() {

    const table =
        document.getElementById("previewTable");

    if (!table) return;

    planningPreviewObserver?.disconnect();

    planningPreviewObserver =
        new MutationObserver(
            () => {
                queueMicrotask(
                    afterPlanningPreviewRender
                );
            }
        );

    planningPreviewObserver.observe(
        table,
        {
            childList: true,
            subtree: true,
        }
    );

    afterPlanningPreviewRender();

}


function afterPlanningPreviewRender() {
    decoratePlanningSortControls();
    bindPlanningColumnDragAndDrop();
    applyPlanningSelectedRowHighlight();
    decoratePlanningStatusCells();
    updatePlanningServerPagerUI();
}

function planningStatusClass(value) {
    const text = String(value || "").trim().toUpperCase();
    if (text === "NOT STARTED" || text === "NOT STARTED.") return "status-not-started";
    if (text === "IN PROGRESS" || text === "IN PROGRES") return "status-in-progress";
    if (text === "COMPLETED" || text === "COMPLETE") return "status-completed";
    if (text === "CANCELED" || text === "CANCELLED") return "status-canceled";
    return "";
}

function decoratePlanningStatusCells() {
    const table = document.getElementById("previewTable");
    if (!table) return;

    const headerRows = [...table.querySelectorAll("thead tr")];
    const headerRow = headerRows.find(row => !row.classList.contains("filter-row"));
    if (!headerRow) return;

    const headers = [...headerRow.querySelectorAll("th")];
    const statusIndex = headers.findIndex(th => {
        const text = String(th.dataset.col || th.textContent || "").trim().toUpperCase();
        return text === "STATUS" || text === "ESTADO";
    });
    if (statusIndex < 0) return;

    table.querySelectorAll("tbody tr").forEach(row => {
        if (row.classList.contains("filter-row")) return;
        const cells = row.querySelectorAll("td");
        const cell = cells[statusIndex];
        if (!cell) return;

        const existing = cell.querySelector(".planning-status-badge");
        const rawText = existing ? existing.textContent : cell.textContent;
        const cls = planningStatusClass(rawText);
        if (!cls) return;

        if (existing) {
            existing.className = `planning-status-badge ${cls}`;
            return;
        }

        const badge = document.createElement("span");
        badge.className = `planning-status-badge ${cls}`;
        badge.textContent = String(rawText || "").trim();
        cell.textContent = "";
        cell.appendChild(badge);
    });
}


function decoratePlanningSortControls() {

    const table =
        document.getElementById("previewTable");

    if (!table) return;

    /*
       Sorting now lives inside the existing hamburger/filter menu,
       so the filter row no longer spends width on two arrow buttons.
    */
    table
        .querySelectorAll(".planning-sort-controls")
        .forEach(
            control => control.remove()
        );

    table
        .querySelectorAll(".excel-filter-btn")
        .forEach(
            button => {

                const column =
                    button.dataset.col ||
                    button
                        .closest(".excel-filter-wrap")
                        ?.dataset.col;

                if (!column) return;

                const isSorted =
                    planningSort.column === column &&
                    planningSort.direction;

                button.title =
                    isSorted
                        ? (
                            planningSort.direction === "asc"
                                ? "Filter options • sorted ascending"
                                : "Filter options • sorted descending"
                        )
                        : "Filter and sort options";

            }
        );

    if (table.dataset.planningSortMenuBound === "1") {
        return;
    }

    table.dataset.planningSortMenuBound = "1";

    table.addEventListener(
        "click",
        event => {

            const button =
                event.target.closest(
                    ".excel-filter-btn"
                );

            if (!button) return;

            const column =
                button.dataset.col ||
                button
                    .closest(".excel-filter-wrap")
                    ?.dataset.col;

            if (!column) return;

            /*
               preview.js calls stopPropagation() on this button.
               We listen in CAPTURE phase so we still see the click,
               then decorate the menu after preview.js opens it.
            */
            setTimeout(
                () => {
                    decoratePlanningFloatingFilterMenu(
                        column
                    );
                },
                0
            );

        },
        true
    );

}


function decoratePlanningFloatingFilterMenu(column) {

    const menu =
        document.getElementById(
            "floatingFilterMenu"
        );

    if (!menu) return;

    menu
        .querySelectorAll(".planning-menu-sort-section")
        .forEach(
            element => element.remove()
        );

    const section =
        document.createElement("div");

    section.className =
        "planning-menu-sort-section";

    const heading =
        document.createElement("div");

    heading.className =
        "planning-menu-sort-title";

    heading.textContent =
        "Sort";

    section.appendChild(heading);

    const actions = [
        ["asc", "↑", "Ascending"],
        ["desc", "↓", "Descending"],
        ["clear", "↕", "Clear sort"],
    ];

    for (
        const [direction, icon, label]
        of actions
    ) {

        const button =
            document.createElement("button");

        button.type = "button";
        button.className =
            "planning-menu-sort-btn";

        if (
            direction !== "clear" &&
            planningSort.column === column &&
            planningSort.direction === direction
        ) {
            button.classList.add("is-active");
        }

        button.innerHTML =
            `<span class="planning-menu-sort-icon">${icon}</span>` +
            `<span>${label}</span>`;

        button.addEventListener(
            "click",
            async event => {

                event.preventDefault();
                event.stopPropagation();

                if (direction === "clear") {
                    await clearPlanningSort();
                }
                else {
                    applyPlanningSort(
                        column,
                        direction
                    );
                }

                menu.classList.add(
                    "excel-menu-hidden"
                );

            }
        );

        section.appendChild(button);
    }

    menu.prepend(section);

}


async function clearPlanningSort() {

    planningSort = {
        column: null,
        direction: null,
    };

    if (isPlanningServerPaged()) {
        planningServerPaging.page = 1;
    }

    /*
       Reload to restore the VIEW/database order instead of leaving
       the already sorted array in memory.
    */
    await refreshPlanningPreview(false);

}


function bindPlanningColumnDragAndDrop() {

    const table =
        document.getElementById("previewTable");

    if (!table) return;

    const headerRows =
        Array.from(
            table.querySelectorAll(
                "thead tr"
            )
        );

    const headerRow =
        headerRows.find(
            row =>
                !row.classList.contains("filter-row")
        );

    if (!headerRow) return;

    const visibleColumns =
        state.visibleColumns || [];

    const headers =
        Array.from(
            headerRow.querySelectorAll("th")
        );

    headers.forEach(
        (th, index) => {

            /*
               First TH is the checkbox/select column.
            */
            if (index === 0) {
                th.draggable = false;
                return;
            }

            const column =
                visibleColumns[index - 1];

            if (!column) return;

            th.dataset.planningColumn =
                column;

            th.draggable = true;
            th.classList.add(
                "planning-draggable-column"
            );

            th.title =
                `${column} • drag to move column`;

            th.ondragstart =
                event => {

                    event.dataTransfer.effectAllowed =
                        "move";

                    event.dataTransfer.setData(
                        "text/plain",
                        column
                    );

                    th.classList.add(
                        "planning-column-dragging"
                    );

                };

            th.ondragend =
                () => {

                    table
                        .querySelectorAll(
                            ".planning-column-drag-over, .planning-column-dragging"
                        )
                        .forEach(
                            element => {
                                element.classList.remove(
                                    "planning-column-drag-over",
                                    "planning-column-dragging"
                                );
                            }
                        );

                };

            th.ondragover =
                event => {

                    event.preventDefault();

                    event.dataTransfer.dropEffect =
                        "move";

                    th.classList.add(
                        "planning-column-drag-over"
                    );

                };

            th.ondragleave =
                () => {
                    th.classList.remove(
                        "planning-column-drag-over"
                    );
                };

            th.ondrop =
                event => {

                    event.preventDefault();

                    const sourceColumn =
                        event.dataTransfer.getData(
                            "text/plain"
                        );

                    const targetColumn =
                        th.dataset.planningColumn;

                    movePlanningVisibleColumn(
                        sourceColumn,
                        targetColumn
                    );

                };

        }
    );

}


function movePlanningVisibleColumn(
    sourceColumn,
    targetColumn
) {

    if (
        !sourceColumn ||
        !targetColumn ||
        sourceColumn === targetColumn
    ) {
        return;
    }

    const columns = [
        ...(state.visibleColumns || [])
    ];

    const sourceIndex =
        columns.indexOf(
            sourceColumn
        );

    const targetIndex =
        columns.indexOf(
            targetColumn
        );

    if (
        sourceIndex < 0 ||
        targetIndex < 0
    ) {
        return;
    }

    const [moved] =
        columns.splice(
            sourceIndex,
            1
        );

    columns.splice(
        targetIndex,
        0,
        moved
    );

    state.visibleColumns =
        columns;

    localStorage.setItem(
        `planning-view-${planningEntity}`,
        JSON.stringify(columns)
    );

    renderPreviewTable();
    updatePageInfo();
    afterPlanningPreviewRender();

}


async function applyPlanningSort(column, direction) {

    if (!column) return;

    planningSort = {
        column,
        direction,
    };

    if (isPlanningServerPaged()) {
        planningServerPaging.page = 1;
        await refreshPlanningPreview(false);
        return;
    }

    sortPlanningRowsInPlace(
        column,
        direction
    );

    state.page = 1;

    renderPreviewTable();
    updatePageInfo();
    afterPlanningPreviewRender();

}


function sortPlanningRowsInPlace(column, direction) {

    const columns =
        state.previewColumns || [];

    const index =
        columns.indexOf(column);

    if (index < 0) return;

    const multiplier =
        direction === "desc"
            ? -1
            : 1;

    state.previewRows =
        [...(state.previewRows || [])]
            .sort(
                (a, b) => {

                    const aValue =
                        Array.isArray(a)
                            ? a[index]
                            : a[column];

                    const bValue =
                        Array.isArray(b)
                            ? b[index]
                            : b[column];

                    const aBlank =
                        aValue === null ||
                        aValue === undefined ||
                        String(aValue).trim() === "";

                    const bBlank =
                        bValue === null ||
                        bValue === undefined ||
                        String(bValue).trim() === "";

                    /* Keep empty values at the bottom in both directions. */
                    if (aBlank && bBlank) return 0;
                    if (aBlank) return 1;
                    if (bBlank) return -1;

                    const result =
                        comparePlanningValues(
                            aValue,
                            bValue
                        );

                    return result * multiplier;
                }
            );

}


function comparePlanningValues(aValue, bValue) {

    const aBlank =
        aValue === null ||
        aValue === undefined ||
        String(aValue).trim() === "";

    const bBlank =
        bValue === null ||
        bValue === undefined ||
        String(bValue).trim() === "";

    if (aBlank && bBlank) return 0;
    if (aBlank) return 1;
    if (bBlank) return -1;

    const aNumber = Number(aValue);
    const bNumber = Number(bValue);

    if (
        !Number.isNaN(aNumber) &&
        !Number.isNaN(bNumber) &&
        String(aValue).trim() !== "" &&
        String(bValue).trim() !== ""
    ) {
        return aNumber - bNumber;
    }

    const aDate = parsePlanningDate(aValue);
    const bDate = parsePlanningDate(bValue);

    if (aDate && bDate) {
        return aDate.getTime() - bDate.getTime();
    }

    return String(aValue)
        .localeCompare(
            String(bValue),
            undefined,
            {
                numeric: true,
                sensitivity: "base",
            }
        );

}



function focusFirstEditableField() {

    setTimeout(
        () => {

            const controls =
                document.querySelectorAll(
                    '#planningDynamicFields [data-planning-field="1"]'
                );

            for (const control of controls) {

                if (
                    !control.readOnly &&
                    !control.disabled
                ) {
                    control.focus();
                    break;
                }

            }

        },
        60
    );

}


function closePlanningEditModal() {

    document
        .getElementById("planningEditModal")
        ?.classList.add("hidden");

    planningFormMode = null;
    planningEditingKey = null;
    planningEditingRow = null;

    clearPlanningEditStatus();

}


function setPlanningSaving(isSaving) {

    const overlay =
        document.getElementById(
            "planningEditSavingOverlay"
        );

    overlay
        ?.classList
        .toggle(
            "hidden",
            !isSaving
        );

    for (
        const id of [
            "btnUpdateContinue",
            "btnUpdateExit",
            "btnCancelPlanningEdit",
            "btnClosePlanningEdit",
        ]
    ) {

        const button =
            document.getElementById(id);

        if (button) {
            button.disabled = Boolean(isSaving);
        }

    }

}


function setPlanningEditStatus(
    type,
    title,
    text
) {

    const bar =
        document.getElementById("planningEditStatus");

    const icon =
        document.getElementById("planningEditStatusIcon");

    const titleEl =
        document.getElementById("planningEditStatusTitle");

    const textEl =
        document.getElementById("planningEditStatusText");

    if (!bar || !icon || !titleEl || !textEl) return;

    bar.classList.remove(
        "hidden",
        "is-success",
        "is-error",
        "is-info"
    );

    bar.classList.add(`is-${type}`);

    icon.textContent =
        type === "success"
            ? "✓"
            : (
                type === "error"
                    ? "!"
                    : "i"
            );

    titleEl.textContent = title || "";
    textEl.textContent = text || "";

}


function clearPlanningEditStatus() {

    const bar =
        document.getElementById("planningEditStatus");

    if (!bar) return;

    bar.classList.add("hidden");

    bar.classList.remove(
        "is-success",
        "is-error",
        "is-info"
    );

}


function bindPlanningPreviewEvents(entity) {

    document
        .getElementById("pageSizeSelect")
        ?.addEventListener(
            "change",
            event => {

                const requestedPageSize =
                    parseInt(event.target.value, 10) || 25;

                if (isPlanningServerPaged()) {
                    planningServerPaging.pageSize = requestedPageSize;
                    planningServerPaging.page = 1;
                    state.pageSize = requestedPageSize;
                    refreshPlanningPreview(false).catch(error =>
                        console.error("Planning page-size error:", error)
                    );
                    return;
                }

                state.pageSize = requestedPageSize;
                state.page = 1;

                renderPreviewTable();
                updatePageInfo();

            }
        );

    document
        .getElementById("btnPrevPage")
        ?.addEventListener(
            "click",
            () => {

                if (isPlanningServerPaged()) {
                    if ((planningServerPaging.page || 1) <= 1) return;
                    planningServerPaging.page--;
                    refreshPlanningPreview(false).catch(error =>
                        console.error("Planning previous-page error:", error)
                    );
                    return;
                }

                if ((state.page || 1) <= 1) return;

                state.page--;

                renderPreviewTable();
                updatePageInfo();

            }
        );

    document
        .getElementById("btnNextPage")
        ?.addEventListener(
            "click",
            () => {

                if (isPlanningServerPaged()) {
                    if ((planningServerPaging.page || 1) >= (planningServerPaging.totalPages || 1)) return;
                    planningServerPaging.page++;
                    refreshPlanningPreview(false).catch(error =>
                        console.error("Planning next-page error:", error)
                    );
                    return;
                }

                const filtered =
                    getFilteredRows();

                const totalPages =
                    Math.max(
                        1,
                        Math.ceil(
                            filtered.length /
                            (state.pageSize || 25)
                        )
                    );

                if ((state.page || 1) >= totalPages) return;

                state.page++;

                renderPreviewTable();
                updatePageInfo();

            }
        );

    document
        .getElementById("btnClearPreviewFilters")
        ?.addEventListener(
            "click",
            () => {

                state.columnFilters = {};
                state.page = 1;

                if (isPlanningServerPaged()) {
                    planningServerPaging.page = 1;
                    planningServerPaging.filterSignature =
                        getPlanningServerFilterSignature();
                    refreshPlanningPreview(false).catch(error =>
                        console.error("Planning clear-filter error:", error)
                    );
                    return;
                }

                renderPreviewTable();
                updatePageInfo();

            }
        );

    document
        .getElementById("btnHidePreview")
        ?.addEventListener(
            "click",
            () => {

                const tableWrap =
                    document.querySelector(
                        ".preview-table-container"
                    );

                const footer =
                    document.querySelector(
                        ".preview-footer"
                    );

                const button =
                    document.getElementById(
                        "btnHidePreview"
                    );

                tableWrap?.classList.toggle("hidden");
                footer?.classList.toggle("hidden");

                if (button && tableWrap) {
                    button.innerHTML =
                        tableWrap.classList.contains("hidden")
                            ? "<span>👁</span> Show"
                            : "<span>🙈</span> Hide";
                }

            }
        );

    document
        .getElementById("btnConfigureView")
        ?.addEventListener(
            "click",
            openPlanningViewConfig
        );

    document
        .getElementById("btnCloseViewConfig")
        ?.addEventListener(
            "click",
            closePlanningViewConfig
        );

    document
        .getElementById("btnSaveView")
        ?.addEventListener(
            "click",
            () => {
                savePlanningViewConfig(entity);
            }
        );

    const columnSearch =
        document.getElementById("columnSearchInput");

    columnSearch
        ?.addEventListener(
            "input",
            renderPlanningColumnChecklist
        );

    document
        .getElementById("btnClearColumnSearch")
        ?.addEventListener(
            "click",
            () => {

                if (columnSearch) {
                    columnSearch.value = "";
                }

                renderPlanningColumnChecklist();

            }
        );

    document
        .getElementById("btnSelectAllColumns")
        ?.addEventListener(
            "click",
            () => {
                setPlanningColumnSelection(
                    state.availableColumns || []
                );
            }
        );

    document
        .getElementById("btnClearAllColumns")
        ?.addEventListener(
            "click",
            () => {
                setPlanningColumnSelection([]);
            }
        );

    document
        .getElementById("btnSelectFirst8Columns")
        ?.addEventListener(
            "click",
            () => {
                setPlanningColumnSelection(
                    (state.availableColumns || [])
                        .slice(0, 8)
                );
            }
        );

    document
        .getElementById("btnResetViewConfig")
        ?.addEventListener(
            "click",
            () => {

                state.columnFilters = {};
                state.pageSize = 25;
                if (isPlanningServerPaged()) {
                    planningServerPaging.page = 1;
                    planningServerPaging.pageSize = 25;
                }

                setPlanningColumnSelection(
                    (state.availableColumns || [])
                        .slice(0, 8)
                );

                const select =
                    document.getElementById("pageSizeSelect");

                if (select) {
                    select.value = "25";
                }

                if (isPlanningServerPaged()) {
                    planningServerPaging.filterSignature =
                        getPlanningServerFilterSignature();
                    refreshPlanningPreview(false).catch(error =>
                        console.error("Planning reset-view error:", error)
                    );
                }

            }
        );

    document
        .getElementById("btnExportExcel")
        ?.addEventListener(
            "click",
            openExportModal
        );

    document
        .getElementById("btnCancelExport")
        ?.addEventListener(
            "click",
            closeExportModal
        );

    document
        .getElementById("btnConfirmExport")
        ?.addEventListener(
            "click",
            confirmExport
        );

    document
        .querySelectorAll(
            'input[name="exportType"]'
        )
        .forEach(
            radio => {

                radio.addEventListener(
                    "change",
                    () => {

                        document
                            .querySelectorAll(
                                ".export-option-card"
                            )
                            .forEach(
                                card => {
                                    card.classList.remove("selected");
                                }
                            );

                        radio
                            .closest(".export-option-card")
                            ?.classList.add("selected");

                    }
                );

            }
        );

    document
        .getElementById("btnClosePlanningEdit")
        ?.addEventListener(
            "click",
            closePlanningEditModal
        );

    document
        .getElementById("btnCancelPlanningEdit")
        ?.addEventListener(
            "click",
            closePlanningEditModal
        );

    document
        .getElementById("btnClosePlanningStatus")
        ?.addEventListener(
            "click",
            clearPlanningEditStatus
        );

    document
        .getElementById("btnDeletePlanning")
        ?.addEventListener(
            "click",
            deletePlanningRecord
        );

    document
        .getElementById("btnUpdateContinue")
        ?.addEventListener(
            "click",
            () => {
                savePlanningRecord(true);
            }
        );

    document
        .getElementById("btnUpdateExit")
        ?.addEventListener(
            "click",
            () => {
                savePlanningRecord(false);
            }
        );

    document.addEventListener(
        "keydown",
        event => {

            if (event.key !== "Escape") return;

            const saving =
                document.getElementById(
                    "planningEditSavingOverlay"
                );

            if (
                saving &&
                !saving.classList.contains("hidden")
            ) {
                return;
            }

            const editModal =
                document.getElementById(
                    "planningEditModal"
                );

            if (
                editModal &&
                !editModal.classList.contains("hidden")
            ) {
                closePlanningEditModal();
                return;
            }

            const viewModal =
                document.getElementById("viewConfigModal");

            if (
                viewModal &&
                !viewModal.classList.contains("hidden")
            ) {
                closePlanningViewConfig();
                return;
            }

            const exportModal =
                document.getElementById("exportModal");

            if (
                exportModal &&
                !exportModal.classList.contains("hidden")
            ) {
                closeExportModal();
            }

        }
    );

}


function openPlanningViewConfig() {

    const modal =
        document.getElementById("viewConfigModal");

    if (!modal) return;

    const search =
        document.getElementById("columnSearchInput");

    if (search) {
        search.value = "";
    }

    renderPlanningColumnChecklist();

    modal.classList.remove("hidden");

}


function closePlanningViewConfig() {

    document
        .getElementById("viewConfigModal")
        ?.classList.add("hidden");

}


function renderPlanningColumnChecklist() {

    const box =
        document.getElementById("columnChecklist");

    if (!box) return;

    const search =
        (
            document
                .getElementById("columnSearchInput")
                ?.value || ""
        )
        .trim()
        .toLowerCase();

    const columns =
        state.availableColumns || [];

    const visible =
        new Set(state.visibleColumns || []);

    const filtered =
        columns.filter(
            column =>
                String(column)
                    .toLowerCase()
                    .includes(search)
        );

    box.innerHTML = "";

    filtered.forEach(
        column => {

            const label =
                document.createElement("label");

            label.className = "view-column-item";

            const checkbox =
                document.createElement("input");

            checkbox.type = "checkbox";
            checkbox.value = column;
            checkbox.checked = visible.has(column);

            label.appendChild(checkbox);
            label.appendChild(
                document.createTextNode(` ${column}`)
            );

            box.appendChild(label);

        }
    );

}


function setPlanningColumnSelection(columns) {

    const selected =
        new Set(columns);

    document
        .querySelectorAll(
            '#columnChecklist input[type="checkbox"]'
        )
        .forEach(
            checkbox => {
                checkbox.checked =
                    selected.has(checkbox.value);
            }
        );

}


function savePlanningViewConfig(entity) {

    const checked =
        Array.from(
            document.querySelectorAll(
                '#columnChecklist input[type="checkbox"]:checked'
            )
        )
        .map(
            checkbox => checkbox.value
        );

    if (!checked.length) {
        alert("Select at least one column.");
        return;
    }

    state.visibleColumns = checked;
    state.page = 1;

    localStorage.setItem(
        `planning-view-${entity}`,
        JSON.stringify(checked)
    );

    closePlanningViewConfig();

    renderPreviewTable();
    updatePageInfo();

}


function loadPlanningView(entity, columns) {

    try {

        const value =
            localStorage.getItem(
                `planning-view-${entity}`
            );

        if (!value) {
            return columns.slice(0, 8);
        }

        const saved =
            JSON.parse(value);

        if (!Array.isArray(saved)) {
            return columns.slice(0, 8);
        }

        const valid =
            saved.filter(
                column =>
                    columns.includes(column)
            );

        return valid.length
            ? valid
            : columns.slice(0, 8);

    }
    catch {

        return columns.slice(0, 8);

    }

}



function decoratePlanningDateField(wrapper, visibleInput, initialValue) {
    const shell = document.createElement("div");
    shell.className = "planning-date-shell";

    // Move the visible control into the shell.
    if (visibleInput.parentElement === wrapper) {
        wrapper.removeChild(visibleInput);
    }
    shell.appendChild(visibleInput);

    const picker = document.createElement("input");
    picker.type = "date";
    picker.className = "planning-native-date-picker";
    picker.tabIndex = -1;
    picker.setAttribute("aria-label", "Select date");
    picker.value = planningDateToIso(initialValue) || visibleInput.dataset.isoValue || "";

    const button = document.createElement("button");
    button.type = "button";
    button.className = "planning-date-button";
    button.textContent = "▣";
    button.title = "Select date";

    const openPicker = () => {
        try {
            if (typeof picker.showPicker === "function") picker.showPicker();
            else picker.click();
        }
        catch {
            picker.click();
        }
    };

    button.addEventListener("click", openPicker);
    visibleInput.addEventListener("click", openPicker);
    picker.addEventListener("change", () => {
        visibleInput.dataset.isoValue = picker.value || "";
        visibleInput.value = picker.value ? planningMediumDate(picker.value) : "";
        visibleInput.dispatchEvent(new Event("change", { bubbles: true }));
    });

    shell.appendChild(button);
    shell.appendChild(picker);
    wrapper.appendChild(shell);
}

// ============================================================
// v11 UX additions
// ============================================================
function hidePlanningOnlyToolbarActions() {
    // Hide is useful in Data Download but not in Planning.
    const ids = ["btnHidePreview", "btnHide"];
    for (const id of ids) {
        const el = document.getElementById(id);
        if (el) el.style.display = "none";
    }

    // Fallback: hide a toolbar button whose visible text is exactly Hide.
    document.querySelectorAll("#planningPage button").forEach(btn => {
        if ((btn.textContent || "").trim().replace(/^\S+\s*/, "") === "Hide" ||
            (btn.textContent || "").trim() === "Hide") {
            btn.style.display = "none";
        }
    });
}

function ensurePlanningDuplicateButton() {
    if (planningEntity !== "audit-project-planning" || !planningEntityConfig?.allow_duplicate) {
        return;
    }

    let button = document.getElementById("btnDuplicatePlanning");
    if (!button) {
        button = document.createElement("button");
        button.id = "btnDuplicatePlanning";
        button.type = "button";
        button.className = "planning-duplicate-btn";
        button.textContent = "⧉ Duplicate";
        button.addEventListener("click", () => {
            window.location.href = "/planning/audit-project-planning/duplicate";
        });
    }

    const newButton = document.getElementById("btnNewPlanning");
    const host = newButton?.parentElement || document.querySelector("#planningPage .preview-right");
    if (host && button.parentElement !== host) {
        if (newButton) host.insertBefore(button, newButton);
        else host.appendChild(button);
    }
}

function showPlanningConfirm({title, message, confirmText = "Confirm", danger = false}) {
    return new Promise(resolve => {
        const overlay = document.createElement("div");
        overlay.className = "planning-confirm-overlay";
        overlay.innerHTML = `
            <div class="planning-confirm-card" role="dialog" aria-modal="true">
                <div class="planning-confirm-icon ${danger ? "is-danger" : ""}">${danger ? "!" : "i"}</div>
                <h3>${escapePlanningHtml(title || "Confirm")}</h3>
                <p>${escapePlanningHtml(message || "")}</p>
                <div class="planning-confirm-actions">
                    <button type="button" data-action="cancel" class="planning-confirm-cancel">Cancel</button>
                    <button type="button" data-action="confirm" class="planning-confirm-ok ${danger ? "is-danger" : ""}">${escapePlanningHtml(confirmText)}</button>
                </div>
            </div>`;
        document.body.appendChild(overlay);

        const finish = value => {
            overlay.remove();
            resolve(value);
        };
        overlay.querySelector('[data-action="cancel"]').addEventListener("click", () => finish(false));
        overlay.querySelector('[data-action="confirm"]').addEventListener("click", () => finish(true));
        overlay.addEventListener("click", event => {
            if (event.target === overlay) finish(false);
        });
        overlay.querySelector('[data-action="confirm"]').focus();
    });
}


function showPlanningNotice({title, message, type = "success"}) {
    return new Promise(resolve => {
        const overlay = document.createElement("div");
        overlay.className = "planning-confirm-overlay";
        const icon = type === "success" ? "✓" : (type === "warning" ? "!" : "i");
        overlay.innerHTML = `
            <div class="planning-confirm-card" role="dialog" aria-modal="true">
                <div class="planning-confirm-icon ${type === "warning" ? "is-danger" : ""}">${icon}</div>
                <h3>${escapePlanningHtml(title || "Done")}</h3>
                <p>${escapePlanningHtml(message || "")}</p>
                <div class="planning-confirm-actions">
                    <button type="button" data-action="ok" class="planning-confirm-ok">OK</button>
                </div>
            </div>`;
        document.body.appendChild(overlay);
        const finish = () => { overlay.remove(); resolve(); };
        overlay.querySelector('[data-action="ok"]').addEventListener("click", finish);
        overlay.addEventListener("click", event => { if (event.target === overlay) finish(); });
        overlay.querySelector('[data-action="ok"]').focus();
    });
}

function escapePlanningHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
