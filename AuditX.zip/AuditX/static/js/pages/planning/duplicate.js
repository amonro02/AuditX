const page = document.getElementById("planningDuplicatePage");

if (page) {
    initDuplicatePlanning();
}

const workspaceRows = new Map();
const availableProjects = new Map();
let planningUsers = [];
let batchCompleted = false;

async function initDuplicatePlanning() {
    bindStaticEvents();
    await fillLookup("region", document.getElementById("dupRegion"));
}

function bindStaticEvents() {
    document.getElementById("btnDuplicateBack")?.addEventListener("click", () => {
        window.location.href = `/planning/audit-project-planning?refresh=${Date.now()}`;
    });

    document.getElementById("dupRegion")?.addEventListener("change", async event => {
        const region = event.target.value;
        const client = document.getElementById("dupClient");
        resetSelect(client, region ? "Loading..." : "-- Select Region first --", !region);
        clearAvailableProjects();
        clearWorkspace();
        planningUsers = [];

        if (region) {
            await fillLookup("client", client, region);
            client.disabled = false;
            planningUsers = await getLookup("planning_user", region);
        }
    });

    document.getElementById("dupClient")?.addEventListener("change", async event => {
        clearWorkspace();
        await loadAvailableProjects(event.target.value);
    });

    document.getElementById("btnAddDuplicateProjects")?.addEventListener("click", addSelectedProjects);
    document.getElementById("btnRunDuplicate")?.addEventListener("click", runDuplicate);
}

async function getLookup(name, parent = "") {
    const suffix = parent ? `?parent_value=${encodeURIComponent(parent)}` : "";
    const joiner = suffix ? "&" : "?";
    const response = await fetch(
        `/api/planning/lookup/${encodeURIComponent(name)}${suffix}${joiner}_=${Date.now()}`,
        { cache: "no-store" }
    );
    const result = await response.json();
    if (!response.ok || result.ok === false) {
        throw new Error(result.message || `Unable to load ${name}.`);
    }
    return result.items || [];
}

async function fillLookup(name, select, parent = "") {
    const items = await getLookup(name, parent);
    select.innerHTML = '<option value="">-- Select --</option>';
    for (const item of items) {
        const option = document.createElement("option");
        option.value = item.value;
        option.textContent = item.extra ? `${item.label} (${item.extra})` : item.label;
        select.appendChild(option);
    }
}

function resetSelect(select, text, disabled = false) {
    if (!select) return;
    select.innerHTML = `<option value="">${escapeHtml(text)}</option>`;
    select.disabled = disabled;
}

function clearAvailableProjects() {
    const list = document.getElementById("dupProjectList");
    if (list) list.innerHTML = '<div class="dup-project-row"><span></span><span></span><span>Select a client to load projects.</span></div>';
    updateSelectedProjectCount();
}

async function loadAvailableProjects(clientKey) {
    const list = document.getElementById("dupProjectList");
    if (!clientKey) {
        clearAvailableProjects();
        return;
    }

    list.innerHTML = '<div class="dup-project-row"><span></span><span></span><span>Loading...</span></div>';
    availableProjects.clear();
    const response = await fetch(
        `/api/planning/duplicate/projects?client_key=${encodeURIComponent(clientKey)}&_=${Date.now()}`,
        { cache: "no-store" }
    );
    const result = await response.json();
    if (!response.ok || result.ok === false) {
        list.innerHTML = `<div class="dup-project-row"><span></span><span></span><span>${escapeHtml(result.message || "Unable to load projects.")}</span></div>`;
        return;
    }

    list.innerHTML = "";
    for (const item of result.items || []) {
        availableProjects.set(String(item.value), item);
        const row = document.createElement("label");
        row.className = "dup-project-row";
        row.innerHTML = `
            <input type="checkbox" class="dup-project-check" value="${escapeHtml(item.value)}" data-label="${escapeHtml(item.label)}">
            <span class="dup-project-key">${escapeHtml(item.value)}</span>
            <span>${escapeHtml(item.label)}</span>`;
        row.querySelector("input").addEventListener("change", updateSelectedProjectCount);
        list.appendChild(row);
    }

    if (!(result.items || []).length) {
        list.innerHTML = '<div class="dup-project-row"><span></span><span></span><span>No active Audit Projects were found for this client.</span></div>';
    }
    updateSelectedProjectCount();
}

function updateSelectedProjectCount() {
    const count = document.querySelectorAll(".dup-project-check:checked").length;
    const label = document.getElementById("dupProjectCount");
    const button = document.getElementById("btnAddDuplicateProjects");
    if (label) label.textContent = `${count} selected`;
    if (button) button.disabled = count === 0;
}

function addSelectedProjects() {
    const selected = [...document.querySelectorAll(".dup-project-check:checked")];
    for (const check of selected) {
        const key = String(check.value);
        if (workspaceRows.has(key)) continue;
        const source = availableProjects.get(key) || {};
        const model = {
            audit_project_key: Number(key),
            audit_project_name: check.dataset.label || source.label || key,
            audit_lead_key: source.audit_lead_key ?? "",
            responsible_key: source.responsible_key ?? "",
        };
        workspaceRows.set(key, model);
        appendWorkspaceRow(model);
    }
    updateWorkspaceState();
}

function appendWorkspaceRow(model) {
    const tbody = document.getElementById("dupWorkspaceBody");
    const tr = document.createElement("tr");
    tr.dataset.projectKey = model.audit_project_key;

    tr.appendChild(textCell(model.audit_project_name));
    tr.appendChild(selectCell("audit_lead_key", planningUsers, true, model.audit_lead_key));
    tr.appendChild(selectCell("responsible_key", planningUsers, true, model.responsible_key));
    tr.appendChild(inputCell("Audit Scope", "text", true));
    tr.appendChild(dateCell("Start Date", true));
    tr.appendChild(dateCell("End Date", true));
    tr.appendChild(readonlyCell("From"));
    tr.appendChild(readonlyCell("To"));
    tr.appendChild(moneyCell("Budget", true));
    tr.appendChild(moneyCell("Budget USD", true));
    tr.appendChild(yesNoCell("Download"));
    tr.appendChild(yesNoCell("Capture"));
    tr.appendChild(yesNoCell("Development"));
    tr.appendChild(fixedStatusCell());
    tr.appendChild(inputCell("Comment", "text", true));

    const removeTd = document.createElement("td");
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "dup-back-btn";
    remove.textContent = "×";
    remove.title = "Remove from batch";
    remove.addEventListener("click", () => {
        workspaceRows.delete(String(model.audit_project_key));
        tr.remove();
        updateWorkspaceState();
    });
    removeTd.appendChild(remove);
    tr.appendChild(removeTd);

    tr.querySelectorAll("input,select,textarea").forEach(control => {
        control.addEventListener("change", () => {
            if (control.dataset.field === "Start Date" || control.dataset.field === "End Date") {
                syncYears(tr);
            }
            updateWorkspaceState();
        });
        control.addEventListener("input", updateWorkspaceState);
    });

    tbody.appendChild(tr);
}

function textCell(text) {
    const td = document.createElement("td");
    td.textContent = text;
    td.style.fontWeight = "700";
    td.style.minWidth = "190px";
    return td;
}

function selectCell(field, items, required = false, selectedValue = "") {
    const td = document.createElement("td");
    const select = document.createElement("select");
    select.dataset.field = field;
    if (required) select.dataset.required = "1";
    select.innerHTML = '<option value="">-- Select --</option>';

    let foundSelected = false;
    for (const item of items || []) {
        const option = document.createElement("option");
        option.value = item.value;
        option.textContent = item.extra ? `${item.label} (${item.extra})` : item.label;
        if (selectedValue !== "" && String(item.value) === String(selectedValue)) {
            option.selected = true;
            foundSelected = true;
        }
        select.appendChild(option);
    }

    // Preserve a legacy assignment even when that user is no longer present in
    // the current active lookup. The user can still replace it before duplicate.
    if (selectedValue !== "" && selectedValue !== null && !foundSelected) {
        const option = document.createElement("option");
        option.value = selectedValue;
        option.textContent = `Current assignment (${selectedValue})`;
        option.selected = true;
        select.appendChild(option);
    }

    td.appendChild(select);
    return td;
}

function inputCell(field, type = "text", required = false) {
    const td = document.createElement("td");
    const input = document.createElement("input");
    input.type = type;
    input.dataset.field = field;
    if (required) input.dataset.required = "1";
    td.appendChild(input);
    return td;
}

function readonlyCell(field) {
    const td = document.createElement("td");
    const input = document.createElement("input");
    input.type = "text";
    input.dataset.field = field;
    input.readOnly = true;
    td.appendChild(input);
    return td;
}

function moneyCell(field, required = false) {
    const td = inputCell(field, "text", required);
    const input = td.querySelector("input");
    input.classList.add("dup-money");
    input.inputMode = "decimal";
    input.placeholder = "0.00";
    input.addEventListener("blur", () => {
        const n = parseMoney(input.value);
        if (n !== null) input.value = formatMoney(n);
    });
    return td;
}

function yesNoCell(field) {
    const td = document.createElement("td");
    const select = document.createElement("select");
    select.dataset.field = field;
    select.innerHTML = '<option value="">No</option><option value="X">Yes</option>';
    td.appendChild(select);
    return td;
}

function fixedStatusCell() {
    const td = document.createElement("td");
    const badge = document.createElement("span");
    badge.className = "planning-status-badge status-not-started";
    badge.textContent = "Not Started";
    badge.title = "Duplicate creates Planning rows as Not Started.";
    td.appendChild(badge);
    return td;
}

function dateCell(field, required = false) {
    const td = document.createElement("td");
    const shell = document.createElement("div");
    shell.className = "planning-date-shell";

    const visible = document.createElement("input");
    visible.type = "text";
    visible.readOnly = true;
    visible.className = "planning-medium-date-input";
    visible.dataset.field = field;
    if (required) visible.dataset.required = "1";

    const hidden = document.createElement("input");
    hidden.type = "date";
    hidden.className = "planning-native-date-picker";
    hidden.dataset.dateFor = field;

    const button = document.createElement("button");
    button.type = "button";
    button.className = "planning-date-button";
    button.textContent = "▣";
    button.title = "Select date";

    const open = () => {
        try { hidden.showPicker ? hidden.showPicker() : hidden.click(); }
        catch { hidden.click(); }
    };
    button.addEventListener("click", open);
    visible.addEventListener("click", open);
    hidden.addEventListener("change", () => {
        visible.dataset.isoValue = hidden.value;
        visible.value = hidden.value ? mediumDate(hidden.value) : "";
        visible.dispatchEvent(new Event("change", { bubbles: true }));
    });

    shell.append(visible, button, hidden);
    td.appendChild(shell);
    return td;
}

function syncYears(tr) {
    const start = tr.querySelector('[data-field="Start Date"]')?.dataset.isoValue || "";
    const end = tr.querySelector('[data-field="End Date"]')?.dataset.isoValue || "";
    const from = tr.querySelector('[data-field="From"]');
    const to = tr.querySelector('[data-field="To"]');
    if (from) from.value = start ? start.slice(0, 4) : "";
    if (to) to.value = end ? end.slice(0, 4) : "";
}

function clearWorkspace() {
    workspaceRows.clear();
    const tbody = document.getElementById("dupWorkspaceBody");
    if (tbody) tbody.innerHTML = "";
    updateWorkspaceState();
}

function readRow(tr, showErrors = false) {
    const row = {
        region_key: Number(document.getElementById("dupRegion")?.value || 0),
        client_key: Number(document.getElementById("dupClient")?.value || 0),
        audit_project_key: Number(tr.dataset.projectKey),
        audit_project_name: tr.children[0]?.textContent?.trim() || "",
    };
    let valid = true;

    tr.querySelectorAll("[data-field]").forEach(control => {
        const field = control.dataset.field;
        let value = control.value;
        if (control.classList.contains("planning-medium-date-input")) {
            value = control.dataset.isoValue || "";
        }
        if (field === "Budget" || field === "Budget USD") {
            value = parseMoney(value);
        }
        row[field] = value;

        const required = control.dataset.required === "1";
        const bad = required && (value === null || value === undefined || String(value).trim() === "");
        if (bad) valid = false;
        if (showErrors) control.closest("td")?.classList.toggle("is-invalid", bad);
    });

    const start = row["Start Date"];
    const end = row["End Date"];
    if (start && end && end < start) valid = false;

    row["From"] = start ? Number(start.slice(0, 4)) : null;
    row["To"] = end ? Number(end.slice(0, 4)) : null;
    return { valid, row };
}

function updateWorkspaceState() {
    const rows = [...document.querySelectorAll("#dupWorkspaceBody tr")];
    let ready = 0;
    for (const tr of rows) {
        const result = readRow(tr, false);
        if (result.valid) ready += 1;
    }

    const summary = document.getElementById("dupSummary");
    const badge = document.getElementById("dupReadyBadge");
    const run = document.getElementById("btnRunDuplicate");

    if (!rows.length) {
        summary.textContent = "No projects selected.";
        badge.textContent = "0 projects";
        badge.className = "dup-row-status";
        run.disabled = true;
        return;
    }

    if (batchCompleted) {
        summary.textContent = "This duplication batch has already been processed. Return to Planning to see the new records.";
        badge.textContent = "Processed";
        badge.className = "dup-row-status is-ready";
        run.disabled = true;
        run.textContent = "Duplicated";
        return;
    }

    const incomplete = rows.length - ready;
    summary.textContent = incomplete
        ? `${rows.length} projects selected · ${incomplete} incomplete.`
        : `${rows.length} projects ready to duplicate.`;
    badge.textContent = incomplete ? `${incomplete} incomplete` : `${ready} ready`;
    badge.className = `dup-row-status ${incomplete ? "is-error" : "is-ready"}`;
    run.disabled = incomplete > 0;
    run.textContent = `Duplicate ${rows.length} project${rows.length === 1 ? "" : "s"}`;
}

function lockDuplicateBatch() {
    batchCompleted = true;

    document.getElementById("dupRegion")?.setAttribute("disabled", "disabled");
    document.getElementById("dupClient")?.setAttribute("disabled", "disabled");
    document.getElementById("btnAddDuplicateProjects")?.setAttribute("disabled", "disabled");

    document.querySelectorAll(".dup-project-check").forEach(control => {
        control.disabled = true;
    });

    document.querySelectorAll("#dupWorkspaceBody input, #dupWorkspaceBody select, #dupWorkspaceBody textarea, #dupWorkspaceBody button").forEach(control => {
        control.disabled = true;
    });

    const run = document.getElementById("btnRunDuplicate");
    if (run) {
        run.disabled = true;
        run.textContent = "Duplicated";
    }

    updateWorkspaceState();
}

async function runDuplicate() {
    const trs = [...document.querySelectorAll("#dupWorkspaceBody tr")];
    const rows = [];
    let valid = true;
    for (const tr of trs) {
        const result = readRow(tr, true);
        if (!result.valid) valid = false;
        rows.push(result.row);
    }
    if (!valid || !rows.length) {
        updateWorkspaceState();
        return;
    }

    const button = document.getElementById("btnRunDuplicate");
    button.disabled = true;
    button.textContent = "Duplicating...";

    try {
        const response = await fetch("/api/planning/audit-project-planning/duplicate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ rows }),
        });
        const result = await response.json();
        if (!response.ok || result.ok === false) {
            throw new Error(result.message || "Unable to duplicate Audit Project Planning.");
        }
        showDuplicateResult(result);

        // A batch with at least one successful insert must not be submitted a
        // second time. Failed rows can be corrected in a new duplicate batch.
        if (Number(result.success_count || 0) > 0) {
            lockDuplicateBatch();
        }
    }
    catch (error) {
        showDuplicateResult({
            success_count: 0,
            failed_count: rows.length,
            results: rows.map(r => ({
                ok: false,
                audit_project_name: r.audit_project_name,
                audit_scope: r["Audit Scope"],
                message: error.message,
            })),
        });
    }
    finally {
        if (!batchCompleted) {
            button.disabled = false;
        }
        updateWorkspaceState();
    }
}

function showDuplicateResult(result) {
    const panel = document.getElementById("dupResults");
    const banner = document.getElementById("dupResultBanner");
    const table = document.getElementById("dupErrorTable");
    const body = document.getElementById("dupErrorBody");
    const ok = Number(result.success_count || 0);
    const bad = Number(result.failed_count || 0);

    panel.hidden = false;
    const engineNote = result.engine ? `<br><small>Engine: ${escapeHtml(result.engine)}</small>` : "";
    const warningNote = result.warning ? `<br><small class="dup-warning-note">${escapeHtml(result.warning)}</small>` : "";
    const outlook = result.outlook_summary || {};
    let outlookNote = "";
    if (Number(outlook.created || 0) > 0 || Number(outlook.failed || 0) > 0) {
        const outlookWarning = Array.isArray(outlook.warnings) && outlook.warnings.length
            ? `<br><small class="dup-warning-note">Outlook detail: ${escapeHtml(outlook.warnings[0])}</small>`
            : "";
        outlookNote = `<br><small>Outlook: ${Number(outlook.sent || 0)} sent · ${Number(outlook.draft || 0)} draft · ${Number(outlook.failed || 0)} failed${Array.isArray(outlook.modes) && outlook.modes.length ? ` · ${escapeHtml(outlook.modes.join(", "))}` : ""}</small>${outlookWarning}`;
    }
    banner.innerHTML = `<div><strong>Duplication completed</strong><br>${ok} project${ok === 1 ? "" : "s"} created successfully. ${bad} could not be created.${engineNote}${outlookNote}${warningNote}<br><small>Use Back to return to Planning; the table will reload from SQL.</small></div>`;
    body.innerHTML = "";

    const failures = (result.results || []).filter(x => !x.ok);
    table.hidden = failures.length === 0;
    for (const item of failures) {
        const tr = document.createElement("tr");
        tr.innerHTML = `<td>${escapeHtml(item.audit_project_name || item.audit_project_key || "")}</td><td>${escapeHtml(item.audit_scope || "")}</td><td>${escapeHtml(item.message || "Unknown error")}</td>`;
        body.appendChild(tr);
    }
    panel.scrollIntoView({ behavior: "smooth", block: "start" });
}

function parseMoney(value) {
    if (value === null || value === undefined || String(value).trim() === "") return null;
    const n = Number(String(value).replaceAll(",", "").trim());
    return Number.isFinite(n) ? n : null;
}

function formatMoney(value) {
    return Number(value).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function mediumDate(iso) {
    const match = String(iso).match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (!match) return iso || "";
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    return `${match[3]}-${months[Number(match[2]) - 1]}-${match[1]}`;
}

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
