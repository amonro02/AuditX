// ============================================================
// AuditX Planning - UI bootstrap hotfix
//
// IMPORTANT:
// Keep the REST of your current dynamic Planning index.js below
// this block if you are applying manually.
//
// This file is intentionally tiny: it guarantees the CSS is
// loaded and that the New button has a visible toolbar host.
// ============================================================

const PLANNING_STYLE_URL =
    "/static/css/pages/planning.css?v=20260911-1443";

export function ensurePlanningStyles() {

    const existing =
        document.querySelector(
            'link[data-auditx-planning-style="1"]'
        );

    if (existing) {
        return;
    }

    const link =
        document.createElement(
            "link"
        );

    link.rel =
        "stylesheet";

    link.href =
        PLANNING_STYLE_URL;

    link.dataset.auditxPlanningStyle =
        "1";

    document.head.appendChild(
        link
    );
}


export function getPlanningToolbarHost() {

    const exportButton =
        document.getElementById(
            "btnExportExcel"
        );

    if (
        exportButton?.parentElement
    ) {
        return exportButton.parentElement;
    }

    return (
        document.querySelector(
            "#planningPage .preview-right"
        ) ||
        document.querySelector(
            "#planningPage .preview-header"
        )
    );
}


export function ensurePlanningNewButtonVisible(
    title,
    onClick
) {

    let button =
        document.getElementById(
            "btnNewPlanning"
        );

    if (!button) {

        button =
            document.createElement(
                "button"
            );

        button.id =
            "btnNewPlanning";

        button.type =
            "button";

        button.className =
            "planning-new-btn";

    }

    button.textContent =
        `＋ New ${title}`;

    button.onclick =
        onClick;

    const host =
        getPlanningToolbarHost();

    if (!host) {
        console.error(
            "Planning toolbar host not found."
        );
        return null;
    }

    const exportButton =
        document.getElementById(
            "btnExportExcel"
        );

    if (
        exportButton &&
        exportButton.parentElement === host
    ) {
        host.insertBefore(
            button,
            exportButton
        );
    }
    else if (
        button.parentElement !== host
    ) {
        host.appendChild(
            button
        );
    }

    return button;
}


/*
HOW TO USE IN YOUR EXISTING:
static/js/pages/planning/index.js

1) Paste/import these helpers at the top.
2) Call ensurePlanningStyles() immediately.
3) Replace your ensurePlanningNewButton() with:

function ensurePlanningNewButton() {
    if (!planningEntityConfig?.allow_create) return;

    ensurePlanningNewButtonVisible(
        planningEntityConfig.title,
        () => openPlanningCreateModal()
    );
}

Do NOT replace the rest of your working dynamic index.js with this
small bootstrap file.
*/
