/*
 * AuditX Planning > HR > Users sidebar integration
 * ------------------------------------------------
 * This file augments the EXISTING shared sidebar at runtime so we do not
 * overwrite base.html (which is used by the rest of AuditX).
 *
 * Final hierarchy:
 * Planning
 *   Region
 *   Client
 *   Audit Project
 *   Deal Type
 *   ERP
 *   Client Documentation
 *   Audit Project Planning
 *   HR
 *     Users
 */

const USERS_PATH = "/planning/hr/users";

function normalizedPath(href) {
    try {
        return new URL(href, window.location.origin).pathname.replace(/\/+$/, "") || "/";
    } catch (_) {
        return "";
    }
}

function findPlanningList() {
    const anchors = Array.from(document.querySelectorAll("a[href]"));
    const planningAnchors = anchors.filter((a) => {
        const path = normalizedPath(a.getAttribute("href"));
        if (!path.startsWith("/planning/")) return false;
        if (path === USERS_PATH) return false;
        return [
            "/planning/region",
            "/planning/client",
            "/planning/audit-project",
            "/planning/deal-type",
            "/planning/erp",
            "/planning/client-documentation",
            "/planning/audit-project-planning",
        ].some((p) => path === p);
    });

    if (!planningAnchors.length) return null;

    // Prefer the nearest UL that contains several Planning entries.
    const candidates = [];
    for (const anchor of planningAnchors) {
        let ul = anchor.closest("ul");
        while (ul) {
            const count = planningAnchors.filter((a) => ul.contains(a)).length;
            if (count >= 3) candidates.push({ ul, count });
            ul = ul.parentElement ? ul.parentElement.closest("ul") : null;
        }
    }

    candidates.sort((a, b) => b.count - a.count);
    return candidates.length ? candidates[0].ul : planningAnchors[0].closest("ul");
}

function makeChevron() {
    const chevron = document.createElement("span");
    chevron.className = "planning-hr-chevron";
    chevron.setAttribute("aria-hidden", "true");
    chevron.textContent = "›";
    return chevron;
}

function installPlanningHrSidebar() {
    if (document.querySelector("[data-auditx-planning-hr='1']")) return true;

    const planningList = findPlanningList();
    if (!planningList) return false;
    
    const sampleLi = Array.from(planningList.children)
        .find((el) => el.tagName === "LI");
    
    const sampleAnchor = sampleLi?.querySelector(
        ":scope > a, :scope > button, a, button"
    );
    
    const planningToggle =
        document.getElementById("planningToggle") ||
        document.querySelector(".planning-toggle");
    
    const li = document.createElement("li");
    li.dataset.auditxPlanningHr = "1";
    li.className = "planning-hr-sidebar-item";
    
    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.id = "planningHrToggle";
    
    const planningBaseClasses = (planningToggle?.className || "planning-toggle")
        .split(/\s+/)
        .filter(cls => ![
            "active",
            "is-active",
            "section-active",
            "open",
            "is-open"
        ].includes(cls))
        .join(" ");
    
    toggle.className =
        `${planningBaseClasses} planning-hr-sidebar-toggle`.trim();
    
    toggle.setAttribute("aria-expanded", "false");
    
    // =============================
    // ICONO + TEXTO HR
    // =============================
    const hrContent = document.createElement("span");
    hrContent.className = "sidebar-link sidebar-link-content";
    
    const hrIcon = document.createElement("img");
    hrIcon.src = "/static/img/sidebar/HR.png";
    hrIcon.className = "sidebar-icon";
    hrIcon.alt = "";
    
    const hrLabel = document.createElement("span");
    hrLabel.textContent = "HR";
    
    hrContent.appendChild(hrIcon);
    hrContent.appendChild(hrLabel);
    
    toggle.appendChild(hrContent);

    
        
    // Clona la MISMA flecha de Planning
    const planningArrow =
        planningToggle?.querySelector(".planning-arrow") ||
        planningToggle?.querySelector("svg") ||
        planningToggle?.lastElementChild;
    
    if (planningArrow) {
        const arrowClone = planningArrow.cloneNode(true);
    
        // evita duplicar IDs si el icono los tuviera
        arrowClone.removeAttribute?.("id");
    
        toggle.appendChild(arrowClone);
    } else {
        toggle.appendChild(makeChevron());
    }

    const nested = document.createElement("ul");
    nested.className = "planning-hr-sidebar-menu";
    nested.hidden = true;

    // ==========================================
    // USERS - SIN HEREDAR CLASES DE PLANNING
    // ==========================================
    
    const usersLi = document.createElement("li");
    usersLi.className = "planning-hr-users-item";
    
    const usersLink = document.createElement("a");
    usersLink.href = USERS_PATH;
    usersLink.className = "sidebar-link planning-hr-users-link";
    
    
    // ICONO
    const usersIcon = document.createElement("img");
    usersIcon.src = "/static/img/sidebar/Users.png";
    usersIcon.className = "sidebar-icon";
    usersIcon.alt = "";
    
    
    // TEXTO
    const usersLabel = document.createElement("span");
    usersLabel.className = "planning-hr-users-label";
    usersLabel.textContent = "Users";
    
    
    // ARMAR
    usersLink.appendChild(usersIcon);
    usersLink.appendChild(usersLabel);
    
    usersLi.appendChild(usersLink);
    nested.appendChild(usersLi);

    if (normalizedPath(window.location.pathname) === USERS_PATH) {
     
        // Mantener HR abierto
        nested.hidden = false;
        li.classList.add("open", "is-open");
        toggle.setAttribute("aria-expanded", "true");
    
        // Planning también pertenece a la ruta actual
        const planningToggle = document.getElementById("planningToggle");
    
        if (planningToggle) {
            planningToggle.classList.add("section-active");
        }
    }

    usersLi.appendChild(usersLink);
    nested.appendChild(usersLi);
    li.append(toggle, nested);
    planningList.appendChild(li);

    toggle.addEventListener("click", () => {
        const willOpen = nested.hidden;
        nested.hidden = !willOpen;
        li.classList.toggle("open", willOpen);
        li.classList.toggle("is-open", willOpen);
        toggle.setAttribute("aria-expanded", willOpen ? "true" : "false");
    });

    syncPlanningHrActiveState();

    return true;
}

function boot() {
    if (installPlanningHrSidebar()) return;

    // Some AuditX layouts render the sidebar just after the page body.
    const observer = new MutationObserver(() => {
        if (installPlanningHrSidebar()) observer.disconnect();
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
    });

    window.setTimeout(() => observer.disconnect(), 5000);
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
} else {
    boot();
}


function syncPlanningHrActiveState() {
    const path = window.location.pathname
        .replace(/\/+$/, "")
        .toLowerCase();
 
    const hrItem = document.querySelector(
        '[data-auditx-planning-hr="1"]'
    );
 
    const hrToggle = document.getElementById("planningHrToggle");
    const hrSubmenu = document.getElementById("planningHrSubmenu");
 
    const usersLink =
        document.querySelector(
            'a[href="/planning/hr/users"]'
        ) ||
        document.querySelector(
            ".planning-hr-users-link"
        );
 
    /* =====================================
       1. LIMPIAR SIEMPRE EL ESTADO ANTERIOR
       ===================================== */
 
    if (usersLink) {
        usersLink.classList.remove(
            "active",
            "is-active",
            "selected",
            "current",
            "section-active"
        );
 
        usersLink.removeAttribute("aria-current");
    }
 
    if (hrToggle) {
        hrToggle.classList.remove(
            "active",
            "is-active",
            "selected",
            "current",
            "section-active"
        );
    }
 
    if (hrItem) {
        hrItem.classList.remove(
            "active",
            "is-active",
            "selected",
            "current",
            "section-active"
        );
    }
 
    /* =====================================
       2. DETERMINAR RUTA ACTUAL
       ===================================== */
 
    const isUsers =
        path === "/planning/hr/users";
 
    const isHr =
        path === "/planning/hr" ||
        path.startsWith("/planning/hr/");
 
    /* =====================================
       3. APLICAR SOLO LO QUE CORRESPONDA
       ===================================== */
 
    if (isHr) {
        if (hrItem) {
            hrItem.classList.add("open", "is-open");
        }
 
        if (hrToggle) {
            hrToggle.classList.add("section-active");
            hrToggle.setAttribute("aria-expanded", "true");
        }
 
        if (hrSubmenu) {
            hrSubmenu.hidden = false;
            hrSubmenu.style.display = "block";
        }
    }
 
    if (isUsers && usersLink) {
        usersLink.classList.add("active", "is-active");
        usersLink.setAttribute("aria-current", "page");
    }
}