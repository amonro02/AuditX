let currentStatusFilter = "ALL";
let followUpsData = [];
 
document.addEventListener("DOMContentLoaded", () => {
    bindEvents();
 
    // Temporal mientras conectamos a SQL
    followUpsData = [];
 
    updateCounters(followUpsData);
    renderFollowUps();
});
 
function bindEvents() {
    bindStatusCards();
    bindClearFilters();
    bindSearch();
    bindNewFollowUp();
}
 
function bindStatusCards() {
    document.querySelectorAll(".summary-pill").forEach(card => {
        card.addEventListener("click", () => {
            currentStatusFilter = card.dataset.status || "ALL";
 
            document.querySelectorAll(".summary-pill")
                .forEach(x => x.classList.remove("active-filter"));
 
            card.classList.add("active-filter");
 
            renderFollowUps();
        });
    });
}
 
function bindClearFilters() {
    const btn = document.getElementById("btnClearFilters");
 
    if (!btn) return;
 
    btn.addEventListener("click", () => {
        currentStatusFilter = "ALL";
 
        document.querySelectorAll(".summary-pill")
            .forEach(x => x.classList.remove("active-filter"));
 
        const search = document.getElementById("txtSearchFollowUp");
 
        if (search) {
            search.value = "";
        }
 
        renderFollowUps();
    });
}
 
function bindSearch() {
    const search = document.getElementById("txtSearchFollowUp");
 
    if (!search) return;
 
    search.addEventListener("input", () => {
        renderFollowUps();
    });
}
 
function bindNewFollowUp() {
    const btn = document.getElementById("btnNewFollowUp");
 
    if (!btn) return;
 
    btn.addEventListener("click");
}
 
function updateCounters(data) {
    const countDraft = data.filter(x => x.status === "Draft").length;
    const countPending = data.filter(x => x.status === "Pending").length;
    const countResponded = data.filter(x => x.status === "Responded").length;
    const countClosed = data.filter(x => x.status === "Closed").length;
 
    setText("countDraft", countDraft);
    setText("countPending", countPending);
    setText("countResponded", countResponded);
    setText("countClosed", countClosed);
}
 
function renderFollowUps() {
    const tbody = document.getElementById("followupTableBody");
 
    if (!tbody) return;
 
    const searchValue =
        document.getElementById("txtSearchFollowUp")?.value?.toLowerCase().trim() || "";
 
    let filtered = [...followUpsData];
 
    if (currentStatusFilter !== "ALL") {
        filtered = filtered.filter(x => x.status === currentStatusFilter);
    }
 
    if (searchValue) {
        filtered = filtered.filter(x =>
            String(x.subject || "").toLowerCase().includes(searchValue) ||
            String(x.vendorName || "").toLowerCase().includes(searchValue) ||
            String(x.vendorNumber || "").toLowerCase().includes(searchValue) ||
            String(x.claimNumbers || "").toLowerCase().includes(searchValue)
        );
    }
 
    if (!filtered.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="empty-row">
                    No follow-ups found.
                </td>
            </tr>
        `;
        return;
    }
 
    tbody.innerHTML = filtered.map(x => `
        <tr>
            <td>
                <button class="table-action" type="button" data-id="${x.followUpID}">
                    Detail
                </button>
            </td>
            <td>${escapeHtml(x.subject || "")}</td>
            <td>${escapeHtml(x.vendorNumber || "")}</td>
            <td>${escapeHtml(x.vendorName || "")}</td>
            <td>${x.claimsCount || 0}</td>
            <td>${formatCurrency(x.totalAmount || 0)}</td>
            <td>${renderStatus(x.status || "")}</td>
            <td>${escapeHtml(x.lastEmailSentDate || "-")}</td>
            <td>${escapeHtml(x.dueDate || "-")}</td>
        </tr>
    `).join("");
}
 
function renderStatus(status) {
    const cleanStatus = escapeHtml(status);
 
    return `<span class="status-badge status-${cleanStatus.toLowerCase()}">${cleanStatus}</span>`;
}
 
function setText(id, value) {
    const el = document.getElementById(id);
 
    if (el) {
        el.textContent = value;
    }
}
 
function formatCurrency(value) {
    const numberValue = Number(value || 0);
 
    return numberValue.toLocaleString("en-US", {
        style: "currency",
        currency: "USD"
    });
}
 
function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}