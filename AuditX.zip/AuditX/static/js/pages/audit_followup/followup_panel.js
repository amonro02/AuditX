let vendorsData = [];
 
document.addEventListener("DOMContentLoaded", () => {
    bindFollowUpPanel();
});
 
function bindFollowUpPanel() {
    document.getElementById("btnNewFollowUp")?.addEventListener("click", openFollowUpPanel);
    document.getElementById("btnCloseFollowUpPanel")?.addEventListener("click", closeFollowUpPanel);
    document.getElementById("btnCancelFollowUp")?.addEventListener("click", closeFollowUpPanel);
    document.getElementById("followUpPanelOverlay")?.addEventListener("click", closeFollowUpPanel);
    document.getElementById("btnAddClaimRow")?.addEventListener("click", addClaimRow);
    document.getElementById("btnSaveDraftFollowUp")?.addEventListener("click", saveDraftFollowUp);
 
    document.getElementById("fuVendorSearch")?.addEventListener("input", onVendorSearch);
    document.getElementById("fuVendorSearch")?.addEventListener("focus", onVendorSearch);
    document.getElementById("fuAuditYear")?.addEventListener("input", updateSubject);
 
    document.addEventListener("click", (e) => {
        if (!e.target.closest(".autocomplete-wrapper")) {
            hideVendorAutocomplete();
        }
    });
}
 
function openFollowUpPanel() {
    resetFollowUpPanel();
 
    document.getElementById("followUpPanelOverlay")?.classList.remove("hidden");
    document.getElementById("followUpPanel")?.classList.remove("hidden");
 
    loadVendors();
    addClaimRow();
}
 
function closeFollowUpPanel() {
    document.getElementById("followUpPanelOverlay")?.classList.add("hidden");
    document.getElementById("followUpPanel")?.classList.add("hidden");
}
 
function resetFollowUpPanel() {
    setValue("fuVendorID", "");
    setValue("fuVendorSearch", "");
    setValue("fuVendorNumber", "");
    setValue("fuAuditYear", new Date().getFullYear());
    setValue("fuContactName", "");
    setValue("fuEmailTo", "");
    setValue("fuEmailCC", "");
    setValue("fuSubject", "");
 
    const container = document.getElementById("claimsContainer");
    if (container) container.innerHTML = "";
 
    hideVendorAutocomplete();
    updateClaimTotals();
}
 
async function loadVendors() {
    try {
        const response = await fetch("/api/followups/vendors");
        const result = await response.json();
 
        if (!result.success) return;
 
        vendorsData = result.data || [];
 
    } catch (error) {
        console.error("Error loading vendors:", error);
    }
}
 
function onVendorSearch() {
    const value = getValue("fuVendorSearch");
    setValue("fuVendorID", "");
 
    renderVendorAutocomplete(value);
    updateSubject();
}
 
function renderVendorAutocomplete(searchText) {
    const list = document.getElementById("vendorAutocompleteList");
    if (!list) return;
 
    const text = String(searchText || "").toLowerCase().trim();
 
    let filtered = vendorsData;
 
    if (text) {
        filtered = vendorsData.filter(v =>
            String(v.vendorName || "").toLowerCase().includes(text) ||
            String(v.vendorNumber || "").toLowerCase().includes(text)
        );
    }
 
    let html = "";
 
    filtered.slice(0, 8).forEach(vendor => {
        html += `
            <div class="autocomplete-item" data-vendor-id="${vendor.vendorID}">
                <strong>${escapeHtml(vendor.vendorName || "")}</strong>
                <span>${escapeHtml(vendor.vendorNumber || "")}</span>
            </div>
        `;
    });
 
    if (text && filtered.length === 0) {
        html += `
            <div class="autocomplete-empty">
                No vendor found.
            </div>
            <div class="autocomplete-create" data-create-vendor="1">
                Use "${escapeHtml(searchText)}" as new vendor
            </div>
        `;
    }
 
    if (!html) {
        list.classList.add("hidden");
        return;
    }
 
    list.innerHTML = html;
    list.classList.remove("hidden");
 
    list.querySelectorAll(".autocomplete-item").forEach(item => {
        item.addEventListener("click", () => {
            const vendorID = item.dataset.vendorId;
            selectVendor(vendorID);
        });
    });
 
    list.querySelector("[data-create-vendor='1']")?.addEventListener("click", () => {
        useNewVendor(searchText);
    });
}
 
function selectVendor(vendorID) {
    const vendor = vendorsData.find(x => String(x.vendorID) === String(vendorID));
    if (!vendor) return;
 
    setValue("fuVendorID", vendor.vendorID || "");
    setValue("fuVendorSearch", vendor.vendorName || "");
    setValue("fuVendorNumber", vendor.vendorNumber || "");
    setValue("fuContactName", vendor.contactName || "");
    setValue("fuEmailTo", vendor.emailTo || "");
    setValue("fuEmailCC", vendor.emailCC || "");
 
    hideVendorAutocomplete();
    updateSubject();
}
 
function useNewVendor(vendorName) {
    setValue("fuVendorID", "");
    setValue("fuVendorSearch", vendorName || "");
    setValue("fuVendorNumber", "");
    setValue("fuContactName", "");
    setValue("fuEmailTo", "");
    setValue("fuEmailCC", "");
 
    hideVendorAutocomplete();
    updateSubject();
}
 
function hideVendorAutocomplete() {
    document.getElementById("vendorAutocompleteList")?.classList.add("hidden");
}
 
function addClaimRow() {
    const container = document.getElementById("claimsContainer");
    if (!container) return;
 
    const row = document.createElement("div");
    row.className = "claim-row";
 
    row.innerHTML = `
        <div class="form-group">
            <label>Claim No.</label>
            <input class="form-control claim-number" type="text">
        </div>
 
        <div class="form-group">
            <label>Project</label>
            <select class="form-control claim-project">
                <option value="">Select project</option>
            </select>
        </div>
 
        <div class="form-group">
            <label>Category</label>
            <select class="form-control claim-rubro">
                <option value="">Select category</option>
            </select>
        </div>
 
        <div class="form-group">
            <label>Currency</label>
            <select class="form-control claim-currency">
                <option value="MXN">MXN</option>
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
            </select>
        </div>
 
        <div class="form-group">
            <label>Amount</label>
            <input class="form-control claim-amount" type="number" step="0.01" value="0">
        </div>
 
        <button class="btn-remove-claim" type="button">×</button>
    `;
 
    const projectSelect = row.querySelector(".claim-project");
 
    projectSelect?.addEventListener("change", () => {
        loadCategories(row, projectSelect.value);
        updateSubject();
    });
 
    row.querySelector(".claim-number")?.addEventListener("input", updateSubject);
    row.querySelector(".claim-amount")?.addEventListener("input", updateClaimTotals);
 
    row.querySelector(".btn-remove-claim")?.addEventListener("click", () => {
        row.remove();
        updateClaimTotals();
        updateSubject();
    });
 
    container.appendChild(row);
 
    loadProjects(row);
    updateClaimTotals();
    updateSubject();
}
 
async function loadProjects(row) {
    const select = row.querySelector(".claim-project");
    if (!select) return;
 
    select.innerHTML = `<option value="">Select project</option>`;
 
    try {
        const response = await fetch("/api/followups/projects");
        const result = await response.json();
 
        if (!result.success) return;
 
        result.data.forEach(project => {
            const option = document.createElement("option");
            option.value = project.projectID;
            option.textContent = project.projectName;
            select.appendChild(option);
        });
 
    } catch (error) {
        console.error("Error loading projects:", error);
    }
}
 
async function loadCategories(row, projectID) {
    const select = row.querySelector(".claim-rubro");
    if (!select) return;
 
    select.innerHTML = `<option value="">Select category</option>`;
 
    if (!projectID) return;
 
    try {
        const response = await fetch(`/api/followups/categories?projectID=${encodeURIComponent(projectID)}`);
        const result = await response.json();
 
        if (!result.success) return;
 
        result.data.forEach(category => {
            const option = document.createElement("option");
            option.value = category.categoryName;
            option.dataset.categoryId = category.categoryID;
            option.textContent = category.categoryName;
            select.appendChild(option);
        });
 
    } catch (error) {
        console.error("Error loading categories:", error);
    }
}
 
function updateSubject() {
    const auditYear = getValue("fuAuditYear") || new Date().getFullYear();
    const vendorName = getValue("fuVendorSearch").toUpperCase();
 
    const projectNames = [];
 
    document.querySelectorAll(".claim-project").forEach(select => {
        const text = select.selectedOptions[0]?.textContent || "";
        if (select.value && text !== "Select project") {
            projectNames.push(text.toUpperCase());
        }
    });
 
    const uniqueProjects = [...new Set(projectNames)];
 
    let projectText = "PROYECTOS VARIOS";
 
    if (uniqueProjects.length === 1) {
        projectText = uniqueProjects[0];
    }
 
    const claimCount = document.querySelectorAll(".claim-row").length || 1;
 
    const subject = `AUDITORÍA ${auditYear} - ${projectText} - ${claimCount} ${vendorName}`.trim();
 
    setValue("fuSubject", subject);
}
 
function updateClaimTotals() {
    const rows = document.querySelectorAll(".claim-row");
    let total = 0;
 
    rows.forEach(row => {
        total += Number(row.querySelector(".claim-amount")?.value || 0);
    });
 
    setText("fuClaimsCount", rows.length);
 
    setText(
        "fuTotalAmount",
        total.toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })
    );
}
 
function getFollowUpPayload() {
    const claims = [];
 
    document.querySelectorAll(".claim-row").forEach(row => {
        const projectSelect = row.querySelector(".claim-project");
        const categorySelect = row.querySelector(".claim-rubro");
        const selectedCategory = categorySelect?.selectedOptions[0];
 
        claims.push({
            claimNumber: row.querySelector(".claim-number")?.value.trim() || "",
            projectID: Number(projectSelect?.value || 0),
            projectName: projectSelect?.selectedOptions[0]?.textContent || "",
            rubroID: Number(selectedCategory?.dataset.categoryId || 0),
            rubro: categorySelect?.value || "",
            currencyCode: row.querySelector(".claim-currency")?.value || "MXN",
            amount: Number(row.querySelector(".claim-amount")?.value || 0)
        });
    });
 
    return {
        vendorID: Number(getValue("fuVendorID") || 0),
        vendorNumber: getValue("fuVendorNumber"),
        vendorName: getValue("fuVendorSearch"),
        auditYear: Number(getValue("fuAuditYear") || 0),
        contactName: getValue("fuContactName"),
        emailTo: getValue("fuEmailTo"),
        emailCC: getValue("fuEmailCC"),
        subjectInitial: getValue("fuSubject"),
        statusCode: "Draft",
        priorityCode: "Medium",
        claims: claims
    };
}
 
async function saveDraftFollowUp() {
    const payload = getFollowUpPayload();
 
    if (!payload.vendorName) {
        alert("Vendor is required.");
        return;
    }
 
    if (!payload.emailTo) {
        alert("Email To is required.");
        return;
    }
 
    if (!payload.subjectInitial) {
        alert("Subject is required.");
        return;
    }
 
    if (!payload.claims || payload.claims.length === 0) {
        alert("At least one claim is required.");
        return;
    }
 
    if (payload.claims.some(claim => !claim.claimNumber)) {
        alert("Every claim must have a Claim No.");
        return;
    }
 
    try {
        const response = await fetch(
            "/api/followups/prepare-email",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(payload)
            }
        );
 
        const result = await response.json();
 
        if (!response.ok || !result.success) {
            throw new Error(
                result.message || "Could not create Outlook draft."
            );
        }
 
        alert("Outlook draft created successfully.");
 
    } catch (error) {
        console.error("Error creating Outlook draft:", error);
        alert(error.message || "Unexpected error.");
    }
}
 
function getValue(id) {
    return document.getElementById(id)?.value.trim() || "";
}
 
function setValue(id, value) {
    const el = document.getElementById(id);
    if (el) el.value = value;
}
 
function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}
 
function escapeHtml(value) {
    return String(value || "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}