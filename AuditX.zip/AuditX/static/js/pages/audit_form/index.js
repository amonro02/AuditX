// static/js/pages/audit_form/index.js
 
document.addEventListener("DOMContentLoaded", () => {
    initAuditForm();
});
 
function initAuditForm() {
    console.log("Audit form page loaded");
 
    bindFormActions();
}
 
function bindFormActions() {
    const form = document.getElementById("auditForm");
    const btnSave = document.getElementById("btnSaveAudit");
    const btnClear = document.getElementById("btnClearAudit");
 
    if (btnSave) {
        btnSave.addEventListener("click", (e) => {
            e.preventDefault();
            handleSave();
        });
    }
 
    if (btnClear) {
        btnClear.addEventListener("click", (e) => {
            e.preventDefault();
            handleClear(form);
        });
    }
}
 
function handleSave() {
    const formData = collectAuditFormData();
    console.log("Audit form data:", formData);
 
    // Aquí después conectamos endpoint real
    alert("Audit form ready to save");
}
 
function handleClear(form) {
    if (!form) return;
    form.reset();
}
 
function collectAuditFormData() {
    const form = document.getElementById("auditForm");
    if (!form) return {};
 
    const data = {};
    const fields = form.querySelectorAll("input, select, textarea");
 
    fields.forEach(field => {
        if (!field.name) return;
 
        if (field.type === "checkbox") {
            data[field.name] = field.checked;
        } else if (field.type === "radio") {
            if (field.checked) {
                data[field.name] = field.value;
            }
        } else {
            data[field.name] = field.value;
        }
    });
 
    return data;
}

// ================================
// FIX BOTONES CONFIGURE VIEW
// ================================
 
document.addEventListener("click", function (e) {
 
    const btn = e.target.closest("button");
    if (!btn) return;
 
    // SELECT ALL
    if (btn.id === "btnSelectAllColumns") {
        document.querySelectorAll("#columnChecklist input").forEach(i => i.checked = true);
        return;
    }
 
    // DESELECT ALL
    if (btn.id === "btnClearAllColumns") {
        document.querySelectorAll("#columnChecklist input").forEach(i => i.checked = false);
        return;
    }
 
    // FIRST 8
    if (btn.id === "btnSelectFirst8Columns") {
        document.querySelectorAll("#columnChecklist input").forEach((i, idx) => {
            i.checked = idx < 8;
        });
        return;
    }
 
    // RESET LAYOUT (usa lo que ya tienes)
    if (btn.id === "btnResetViewConfig") {
 
        const base =
            state.visibleColumns?.length
                ? state.visibleColumns
                : (state.previewColumns || []);
 
        document.querySelectorAll("#columnChecklist input").forEach((i, idx) => {
            i.checked = base.slice(0, 8).includes(i.value);
        });
 
        return;
    }
 
    // CLEAR SEARCH
    if (btn.id === "btnClearColumnSearch") {
 
        const input = document.getElementById("columnSearchInput");
 
        if (input) {
            input.value = "";
            input.dispatchEvent(new Event("input"));
        }
 
        return;
    }
 
    // SAVE VIEW (usa tu lógica actual)
    if (btn.id === "btnSaveView") {
 
        const selected = Array.from(
            document.querySelectorAll("#columnChecklist input:checked")
        ).map(x => x.value);
 
        state.visibleColumns = selected;
 
        console.log("Saving view:", selected);
 
        // 🔥 si ya tienes backend, esto no rompe nada
        fetch("/api/save-view-layout", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                dataListId: state.selectedDataListId,
                columns: selected
            })
        }).catch(() => {});
 
        if (typeof renderPreview === "function") {
            renderPreview();
        }
 
        if (typeof closeViewConfig === "function") {
            closeViewConfig();
        }
 
        return;
    }
 
});
 
 
// ================================
// SEARCH EN VIVO
// ================================
document.addEventListener("input", function (e) {
 
    if (e.target.id === "columnSearchInput") {
 
        const value = e.target.value.toLowerCase();
 
        document.querySelectorAll("#columnChecklist label").forEach(label => {
            label.style.display = label.textContent.toLowerCase().includes(value)
                ? "flex"
                : "none";
        });
    }
 
});