let selectedClientKey = null;
let clientsData = [];
 
const clientModal = document.getElementById("clientModal");
const clientSelectorBtn = document.getElementById("clientSelectorBtn");
const btnCloseClientModal = document.getElementById("btnCloseClientModal");
const btnCancelClientModal = document.getElementById("btnCancelClientModal");
 
const clientTableBody = document.getElementById("clientTableBody");
const clientNameFilter = document.getElementById("clientNameFilter");
const clientDateFilter = document.getElementById("clientDateFilter");
const clientCountLabel = document.getElementById("clientCountLabel");
 
const currentClientName = document.getElementById("currentClientName");
const autoSelectLastClient = document.getElementById("autoSelectLastClient");
 
document.addEventListener("DOMContentLoaded", async () => {
    await loadCurrentClient();
});
 
function openClientModal() {
    if (!clientModal) return;
 
    clientModal.classList.remove("hidden");
    document.body.classList.add("modal-open");
 
    if (clientNameFilter) clientNameFilter.value = "";
    if (clientDateFilter) clientDateFilter.value = "";
 
    loadClients();
 
    setTimeout(() => {
        if (clientNameFilter) clientNameFilter.focus();
    }, 120);
}
 
function closeClientModal() {
    if (!clientModal) return;
 
    clientModal.classList.add("hidden");
    document.body.classList.remove("modal-open");
}
 
async function loadCurrentClient() {
    try {
        const response = await fetch("/api/clients/current");
        const text = await response.text();
 
        let data = {};
        try {
            data = JSON.parse(text);
        } catch {
            console.error("Invalid JSON current client:", text);
            return;
        }
 
        if (data.success && data.client) {
            selectedClientKey = data.client.clientKey;
 
            if (currentClientName) {
                currentClientName.textContent = data.client.clientName;
            }
        }
    } catch (error) {
        console.error("Error loading current client:", error);
    }
}
 
async function loadClients() {
    if (!clientTableBody) return;
 
    clientTableBody.innerHTML = `
        <tr>
            <td colspan="2">
                <div class="auditx-client-empty">Loading clients...</div>
            </td>
        </tr>
    `;
 
    try {
        const response = await fetch("/api/clients");
        const text = await response.text();
 
        let data = {};
        try {
            data = JSON.parse(text);
        } catch {
            console.error("Invalid JSON clients:", text);
            clientTableBody.innerHTML = `
                <tr>
                    <td colspan="2">
                        <div class="auditx-client-empty">Backend error</div>
                    </td>
                </tr>
            `;
            return;
        }
 
        if (!data.success) {
            throw new Error(data.message || "Error loading clients");
        }
 
        clientsData = data.clients || [];
 
        if (data.currentClient && data.currentClient.clientKey) {
            selectedClientKey = data.currentClient.clientKey;
        }
 
        renderClients();
 
    } catch (error) {
        console.error("Error loading clients:", error);
 
        clientTableBody.innerHTML = `
            <tr>
                <td colspan="2">
                    <div class="auditx-client-empty">Error loading clients</div>
                </td>
            </tr>
        `;
    }
}
 
function renderClients() {
    if (!clientTableBody) return;
 
    const nameTerm = (clientNameFilter?.value || "").toLowerCase().trim();
    const dateTerm = (clientDateFilter?.value || "").toLowerCase().trim();
 
    let filtered = clientsData.filter(client => {
        const clientName = String(client.clientName || "").toLowerCase();
        const lastAccess = formatDate(client.lastAccessAt).toLowerCase();
 
        return clientName.includes(nameTerm) && lastAccess.includes(dateTerm);
    });
 
    if (clientCountLabel) {
        clientCountLabel.textContent = `${filtered.length} of ${clientsData.length} clients`;
    }
 
    if (!filtered.length) {
        clientTableBody.innerHTML = `
            <tr>
                <td colspan="2">
                    <div class="auditx-client-empty">No clients found</div>
                </td>
            </tr>
        `;
        return;
    }
 
    clientTableBody.innerHTML = "";
 
    filtered.forEach(client => {
        const isActive = String(client.clientKey) === String(selectedClientKey);
 
        const tr = document.createElement("tr");
 
        if (isActive) {
            tr.classList.add("active-client-row");
        }
 
        tr.innerHTML = `
            <td>
                <a href="#" class="client-name-link">
                    <span class="client-initials-badge">
                        ${getInitials(client.clientName)}
                    </span>
                    <span class="client-name-label">
                        ${escapeHtml(client.clientName)}
                    </span>
                </a>
            </td>
 
            <td>
                <span class="client-date-text">
                    ${formatDate(client.lastAccessAt)}
                </span>
            </td>
        `;
 
        tr.addEventListener("click", async (event) => {
            event.preventDefault();
 
            if (isActive) {
                closeClientModal();
                return;
            }
            tr.classList.add("client-row-selecting");
            await selectClient(client);
        });
 
        clientTableBody.appendChild(tr);
    });
}
 
async function selectClient(client) {
    try {
        console.log("Selecting client:", client);
 
        if (!client.clientKey) {
            alert("ClientKey missing");
            return;
        }
 
        const response = await fetch("/api/clients/select", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                clientKey: client.clientKey,
                autoSelect: autoSelectLastClient ? autoSelectLastClient.checked : true
            })
        });
 
        const text = await response.text();
 
        let data = {};
        try {
            data = JSON.parse(text);
        } catch {
            console.error("Invalid JSON select:", text);
            alert("Backend error selecting client");
            return;
        }
 
        if (!response.ok || !data.success) {
            alert(data.message || "Error selecting client");
            return;
        }
 
        selectedClientKey = data.client.clientKey;
 
        if (currentClientName) {
            currentClientName.textContent = data.client.clientName;
        }
 
        closeClientModal();
 
        setTimeout(() => {
            location.reload();
        }, 150);
 
    } catch (error) {
        console.error("Error selecting client:", error);
        alert("Error selecting client");
    }
}
 
function formatDate(dateStr) {
    if (!dateStr) return "No access yet";
 
    const date = new Date(dateStr);
 
    if (isNaN(date.getTime())) {
        return dateStr;
    }
 
    return date.toLocaleString("es-MX", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    });
}
 
function escapeHtml(value) {
    if (value === null || value === undefined) return "";
 
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
 
clientSelectorBtn?.addEventListener("click", openClientModal);
btnCloseClientModal?.addEventListener("click", closeClientModal);
btnCancelClientModal?.addEventListener("click", closeClientModal);
 
clientNameFilter?.addEventListener("input", renderClients);
clientDateFilter?.addEventListener("input", renderClients);
 
clientModal?.addEventListener("click", (event) => {
    if (event.target === clientModal) {
        closeClientModal();
    }
});

function getInitials(name) {
    if (!name) return "?";
 
    const words = String(name).trim().split(/\s+/);
 
    if (words.length === 1) {
        return words[0].substring(0, 2).toUpperCase();
    }
 
    return `${words[0][0]}${words[1][0]}`.toUpperCase();
}
 