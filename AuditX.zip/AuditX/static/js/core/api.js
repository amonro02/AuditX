// core/api.js
 
export async function post(url, data) {
    const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    });
 
    if (!res.ok) {
        const text = await res.text();
        throw new Error(text);
    }
 
    return res.json();
}