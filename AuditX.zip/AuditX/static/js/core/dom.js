// core/dom.js
 
export const $ = (selector) => document.querySelector(selector);
export const $$ = (selector) => document.querySelectorAll(selector);
 
export function on(el, event, cb) {
    el?.addEventListener(event, cb);
}