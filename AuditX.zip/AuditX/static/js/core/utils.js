// core/utils.js
 
export function debounce(fn, delay = 300) {
    let t;
    return (...args) => {
        clearTimeout(t);
        t = setTimeout(() => fn(...args), delay);
    };
}
 
export function formatTime(ms) {
    return (ms / 1000).toFixed(2) + "s";
}