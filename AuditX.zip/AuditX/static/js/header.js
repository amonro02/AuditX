document.addEventListener("DOMContentLoaded", function () {
    const overlay = document.getElementById("auditxOverlay");
    const profileBtn = document.getElementById("profileMenuBtn");
    const profileMenu = document.getElementById("profileMenu");
    const releaseBtn = document.getElementById("releaseMenuBtn");
    const releaseSubmenu = document.getElementById("releaseSubmenu");
    const sidebarToggleBtn = document.getElementById("sidebarToggleBtn");
    const appLayout = document.querySelector(".app-layout");
 
    function showOverlay() {
        overlay?.classList.remove("hidden");
    }
 
    function hideOverlay() {
        overlay?.classList.add("hidden");
    }
 
    function closeMenus() {
        profileMenu?.classList.add("hidden");
        releaseSubmenu?.classList.add("hidden");
        hideOverlay();
    }
 
    profileBtn?.addEventListener("click", function (e) {
        e.stopPropagation();
 
        const isHidden = profileMenu?.classList.contains("hidden");
 
        closeMenus();
 
        if (isHidden) {
            profileMenu.classList.remove("hidden");
            showOverlay();
        }
    });
 
    releaseBtn?.addEventListener("click", function (e) {
        e.stopPropagation();
        releaseSubmenu?.classList.toggle("hidden");
        showOverlay();
    });
 
    sidebarToggleBtn?.addEventListener("click", function () {
        appLayout?.classList.toggle("sidebar-collapsed");
    });
 
    overlay?.addEventListener("click", function () {
        closeMenus();
        closeReleaseModal();
    });
 
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") {
            closeMenus();
            closeReleaseModal();
        }
    });
});
 
const releaseData = {
    "v1.2.0": {
        date: "20 Abril 2026",
        module: "General",
        type: "Actual",
        env: "Producción",
        changes: [
            "Nuevo header estilo iOS.",
            "Perfil con menú desplegable.",
            "Submenú de últimas releases.",
            "Modal de detalle de release."
        ]
    },
    "v1.1.9": {
        date: "15 Abril 2026",
        module: "Data Download",
        type: "Mejora",
        env: "Producción",
        changes: [
            "Corrección de paginación.",
            "Mejor manejo de columnas visibles.",
            "Ajustes menores de estilo."
        ]
    },
    "v1.1.8": {
        date: "10 Abril 2026",
        module: "Audit Extract",
        type: "Fix",
        env: "QA",
        changes: [
            "Ajuste en carga de proyecto.",
            "Validación de cliente activo.",
            "Mejora en mensajes del sistema."
        ]
    },
    "v1.1.7": {
        date: "05 Abril 2026",
        module: "Tracker",
        type: "Mejora",
        env: "Producción",
        changes: [
            "Nuevos contadores de casos.",
            "Mejora en estados visuales.",
            "Optimización de consulta inicial."
        ]
    },
    "v1.1.6": {
        date: "01 Abril 2026",
        module: "General",
        type: "Release",
        env: "Producción",
        changes: [
            "Primera versión del header dinámico.",
            "Ajustes de layout principal.",
            "Mejoras de navegación."
        ]
    }
};
 
function openReleaseModal(version) {
    const data = releaseData[version] || releaseData["v1.2.0"];
 
    document.getElementById("releaseModalTitle").textContent = "Release " + version;
    document.getElementById("releaseModalDate").textContent = data.date;
    document.getElementById("releaseModalModule").textContent = data.module;
    document.getElementById("releaseModalType").textContent = data.type;
    document.getElementById("releaseModalEnv").textContent = data.env;
 
    const changesList = document.getElementById("releaseModalChanges");
    changesList.innerHTML = "";
 
    data.changes.forEach(function (change) {
        const li = document.createElement("li");
        li.textContent = change;
        changesList.appendChild(li);
    });
 
    document.getElementById("releaseModal")?.classList.remove("hidden");
    document.getElementById("auditxOverlay")?.classList.remove("hidden");
}
 
function closeReleaseModal() {
    document.getElementById("releaseModal")?.classList.add("hidden");
    document.getElementById("auditxOverlay")?.classList.add("hidden");
}