// static/js/components/tabs.js
 
export function initTabs(wrapperSelector = "[data-tabs]") {
    document.querySelectorAll(wrapperSelector).forEach(wrapper => {
        const tabs = wrapper.querySelectorAll("[data-tab]");
        const panels = wrapper.querySelectorAll("[data-tab-panel]");
 
        tabs.forEach(tab => {
            tab.addEventListener("click", () => {
                const target = tab.dataset.tab;
 
                tabs.forEach(t => t.classList.remove("active"));
                panels.forEach(p => p.classList.remove("active"));
 
                tab.classList.add("active");
 
                const panel = wrapper.querySelector(`[data-tab-panel="${target}"]`);
                if (panel) {
                    panel.classList.add("active");
                }
            });
        });
 
        if (tabs.length && !wrapper.querySelector("[data-tab].active")) {
            tabs[0].classList.add("active");
            const firstTarget = tabs[0].dataset.tab;
            const firstPanel = wrapper.querySelector(`[data-tab-panel="${firstTarget}"]`);
            if (firstPanel) {
                firstPanel.classList.add("active");
            }
        }
    });
}