// components/loading.js
 
let start;
 
export function showLoading(text = "Loading...") {
    const el = document.getElementById("previewLoading");
    if (!el) return;
 
    start = performance.now();
    el.style.display = "block";
 
    el.innerHTML = `
        <div class="loading-bar"></div>
        <div>${text}</div>
        <div id="loadingTime">0s</div>
    `;
 
    const timer = setInterval(() => {
        const t = ((performance.now() - start) / 1000).toFixed(1);
        document.getElementById("loadingTime").textContent = t + "s";
    }, 100);
 
    el.dataset.timer = timer;
}
 
export function hideLoading() {
    const el = document.getElementById("previewLoading");
    if (!el) return;
 
    clearInterval(el.dataset.timer);
    el.style.display = "none";
}