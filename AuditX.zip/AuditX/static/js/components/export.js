// static/js/components/export.js
 
export function downloadBlob(blob, fileName = "download.bin") {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);
}
 
export async function exportFile(url, payload = {}, fileName = "export.xlsx") {
    const res = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
    });
 
    if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Export failed");
    }
 
    const blob = await res.blob();
    downloadBlob(blob, fileName);
}