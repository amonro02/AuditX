// components/table.js
 
export function renderTable(containerId, data) {
    const el = document.getElementById(containerId);
    if (!el || !data.length) return;
 
    const cols = Object.keys(data[0]);
 
    let html = "<table><thead><tr>";
    cols.forEach(c => html += `<th>${c}</th>`);
    html += "</tr></thead><tbody>";
 
    data.forEach(row => {
        html += "<tr>";
        cols.forEach(c => html += `<td>${row[c]}</td>`);
        html += "</tr>";
    });
 
    html += "</tbody></table>";
 
    el.innerHTML = html;
}