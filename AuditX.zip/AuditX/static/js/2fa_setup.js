console.log("2FA SETUP JS LOADED");
 
document.addEventListener("DOMContentLoaded", async () => {
    console.log("DOM READY 2FA SETUP");
 
    setupOTPInputs();
    await load2faSetup();
 
    const form = document.getElementById("setup2faForm");
 
    if (!form) {
        console.error("setup2faForm not found");
        return;
    }
 
    form.addEventListener("submit", verifySetup2fa);
});

const inputs = document.querySelectorAll(".otp-input");
 
inputs.forEach((input, index) => {
 
    input.addEventListener("input", () => {
        if (input.value.length === 1 && index < inputs.length - 1) {
            inputs[index + 1].focus();
        }
    });
 
    input.addEventListener("keydown", (e) => {
        if (e.key === "Backspace" && input.value === "" && index > 0) {
            inputs[index - 1].focus();
        }
    });
 
});
 
async function load2faSetup() {
    const qrImage = document.getElementById("qrImage");
    const message = document.getElementById("setupMessage");
 
    try {
        const response = await fetch("/api/2fa/setup", {
            method: "GET"
        });
 
        const data = await response.json();
 
        console.log("QR RESPONSE:", data);
 
        if (!data.success) {
            showMessage(message, data.message || "Unable to generate QR.", "error");
            return;
        }
 
        qrImage.src = data.qr_code;
 
    } catch (error) {
        console.error(error);
        showMessage(message, "Connection error generating QR.", "error");
    }
}
 
function setupOTPInputs() {
    const inputs = document.querySelectorAll(".otp-input");
 
    inputs.forEach((input, index) => {
        input.addEventListener("input", () => {
            input.value = input.value.replace(/[^0-9]/g, "");
 
            if (input.value && index < inputs.length - 1) {
                inputs[index + 1].focus();
            }
        });
 
        input.addEventListener("keydown", (event) => {
            if (event.key === "Backspace" && !input.value && index > 0) {
                inputs[index - 1].focus();
            }
        });
 
        input.addEventListener("paste", (event) => {
            event.preventDefault();
 
            const pasted = (event.clipboardData || window.clipboardData)
                .getData("text")
                .replace(/[^0-9]/g, "")
                .slice(0, 6);
 
            if (!pasted) return;
 
            inputs.forEach((otpInput, otpIndex) => {
                otpInput.value = pasted[otpIndex] || "";
            });
 
            const nextIndex = Math.min(pasted.length, inputs.length - 1);
            inputs[nextIndex].focus();
        });
    });
 
    if (inputs.length > 0) {
        inputs[0].focus();
    }
}
 
function getOTPCode() {
    const inputs = document.querySelectorAll(".otp-input");
    let code = "";
 
    inputs.forEach(input => {
        code += input.value.trim();
    });
 
    return code;
}
 
async function verifySetup2fa(event) {
    event.preventDefault();
 
    const code = getOTPCode();
    const button = document.getElementById("btnVerify2fa");
    const message = document.getElementById("setupMessage");
 
    if (!code || code.length !== 6) {
        showMessage(message, "Enter the 6-digit code.", "error");
        return;
    }
 
    button.disabled = true;
    button.textContent = "Verifying...";
 
    try {
        const response = await fetch("/api/2fa/verify-setup", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ code })
        });
 
        const data = await response.json();
 
        console.log("VERIFY SETUP RESPONSE:", data);
 
        if (!response.ok || data.success !== true) {
            showMessage(message, data.message || "Invalid code.", "error");
            return;
        }
 
        window.location.href = data.redirect || "/home";
 
    } catch (error) {
        console.error(error);
        showMessage(message, "Connection error. Please try again.", "error");
    } finally {
        button.disabled = false;
        button.textContent = "Verify and continue";
    }
}
 
function showMessage(element, text, type) {
    if (!element) return;
 
    element.textContent = text;
    element.className = `message ${type}`;
}