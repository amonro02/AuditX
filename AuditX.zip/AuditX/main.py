from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from services.login_service import validate_user_email
from services.data_list_service import (
    load_projects,
    load_reports,
    load_data_lists,
    load_data_list_meta
) 
from services.layout_service import (
    load_user_layout,
    save_user_layout,
    save_user_columns,
    save_user_filters,
    reset_user_layout
)
from services.query_service import load_query_fields, execute_query

from routes.auth_routes import auth_bp
from routes.client_routes import client_bp
from routes.planning_routes import planning_bp

from config.session import get_current_client_db
from database.connection import get_followup_connection

def create_app():
    app = Flask(__name__) 
    app.secret_key = "auditx_secret_key" 
    app.register_blueprint(auth_bp) 
    app.register_blueprint(client_bp) 
    app.register_blueprint(planning_bp)

    #print("\n========== RUTAS PLANNING REGISTRADAS ==========")    
    #for rule in app.url_map.iter_rules():
    #    if "planning" in str(rule).lower():
    #        print(
    #            "RULE:",
    #            rule,
    #            "| ENDPOINT:",
    #            rule.endpoint,
    #            "| METHODS:",
    #            sorted(rule.methods)
    #        )    
    #print("=================================================\n")
     
    return app
 
 
app = create_app()
COMING_SOON_MODULES = ["tracker", "panoptic", "audit-extract"] 
 
# =========================
# LOGIN PAGE
# =========================
@app.route("/")
def root():
    return redirect(url_for("auth.login"))
 
# =========================
# LOGOUT
# =========================
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# =========================
# BASE
# =========================


@app.route("/tracker")
def tracker():
    return render_template("pages/coming_soon.html", current_module="Tracker")
 
 
@app.route("/panoptic")
def panoptic():
    return render_template("pages/coming_soon.html", current_module="Panoptic")
 
 
@app.route("/data-download")
def data_download():
    return render_template("pages/data_download.html", current_module="Data Download")
 
@app.route("/audit-extract")
def audit_form():
    return render_template("pages/coming_soon.html", current_module="Audit Extract")

@app.route("/audit-followUp")
def audit_followup():
    return render_template("pages/audit_followUp.html", current_module="Audit FollowUp")

# =========================
# VIEWS DINÁMICAS 
# =========================
@app.route("/api/projects")
def api_projects():
   

    server, database = get_current_client_db() 
 
    if not server or not database:
        return jsonify({
            "success": False,
            "message": "Client not selected",
            "projects": []
        }), 400
 
    try:
        result = load_projects(server, database)
 
        rows = result.get("rows", result) if isinstance(result, dict) else result
 
        projects = []
        for p in rows:
            projects.append({
                "ProjectID": p.get("projectId"),
                "ProjectName": p.get("projectName"),
                "ClientName": p.get("clientName"),
                "DateEntered": str(p.get("dateEntered")) if p.get("dateEntered") else None,
                "Sort": p.get("sort")
            })
 
        return jsonify({
            "success": True,
            "projects": projects
        })
 
    except Exception as e:
        print("ERROR /api/projects:", str(e))
        return jsonify({
            "success": False,
            "message": str(e),
            "projects": []
        }), 500
 
 
@app.route("/api/reports")
def api_reports():

    server, database = get_current_client_db() 

    project_id = request.args.get("projectId", type=int)
    result = load_reports(project_id,server,database)
    print("DEBUG /api/reports:", project_id, result)
    return jsonify(result)
 
 
@app.route("/api/data-lists")
def api_data_lists():

    server, database = get_current_client_db() 

    report_list_id = request.args.get("reportListId", type=int)
    result = load_data_lists(report_list_id,server,database)
    print("DEBUG /api/data-lists:", report_list_id, result)
    return jsonify(result)
 
 
@app.route("/api/query-fields/<int:data_list_id>", methods=["GET"])
def api_query_fields(data_list_id):
    
    server, database = get_current_client_db() 

    if not server or not database:
        return jsonify({
            "ok": False,
            "message": "Client not selected",
            "fields": []
        }), 400
 
    try:
        result = load_query_fields(data_list_id)
        return jsonify(result)
 
    except Exception as e:
        print("ERROR /api/query-fields:", str(e))
        return jsonify({
            "ok": False,
            "message": str(e),
            "fields": []
        }), 500
 
 
@app.route("/api/query-design-preview", methods=["POST"])
def api_query_design_preview():
    data = request.get_json(silent=True) or {}
 
    raw_top = data.get("top")
 
    if raw_top is None or str(raw_top).strip() == "":
        top = None  # SELECT *
    else:
        try:
            top = int(raw_top)
            if top <= 0:
                top = None
        except Exception:
            top = None
 
    result = execute_query(
        data_list_id=data.get("dataListId"),
        filters=data.get("filters", []),
        top=top
    )
 
    return jsonify(result)
 
 
@app.route("/api/layout/load/<int:data_list_id>", methods=["GET"])
def api_layout_load(data_list_id):
    try:
        user_key = request.args.get("userKey", "default_user")
 
        result = load_user_layout(
            user_key=user_key,
            data_list_id=data_list_id
        )
 
        return jsonify(result)
 
    except Exception as e:
        print("api_layout_load error:", e)
 
        return jsonify({
            "ok": True,
            "exists": False,
            "layout": [],
            "columns": [],
            "filters": [],
            "pageSize": 25,
            "message": str(e)
        }), 200
 
 
@app.route("/api/layout/save", methods=["POST"])
def api_layout_save():
    try:
        data = request.get_json() or {}
        result = save_user_layout(data)
        return jsonify(result)
 
    except Exception as e:
        print("api_layout_save error:", e)
 
        return jsonify({
            "ok": False,
            "message": str(e)
        }), 200
 
 
@app.route("/api/layout/save-columns", methods=["POST"])
def api_layout_save_columns():
    try:
        data = request.get_json() or {}
        result = save_user_columns(data)
        return jsonify(result)
 
    except Exception as e:
        print("api_layout_save_columns error:", e)
 
        return jsonify({
            "ok": False,
            "message": str(e)
        }), 200
 
 
@app.route("/api/layout/save-filters", methods=["POST"])
def api_layout_save_filters():
    try:
        data = request.get_json() or {}
        result = save_user_filters(data)
        return jsonify(result)
 
    except Exception as e:
        print("api_layout_save_filters error:", e)
 
        return jsonify({
            "ok": False,
            "message": str(e)
        }), 200
 
 
@app.route("/api/layout/reset/<int:data_list_id>", methods=["POST"])
def api_layout_reset(data_list_id):
    try:
        data = request.get_json() or {}
        user_key = data.get("userKey") or request.args.get("userKey") or "default_user"
 
        result = reset_user_layout(
            user_key=user_key,
            data_list_id=data_list_id
        )
 
        return jsonify(result)
 
    except Exception as e:
        print("api_layout_reset error:", e)
 
        return jsonify({
            "ok": False,
            "message": str(e)
        }), 200
 
 
#======
@app.route("/api/data-list-meta/<int:data_list_id>", methods=["GET"])
def api_data_list_meta(data_list_id):
    server, database = get_current_client_db()
 
    if not server or not database:
        return jsonify({
            "ok": False,
            "message": "Client not selected",
            "row": None
        }), 400
 
    try:
        result = load_data_list_meta(data_list_id)
 
        return jsonify({
            "ok": True,
            "row": result
        })
 
    except Exception as e:
        print("ERROR /api/data-list-meta:", str(e))
 
        return jsonify({
            "ok": False,
            "message": str(e),
            "row": None
        }), 500

#########################################################################
#                      Audit FollowUp
#########################################################################

@app.route("/api/followups/projects", methods=["GET"])
def get_followup_projects():
    client_key = session.get("client_key")
 
    conn = get_followup_connection()
    cursor = conn.cursor()
 
    cursor.execute("""
        SELECT
            ProjectID,
            ProjectCode,
            ProjectName
        FROM dbo.Projects
        WHERE IsActive = 1
          AND (ClientKey = ? OR ClientKey IS NULL)
        ORDER BY ProjectName
    """, client_key)
 
    rows = cursor.fetchall()
 
    return jsonify({
        "success": True,
        "data": [
            {
                "projectID": row.ProjectID,
                "projectCode": row.ProjectCode,
                "projectName": row.ProjectName
            }
            for row in rows
        ]
    })
 
@app.route("/api/followups/categories", methods=["GET"])
def get_followup_categories():
    client_key = session.get("client_key")
    project_id = request.args.get("projectID")
 
    print("client_key:", client_key)
    print("project_id:", project_id)
    print("args:", dict(request.args))
 
    if not project_id:
        return jsonify({
            "success": True,
            "data": []
        })
 
    conn = get_followup_connection()
    cursor = conn.cursor()
 
    cursor.execute("""
        SELECT
            CategoryID,
            CategoryCode,
            CategoryName
        FROM dbo.ProjectCategories
        WHERE IsActive = 1
          AND ProjectID = ?
          AND (ClientKey = ? OR ClientKey IS NULL)
        ORDER BY CategoryName
    """, project_id, client_key)
 
    rows = cursor.fetchall()
    conn.close()
 
    return jsonify({
        "success": True,
        "data": [
            {
                "categoryID": row.CategoryID,
                "categoryCode": row.CategoryCode,
                "categoryName": row.CategoryName
            }
            for row in rows
        ]
    })

@app.route("/api/followups/vendors", methods=["GET"])
def get_followup_vendors():
    client_key = session.get("client_key")
 
    conn = get_followup_connection()
    cursor = conn.cursor()
 
    cursor.execute("""
        SELECT
            VendorID,
            VendorNumber,
            VendorName,
            DefaultEmailTo,
            DefaultEmailCC
        FROM dbo.Vendors
        WHERE IsActive = 1
          AND (ClientKey = ? OR ClientKey IS NULL)
        ORDER BY VendorName
    """, client_key)
 
    rows = cursor.fetchall()
    conn.close()
 
    return jsonify({
        "success": True,
        "data": [
            {
                "vendorID": row.VendorID,
                "vendorNumber": row.VendorNumber,
                "vendorName": row.VendorName,
                "emailTo": row.DefaultEmailTo,
                "emailCC": row.DefaultEmailCC
            }
            for row in rows
        ]
    })
 
@app.route("/api/followups/prepare-email", methods=["POST"])
def prepare_followup_email():
    data = request.get_json()
 
    client_key = session.get("client_key")
    user_email = session.get("user_email")
 
    vendor_name = data.get("vendorName")
    contact_name = data.get("contactName")
    email_to = data.get("emailTo")
    email_cc = data.get("emailCC")
    subject = data.get("subjectInitial")
    audit_year = data.get("auditYear")
    claims = data.get("claims", [])
 
    if not vendor_name:
        return jsonify({"success": False, "message": "Vendor is required."})
 
    if not email_to:
        return jsonify({"success": False, "message": "Email To is required."})
 
    if not subject:
        return jsonify({"success": False, "message": "Subject is required."})
 
    if not claims:
        return jsonify({"success": False, "message": "At least one claim is required."})
 
    html_body = build_followup_email_html(
        contact_name=contact_name,
        vendor_name=vendor_name,
        audit_year=audit_year,
        claims=claims
    )
 
    try:
        outlook_result = create_outlook_draft(
            to=email_to,
            cc=email_cc,
            subject=subject,
            html_body=html_body
        )
 
        return jsonify({
            "success": True,
            "message": "Email prepared successfully.",
            "outlookEntryID": outlook_result.get("entry_id"),
            "conversationID": outlook_result.get("conversation_id")
        })
 
    except Exception as e:
        return jsonify({
            "success": False,
            "message": str(e)
        })
def create_outlook_draft(to, cc, subject, html_body):
    import win32com.client
 
    outlook = win32com.client.Dispatch("Outlook.Application")
    mail = outlook.CreateItem(0)
 
    mail.To = to
    mail.CC = cc or ""
    mail.Subject = subject
    mail.HTMLBody = html_body
 
    mail.Display()
 
    return {
        "entry_id": getattr(mail, "EntryID", None),
        "conversation_id": getattr(mail, "ConversationID", None)
    }

#########################################################################



@app.context_processor
def inject_module_name():
    return dict(current_module=get_module_name(request.path.lower()))
 
def get_module_name(path):
    if "data-download" in path:
        return "Data Download"
    elif "audit-extract" in path:
        return "Audit Extract"
    elif "tracker" in path:
        return "Tracker"
    elif "panoptic" in path:
        return "Panoptic"
    elif "audit-followUp" in path:
        return "Audit FollowUp"    
    return "Home"

#@app.errorhandler(404)
#def handle_404(e):
#    return f"404 REAL: {request.path}", 404

@app.errorhandler(404)
def handle_404(e):
    path = request.path.lower()
 
    # Si es módulo de la app → mostrar coming soon
    if not path.startswith("/static"):
        return render_template("pages/coming_soon.html"), 200
 
    # Si es archivo real que no existe
    return render_template("404.html"), 404


# =========================
# RUN
# =========================
if __name__ == "__main__":
    app.run(debug=True)