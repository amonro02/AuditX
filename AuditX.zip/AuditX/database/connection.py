"""
    Módulo: connection
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:        
         Centraliza la creación de conexiones a SQL Server, proporcionando métodos para conectarse a bases de datos configuradas,
         establecer conexiones dinámicas y validar la disponibilidad de las conexiones.
"""

import pyodbc
from database.db_config import (
    DB_CONFIG_WINDOWS,
    DB_CONFIG_AUDITFOLLOWUP,
    DB_CONFIG_PLANNING
)
 

def get_connection(config=None):
    """
    Conexión genérica.
    Si no recibe configuración usa AuditX.
    """
 
    config = config or DB_CONFIG_WINDOWS
 
    return pyodbc.connect(
        f"DRIVER={{{config['driver']}}};"
        f"SERVER={config['server']};"
        f"DATABASE={config['database']};"
        "Trusted_Connection=yes;"
        "TrustServerCertificate=yes;"
    )
 
 
def get_followup_connection():
    """
    Conexión a PRGX_AUDITFOLLOWUP
    """
 
    return get_connection(DB_CONFIG_AUDITFOLLOWUP)

def get_planning_connection():
    """
    Conexión a PRGX_PLANNING
    """
 
    return get_connection(DB_CONFIG_PLANNING)
      
  
def get_dynamic_connection(server: str, database: str, driver=None):
    """
        Dynamic connection: used to connect to the real SQL Server / Database        
    """
 
    driver = driver or DB_CONFIG_WINDOWS["driver"]
 
    if not server or not database:
        raise ValueError("server and database are required")
 
    return pyodbc.connect(
        f"DRIVER={{{driver}}};"
        f"SERVER={server};"
        f"DATABASE={database};"
        "Trusted_Connection=yes;"
        "TrustServerCertificate=yes;"
    )
 
 
def test_base_connection():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT @@VERSION")
    row = cursor.fetchone()
    conn.close()
    return row[0] if row else None
 
 
def test_dynamic_connection(server: str, database: str):
    conn = get_dynamic_connection(server, database)
    cursor = conn.cursor()
    cursor.execute("SELECT @@VERSION")
    row = cursor.fetchone()
    conn.close()
    return row[0] if row else None

class Database:
 
    def __init__(self, config=None):
        self.config = config
 
    def connect(self):
        return get_connection(self.config)
 
    def fetch_one(self, sql, params=None):
        params = params or []
 
        with self.connect() as conn:
            cur = conn.cursor()
            cur.execute(sql, params)
 
            row = cur.fetchone()
 
            if row is None:
                return None
 
            cols = [c[0] for c in cur.description]
            return dict(zip(cols, row))
 
    def fetch_all(self, sql, params=None):
        params = params or []
 
        with self.connect() as conn:
            cur = conn.cursor()
            cur.execute(sql, params)
 
            cols = [c[0] for c in cur.description]
            return [dict(zip(cols, r)) for r in cur.fetchall()]
 
    def execute(self, sql, params=None):
        params = params or []
 
        with self.connect() as conn:
            cur = conn.cursor()
            cur.execute(sql, params)
            conn.commit()
 
            return cur.rowcount