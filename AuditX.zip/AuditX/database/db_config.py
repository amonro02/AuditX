"""

    Módulo: db_config
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:
        Este bloque configura los parametros de coneccion  para la base de datos

"""
 
DB_CONFIG_WINDOWS = {
    "driver":"ODBC Driver 17 for SQL Server",
    "server": "ATL20AF2222SQ19",
    "database": "PRGX_AUDITX"
}

DB_CONFIG_AUDITFOLLOWUP = {
    "driver":"ODBC Driver 17 for SQL Server",
    "server": "ATL20AF2222SQ19",
    "database": "PRGX_AUDITFOLLOWUP"
}

DB_CONFIG_PLANNING = {
    "driver":"ODBC Driver 17 for SQL Server",
    "server": "ATL20AF2222SQ19",
    "database": "PRGX_PLANNING"
}