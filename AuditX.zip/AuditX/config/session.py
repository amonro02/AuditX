
"""

    Módulo: session
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:
        Este bloque actúa como un administrador del contexto del cliente dentro de la sesión de la aplicación. Sus responsabilidades son:

        Obtener el servidor y la base de datos del cliente actual.
        Validar que exista un cliente seleccionado antes de realizar operaciones.
        Guardar el cliente seleccionado en la sesión.
        Eliminar el cliente de la sesión cuando sea necesario.

        En conjunto, permite que el resto de la aplicación trabaje siempre con la base de datos correspondiente al cliente seleccionado,
        sin tener que solicitar esos datos en cada petición.
"""

from flask import session

# ==========================================
# GET CURRENT CLIENT (CORE)
# ==========================================
def get_current_client_db():
    server = session.get("client_sql_server")
    database = session.get("client_sql_database")
 
    return server, database
 
 
# ==========================================
# VALIDATE CLIENT CONTEXT
# ==========================================
def validate_client_session():
    server, database = get_current_client_db()
 
    if not server or not database:
        return False, {
            "success": False,
            "message": "Client not selected",
            "data": []
        }
 
    return True, (server, database)
 
 
# ==========================================
# SET CLIENT SESSION (cuando seleccionas cliente)
# ==========================================
def set_client_session(client):
    session["client_name"] = client.get("ClientName")
    session["client_sql_server"] = client.get("SQL_Server")
    session["client_sql_database"] = client.get("SQL_Database")
 
 
# ==========================================
# CLEAR CLIENT SESSION
# ==========================================
def clear_client_session():
    session.pop("client_name", None)
    session.pop("client_sql_server", None)
    session.pop("client_sql_database", None)
 
 
# ==========================================
# DEBUG (opcional)
# ==========================================
def debug_session():
    return {
        "client_name": session.get("client_name"),
        "server": session.get("client_sql_server"),
        "database": session.get("client_sql_database"),
    }
 