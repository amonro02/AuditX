# ============================================================
# AuditX - Planning dynamic entity configuration
# Version: 2026-09-22 v9
#
# Generic rules supported per field:
#   required=True                 -> mandatory + green field
#   transform="uppercase"         -> UPPERCASE
#   transform="lowercase"         -> lowercase
#   min_length / max_length       -> text length validation
#   min / max                     -> numeric validation
#   display_format="medium_date"  -> display/grid date format
#   readonly=True                 -> visible but not directly editable
#   derived_from / derive="year" -> derive year from another date field
#   field_type="money"           -> thousands separators + 2 decimals
#   after_or_equal="Field"        -> date relationship validation
#   before_or_equal="Field"       -> date relationship validation
#   lookup="name"                 -> shows label, saves configured value
#   depends_on="Field"            -> cascading lookup
#   source_fields=[...]           -> alternate VIEW column names for Update
#   choices=[...]                 -> static dropdown
#
# All entities below use ONE modal / ONE JS / ONE backend engine.
# ============================================================


def F(view_field, column, label, field_type="text", **kwargs):
    item = {
        "view_field": view_field,
        "column": column,
        "label": label,
        "type": field_type,
    }
    item.update(kwargs)
    return item


_AUDIT = {
    "added_on": "added_on",
    "added_by": "added_by",
    "changed_on": "changed_on",
    "changed_by": "changed_by",
}

_YN = [
    {"value": "Y", "label": "Yes"},
    {"value": "N", "label": "No"},
]

_X_YES_NO = [
    {"value": "X", "label": "Yes"},
    {"value": "", "label": "No"},
]

_DOC_TYPE = [
    {"value": "DIGITAL", "label": "DIGITAL"},
    {"value": "FISICA", "label": "FISICA"},
]


PLANNING_ENTITIES = {
    # ========================================================
    # REGION
    # ========================================================
    "region": {
        "title": "Region",
        "view": "dbo.VW_Region",
        "table": "dbo.Region",
        "view_key": "Key",
        "table_key": "region_key",
        "identity_key": True,
        "allow_create": True,
        "allow_update": True,
        "allow_delete": True,
        # Load enough rows for the client-side filters/pagination. The legacy
        # TOP 1000 window hid recent Planning records that were outside that slice.
        "preview_limit": 10000,
        "preview_order_by": "[Key] DESC",
        "delete_column": "flag",
        "delete_value": 1,
        "modal_width": "medium",
        "audit": _AUDIT,
        "create_defaults": {"flag": 0},
        "fields": [
            F("Key", "region_key", "Key", "readonly", show_on_create=False),
            F(
                "Name", "region_name", "Name",
                required=True,
                transform="uppercase",
                min_length=2,
                max_length=100,
                source_fields=["Name", "Region Name", "region_name"],
            ),
            F(
                "Acronym", "region_acronym", "Acronym",
                required=True,
                transform="uppercase",
                min_length=2,
                max_length=20,
                source_fields=["Acronym", "Region Acronym", "region_acronym"],
            ),
        ],
    },

    # ========================================================
    # CLIENT
    # ========================================================
    "client": {
        "title": "Client",
        "view": "dbo.VW_Client",
        "table": "dbo.Client",
        "view_key": "Key",
        "table_key": "client_key",
        "identity_key": True,
        "allow_create": True,
        "allow_update": True,
        "allow_delete": True,
        "delete_column": "flag",
        "delete_value": 1,
        "modal_width": "xlarge",
        "audit": _AUDIT,
        "create_defaults": {"flag": 0},
        "fields": [
            F("Key", "client_key", "Key", "readonly", show_on_create=False),
            F(
                "region_key", "region_key", "Region Name", "lookup",
                lookup="region",
                required=True,
                source_fields=["region_key", "Region Key"],
            ),
            F(
                "Name", "client_name", "Name",
                required=True,
                transform="uppercase",
                max_length=200,
                source_fields=["Name", "Client Name", "client_name"],
            ),
            F(
                "Name Ctx", "client_name_claimtrax", "Name Ctx",
                transform="uppercase",
                max_length=200,
                source_fields=["Name Ctx", "Client Name Ctx", "client_name_claimtrax"],
            ),
            F(
                "Legal Name", "client_legal_name", "Legal Name",
                required=True,
                transform="uppercase",
                max_length=250,
                span=2,
                source_fields=["Legal Name", "client_legal_name"],
            ),
            F(
                "Business Unit", "client_business_unit", "Business Unit",
                required=True,
                transform="uppercase",
                max_length=150,
                source_fields=["Business Unit", "client_business_unit"],
            ),
            F(
                "Client Code", "client_code", "Client Code",
                transform="uppercase",
                max_length=100,
                source_fields=["Client Code", "client_code"],
            ),
            F(
                "Fiscal Number", "client_fiscal_number", "Fiscal Number",
                transform="uppercase",
                max_length=100,
                source_fields=["Fiscal Number", "client_fiscal_number"],
            ),
            F(
                "Country", "client_country", "Country",
                transform="uppercase",
                max_length=100,
                source_fields=["Country", "client_country"],
            ),
            F(
                "Region", "client_region", "Region",
                transform="uppercase",
                max_length=100,
                source_fields=["Region", "client_region"],
            ),
            F(
                "City", "client_city", "City",
                transform="uppercase",
                max_length=100,
                source_fields=["City", "client_city"],
            ),
            F(
                "Postal Code", "client_postal_code", "Postal Code",
                transform="uppercase",
                max_length=50,
                source_fields=["Postal Code", "client_postal_code"],
            ),
            F(
                "currency_key", "currency_key", "Currency", "lookup",
                lookup="currency",
                extra_target="Currency Code",
                show_extra_in_label=True,
                required=True,
                source_fields=["currency_key", "Currency Key"],
            ),
            F(
                "Currency Code", None, "Currency Code", "display",
                highlight_required=True,
                source_fields=["Currency Code", "currency_code"],
            ),
            F(
                "Payment Term", "client_payment_term", "Payment Term", "number",
                min=0,
                max=3650,
                source_fields=["Payment Term", "client_payment_term"],
            ),
            F(
                "Start Date", "client_start_date", "Start Date", "date",
                required=True,
                display_format="medium_date",
                source_fields=["Start Date", "client_start_date"],
            ),
            F(
                "End Date", "client_end_date", "End Date", "date",
                required=False,
                display_format="medium_date",
                after_or_equal="Start Date",
                source_fields=["End Date", "client_end_date"],
            ),
            F(
                "Address", "client_address", "Address", "textarea",
                transform="uppercase",
                max_length=1000,
                span=2,
                source_fields=["Address", "client_address"],
            ),
        ],
    },

    # ========================================================
    # AUDIT PROJECT
    # dbo.audit_project
    # ========================================================
    "audit-project": {
        "title": "Audit Project",
        "view": "dbo.VW_AuditProject",
        "table": "dbo.audit_project",
        "view_key": "Key",
        "table_key": "audit_project_key",
        "identity_key": True,
        "allow_create": True,
        "allow_update": True,
        "allow_delete": True,
        "delete_column": "flag",
        "delete_value": 1,
        "modal_width": "large",
        "audit": _AUDIT,
        "create_defaults": {"flag": 0},
        "fields": [
            F("Key", "audit_project_key", "Key", "readonly", show_on_create=False),
            # UI helper: Region is not stored in audit_project; it filters Client.
            F(
                "region_key", None, "Region Name", "lookup",
                lookup="region",
                required=True,
                source_fields=["region_key", "Region Key"],
            ),
            F(
                "client_key", "client_key", "Client Name", "lookup",
                lookup="client",
                depends_on="region_key",
                required=True,
                source_fields=["client_key", "Client Key"],
            ),
            F(
                "Audit Project", "audit_project_name", "Name",
                required=True,
                transform="uppercase",
                max_length=250,
                source_fields=["Audit Project", "Name", "audit_project_name"],
            ),
            F(
                "Name Ctx", "audit_project_name_claimtrax", "Name Ctx",
                transform="uppercase",
                max_length=250,
                source_fields=["Name Ctx", "audit_project_name_claimtrax"],
            ),
            F(
                "Name PS", "audit_project_name_peoplesoft", "Name PS",
                transform="uppercase",
                max_length=250,
                source_fields=["Name PS", "audit_project_name_peoplesoft"],
            ),
            F(
                "Active", "select", "Active", "choice",
                choices=_YN,
                default="Y",
                source_fields=["Active", "select"],
            ),
        ],
    },

    # ========================================================
    # DEAL TYPE
    # dbo.a_deal_type
    # ========================================================
    "deal-type": {
        "title": "Deal Type",
        "view": "dbo.VW_aDealtype",
        "table": "dbo.a_deal_type",
        "view_key": "Key",
        "table_key": "deal_type_key",
        "identity_key": True,
        "allow_create": True,
        "allow_update": True,
        "allow_delete": True,
        "delete_column": "flag",
        "delete_value": 1,
        "modal_width": "xlarge",
        "audit": _AUDIT,
        "create_defaults": {"flag": 0},
        "fields": [
            F("Key", "deal_type_key", "Key", "readonly", show_on_create=False),
            F(
                "region_key", None, "Region Name", "lookup",
                lookup="region",
                required=True,
                source_fields=["region_key", "Region Key"],
            ),
            F(
                "client_key", None, "Client Name", "lookup",
                lookup="client",
                depends_on="region_key",
                required=True,
                source_fields=["client_key", "Client Key"],
            ),
            F(
                "audit_project_key", "audit_project_key", "Audit Project", "lookup",
                lookup="audit_project",
                depends_on="client_key",
                required=True,
                source_fields=["audit_project_key", "Audit Project Key"],
            ),
            F(
                "Deal Type", "deal_type_name", "Deal Type",
                required=True,
                transform="uppercase",
                max_length=250,
                source_fields=["Deal Type", "Name", "deal_type_name"],
            ),
            F(
                "Deal Type Ctx", "deal_type_name_claimtrax", "Deal Type Ctx",
                transform="uppercase",
                max_length=250,
                source_fields=["Deal Type Ctx", "deal_type_name_claimtrax"],
            ),
            F(
                "Description", "deal_type_description", "Description", "textarea",
                required=True,
                transform="uppercase",
                max_length=2000,
                span=2,
                source_fields=["Description", "deal_type_description"],
            ),
            F(
                "Ctx Code", "claimtrax_code_key", "Ctx Code", "lookup",
                lookup="claimtrax_code",
                required=True,
                extra_targets={
                    "name": "Ctx Name",
                    "name_eng": "Ctx Name Eng",
                },
                source_fields=["Ctx Code", "claimtrax_code_key", "Claimtrax Code Key"],
            ),
            F(
                "Ctx Name", None, "Ctx Name", "display",
                source_fields=["Ctx Name", "Claimtrax Name", "claimtrax_name"],
            ),
            F(
                "Ctx Name Eng", None, "Ctx Name Eng", "display",
                source_fields=[
                    "Ctx Name Eng", "Ctx Name En",
                    "Claimtrax Name Eng", "Claimtrax Name En",
                    "claimtrax_name_eng", "claimtrax_name_en",
                ],
            ),
            F(
                "Active", "active", "Active", "choice",
                required=True,
                choices=_YN,
                default="Y",
                source_fields=["Active", "active"],
            ),
        ],
    },

    # ========================================================
    # ERP
    # dbo.erp
    # ========================================================
    "erp": {
        "title": "ERP",
        "view": "dbo.VW_ERP",
        "table": "dbo.erp",
        "view_key": "Key",
        "table_key": "erp_key",
        "identity_key": True,
        "allow_create": True,
        "allow_update": True,
        "allow_delete": True,
        "delete_column": "flag",
        "delete_value": 1,
        "modal_width": "large",
        "audit": _AUDIT,
        "create_defaults": {"flag": 0},
        "fields": [
            F("Key", "erp_key", "Key", "readonly", show_on_create=False),
            F(
                "region_key", None, "Region Name", "lookup",
                lookup="region",
                required=True,
                source_fields=["region_key", "Region Key"],
            ),
            F(
                "client_key", "client_key", "Client Name", "lookup",
                lookup="client",
                depends_on="region_key",
                required=True,
                source_fields=["client_key", "Client Key"],
            ),
            F(
                "Name", "erp_name", "Name",
                required=True,
                transform="uppercase",
                max_length=200,
                source_fields=["Name", "ERP Name", "erp_name"],
            ),
            F(
                "Content", "erp_content", "Content",
                required=True,
                transform="uppercase",
                max_length=1000,
                span=2,
                source_fields=["Content", "erp_content"],
            ),
            F(
                "Access", "erp_access", "Access", "choice",
                choices=_X_YES_NO,
                source_fields=["Access", "erp_access"],
            ),
            F(
                "Data", "erp_data", "Data", "choice",
                choices=_X_YES_NO,
                source_fields=["Data", "erp_data"],
            ),
        ],
    },

    # ========================================================
    # CLIENT DOCUMENTATION
    # dbo.client_documentation
    # ========================================================
    "client-documentation": {
        "title": "Client Documentation",
        "view": "dbo.VW_ClientDocumentation",
        "table": "dbo.client_documentation",
        "view_key": "Key",
        "table_key": "client_documentation_key",
        "identity_key": True,
        "allow_create": True,
        "allow_update": True,
        "allow_delete": True,
        "delete_column": "flag",
        "delete_value": 1,
        "modal_width": "xlarge",
        "audit": _AUDIT,
        "create_defaults": {"flag": 0},
        "fields": [
            F("Key", "client_documentation_key", "Key", "readonly", show_on_create=False),
            F(
                "region_key", None, "Region Name", "lookup",
                lookup="region",
                required=True,
                source_fields=["region_key", "Region Key"],
            ),
            F(
                "client_key", "client_key", "Client Name", "lookup",
                lookup="client",
                depends_on="region_key",
                required=True,
                source_fields=["client_key", "Client Key"],
            ),
            F(
                "ERP Name", "erp_name", "ERP Name", "lookup",
                lookup="erp_name",
                depends_on="client_key",
                required=True,
                source_fields=["Name", "ERP Name", "erp_name"],
            ),
            F(
                "Type", "documentation_type", "Type", "choice",
                required=True,
                choices=_DOC_TYPE,
                transform="uppercase",
                source_fields=["Type", "documentation_type"],
            ),
            F(
                "Client Download", "client_download", "Client Download", "choice",
                choices=_X_YES_NO,
                source_fields=["Client Download", "client_download"],
            ),
            F(
                "PRGX Download", "manual_download", "PRGX Download", "choice",
                choices=_X_YES_NO,
                source_fields=["PRGX Download", "Manual Download", "manual_download"],
            ),
            F(
                "AutoIt", "automatic_download", "AutoIt", "choice",
                choices=_X_YES_NO,
                source_fields=["AutoIt", "Automatic Download", "automatic_download"],
            ),
            F(
                "Digitalization", "digitalization", "Digitalization", "choice",
                choices=_X_YES_NO,
                source_fields=["Digitalization", "digitalization"],
            ),
            F(
                "Manual Entry", "manual_recording", "Manual Entry", "choice",
                choices=_X_YES_NO,
                source_fields=["Manual Entry", "Manual Recording", "manual_recording"],
            ),
            F(
                "Ocr", "ocr", "OCR", "choice",
                choices=_X_YES_NO,
                source_fields=["Ocr", "OCR", "ocr"],
            ),
            F(
                "Content", "documentation_content", "Content", "textarea",
                required=True,
                transform="uppercase",
                max_length=4000,
                span=2,
                source_fields=["Content", "documentation_content"],
            ),
            F(
                "Source", "documentation_source", "Source", "textarea",
                required=True,
                max_length=4000,
                span=2,
                source_fields=["Source", "documentation_source"],
            ),
        ],
    },

    # ========================================================
    # AUDIT PROJECT PLANNING
    # dbo.audit_project_planning
    # ========================================================
    "audit-project-planning": {
        "title": "Audit Project Planning",
        "view": "dbo.VW_AuditProjectPlanning",
        "table": "dbo.audit_project_planning",
        "view_key": "Key",
        "table_key": "audit_project_planning_key",
        "identity_key": True,
        "allow_create": True,
        "allow_update": True,
        "allow_delete": True,
        # v13.4: real SQL Server pagination. No TOP 10,000/50,000 window.
        # Only the requested page is read while COUNT(*) and filters operate
        # against the complete dbo.VW_AuditProjectPlanning view.
        "server_side_paging": True,
        "server_page_size": 25,
        "server_max_page_size": 500,
        "server_default_sort_column": "Key",
        "server_default_sort_direction": "DESC",
        "delete_column": "flag",
        "delete_value": 1,
        "modal_width": "xlarge",
        "audit": _AUDIT,
        "create_defaults": {"flag": 0},
        "fields": [
            F("Key", "audit_project_planning_key", "Key", "readonly", show_on_create=False),
            F(
                "region_key", None, "Region Name", "lookup",
                lookup="region",
                required=True,
                source_fields=["region_key", "Region Key"],
            ),
            F(
                "client_key", None, "Client Name", "lookup",
                lookup="client",
                depends_on="region_key",
                required=True,
                source_fields=["client_key", "Client Key"],
            ),
            F(
                "audit_project_key", "audit_project_key", "Audit Project", "lookup",
                lookup="audit_project",
                depends_on="client_key",
                required=True,
                source_fields=["audit_project_key", "Audit Project Key"],
            ),
            F(
                "audit_lead_key", "audit_lead_key", "Audit Lead", "lookup",
                lookup="planning_user",
                depends_on="region_key",
                show_extra_in_label=True,
                required=True,
                source_fields=[
                    "audit_lead_key",
                    "Audit Lead Key",
                    "Audit Lead",
                ],
            ),
            F(
                "responsible_key", "responsible_key", "Responsible", "lookup",
                lookup="planning_user",
                depends_on="region_key",
                show_extra_in_label=True,
                required=True,
                source_fields=[
                    "responsible_key",
                    "Responsible Key",
                    "Responsible",
                ],
            ),
            F(
                "Audit Scope", "audit_scope", "Audit Scope",
                required=True,
                transform="uppercase",
                max_length=2000,
                span=2,
                source_fields=["Audit Scope", "audit_scope"],
            ),
            F(
                "Start Date", "planned_start_audit_date", "Start Date", "date",
                required=True,
                display_format="medium_date",
                source_fields=["Start Date", "planned_start_audit_date"],
            ),
            F(
                "End Date", "planned_end_audit_date", "End Date", "date",
                required=True,
                display_format="medium_date",
                after_or_equal="Start Date",
                source_fields=["End Date", "planned_end_audit_date"],
            ),
            F(
                "From", "budget_year_from", "From", "number",
                min=1900,
                max=2200,
                readonly=True,
                derived_from="Start Date",
                derive="year",
                source_fields=["From", "budget_year_from"],
            ),
            F(
                "To", "budget_year_to", "To", "number",
                min=1900,
                max=2200,
                readonly=True,
                derived_from="End Date",
                derive="year",
                source_fields=["To", "budget_year_to"],
            ),
            F(
                "Budget", "yearly_budget_value_local_currency", "Budget", "money",
                min=0,
                decimals=2,
                source_fields=["Budget", "yearly_budget_value_local_currency"],
            ),
            F(
                "Budget USD", "yearly_budget_value_usd", "Budget USD", "money",
                min=0,
                decimals=2,
                source_fields=["Budget USD", "yearly_budget_value_usd"],
            ),
            F(
                "Status", "app_status_key", "Status", "lookup",
                lookup="planning_status",
                source_fields=["Status", "app_status_key", "App Status Key"],
            ),
            F(
                "Comment", "as_comment", "Comment", "textarea",
                max_length=4000,
                span=2,
                source_fields=["Comment", "as_comment"],
            ),
        ],
    },
}


# ============================================================
# LOOKUPS
#
# Lookup resolver accepts exact column names OR candidate lists.
# This is useful for old Planning tables whose labels varied over
# time (Audit Lead, Responsible, ClaimTrax code, Status).
# ============================================================
PLANNING_LOOKUPS = {
    "region": {
        "table": "dbo.Region",
        "value_field": "region_key",
        "label_field": "region_name",
        "extra_field": "region_acronym",
        "where": "[flag] = 0",
        "order_by": "region_name",
    },
    "currency": {
        "table": "dbo.Currency",
        "value_field": "currency_key",
        "label_field": ["currency_name_sp", "currency_name", "name"],
        "extra_field": ["currency_code", "code"],
        "where": None,
        "order_by": ["currency_name_sp", "currency_name", "name"],
    },
    "client": {
        "table": "dbo.Client",
        "value_field": "client_key",
        "label_field": "client_name",
        "extra_field": "client_code",
        "filter_column": "region_key",
        "where": "[flag] = 0",
        "order_by": "client_name",
    },
    "audit_project": {
        "table": "dbo.audit_project",
        "value_field": "audit_project_key",
        "label_field": "audit_project_name",
        "filter_column": "client_key",
        "where": "[flag] = 0",
        "order_by": "audit_project_name",
    },
    "planning_user": {
        # Legacy Access allowed Audit Lead / Responsible to be selected from
        # the active Planning user catalog; it was not limited to the selected
        # Planning Region.  Filtering by region caused new/test regions to show
        # an empty Assigned/Responsible list.  VW_User already excludes flag=1.
        "table": "dbo.VW_User",
        "value_field": ["Key", "user_key"],
        "label_field": ["Full Name", "Name", "user_full_name", "user_name"],
        "extra_field": ["User Domain", "Email", "user", "user_email"],
        "where": None,
        "order_by": ["Full Name", "Name", "user_full_name", "user_name"],
    },
    "erp_name": {
        # Client Documentation: use the same ERP view that powers /planning/erp.
        # It exposes client_key + Name, so the dropdown contains only ERPs
        # belonging to the selected client and stores the ERP name.
        "table": "dbo.VW_ERP",
        "value_field": "Name",
        "label_field": "Name",
        "filter_column": "client_key",
        "where": None,
        "order_by": "Name",
        "distinct": True,
    },
    "claimtrax_code": {
        # Prefer the physical Claimtrax code catalogs.  A VW_aDealtype fallback
        # is included because that view is confirmed to expose Ctx Code + names.
        # The resolver is instructed to skip a source that has the code but not
        # both descriptive columns, preventing blank Ctx Name fields.
        "table_candidates": [
            "dbo.claimtraxcode",
            "dbo.claimtrax_code",
            "dbo.claimtrax_code_list",
            "dbo.VW_ClaimtraxCode",
            "dbo.VW_Claimtrax_Code",
            "dbo.VW_aDealtype",
        ],
        "value_field": [
            "claimtrax_code_key",
            "claimtraxcode_key",
            "ctx_code_key",
            "code_key",
            "key",
            "Ctx Code",
        ],
        "label_field": [
            "claimtrax_code",
            "ctx_code",
            "code",
            "claimtrax_code_key",
            "Ctx Code",
        ],
        "extra_fields": {
            "name": [
                "claimtrax_name",
                "claimtrax_code_name",
                "ctx_name",
                "Ctx Name",
                "name",
                "description",
            ],
            "name_eng": [
                "claimtrax_name_eng",
                "claimtrax_name_en",
                "claimtrax_code_name_eng",
                "claimtrax_code_name_en",
                "ctx_name_eng",
                "ctx_name_en",
                "Ctx Name Eng",
                "Ctx Name En",
                "name_eng",
                "name_en",
                "english_name",
                "description_eng",
                "description_en",
            ],
        },
        "require_extra_fields": ["name", "name_eng"],
        "order_by": [
            "claimtrax_code", "ctx_code", "code",
            "claimtrax_code_key", "Ctx Code"
        ],
        "distinct": True,
    },
    "audit_lead": {
        "table_candidates": [
            "dbo.audit_lead",
            "dbo.audit_leads",
            "dbo.VW_AuditLead",
            "dbo.VW_AuditLeadPlanning",
        ],
        "value_field": ["audit_lead_key", "key"],
        "label_field": [
            "audit_lead_name",
            "audit_lead",
            "name",
            "full_name",
        ],
        "order_by": ["audit_lead_name", "audit_lead", "name", "full_name"],
    },
    "responsible": {
        "table_candidates": [
            "dbo.responsible",
            "dbo.audit_responsible",
            "dbo.VW_AuditResponsible",
            "dbo.VW_Responsible",
        ],
        "value_field": ["responsible_key", "key"],
        "label_field": [
            "responsible_name",
            "responsible",
            "name",
            "full_name",
        ],
        "order_by": ["responsible_name", "responsible", "name", "full_name"],
    },
    "planning_status": {
        # Exact catalog confirmed in dbo.audit_project_planning_status.
        # Keep it static here so the New/Edit form always exposes only these
        # four permitted statuses, even if the database lookup is unavailable.
        "items": [
            {"value": 1, "label": "Not Started"},
            {"value": 2, "label": "In progress"},
            {"value": 3, "label": "Completed"},
            {"value": 4, "label": "Canceled"},
        ],
    },
}

# ============================================================
# v12 - Legacy Planning stored-procedure contracts + HR/Users
# Source: legacy Access/VBA + SQL Server procedures supplied by user.
# The browser validates these rules first; SQL Server SPs remain the
# authoritative persistence/business-rule layer.
# ============================================================


def _field_by_name(entity, view_field):
    for _field in PLANNING_ENTITIES[entity].get("fields", []):
        if _field.get("view_field") == view_field:
            return _field
    return None


def _patch_field(entity, view_field, **changes):
    _field = _field_by_name(entity, view_field)
    if _field:
        _field.update(changes)
    return _field


# Exact/legacy SP limits that should be prevented in the form before save.
_patch_field("region", "Name", max_length=255)
_patch_field("region", "Acronym", max_length=50)

_patch_field("client", "Name", max_length=40)
_patch_field("client", "Name Ctx", max_length=50)
_patch_field("client", "Legal Name", max_length=40)
_patch_field("client", "Business Unit", max_length=255)
_patch_field("client", "Fiscal Number", max_length=50)
_patch_field("client", "Client Code", max_length=50)
_patch_field("client", "Country", max_length=255)
_patch_field("client", "Region", max_length=255)
_patch_field("client", "City", max_length=255)
_patch_field("client", "Address", max_length=255)
_patch_field("client", "Postal Code", max_length=255)
_patch_field("client", "End Date", required=False)

_patch_field("audit-project", "Audit Project", max_length=255)
_patch_field("audit-project", "Name Ctx", max_length=40)
_patch_field("audit-project", "Name PS", max_length=30)

_patch_field("deal-type", "Deal Type", max_length=255)
_patch_field("deal-type", "Deal Type Ctx", max_length=255)
_patch_field("deal-type", "Description", max_length=500)

_patch_field("erp", "Name", max_length=255)
_patch_field("erp", "Content", max_length=255)

_patch_field("client-documentation", "Type", max_length=255)
_patch_field("client-documentation", "Content", max_length=255)
_patch_field("client-documentation", "Source", max_length=255)

_patch_field("audit-project-planning", "Audit Scope", max_length=255)
_patch_field("audit-project-planning", "Budget", required=True)
_patch_field("audit-project-planning", "Budget USD", required=True)
_patch_field("audit-project-planning", "Status", required=True, default=1)
_patch_field("audit-project-planning", "Comment", max_length=255, required=True)
_patch_field("audit-project-planning", "From", required=True)
_patch_field("audit-project-planning", "To", required=True)
PLANNING_ENTITIES["audit-project-planning"]["allow_duplicate"] = True

# Legacy Planning explicitly requires these three process indicators.
_audit_planning_fields = PLANNING_ENTITIES["audit-project-planning"]["fields"]
if not _field_by_name("audit-project-planning", "Download"):
    _audit_planning_fields.extend([
        F(
            "Download", "download_information", "Download", "choice",
            required=True,
            choices=_X_YES_NO,
            default="",
            source_fields=["Download", "download_information"],
        ),
        F(
            "Capture", "capture_information", "Capture", "choice",
            required=True,
            choices=_X_YES_NO,
            default="",
            source_fields=["Capture", "capture_information"],
        ),
        F(
            "Development", "development_tool", "Development", "choice",
            required=True,
            choices=_X_YES_NO,
            default="",
            source_fields=["Development", "development_tool"],
        ),
    ])

# ============================================================
# HR > USERS (still inside the Planning sidebar group)
# ============================================================
PLANNING_ENTITIES["users"] = {
    "title": "Users",
    "section": "HR",
    "view": "dbo.VW_User",
    "table": "dbo.user",
    "view_key": "Key",
    "table_key": "user_key",
    "identity_key": True,
    "allow_create": True,
    "allow_update": True,
    "allow_delete": True,
    "delete_column": "flag",
    "delete_value": 1,
    "modal_width": "xlarge",
    "audit": _AUDIT,
    "create_defaults": {"flag": 0},
    "fields": [
        F("Key", "user_key", "Key", "readonly", show_on_create=False),
        F(
            "region_key", "region_key", "Region Name", "lookup",
            lookup="region", required=True,
            source_fields=["region_key", "Region Key"],
        ),
        F(
            "Full Name", "user_full_name", "Full Name",
            required=True, transform="uppercase", max_length=100,
            source_fields=["Full Name", "user_full_name"],
        ),
        F(
            "Name", "user_name", "Name",
            required=True, transform="uppercase", max_length=100,
            source_fields=["Name", "user_name"],
        ),
        F(
            "User Domain", "user", "User Domain",
            required=True, transform="uppercase", max_length=15,
            source_fields=["User Domain", "User", "user"],
        ),
        F(
            "Number", "user_number", "Number",
            required=True, transform="uppercase", max_length=15,
            source_fields=["Number", "user_number"],
        ),
        F(
            "user_title_key", "user_title_key", "Title", "lookup",
            lookup="user_title", required=True,
            source_fields=["user_title_key", "Title Key"],
        ),
        F(
            "Email", "user_email", "Email", "email",
            required=True, transform="lowercase", max_length=100,
            pattern=r"^[^\s@]+@[^\s@]+\.[^\s@]+$",
            pattern_message="The inputted e-mail does not seem to be a valid e-mail.",
            source_fields=["Email", "user_email"],
        ),
        F(
            "user_country_key", "user_country_key", "Country", "lookup",
            lookup="user_country", required=True,
            source_fields=["user_country_key", "Country Key"],
        ),
        F(
            "user_department_key", "user_department_key", "Department", "lookup",
            lookup="user_department", required=True,
            source_fields=["user_department_key", "Department Key"],
        ),
        F(
            "Active", "active", "Active", "choice",
            required=True,
            choices=[
                {"value": 1, "label": "Yes"},
                {"value": 0, "label": "No"},
            ],
            default=1,
            source_fields=["Active", "active"],
        ),
    ],
}

PLANNING_LOOKUPS.update({
    "user_title": {
        "table": "dbo.user_title",
        "value_field": "user_title_key",
        "label_field": ["user_title", "title", "name"],
        "where": None,
        "order_by": ["user_title", "title", "name"],
    },
    "user_country": {
        "table": "dbo.user_country",
        "value_field": "user_country_key",
        "label_field": ["user_country", "country", "name"],
        "where": None,
        "order_by": ["user_country", "country", "name"],
    },
    "user_department": {
        "table": "dbo.user_department",
        "value_field": "user_department_key",
        "label_field": ["department_name", "department", "name"],
        "where": None,
        "order_by": ["department_name", "department", "name"],
    },
})


# ============================================================
# Stored procedures used by the legacy Access application.
# param_map keys are matched case-insensitively against sys.parameters,
# so this remains resilient if the exact SP casing differs.
# Special values: __key__, __status__.
# ============================================================
PLANNING_SP_CONTRACTS = {
    "region": {
        "name": "dbo.SP_AddRegion",
        "param_map": {
            "region_key": "__key__",
            "RegionName": "Name",
            "RegionAcronym": "Acronym",
            "Status": "__status__",
        },
    },
    "client": {
        "name": "dbo.SP_AddClientP",
        "param_map": {
            "client_key": "__key__",
            "region_key": "region_key",
            "ClientName": "Name",
            "NameClaimtrax": "Name Ctx",
            "LegalName": "Legal Name",
            "Business": "Business Unit",
            "FiscalNumber": "Fiscal Number",
            "ClientCode": "Client Code",
            "Country": "Country",
            "Region": "Region",
            "City": "City",
            "Address": "Address",
            "PostalCode": "Postal Code",
            "CurrencyKey": "currency_key",
            "Payment": "Payment Term",
            "StartDate": "Start Date",
            "EndDate": "End Date",
            "Status": "__status__",
        },
    },
    "audit-project": {
        "name": "dbo.SP_AddAuditProject",
        "param_map": {
            "audit_project_key": "__key__",
            "client_key": "client_key",
            "audit_project_name": "Audit Project",
            "audit_project_name_claimtrax": "Name Ctx",
            "audit_project_name_peoplesoft": "Name PS",
            "select": "Active",
            "Status": "__status__",
        },
    },
    "deal-type": {
        "name": "dbo.SP_AddDealType",
        "param_map": {
            "deal_type_key": "__key__",
            "audit_project_key": "audit_project_key",
            "deal_type_name": "Deal Type",
            "deal_type_name_claimtrax": "Deal Type Ctx",
            "deal_type_description": "Description",
            "claimtrax_code_key": "Ctx Code",
            "active": "Active",
            "Status": "__status__",
        },
    },
    "erp": {
        "name": "dbo.SP_AddErp",
        "param_map": {
            "erp_key": "__key__",
            "client_key": "client_key",
            "erp_name": "Name",
            "erp_content": "Content",
            "erp_access": "Access",
            "erp_data": "Data",
            "status": "__status__",
        },
    },
    "client-documentation": {
        "name": "dbo.SP_AddClientDocumentation",
        "param_map": {
            "client_documentation_key": "__key__",
            "client_key": "client_key",
            "erp_name": "ERP Name",
            "documentation_type": "Type",
            "documentation_content": "Content",
            "documentation_source": "Source",
            "client_download": "Client Download",
            "manual_download": "PRGX Download",
            "automatic_download": "AutoIt",
            "digitalization": "Digitalization",
            "manual_recording": "Manual Entry",
            "ocr": "Ocr",
            "Status": "__status__",
        },
    },
    "audit-project-planning": {
        "name": "dbo.SP_AddAuditProjectPlanning",
        "param_map": {
            "audit_project_planning_key": "__key__",
            "audit_project_key": "audit_project_key",
            "audit_lead_key": "audit_lead_key",
            "responsible_key": "responsible_key",
            "audit_scope": "Audit Scope",
            "planned_start_audit_date": "Start Date",
            "planned_end_audit_date": "End Date",
            "yearly_budget_value_local_currency": "Budget",
            "yearly_budget_value_usd": "Budget USD",
            "download_information": "Download",
            "capture_information": "Capture",
            "development_tool": "Development",
            "as_comment": "Comment",
            "app_status_key": "Status",
            "Status": "__status__",
        },
    },
    "users": {
        "name": "dbo.SP_AddUserP",
        "param_map": {
            "user_key": "__key__",
            "region_key": "region_key",
            "userFullName": "Full Name",
            "userName": "Name",
            "userNet": "User Domain",
            "userNo": "Number",
            "userTitleKey": "user_title_key",
            "UserEmail": "Email",
            "CountryKey": "user_country_key",
            "DepartmentKey": "user_department_key",
            "Active": "Active",
            "status": "__status__",
        },
    },
}

PLANNING_MESSAGES = {
    "region": {
        "create": "The region was added successfully.",
        "update": "The region was updated successfully.",
        "delete": "The region was removed successfully.",
    },
    "client": {
        "create": "The client was added successfully.",
        "update": "The client was updated successfully.",
        "delete": "The client was removed successfully.",
    },
    "audit-project": {
        "create": "The Audit Project was added successfully.",
        "update": "The Audit Project was updated successfully.",
        "delete": "The Audit Project was removed successfully.",
    },
    "deal-type": {
        "create": "The Deal Type was added successfully.",
        "update": "The Deal Type was updated successfully.",
        "delete": "The Deal Type was removed successfully.",
    },
    "erp": {
        "create": "The ERP was added successfully.",
        "update": "The ERP was updated successfully.",
        "delete": "The ERP was removed successfully.",
    },
    "client-documentation": {
        "create": "The Client Documentation was added successfully.",
        "update": "The Client Documentation was updated successfully.",
        "delete": "The Client Documentation was removed successfully.",
    },
    "audit-project-planning": {
        "create": "The Audit Project Planning was added successfully.",
        "update": "The Audit Project Planning was updated successfully.",
        "delete": "The Audit Project Planning was removed successfully.",
    },
    "users": {
        "create": "The user was added successfully.",
        "update": "The user was updated successfully.",
        "delete": "The user was removed successfully.",
    },
}
# X/blank is the legacy storage contract; blank means an explicit No.
# Therefore these toggles are not treated as missing when blank.
_patch_field("audit-project-planning", "Download", required=False)
_patch_field("audit-project-planning", "Capture", required=False)
_patch_field("audit-project-planning", "Development", required=False)
# Legacy Access stored Active/Select as X/blank even though the UI displayed Y/N.
_patch_field("audit-project", "Active", choices=_X_YES_NO, default="X", required=False)
_patch_field("deal-type", "Active", choices=_X_YES_NO, default="X", required=False)
