# AuditX 
 
AuditX is a modular web application for audit data analysis, query building, and data export.
 
## Features
 
- Dynamic Query Builder
- Data Preview
- Excel Export (with partition support)
- Modular UI Components
- Login System
- Dashboard with dynamic views
 
---
 
## Project Structure