"""
    Módulo: connection
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:        
             Gestiona las preferencias de visualización de los usuarios para las listas de datos, permitiendo consultar, guardar, actualizar
             y restablecer la configuración de columnas, filtros y tamaño de página.

"""

import json
from database.connection import (
    get_dynamic_connection
)
from config.session import get_current_client_db
 
 
TABLE_NAME = "dbo.UserPreviewLayout"
 
 
def _safe_json_loads(value, default):
    if not value:
        return default
 
    try:
        return json.loads(value)
    except Exception:
        return default
 
 
def get_user_preview_layout(user_key: str, data_list_id: int):
    server, database = get_current_client_db() 
    query = f"""
        SELECT TOP 1
            Id,
            UserKey,
            DataListId,
            VisibleColumns,
            Filters,
            PageSize,
            CreatedAt,
            UpdatedAt
        FROM {TABLE_NAME}
        WHERE UserKey = ?
          AND DataListId = ?
        ORDER BY UpdatedAt DESC, CreatedAt DESC
    """
 
    conn = get_dynamic_connection(server,database)
    cursor = conn.cursor()
 
    try:
        cursor.execute(query, (user_key, data_list_id))
        row = cursor.fetchone()
 
        if not row:
            return {
                "exists": False,
                "columns": [],
                "filters": [],
                "pageSize": 25
            }
 
        return {
            "exists": True,
            "columns": _safe_json_loads(row.VisibleColumns, []),
            "filters": _safe_json_loads(row.Filters, []),
            "pageSize": row.PageSize or 25
        }
 
    finally:
        conn.close()
 
 
def save_user_preview_layout(
    user_key: str,
    data_list_id: int,
    visible_columns=None,
    filters=None,
    page_size: int = 25
):
    server, database = get_current_client_db() 
    visible_columns = visible_columns or []
    filters = filters or []
 
    columns_json = json.dumps(visible_columns, ensure_ascii=False)
    filters_json = json.dumps(filters, ensure_ascii=False)
 
    query_exists = f"""
        SELECT TOP 1 Id
        FROM {TABLE_NAME}
        WHERE UserKey = ?
          AND DataListId = ?
    """
 
    query_update = f"""
        UPDATE {TABLE_NAME}
        SET VisibleColumns = ?,
            Filters = ?,
            PageSize = ?,
            UpdatedAt = GETDATE()
        WHERE UserKey = ?
          AND DataListId = ?
    """
 
    query_insert = f"""
        INSERT INTO {TABLE_NAME}
            (UserKey, DataListId, VisibleColumns, Filters, PageSize, CreatedAt, UpdatedAt)
        VALUES
            (?, ?, ?, ?, ?, GETDATE(), GETDATE())
    """
 
    conn = get_dynamic_connection(server,database)
    cursor = conn.cursor()
 
    try:
        cursor.execute(query_exists, (user_key, data_list_id))
        row = cursor.fetchone()
 
        if row:
            cursor.execute(
                query_update,
                (
                    columns_json,
                    filters_json,
                    page_size,
                    user_key,
                    data_list_id
                )
            )
        else:
            cursor.execute(
                query_insert,
                (
                    user_key,
                    data_list_id,
                    columns_json,
                    filters_json,
                    page_size
                )
            )
 
        conn.commit()
 
        return True
 
    finally:
        conn.close()
 
 
def save_visible_columns(user_key: str, data_list_id: int, visible_columns):
    current = get_user_preview_layout(user_key, data_list_id)
 
    return save_user_preview_layout(
        user_key=user_key,
        data_list_id=data_list_id,
        visible_columns=visible_columns,
        filters=current.get("filters", []),
        page_size=current.get("pageSize", 25)
    )
 
 
def save_filters(user_key: str, data_list_id: int, filters, page_size: int = None):
    current = get_user_preview_layout(user_key, data_list_id)
 
    return save_user_preview_layout(
        user_key=user_key,
        data_list_id=data_list_id,
        visible_columns=current.get("columns", []),
        filters=filters,
        page_size=page_size or current.get("pageSize", 25)
    )
 
 
def reset_user_preview_layout(user_key: str, data_list_id: int):
    server, database = get_current_client_db() 
    query = f"""
        DELETE FROM {TABLE_NAME}
        WHERE UserKey = ?
          AND DataListId = ?
    """
 
    conn = get_dynamic_connection(server,database)
    cursor = conn.cursor()
 
    try:
        cursor.execute(query, (user_key, data_list_id))
        conn.commit()
        return True
 
    finally:
        conn.close()