"""

    Módulo: db_config
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:        
        Centraliza las operaciones de acceso a datos relacionadas con la asociación usuario-cliente,
        incluyendo la consulta de clientes disponibles, la obtención de la información de conexión y
        la actualización del último cliente seleccionado.

"""

from database.connection import get_connection
 
 
def row_to_dict(cursor, row):
    columns = [column[0] for column in cursor.description]
    return dict(zip(columns, row))
 
 
def get_value(row_dict, *names):
    for name in names:
        if name in row_dict:
            return row_dict[name]
    return None
 
 
def format_datetime(value):
    if not value:
        return None
 
    try:
        return value.strftime("%Y-%m-%d %H:%M")
    except Exception:
        return str(value)
 
 
def get_clients_by_user(user_key):
    conn = get_connection()
    cursor = conn.cursor()
 
    query = """
        SELECT *
        FROM dbo.F_get_clients_by_user(?)
        ORDER BY
            LastAccessAt DESC,
            ClientName ASC
    """
 
    cursor.execute(query, user_key)
    rows = cursor.fetchall()
 
    clients = []
 
    for row in rows:
        row_dict = row_to_dict(cursor, row)
 
        clients.append({
            "userClientKey": get_value(row_dict, "UserClientKey", "userClientKey"),
            "userKey": get_value(row_dict, "UserKey", "userKey"),
            "clientKey": get_value(row_dict, "ClientKey", "clientKey"),
            "clientName": get_value(row_dict, "ClientName", "clientName"),
            "lastAccessAt": format_datetime(
                get_value(row_dict, "LastAccessAt", "lastAccessAt")
            ),
            "isLastSelected": bool(
                get_value(row_dict, "IsLastSelected", "isLastSelected") or 0
            )
        })
 
    conn.close()
    return clients
 
 
def get_client_for_user(user_key, client_key):
    conn = get_connection()
    cursor = conn.cursor()
 
    query = """
        SELECT TOP 1 *
        FROM dbo.F_get_client_for_user(?, ?)
    """
 
    cursor.execute(query, user_key, client_key)
    row = cursor.fetchone()
 
    if not row:
        conn.close()
        return None
 
    row_dict = row_to_dict(cursor, row)
    conn.close()
 
    return {
        "userClientKey": get_value(row_dict, "UserClientKey", "userClientKey"),
        "userKey": get_value(row_dict, "UserKey", "userKey"),
        "clientKey": get_value(row_dict, "ClientKey", "clientKey"),
        "clientName": get_value(row_dict, "ClientName", "clientName"),
        "sqlServer": get_value(row_dict, "SQL_Server", "SqlServer", "sqlServer"),
        "sqlDatabase": get_value(row_dict, "SQL_Database", "SqlDatabase", "sqlDatabase")
    }
 
 
def get_last_selected_client(user_key):
    clients = get_clients_by_user(user_key)
 
    if not clients:
        return None
 
    selected = None
 
    for client in clients:
        if client.get("isLastSelected"):
            selected = client
            break
 
    if not selected:
        selected = clients[0]
 
    return get_client_for_user(user_key, selected.get("clientKey"))
 
 
def mark_client_as_selected(user_key, client_key):
    conn = get_connection()
    cursor = conn.cursor()
 
    cursor.execute("""
        UPDATE dbo.userclients
        SET
            UpdatedAt = GETDATE()
        WHERE UserKey = ?
    """, user_key)
 
    cursor.execute("""
        UPDATE dbo.userclients
        SET
            LastAccessAt = GETDATE(),
            UpdatedAt = GETDATE()
        WHERE UserKey = ?
          AND ClientKey = ?
          AND IsActive = 1
    """, user_key, client_key)
 
    conn.commit()
    conn.close()