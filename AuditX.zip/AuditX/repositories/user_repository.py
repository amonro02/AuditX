"""
    Módulo: connection
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:        
            Gestiona las operaciones de acceso a datos relacionadas con usuarios, incluyendo la consulta de información de usuario, manejo
            de autenticación de doble factor (2FA) y control de intentos fallidos de acceso.

            get_user_by_email() → obtiene la información del usuario para autenticación.
            save_user_2fa() → almacena y habilita la configuración de doble factor.
            update_user_attempts() → registra intentos fallidos y bloqueo temporal.
            reset_user_attempts() → limpia el control de intentos después de una autenticación exitosa.

"""

from database.connection import get_connection
  
def get_user_by_email(email):
    query = """
        SELECT
            UserKey,
            Email,
            FullName,
            NetworkUserID,
            Role,
            IsActive,
            TwoFactorSecret,
            TwoFactorEnabled,
            FailedAttempts,
            LockedUntil
        FROM dbo.users
        WHERE Email = ?
    """
 
    conn = get_connection()
    cursor = conn.cursor()
 
    cursor.execute(query, email)
    row = cursor.fetchone()
 
    cursor.close()
    conn.close()
 
    if not row:
        return None
 
    return {
        "UserID": row.UserKey,
        "Email": row.Email,
        "FullName": row.FullName,
        "UserName": row.NetworkUserID,
        "Role": row.Role,
        "IsActive": row.IsActive,
        "TwoFactorSecret": row.TwoFactorSecret,
        "TwoFactorEnabled": row.TwoFactorEnabled,
        "FailedAttempts": row.FailedAttempts,
        "LockedUntil": row.LockedUntil,
    }
 
 
def save_user_2fa(email, secret):
    query = """
        UPDATE dbo.users
        SET
            TwoFactorSecret = ?,
            TwoFactorEnabled = 1,
            UpdatedAt = GETDATE()
        WHERE Email = ?
    """
 
    conn = get_connection()
    cursor = conn.cursor()
 
    cursor.execute(query, secret, email)
    conn.commit()
 
    cursor.close()
    conn.close()
 
 
def update_user_attempts(email, attempts, locked_until):
    query = """
        UPDATE dbo.users
        SET
            FailedAttempts = ?,
            LockedUntil = ?,
            UpdatedAt = GETDATE()
        WHERE Email = ?
    """
 
    conn = get_connection()
    cursor = conn.cursor()
 
    cursor.execute(query, attempts, locked_until, email)
    conn.commit()
 
    cursor.close()
    conn.close()
 
 
def reset_user_attempts(email):
    query = """
        UPDATE dbo.users
        SET
            FailedAttempts = 0,
            LockedUntil = NULL,
            UpdatedAt = GETDATE()
        WHERE Email = ?
    """
 
    conn = get_connection()
    cursor = conn.cursor()
 
    cursor.execute(query, email)
    conn.commit()
 
    cursor.close()
    conn.close()