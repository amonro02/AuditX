"""
    Módulo: connection
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:        
             Gestiona las consultas relacionadas con proyectos, reportes y listas de datos del cliente, proporcionando la información
             necesaria para navegar y acceder a los recursos disponibles en la base de datos.

"""

from database.connection import (
    get_dynamic_connection
)    
from config.session import get_current_client_db
    
 
 
def get_projects(server: str,database: str):
    query = """
        SELECT DISTINCT
            ProjectsID,
            ClientName,
            ProjectName,
            DateEntered,
            Sort
        FROM dbo.PROJECTS
        WHERE ProjectName IS NOT NULL
          AND LTRIM(RTRIM(ProjectName)) <> ''
        ORDER BY ProjectName
    """
 
    conn = get_dynamic_connection(server,database)
    cursor = conn.cursor()
    cursor.execute(query)
    rows = cursor.fetchall()
    conn.close()
 
    return [
        {
            "projectId": row.ProjectsID,
            "projectName": row.ProjectName,
            "clientName": row.ClientName,
            "dateEntered": row.DateEntered,
            "sort": row.Sort
        }
        for row in rows
    ]
 
 
def get_reports_by_project_id(project_id: int,server: str,database: str):
    query = """
        SELECT DISTINCT
            ReportListID,
            ReportDisplayName,
            SourceType
        FROM dbo.ReportListX
        WHERE ProjectsID = ?
          AND ReportDisplayName IS NOT NULL
          AND LTRIM(RTRIM(ReportDisplayName)) <> ''
        ORDER BY ReportDisplayName
    """
 
    conn = get_dynamic_connection(server,database)
    cursor = conn.cursor()
    cursor.execute(query, (project_id,))
    rows = cursor.fetchall()
    conn.close()
 
    return [
        {
            "reportListId": row.ReportListID,
            "reportName": row.ReportDisplayName,
            "sourceType": getattr(row, "SourceType", None)
        }
        for row in rows
    ]
 
 
def get_data_lists_by_report_list_id(report_list_id: int,server: str,database: str):
    query = """
        SELECT
            DataListID,
            COALESCE(LinkedTableName, SQL_TableName) AS TableName,
            SourceType
        FROM dbo.DataList
        WHERE ReportListID = ?
        ORDER BY COALESCE(LinkedTableName, SQL_TableName)
    """
 
    conn = get_dynamic_connection(server,database)
    cursor = conn.cursor()
    cursor.execute(query, (report_list_id,))
    rows = cursor.fetchall()
    conn.close()
 
    return [
        {
            "dataListId": row.DataListID,
            "tableName": row.TableName,
            "sourceType": row.SourceType
        }
        for row in rows
    ]
 
 
def get_data_list_by_id(data_list_id: int):
    server, database = get_current_client_db() 
    query = """
        SELECT
            DataListID,
            ReportListID,
            SQL_Server,
            SQL_Database,
            SQL_TableName,
            LinkedTableName,
            SourceType
        FROM dbo.DataList
        WHERE DataListID = ?
    """
 
    conn = get_dynamic_connection(server,database)
    cursor = conn.cursor()
    cursor.execute(query, (data_list_id,))
    row = cursor.fetchone()
    conn.close()
 
    if not row:
        return None
 
    return {
        "dataListId": row.DataListID,
        "reportListId": row.ReportListID,
        "server": row.SQL_Server,
        "database": row.SQL_Database,
        "tableName": row.LinkedTableName or row.SQL_TableName,
        "sourceType": row.SourceType
    }