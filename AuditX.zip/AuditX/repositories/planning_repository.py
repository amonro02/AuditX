from datetime import date, datetime
from decimal import Decimal
import re

from database.connection import get_planning_connection
from config.planning_entities import PLANNING_ENTITIES, PLANNING_LOOKUPS


_MONTHS = (
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
)


def _quote_identifier(name):
    return "[" + str(name).replace("]", "]]" ) + "]"


def _quote_table(name):
    return ".".join(
        _quote_identifier(part)
        for part in str(name).split(".")
    )


def _medium_date(value):
    """User-facing date: 11-Sep-2026."""
    if isinstance(value, datetime):
        value = value.date()

    if not isinstance(value, date):
        return value

    return f"{value.day:02d}-{_MONTHS[value.month - 1]}-{value.year:04d}"


def _format_value(value):
    if value is None:
        return ""

    if isinstance(value, (datetime, date)):
        return _medium_date(value)

    if isinstance(value, Decimal):
        return float(value)

    if isinstance(value, (str, int, float, bool)):
        return value

    return str(value)


def _get_entity(entity):
    return PLANNING_ENTITIES.get(entity)


def _public_entity_config(entity):
    config = _get_entity(entity)

    if not config:
        return None

    public_fields = []

    for field in config.get("fields", []):
        public_fields.append({
            "view_field": field.get("view_field"),
            "source_fields": field.get("source_fields") or [],
            "label": field.get("label"),
            "type": field.get("type", "text"),
            "required": bool(field.get("required", False)),
            "highlight_required": bool(field.get("highlight_required", False)),
            "lookup": field.get("lookup"),
            "depends_on": field.get("depends_on"),
            "extra_target": field.get("extra_target"),
            "extra_targets": field.get("extra_targets") or {},
            "choices": field.get("choices") or [],
            "show_extra_in_label": bool(field.get("show_extra_in_label", False)),
            "span": int(field.get("span", 1) or 1),
            "show_on_create": field.get("show_on_create", True),
            "default": field.get("default"),
            "transform": field.get("transform"),
            "min_length": field.get("min_length"),
            "max_length": field.get("max_length"),
            "min": field.get("min"),
            "max": field.get("max"),
            "pattern": field.get("pattern"),
            "pattern_message": field.get("pattern_message"),
            "display_format": field.get("display_format"),
            "after_or_equal": field.get("after_or_equal"),
            "before_or_equal": field.get("before_or_equal"),
            "readonly": bool(field.get("readonly", False)),
            "derived_from": field.get("derived_from"),
            "derive": field.get("derive"),
            "decimals": field.get("decimals"),
        })

    return {
        "entity": entity,
        "title": config.get("title", entity),
        "view_key": config.get("view_key", "Key"),
        "modal_width": config.get("modal_width", "large"),
        "allow_create": bool(config.get("allow_create", False)),
        "allow_update": bool(config.get("allow_update", False)),
        "allow_delete": bool(config.get("allow_delete", False)),
        "date_display": "DD-MMM-YYYY",
        "server_side_paging": bool(config.get("server_side_paging", False)),
        "server_page_size": int(config.get("server_page_size", 25) or 25),
        "fields": public_fields,
    }


def _coerce_positive_int(value, default, minimum=1, maximum=None):
    try:
        number = int(value)
    except (TypeError, ValueError):
        number = int(default)

    if number < minimum:
        number = minimum

    if maximum is not None:
        number = min(number, maximum)

    return number


def _jsonable_filter_value(value):
    """Normalize a filter payload coming from the Data Download UI.

    The shared Data Download component has changed shape a few times, so this
    helper intentionally accepts strings, arrays and common object shapes.
    """
    if value is None:
        return None

    if isinstance(value, (str, int, float, bool)):
        return value

    if isinstance(value, (list, tuple, set)):
        return [
            _jsonable_filter_value(item)
            for item in value
            if item not in (None, "")
        ]

    if isinstance(value, dict):
        return {
            str(key): _jsonable_filter_value(item)
            for key, item in value.items()
        }

    return str(value)


def _extract_filter_terms(value):
    """Return (mode, terms) where mode is contains or exact-list.

    This is deliberately tolerant so Planning can reuse the existing Data
    Download filter UI without depending on one exact JavaScript state shape.
    """
    value = _jsonable_filter_value(value)

    if value in (None, "", [], {}):
        return None, []

    if isinstance(value, bool):
        return None, []

    if isinstance(value, (int, float)):
        return "contains", [str(value)]

    if isinstance(value, str):
        text = value.strip()
        return ("contains", [text]) if text else (None, [])

    if isinstance(value, list):
        terms = [str(item).strip() for item in value if str(item).strip()]
        return ("exact-list", terms) if terms else (None, [])

    if isinstance(value, dict):
        # Most Data Download revisions use one of these keys for text search.
        for key in (
            "search", "text", "query", "contains", "filter", "term",
            "searchText", "search_text",
        ):
            candidate = value.get(key)
            if candidate not in (None, "", [], {}):
                return _extract_filter_terms(candidate)

        # Excel-style multi-select filters normally surface one of these.
        for key in (
            "selectedValues", "selected_values", "values", "selected",
            "checked", "include", "items",
        ):
            candidate = value.get(key)
            if isinstance(candidate, (list, tuple, set)):
                terms = [str(item).strip() for item in candidate if str(item).strip()]
                if terms:
                    return "exact-list", terms

        # Some implementations keep selected labels as {label: true}.
        bool_terms = [
            str(key).strip()
            for key, enabled in value.items()
            if enabled is True and str(key).strip()
        ]
        if bool_terms:
            return "exact-list", bool_terms

        # Last-resort scalar value.
        for key in ("value", "label"):
            candidate = value.get(key)
            if candidate not in (None, ""):
                return _extract_filter_terms(candidate)

    return None, []


def _build_server_where(columns, filters):
    """Build a safe SQL WHERE clause from UI filters.

    Only actual columns returned by the configured VIEW are accepted, so a
    browser cannot inject identifiers. Values remain parameterized.
    """
    available = {str(column).lower(): str(column) for column in columns}
    clauses = []
    params = []

    if not isinstance(filters, dict):
        return "", params

    for requested_column, raw_filter in filters.items():
        actual = available.get(str(requested_column).lower())
        if not actual:
            continue

        mode, terms = _extract_filter_terms(raw_filter)
        if not mode or not terms:
            continue

        expression = f"CONVERT(NVARCHAR(4000), {_quote_identifier(actual)})"

        if mode == "exact-list":
            option_clauses = []
            for term in terms:
                if term == "(Blanks)":
                    option_clauses.append(
                        f"({_quote_identifier(actual)} IS NULL OR LTRIM(RTRIM({expression})) = '')"
                    )
                    continue

                option_clauses.append(f"LTRIM(RTRIM({expression})) = ?")
                params.append(term)

            if option_clauses:
                clauses.append("(" + " OR ".join(option_clauses) + ")")
            continue

        # Contains search, case-insensitive under the normal SQL Server
        # collation used by AuditX. Escape LIKE wildcards entered by the user.
        term = str(terms[0])
        escaped = term.replace("[", "[[]").replace("%", "[%]").replace("_", "[_]")
        clauses.append(f"{expression} LIKE ?")
        params.append(f"%{escaped}%")

    if not clauses:
        return "", params

    return " WHERE " + " AND ".join(clauses), params


def get_planning_data(
    entity,
    top=None,
    page=None,
    page_size=None,
    filters=None,
    sort_column=None,
    sort_direction=None,
    quick_filter_column=None,
    quick_filter_text=None,
):
    config = _get_entity(entity)

    if not config:
        return {
            "ok": False,
            "message": f"Planning entity not found: {entity}",
            "columns": [],
            "rows": [],
            "tableName": "",
            "sql": "",
        }

    view_name = config.get("view")

    if not view_name:
        return {
            "ok": False,
            "message": f"Planning view not configured: {entity}",
            "columns": [],
            "rows": [],
            "tableName": "",
            "sql": "",
        }

    server_side = bool(config.get("server_side_paging", False))

    # ========================================================
    # Server-side pagination for large Planning entities.
    # ========================================================
    if server_side:
        default_page_size = _coerce_positive_int(
            config.get("server_page_size", 25),
            25,
            minimum=1,
            maximum=500,
        )
        max_page_size = _coerce_positive_int(
            config.get("server_max_page_size", 500),
            500,
            minimum=1,
            maximum=5000,
        )
        resolved_page = _coerce_positive_int(page, 1, minimum=1)
        resolved_page_size = _coerce_positive_int(
            page_size,
            default_page_size,
            minimum=1,
            maximum=max_page_size,
        )

        conn = get_planning_connection()
        cursor = conn.cursor()

        try:
            # Read the real VIEW columns first. This is also the identifier
            # whitelist used for filters and sorting.
            cursor.execute(f"SELECT TOP 0 * FROM {_quote_table(view_name)}")
            columns = [col[0] for col in cursor.description]
            available = {str(column).lower(): str(column) for column in columns}

            effective_filters = dict(filters or {}) if isinstance(filters, dict) else {}
            if quick_filter_text not in (None, "") and quick_filter_column:
                effective_filters[str(quick_filter_column)] = str(quick_filter_text)

            where_sql, filter_params = _build_server_where(columns, effective_filters)

            default_sort_column = (
                config.get("server_default_sort_column")
                or config.get("view_key")
                or (columns[0] if columns else None)
            )
            requested_sort = available.get(str(sort_column or "").lower())
            actual_sort_column = requested_sort or available.get(str(default_sort_column or "").lower())
            if not actual_sort_column and columns:
                actual_sort_column = columns[0]

            default_direction = str(
                config.get("server_default_sort_direction") or "DESC"
            ).upper()
            direction = str(sort_direction or default_direction).upper()
            if direction not in {"ASC", "DESC"}:
                direction = "DESC"

            count_sql = (
                f"SELECT COUNT_BIG(1) FROM {_quote_table(view_name)}"
                f"{where_sql}"
            )
            cursor.execute(count_sql, filter_params)
            count_row = cursor.fetchone()
            total_rows = int(count_row[0] if count_row else 0)
            total_pages = max(1, (total_rows + resolved_page_size - 1) // resolved_page_size)
            resolved_page = min(resolved_page, total_pages)
            offset = (resolved_page - 1) * resolved_page_size

            order_sql = _quote_identifier(actual_sort_column)
            data_sql = (
                f"SELECT * FROM {_quote_table(view_name)}"
                f"{where_sql} "
                f"ORDER BY {order_sql} {direction} "
                f"OFFSET ? ROWS FETCH NEXT ? ROWS ONLY"
            )
            params = [*filter_params, offset, resolved_page_size]
            cursor.execute(data_sql, params)
            rows = cursor.fetchall()

            clean_rows = [
                [_format_value(value) for value in row]
                for row in rows
            ]

            return {
                "ok": True,
                "columns": columns,
                "rows": clean_rows,
                "tableName": view_name,
                "sql": data_sql,
                "server_side": True,
                "page": resolved_page,
                "page_size": resolved_page_size,
                "total_rows": total_rows,
                "total_pages": total_pages,
                "loaded_count": len(clean_rows),
                "sort_column": actual_sort_column,
                "sort_direction": direction.lower(),
            }

        except Exception as e:
            return {
                "ok": False,
                "message": str(e),
                "columns": [],
                "rows": [],
                "tableName": view_name,
                "sql": "",
                "server_side": True,
            }

        finally:
            cursor.close()
            conn.close()

    # ========================================================
    # Existing client-side behavior for smaller catalogs.
    # ========================================================
    configured_limit = config.get("preview_limit", 5000)
    try:
        configured_limit = int(configured_limit)
    except (TypeError, ValueError):
        configured_limit = 5000

    try:
        limit = int(top) if top not in (None, "") else configured_limit
    except (TypeError, ValueError):
        limit = configured_limit

    if limit <= 0:
        limit = configured_limit
    limit = min(limit, 50000)

    order_by = str(config.get("preview_order_by") or "").strip()
    sql = f"SELECT TOP {limit} * FROM {_quote_table(view_name)}"
    if order_by:
        sql += f" ORDER BY {order_by}"

    conn = get_planning_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(sql)

        columns = [col[0] for col in cursor.description]
        rows = cursor.fetchall()

        clean_rows = [
            [_format_value(value) for value in row]
            for row in rows
        ]

        return {
            "ok": True,
            "columns": columns,
            "rows": clean_rows,
            "tableName": view_name,
            "sql": sql,
            "loaded_count": len(clean_rows),
            "preview_limit": limit,
            "server_side": False,
        }

    except Exception as e:
        return {
            "ok": False,
            "message": str(e),
            "columns": [],
            "rows": [],
            "tableName": view_name,
            "sql": sql,
            "server_side": False,
        }

    finally:
        cursor.close()
        conn.close()


def get_planning_record(entity, key):
    """Fetch one record from the configured VIEW by its visible key."""
    config = _get_entity(entity)

    if not config:
        return {
            "ok": False,
            "message": f"Planning entity not found: {entity}",
            "columns": [],
            "row": None,
        }

    view_name = config.get("view")
    view_key = config.get("view_key", "Key")

    if not view_name or not view_key:
        return {
            "ok": False,
            "message": f"Planning view/key not configured: {entity}",
            "columns": [],
            "row": None,
        }

    sql = (
        f"SELECT TOP 1 * FROM {_quote_table(view_name)} "
        f"WHERE {_quote_identifier(view_key)} = ?"
    )

    conn = get_planning_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(sql, [key])
        columns = [col[0] for col in cursor.description]
        row = cursor.fetchone()

        if not row:
            return {
                "ok": True,
                "columns": columns,
                "row": None,
            }

        values = [_format_value(value) for value in row]

        # The legacy Planning VIEWs are optimized for display and sometimes
        # expose a label but not its underlying foreign key.  Update forms need
        # the actual stored keys (Audit Lead, Responsible, Ctx Code, Status, etc.)
        # to repopulate their dropdowns reliably.  Merge any missing base-table
        # columns into the record response while keeping the VIEW values intact.
        table_name = config.get("table")
        table_key = config.get("table_key")

        if table_name and table_key:
            try:
                cursor.execute(
                    f"SELECT TOP 1 * FROM {_quote_table(table_name)} "
                    f"WHERE {_quote_identifier(table_key)} = ?",
                    [key],
                )
                base_columns = [col[0] for col in cursor.description]
                base_row = cursor.fetchone()

                if base_row:
                    existing = {str(name).strip().lower() for name in columns}
                    for name, value in zip(base_columns, base_row):
                        normalized_name = str(name).strip().lower()
                        if normalized_name in existing:
                            continue
                        columns.append(name)
                        values.append(_format_value(value))
                        existing.add(normalized_name)
            except Exception:
                # The VIEW remains authoritative for display.  A base-table
                # enrichment failure must not prevent the Update modal opening.
                pass

        return {
            "ok": True,
            "columns": columns,
            "row": values,
        }

    except Exception as e:
        return {
            "ok": False,
            "message": str(e),
            "columns": [],
            "row": None,
        }

    finally:
        cursor.close()
        conn.close()

def get_planning_entity_config(entity):
    public = _public_entity_config(entity)

    if not public:
        return {
            "ok": False,
            "message": f"Planning entity not found: {entity}",
        }

    return {
        "ok": True,
        **public,
    }


def _candidate_list(value):
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return [str(x) for x in value if x]
    return [str(value)]


def _resolve_lookup_table(cursor, lookup):
    candidates = _candidate_list(
        lookup.get("table_candidates") or lookup.get("table")
    )

    last_error = None

    for table_name in candidates:
        try:
            cursor.execute(
                f"SELECT TOP 0 * FROM {_quote_table(table_name)}"
            )
            columns = [col[0] for col in cursor.description]
            return table_name, columns
        except Exception as e:
            last_error = e

    if last_error:
        raise last_error

    raise ValueError("Lookup table is not configured.")


def _resolve_lookup_column(columns, spec, required=True):
    candidates = _candidate_list(spec)
    by_lower = {str(col).lower(): col for col in columns}

    for candidate in candidates:
        actual = by_lower.get(candidate.lower())
        if actual:
            return actual

    if required:
        raise ValueError(
            "Lookup column not found. Tried: " + ", ".join(candidates)
        )

    return None


def get_planning_lookup(lookup_name, parent_value=None):
    """
    Resolve a Planning lookup safely.

    Important v8 behavior:
    - Tries EVERY configured table/view candidate.
    - A candidate is accepted only when its required value + label columns
      actually exist.
    - If a candidate exists but has the wrong schema, the next candidate is
      attempted instead of returning HTTP 400 immediately.
    - Optional DISTINCT support is useful when a VIEW is used as fallback.
    """
    lookup = PLANNING_LOOKUPS.get(lookup_name)

    if not lookup:
        return {
            "ok": False,
            "message": f"Planning lookup not found: {lookup_name}",
            "items": [],
        }

    # Static items are supported for future configs.
    if lookup.get("items") is not None:
        return {
            "ok": True,
            "lookup": lookup_name,
            "items": lookup.get("items") or [],
        }

    conn = get_planning_connection()
    cursor = conn.cursor()

    errors = []

    try:
        table_candidates = _candidate_list(
            lookup.get("table_candidates") or lookup.get("table")
        )

        if not table_candidates:
            return {
                "ok": False,
                "message": f"Lookup source not configured: {lookup_name}",
                "items": [],
            }

        for table_name in table_candidates:
            try:
                # 1) Confirm source exists and read its actual columns.
                cursor.execute(
                    f"SELECT TOP 0 * FROM {_quote_table(table_name)}"
                )
                columns = [col[0] for col in cursor.description]

                # 2) Required columns. If they do not exist, this source is
                #    not the right one; continue with the next candidate.
                value_name = _resolve_lookup_column(
                    columns, lookup.get("value_field")
                )
                label_name = _resolve_lookup_column(
                    columns, lookup.get("label_field")
                )

                # 3) Optional columns.
                extra_name = _resolve_lookup_column(
                    columns,
                    lookup.get("extra_field"),
                    required=False,
                )

                extra_fields = {}
                for extra_key, extra_spec in (lookup.get("extra_fields") or {}).items():
                    resolved = _resolve_lookup_column(
                        columns,
                        extra_spec,
                        required=False,
                    )
                    if resolved:
                        extra_fields[extra_key] = resolved

                # Some legacy lookup sources contain the key/code but omit the
                # descriptive columns needed by the form.  When configured, do
                # not accept such a partial source; continue to the next candidate.
                required_extra_fields = _candidate_list(
                    lookup.get("require_extra_fields")
                )
                missing_extra_fields = [
                    name for name in required_extra_fields
                    if name not in extra_fields
                ]
                if missing_extra_fields:
                    raise ValueError(
                        "Lookup source is missing required extra fields: "
                        + ", ".join(missing_extra_fields)
                    )

                filter_name = _resolve_lookup_column(
                    columns,
                    lookup.get("filter_column"),
                    required=False,
                )

                order_name = _resolve_lookup_column(
                    columns,
                    lookup.get("order_by"),
                    required=False,
                )

                # Build the SELECT list without duplicated physical columns.
                # This is important for lookups such as ERP where value_field
                # and label_field are both "Name".  Selecting [Name] twice and
                # then ORDER BY [Name] can raise SQL Server error 209
                # (Ambiguous column name).
                select_columns = []
                for name in [value_name, label_name]:
                    if name and name not in select_columns:
                        select_columns.append(name)

                if extra_name and extra_name not in select_columns:
                    select_columns.append(extra_name)

                for name in extra_fields.values():
                    if name not in select_columns:
                        select_columns.append(name)

                distinct = "DISTINCT " if lookup.get("distinct") else ""

                source_alias = "src"
                sql = (
                    f"SELECT {distinct}"
                    + ", ".join(
                        f"{source_alias}.{_quote_identifier(name)}"
                        for name in select_columns
                    )
                    + f" FROM {_quote_table(table_name)} AS {source_alias}"
                )

                conditions = []
                params = []

                where = lookup.get("where")
                if where:
                    conditions.append(f"({where})")

                if filter_name and parent_value not in (None, ""):
                    conditions.append(
                        f"{source_alias}.{_quote_identifier(filter_name)} = ?"
                    )
                    params.append(parent_value)

                if conditions:
                    sql += " WHERE " + " AND ".join(conditions)

                if order_name:
                    sql += (
                        f" ORDER BY {source_alias}.{_quote_identifier(order_name)}"
                    )

                # If this candidate has an incompatible WHERE or other
                # source-specific issue, try the next source instead.
                cursor.execute(sql, params)

                index_by_name = {
                    name: idx for idx, name in enumerate(select_columns)
                }

                items = []
                seen = set()

                for row in cursor.fetchall():
                    value = _format_value(row[index_by_name[value_name]])
                    label = _format_value(row[index_by_name[label_name]])

                    # Ignore unusable blank lookup rows.
                    if value in (None, ""):
                        continue

                    # Protect fallback VIEWs from duplicate options.
                    dedupe_key = (str(value), str(label))
                    if dedupe_key in seen:
                        continue
                    seen.add(dedupe_key)

                    extras = {
                        key: _format_value(row[index_by_name[name]])
                        for key, name in extra_fields.items()
                    }

                    items.append({
                        "value": value,
                        "label": label,
                        "extra": (
                            _format_value(row[index_by_name[extra_name]])
                            if extra_name
                            else ""
                        ),
                        "extras": extras,
                    })

                return {
                    "ok": True,
                    "lookup": lookup_name,
                    "table": table_name,
                    "items": items,
                }

            except Exception as candidate_error:
                errors.append(
                    f"{table_name}: {candidate_error}"
                )
                continue

        return {
            "ok": False,
            "message": (
                f"Unable to resolve lookup '{lookup_name}'. "
                + " | ".join(errors)
            ),
            "items": [],
        }

    except Exception as e:
        return {
            "ok": False,
            "message": str(e),
            "items": [],
        }

    finally:
        cursor.close()
        conn.close()


def _writable_fields(config):
    result = {}

    for field in config.get("fields", []):
        field_type = field.get("type", "text")
        column = field.get("column")
        view_field = field.get("view_field")

        if (
            not column
            or not view_field
            or field_type in ("readonly", "display")
        ):
            continue

        result[view_field] = column

    return result


def _parse_date(value, label):
    if value in (None, ""):
        return None

    if isinstance(value, datetime):
        return value.date()

    if isinstance(value, date):
        return value

    text = str(value).strip()

    formats = (
        "%Y-%m-%d",
        "%Y-%m-%dT%H:%M:%S",
        "%d-%b-%Y",
        "%m/%d/%Y",
    )

    for fmt in formats:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            pass

    raise ValueError(
        f"{label} must use DD-MMM-YYYY (example: 11-Sep-2026)."
    )


def _normalize_values(config, values, mode):
    values = values or {}
    normalized = {}
    date_values = {}

    for field in config.get("fields", []):
        view_field = field.get("view_field")
        column = field.get("column")
        field_type = field.get("type", "text")
        label = field.get("label") or view_field

        if not view_field or field_type in ("readonly", "display"):
            continue

        has_value = view_field in values
        value = values.get(view_field)

        # UI helper fields (for example Region on ERP) are still
        # validated, but are not included in SQL because column=None.
        if not has_value:
            if mode == "create" and field.get("required"):
                raise ValueError(f"{label} is required.")
            continue

        if isinstance(value, str):
            value = value.strip()

        blank = value is None or (isinstance(value, str) and value == "")

        if field.get("required") and blank:
            raise ValueError(f"{label} is required.")

        if blank:
            if column:
                normalized[view_field] = None
            continue

        if field_type == "date":
            value = _parse_date(value, label)
            date_values[view_field] = value

        elif field_type in ("number", "money"):
            try:
                if field_type == "money" and isinstance(value, str):
                    value = value.replace(",", "").strip()
                number = float(value)
            except (TypeError, ValueError):
                raise ValueError(f"{label} must be numeric.")

            min_value = field.get("min")
            max_value = field.get("max")

            if min_value is not None and number < float(min_value):
                raise ValueError(f"{label} must be at least {min_value}.")

            if max_value is not None and number > float(max_value):
                raise ValueError(f"{label} must be at most {max_value}.")

            value = int(number) if number.is_integer() else number

        elif field_type == "lookup":
            # Keep numeric keys numeric whenever possible; ERP Name is
            # intentionally textual and remains a string.
            try:
                numeric = int(value)
                value = numeric
            except (TypeError, ValueError):
                pass

        elif field_type == "choice":
            allowed = [str(x.get("value", "")) for x in field.get("choices", [])]
            text_value = str(value)
            if allowed and text_value not in allowed:
                raise ValueError(f"{label} contains an invalid option.")
            value = text_value or None

        elif isinstance(value, str):
            transform = field.get("transform")

            if transform == "uppercase":
                value = value.upper()
            elif transform == "lowercase":
                value = value.lower()

            min_length = field.get("min_length")
            max_length = field.get("max_length")

            if min_length is not None and len(value) < int(min_length):
                raise ValueError(
                    f"{label} must contain at least {min_length} characters."
                )

            if max_length is not None and len(value) > int(max_length):
                raise ValueError(
                    f"{label} cannot exceed {max_length} characters."
                )

            pattern = field.get("pattern")
            if pattern and not re.fullmatch(pattern, value):
                raise ValueError(
                    field.get("pattern_message")
                    or f"{label} has an invalid format."
                )

        if column:
            normalized[view_field] = value

    # Relationship rules, mainly dates.
    for field in config.get("fields", []):
        view_field = field.get("view_field")
        if view_field not in date_values:
            continue

        current = date_values[view_field]
        label = field.get("label") or view_field

        after_field = field.get("after_or_equal")
        if after_field:
            other = date_values.get(after_field)
            if other and current < other:
                raise ValueError(
                    f"{label} cannot be earlier than {after_field}."
                )

        before_field = field.get("before_or_equal")
        if before_field:
            other = date_values.get(before_field)
            if other and current > other:
                raise ValueError(
                    f"{label} cannot be later than {before_field}."
                )

    return normalized


def update_planning_record(entity, key, values, changed_by):
    config = _get_entity(entity)

    if not config:
        return {
            "ok": False,
            "message": f"Update not configured for: {entity}",
        }

    if not config.get("allow_update"):
        return {
            "ok": False,
            "message": f"Update is disabled for: {entity}",
        }

    table_name = config.get("table")
    table_key = config.get("table_key")

    if not table_name or not table_key:
        return {
            "ok": False,
            "message": f"Update table/key not configured for: {entity}",
        }

    try:
        values = _normalize_values(config, values, "update")
    except ValueError as e:
        return {"ok": False, "message": str(e)}

    allowed_fields = _writable_fields(config)

    sets = []
    params = []

    for view_field, value in values.items():
        table_field = allowed_fields.get(view_field)

        if not table_field:
            continue

        sets.append(
            f"{_quote_identifier(table_field)} = ?"
        )
        params.append(value)

    if not sets:
        return {
            "ok": False,
            "message": "No editable fields were provided.",
        }

    audit = config.get("audit", {})

    changed_on = audit.get("changed_on")
    changed_by_col = audit.get("changed_by")

    if changed_on:
        sets.append(
            f"{_quote_identifier(changed_on)} = GETDATE()"
        )

    if changed_by_col:
        sets.append(
            f"{_quote_identifier(changed_by_col)} = ?"
        )
        params.append(changed_by)

    params.append(key)

    sql = f"""
        UPDATE {_quote_table(table_name)}
        SET {", ".join(sets)}
        WHERE {_quote_identifier(table_key)} = ?
    """

    conn = get_planning_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(sql, params)

        if cursor.rowcount == 0:
            conn.rollback()
            return {
                "ok": False,
                "message": f"Record not found. Key: {key}",
            }

        conn.commit()

        return {
            "ok": True,
            "message": f"{config.get('title', entity)} updated successfully.",
            "key": key,
            "changed_by": changed_by,
        }

    except Exception as e:
        conn.rollback()

        return {
            "ok": False,
            "message": str(e),
        }

    finally:
        cursor.close()
        conn.close()


def create_planning_record(entity, values, added_by):
    config = _get_entity(entity)

    if not config:
        return {
            "ok": False,
            "message": f"Create not configured for: {entity}",
        }

    if not config.get("allow_create"):
        return {
            "ok": False,
            "message": f"Create is disabled for: {entity}",
        }

    table_name = config.get("table")
    table_key = config.get("table_key")

    if not table_name:
        return {
            "ok": False,
            "message": f"Create table not configured for: {entity}",
        }

    try:
        values = _normalize_values(config, values, "create")
    except ValueError as e:
        return {"ok": False, "message": str(e)}

    allowed_fields = _writable_fields(config)

    columns = []
    value_sql = []
    params = []

    for view_field, value in values.items():
        table_field = allowed_fields.get(view_field)

        if not table_field:
            continue

        columns.append(_quote_identifier(table_field))
        value_sql.append("?")
        params.append(value)

    for column, value in config.get("create_defaults", {}).items():
        columns.append(_quote_identifier(column))
        value_sql.append("?")
        params.append(value)

    audit = config.get("audit", {})

    added_on = audit.get("added_on")
    added_by_col = audit.get("added_by")

    if added_on:
        columns.append(_quote_identifier(added_on))
        value_sql.append("GETDATE()")

    if added_by_col:
        columns.append(_quote_identifier(added_by_col))
        value_sql.append("?")
        params.append(added_by)

    if not columns:
        return {
            "ok": False,
            "message": "No fields were provided for the new record.",
        }

    insert_sql = f"""
        INSERT INTO {_quote_table(table_name)}
        (
            {", ".join(columns)}
        )
        VALUES
        (
            {", ".join(value_sql)}
        )
    """

    identity_key = bool(config.get("identity_key", True))

    if identity_key and table_key:
        sql = (
            "SET NOCOUNT ON;\n"
            + insert_sql
            + ";\nSELECT CAST(SCOPE_IDENTITY() AS INT) AS new_key;"
        )
    else:
        sql = insert_sql

    conn = get_planning_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(sql, params)

        new_key = None

        if identity_key and table_key:
            while cursor.description is None:
                if not cursor.nextset():
                    break

            if cursor.description is not None:
                row = cursor.fetchone()
                if row:
                    new_key = row[0]

        conn.commit()

        return {
            "ok": True,
            "message": f"{config.get('title', entity)} created successfully.",
            "key": new_key,
            "added_by": added_by,
        }

    except Exception as e:
        conn.rollback()

        return {
            "ok": False,
            "message": str(e),
        }

    finally:
        cursor.close()
        conn.close()


def delete_planning_record(entity, key, changed_by):
    """Soft-delete a Planning record by setting its configured flag."""
    config = _get_entity(entity)

    if not config or not config.get("allow_delete"):
        return {
            "ok": False,
            "message": f"Delete is disabled for: {entity}",
        }

    table_name = config.get("table")
    table_key = config.get("table_key")
    delete_column = config.get("delete_column", "flag")
    delete_value = config.get("delete_value", 1)

    if not table_name or not table_key or not delete_column:
        return {
            "ok": False,
            "message": f"Delete is not configured for: {entity}",
        }

    sets = [f"{_quote_identifier(delete_column)} = ?"]
    params = [delete_value]

    audit = config.get("audit", {})
    changed_on = audit.get("changed_on")
    changed_by_col = audit.get("changed_by")

    if changed_on:
        sets.append(f"{_quote_identifier(changed_on)} = GETDATE()")

    if changed_by_col:
        sets.append(f"{_quote_identifier(changed_by_col)} = ?")
        params.append(changed_by)

    params.append(key)

    sql = f"""
        UPDATE {_quote_table(table_name)}
        SET {", ".join(sets)}
        WHERE {_quote_identifier(table_key)} = ?
    """

    conn = get_planning_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(sql, params)

        if cursor.rowcount == 0:
            conn.rollback()
            return {"ok": False, "message": f"Record not found. Key: {key}"}

        conn.commit()

        return {
            "ok": True,
            "message": f"{config.get('title', entity)} deleted successfully.",
            "key": key,
            "changed_by": changed_by,
        }

    except Exception as e:
        conn.rollback()
        return {"ok": False, "message": str(e)}

    finally:
        cursor.close()
        conn.close()

# ============================================================
# v12 - Stored-procedure persistence layer
# ============================================================
from config.planning_entities import PLANNING_SP_CONTRACTS, PLANNING_MESSAGES


def _sp_contract(entity):
    return PLANNING_SP_CONTRACTS.get(entity)


def _sp_parameters(cursor, procedure_name):
    """Return actual SQL Server parameter names in declaration order."""
    cursor.execute(
        """
        SELECT p.name
        FROM sys.parameters AS p
        WHERE p.object_id = OBJECT_ID(?)
        ORDER BY p.parameter_id
        """,
        [procedure_name],
    )
    return [str(row[0]).lstrip("@") for row in cursor.fetchall()]


def _norm_param(name):
    return re.sub(r"[^a-z0-9]", "", str(name).lower())


def _sp_value_map(contract, values, key, status):
    result = {}
    mapping = contract.get("param_map", {})
    for param_name, source in mapping.items():
        if source == "__key__":
            value = key
        elif source == "__status__":
            value = status
        else:
            value = values.get(source)
        result[_norm_param(param_name)] = value
    return result


def _execute_configured_sp(entity, values, key, status):
    contract = _sp_contract(entity)
    if not contract:
        raise ValueError(f"Stored procedure is not configured for {entity}.")

    procedure_name = contract["name"]
    conn = get_planning_connection()
    cursor = conn.cursor()
    try:
        actual_params = _sp_parameters(cursor, procedure_name)
        if not actual_params:
            raise ValueError(f"Stored procedure not found: {procedure_name}")

        value_map = _sp_value_map(contract, values, key, status)
        sql_parts = []
        params = []

        for actual in actual_params:
            sql_parts.append(f"@{actual}=?")
            params.append(value_map.get(_norm_param(actual)))

        sql = f"EXEC {procedure_name} " + ", ".join(sql_parts)
        cursor.execute(sql, params)

        # Consume result sets so pyodbc can commit cleanly even when an SP
        # internally emits row counts/resultsets.
        try:
            while cursor.nextset():
                pass
        except Exception:
            pass

        conn.commit()
        return True
    except Exception:
        conn.rollback()
        raise
    finally:
        cursor.close()
        conn.close()


def _latest_key(entity):
    config = _get_entity(entity)
    if not config:
        return None
    table = config.get("table")
    key_col = config.get("table_key")
    if not table or not key_col:
        return None

    conn = get_planning_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            f"SELECT MAX({_quote_identifier(key_col)}) FROM {_quote_table(table)}"
        )
        row = cursor.fetchone()
        return row[0] if row else None
    finally:
        cursor.close()
        conn.close()


def _message(entity, action):
    return (
        PLANNING_MESSAGES.get(entity, {}).get(action)
        or f"{_get_entity(entity).get('title', entity)} {action} completed successfully."
    )


def _user_domain_exists(value, exclude_key=None):
    if value in (None, ""):
        return False
    conn = get_planning_connection()
    cursor = conn.cursor()
    try:
        sql = "SELECT TOP 1 user_key FROM dbo.[user] WHERE [user] = ? AND ISNULL(flag,0)=0"
        params = [value]
        if exclude_key not in (None, ""):
            sql += " AND user_key <> ?"
            params.append(exclude_key)
        cursor.execute(sql, params)
        return cursor.fetchone() is not None
    finally:
        cursor.close()
        conn.close()


def get_planning_entity_config(entity):
    public = _public_entity_config(entity)
    if not public:
        return {"ok": False, "message": f"Planning entity not found: {entity}"}
    public["allow_duplicate"] = bool(_get_entity(entity).get("allow_duplicate", False))
    public["section"] = _get_entity(entity).get("section")
    return {"ok": True, **public}


def create_planning_record(entity, values, added_by):
    config = _get_entity(entity)
    if not config or not config.get("allow_create"):
        return {"ok": False, "message": f"Create is disabled for: {entity}"}

    try:
        values = _normalize_values(config, values, "create")
    except ValueError as exc:
        return {"ok": False, "message": str(exc)}

    if entity == "users" and _user_domain_exists(values.get("User Domain")):
        return {
            "ok": False,
            "message": "The user already exists in the database. Please validate the data.",
        }

    contract = _sp_contract(entity)
    if not contract:
        return {"ok": False, "message": f"Stored procedure is not configured for: {entity}"}

    try:
        _execute_configured_sp(entity, values, key=0, status=0)
        new_key = _latest_key(entity)
        result = {
            "ok": True,
            "message": _message(entity, "create"),
            "key": new_key,
            "added_by": added_by,
        }

        if entity == "audit-project-planning" and new_key:
            try:
                from services.planning_outlook import notify_audit_project_planning
                mail_result = notify_audit_project_planning("create", new_key, values)
                result["outlook"] = mail_result
                if not mail_result.get("ok") and mail_result.get("warning"):
                    result["warning"] = mail_result["warning"]
            except Exception as exc:
                result["warning"] = f"Planning was saved, but Outlook notification could not be prepared: {exc}"

        return result
    except Exception as exc:
        return {"ok": False, "message": str(exc)}


def update_planning_record(entity, key, values, changed_by):
    config = _get_entity(entity)
    if not config or not config.get("allow_update"):
        return {"ok": False, "message": f"Update is disabled for: {entity}"}

    try:
        values = _normalize_values(config, values, "update")
    except ValueError as exc:
        return {"ok": False, "message": str(exc)}

    if entity == "users" and _user_domain_exists(values.get("User Domain"), exclude_key=key):
        return {
            "ok": False,
            "message": "The user already exists in the database. Please validate the data.",
        }

    try:
        _execute_configured_sp(entity, values, key=key, status=0)
        return {
            "ok": True,
            "message": _message(entity, "update"),
            "key": key,
            "changed_by": changed_by,
        }
    except Exception as exc:
        return {"ok": False, "message": str(exc)}


def delete_planning_record(entity, key, changed_by):
    config = _get_entity(entity)
    if not config or not config.get("allow_delete"):
        return {"ok": False, "message": f"Delete is disabled for: {entity}"}

    try:
        # Legacy procedures use any non-zero status (Access used -1) to perform
        # their cascade/soft-delete logic.  Other parameters can be NULL because
        # they are not read in that branch.
        _execute_configured_sp(entity, {}, key=key, status=-1)
        result = {
            "ok": True,
            "message": _message(entity, "delete"),
            "key": key,
            "changed_by": changed_by,
        }

        if entity == "audit-project-planning":
            try:
                from services.planning_outlook import notify_audit_project_planning
                mail_result = notify_audit_project_planning("delete", key, {})
                if not mail_result.get("ok") and mail_result.get("warning"):
                    result["warning"] = mail_result["warning"]
            except Exception as exc:
                result["warning"] = f"Planning was removed, but Outlook notification could not be prepared: {exc}"

        return result
    except Exception as exc:
        return {"ok": False, "message": str(exc)}


# ============================================================
# Audit Project Planning - improved duplicate workflow
# ============================================================

def get_duplicate_projects(client_key):
    """Return active projects plus the latest Planning assignment for each one.

    Audit Lead and Responsible are pre-populated in the duplicate workspace from
    the latest active Planning row for that project. The user can still change
    either value before submitting the batch.
    """
    conn = get_planning_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            """
            SELECT
                AP.audit_project_key,
                AP.audit_project_name,
                P.audit_lead_key,
                P.responsible_key
            FROM dbo.audit_project AS AP
            OUTER APPLY (
                SELECT TOP 1
                    APP.audit_lead_key,
                    APP.responsible_key
                FROM dbo.audit_project_planning AS APP
                WHERE APP.audit_project_key = AP.audit_project_key
                  AND ISNULL(APP.flag, 0) = 0
                ORDER BY APP.audit_project_planning_key DESC
            ) AS P
            WHERE AP.client_key = ?
              AND ISNULL(AP.flag,0)=0
            ORDER BY AP.audit_project_name
            """,
            [client_key],
        )
        return {
            "ok": True,
            "items": [
                {
                    "value": row[0],
                    "label": row[1],
                    "audit_lead_key": row[2],
                    "responsible_key": row[3],
                }
                for row in cursor.fetchall()
            ],
        }
    except Exception as exc:
        return {"ok": False, "message": str(exc), "items": []}
    finally:
        cursor.close()
        conn.close()



def _normalized_system_user(cursor):
    """Return the same SQL login text normalization used by the legacy SPs."""
    cursor.execute(
        """
        SELECT REPLACE(REPLACE(REPLACE(SYSTEM_USER, 'apac\\', ''), 'amer\\', ''), 'emea\\', '')
        """
    )
    row = cursor.fetchone()
    return (row[0] if row else "") or ""


def _object_columns(cursor, object_name):
    cursor.execute(
        """
        SELECT c.name
        FROM sys.columns AS c
        WHERE c.object_id = OBJECT_ID(?)
        ORDER BY c.column_id
        """,
        [object_name],
    )
    return [str(row[0]) for row in cursor.fetchall()]


def _object_exists(cursor, object_name, object_type=None):
    sql = "SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(?)"
    params = [object_name]
    if object_type:
        sql += " AND type = ?"
        params.append(object_type)
    cursor.execute(sql, params)
    return cursor.fetchone() is not None


def _legacy_duplicate_batch(rows, changed_by):
    """Run the exact legacy batch SP using dbo.VW_AuditProjectPlanning_Temp.

    The supplied Access/SQL code confirms this flow:
      1) stage selected projects in VW_AuditProjectPlanning_Temp
      2) EXEC dbo.SP_Add_Duplicates_AuditProjectPlanning
      3) duplicates are written to dbo.error_audit_project_planning
      4) successful rows remain inserted even if other rows fail

    An application lock is used so two AuditX users cannot mix rows in the
    legacy global staging view.  The lock is session-scoped and releases when
    this connection closes.
    """
    config = _get_entity("audit-project-planning")
    prepared = []

    for raw in rows or []:
        payload = dict(raw)
        payload["Status"] = 1
        values = _normalize_values(config, payload, "create")
        project_key = int(raw.get("audit_project_key") or values.get("audit_project_key") or 0)
        project_name = str(raw.get("audit_project_name") or raw.get("Audit Project") or project_key)
        prepared.append({
            "audit_project_key": project_key,
            "audit_project_name": project_name,
            "audit_lead_key": values.get("audit_lead_key"),
            "responsible_key": values.get("responsible_key"),
            "audit_scope": values.get("Audit Scope"),
            "planned_start_audit_date": values.get("Start Date"),
            "planned_end_audit_date": values.get("End Date"),
            "yearly_budget_value_local_currency": values.get("Budget"),
            "yearly_budget_value_usd": values.get("Budget USD"),
            "as_comment": values.get("Comment"),
            "download_information": values.get("Download"),
            "capture_information": values.get("Capture"),
            "development_tool": values.get("Development"),
            # The legacy duplicate SP always inserts app_status_key = 1.
            "app_status_key": 1,
        })

    conn = get_planning_connection()
    cursor = conn.cursor()
    batch_started = None

    try:
        if not _object_exists(cursor, "dbo.SP_Add_Duplicates_AuditProjectPlanning", "P"):
            raise RuntimeError("Stored procedure not found: dbo.SP_Add_Duplicates_AuditProjectPlanning")
        if not _object_exists(cursor, "dbo.VW_AuditProjectPlanning_Temp"):
            raise RuntimeError("Staging object not found: dbo.VW_AuditProjectPlanning_Temp")

        # Legacy staging is global. Serialize batches to prevent cross-user mix.
        cursor.execute(
            """
            DECLARE @r INT;
            EXEC @r = sys.sp_getapplock
                @Resource = 'AuditX.Planning.AuditProjectPlanning.Duplicate',
                @LockMode = 'Exclusive',
                @LockOwner = 'Session',
                @LockTimeout = 15000;
            SELECT @r;
            """
        )
        lock_row = cursor.fetchone()
        if not lock_row or int(lock_row[0]) < 0:
            raise RuntimeError("Another duplicate batch is running. Please try again in a few seconds.")

        db_user = _normalized_system_user(cursor)
        cursor.execute("SELECT GETDATE()")
        batch_started = cursor.fetchone()[0]

        # Clean only legacy errors belonging to this SQL login and submitted projects.
        project_keys = sorted({x["audit_project_key"] for x in prepared if x["audit_project_key"]})
        if project_keys and _object_exists(cursor, "dbo.error_audit_project_planning", "U"):
            placeholders = ",".join("?" for _ in project_keys)
            cursor.execute(
                f"""
                DELETE FROM dbo.error_audit_project_planning
                WHERE added_by = ? AND audit_project_key IN ({placeholders})
                """,
                [db_user, *project_keys],
            )

        # Match the Access workflow: clear the legacy shared staging view first.
        cursor.execute("DELETE FROM dbo.VW_AuditProjectPlanning_Temp")

        available = {c.lower(): c for c in _object_columns(cursor, "dbo.VW_AuditProjectPlanning_Temp")}
        if not available:
            raise RuntimeError("Unable to inspect dbo.VW_AuditProjectPlanning_Temp columns.")

        logical_order = [
            "audit_project_key",
            "audit_project_name",
            "audit_lead_key",
            "responsible_key",
            "audit_scope",
            "planned_start_audit_date",
            "planned_end_audit_date",
            "yearly_budget_value_local_currency",
            "yearly_budget_value_usd",
            "as_comment",
            "download_information",
            "capture_information",
            "development_tool",
            "app_status_key",
            "added_on",
            "added_by",
        ]
        insert_columns = [available[name] for name in logical_order if name in available]

        required_for_sp = {
            "audit_project_key",
            "audit_lead_key",
            "responsible_key",
            "audit_scope",
            "planned_start_audit_date",
            "planned_end_audit_date",
            "yearly_budget_value_local_currency",
            "yearly_budget_value_usd",
            "as_comment",
            "added_on",
            "added_by",
        }
        missing = sorted(required_for_sp - set(available))
        if missing:
            raise RuntimeError(
                "Legacy duplicate staging view is missing required columns: " + ", ".join(missing)
            )

        placeholders = ", ".join("?" for _ in insert_columns)
        column_sql = ", ".join(_quote_identifier(c) for c in insert_columns)
        insert_sql = (
            f"INSERT INTO dbo.VW_AuditProjectPlanning_Temp ({column_sql}) "
            f"VALUES ({placeholders})"
        )

        for item in prepared:
            row_values = []
            for actual_col in insert_columns:
                key = actual_col.lower()
                if key == "added_on":
                    row_values.append(batch_started)
                elif key == "added_by":
                    row_values.append(changed_by)
                else:
                    row_values.append(item.get(key))
            cursor.execute(insert_sql, row_values)

        # Execute the exact legacy batch procedure supplied by the user.
        cursor.execute("EXEC dbo.SP_Add_Duplicates_AuditProjectPlanning")
        try:
            while cursor.nextset():
                pass
        except Exception:
            pass

        # The legacy SP writes rejected duplicates here and allows the rest to succeed.
        error_rows = []
        if project_keys and _object_exists(cursor, "dbo.error_audit_project_planning", "U"):
            placeholders = ",".join("?" for _ in project_keys)
            cursor.execute(
                f"""
                SELECT audit_project_key, audit_project_name, audit_scope, added_on, added_by
                FROM dbo.error_audit_project_planning
                WHERE audit_project_key IN ({placeholders})
                  AND added_on >= ?
                ORDER BY added_on, audit_project_key
                """,
                [*project_keys, batch_started],
            )
            error_rows = cursor.fetchall()

        conn.commit()

        failed_pairs = set()
        failed_details = []
        for row in error_rows:
            pair = (int(row[0]), str(row[2] or "").strip())
            failed_pairs.add(pair)
            failed_details.append({
                "ok": False,
                "audit_project_key": row[0],
                "audit_project_name": row[1] or str(row[0]),
                "audit_scope": row[2] or "",
                "message": "This Audit Project already exists for the selected Audit Scope.",
            })

        results = []
        success_count = 0
        failed_count = 0
        failed_keys = {int(x["audit_project_key"]) for x in failed_details}

        for item in prepared:
            scope = str(item.get("audit_scope") or "").strip()
            is_failed = (
                (item["audit_project_key"], scope) in failed_pairs
                or item["audit_project_key"] in failed_keys
            )
            if is_failed:
                failed_count += 1
                match = next(
                    (x for x in failed_details if int(x["audit_project_key"]) == item["audit_project_key"]),
                    None,
                )
                results.append(match or {
                    "ok": False,
                    "audit_project_key": item["audit_project_key"],
                    "audit_project_name": item["audit_project_name"],
                    "audit_scope": scope,
                    "message": "The project could not be duplicated.",
                })
            else:
                success_count += 1
                created = {
                    "ok": True,
                    "audit_project_key": item["audit_project_key"],
                    "audit_project_name": item["audit_project_name"],
                    "audit_scope": scope,
                    "message": "Created successfully.",
                }

                # Resolve the key created by the batch SP so Outlook can use
                # the same notification service as normal Planning creates.
                try:
                    cursor.execute(
                        """
                        SELECT TOP 1 audit_project_planning_key
                        FROM dbo.audit_project_planning
                        WHERE audit_project_key = ?
                          AND added_on >= ?
                          AND ISNULL(flag,0) = 0
                        ORDER BY audit_project_planning_key DESC
                        """,
                        [item["audit_project_key"], batch_started],
                    )
                    key_row = cursor.fetchone()
                    if key_row:
                        created["key"] = key_row[0]
                except Exception:
                    pass

                results.append(created)

        # Best-effort Outlook notifications. Mail failures never undo SQL work.
        for result_item in results:
            if not result_item.get("ok") or not result_item.get("key"):
                continue
            try:
                source = next(
                    (x for x in prepared if x["audit_project_key"] == result_item["audit_project_key"]),
                    {},
                )
                from services.planning_outlook import notify_audit_project_planning
                mail = notify_audit_project_planning(
                    "duplicate",
                    result_item["key"],
                    {
                        "audit_lead_key": source.get("audit_lead_key"),
                        "responsible_key": source.get("responsible_key"),
                        "Audit Project": source.get("audit_project_name"),
                        "Audit Scope": source.get("audit_scope"),
                        "Start Date": source.get("planned_start_audit_date"),
                        "End Date": source.get("planned_end_audit_date"),
                        "Budget": source.get("yearly_budget_value_local_currency"),
                        "Budget USD": source.get("yearly_budget_value_usd"),
                        "Comment": source.get("as_comment"),
                        "Status": 1,
                    },
                )
                result_item["outlook"] = mail
                if not mail.get("ok") and mail.get("warning"):
                    result_item["warning"] = mail["warning"]
            except Exception as mail_exc:
                result_item["warning"] = f"Project was created, but Outlook notification failed: {mail_exc}"

        mail_results = [x.get("outlook") for x in results if x.get("outlook")]
        outlook_summary = {
            "created": len(mail_results),
            "sent": sum(1 for x in mail_results if x.get("sent")),
            "draft": sum(1 for x in mail_results if x.get("draft")),
            "failed": sum(1 for x in mail_results if not x.get("ok")),
            "modes": sorted({str(x.get("email_mode") or "") for x in mail_results if x.get("email_mode")}),
            "warnings": [str(x.get("warning")) for x in mail_results if x.get("warning")],
        }

        return {
            "ok": True,
            "message": "Duplication completed.",
            "engine": "dbo.SP_Add_Duplicates_AuditProjectPlanning",
            "success_count": success_count,
            "failed_count": failed_count,
            "results": results,
            "outlook_summary": outlook_summary,
            "changed_by": changed_by,
        }

    except Exception:
        conn.rollback()
        raise
    finally:
        try:
            # Keep the global legacy staging area clean even when an error occurs.
            cursor.execute("DELETE FROM dbo.VW_AuditProjectPlanning_Temp")
            conn.commit()
        except Exception:
            pass
        cursor.close()
        conn.close()


def _duplicate_fallback_per_row(rows, changed_by):
    """Compatibility fallback when the legacy global staging view is unavailable.

    The SQL insert is kept row-by-row, but successful rows still resolve their
    generated key and run the exact same Outlook notification as the batch path.
    """
    results = []
    success_count = 0
    failed_count = 0
    config = _get_entity("audit-project-planning")

    for raw in rows or []:
        project_key = raw.get("audit_project_key")
        project_name = raw.get("audit_project_name") or raw.get("Audit Project") or str(project_key or "")
        try:
            payload = dict(raw)
            payload["Status"] = 1
            values = _normalize_values(config, payload, "create")
            values["Status"] = 1
            _execute_configured_sp("audit-project-planning", values, key=0, status=0)
            new_key = _latest_key("audit-project-planning")

            item = {
                "ok": True,
                "key": new_key,
                "audit_project_key": project_key,
                "audit_project_name": project_name,
                "audit_scope": raw.get("Audit Scope") or "",
                "message": "Created successfully.",
            }

            if new_key:
                try:
                    from services.planning_outlook import notify_audit_project_planning
                    mail = notify_audit_project_planning(
                        "duplicate",
                        new_key,
                        {
                            **values,
                            "Audit Project": project_name,
                            "audit_lead_key": values.get("audit_lead_key"),
                            "responsible_key": values.get("responsible_key"),
                        },
                    )
                    item["outlook"] = mail
                    if not mail.get("ok") and mail.get("warning"):
                        item["warning"] = mail["warning"]
                except Exception as mail_exc:
                    item["warning"] = f"Project was created, but Outlook notification failed: {mail_exc}"

            success_count += 1
            results.append(item)
        except Exception as exc:
            failed_count += 1
            results.append({
                "ok": False,
                "audit_project_key": project_key,
                "audit_project_name": project_name,
                "audit_scope": raw.get("Audit Scope") or raw.get("audit_scope") or "",
                "message": str(exc),
            })

    mail_results = [x.get("outlook") for x in results if x.get("outlook")]
    outlook_summary = {
        "created": len(mail_results),
        "sent": sum(1 for x in mail_results if x.get("sent")),
        "draft": sum(1 for x in mail_results if x.get("draft")),
        "failed": sum(1 for x in mail_results if not x.get("ok")),
        "modes": sorted({str(x.get("email_mode") or "") for x in mail_results if x.get("email_mode")}),
        "warnings": [str(x.get("warning")) for x in mail_results if x.get("warning")],
    }

    return {
        "ok": True,
        "message": "Duplication completed using compatibility mode.",
        "engine": "row-by-row fallback",
        "success_count": success_count,
        "failed_count": failed_count,
        "results": results,
        "outlook_summary": outlook_summary,
        "changed_by": changed_by,
    }



def duplicate_audit_project_planning(rows, changed_by):
    """Duplicate a batch using the actual legacy batch SP when available.

    Partial success is intentional: existing project/scope combinations are
    reported as failures while valid rows stay inserted, exactly as the supplied
    dbo.SP_Add_Duplicates_AuditProjectPlanning does.
    """
    try:
        return _legacy_duplicate_batch(rows, changed_by)
    except Exception as legacy_exc:
        fallback = _duplicate_fallback_per_row(rows, changed_by)
        fallback["warning"] = (
            "Legacy batch procedure could not be used, so AuditX switched to "
            f"compatibility mode. Details: {legacy_exc}"
        )
        return fallback

# Final delete override: capture Planning details BEFORE the SP flags the row,
# so the Outlook notification still has Client / Project / Scope context.
def delete_planning_record(entity, key, changed_by):
    config = _get_entity(entity)
    if not config or not config.get("allow_delete"):
        return {"ok": False, "message": f"Delete is disabled for: {entity}"}

    before = None
    if entity == "audit-project-planning":
        try:
            before_result = get_planning_record(entity, key)
            if before_result.get("ok") and before_result.get("row"):
                before = dict(zip(before_result.get("columns") or [], before_result["row"]))
        except Exception:
            before = None

    try:
        _execute_configured_sp(entity, {}, key=key, status=-1)
        result = {
            "ok": True,
            "message": _message(entity, "delete"),
            "key": key,
            "changed_by": changed_by,
        }

        if entity == "audit-project-planning":
            try:
                from services.planning_outlook import notify_audit_project_planning
                mail_values = before or {}
                mail_result = notify_audit_project_planning("delete", key, mail_values)
                result["outlook"] = mail_result
                if not mail_result.get("ok") and mail_result.get("warning"):
                    result["warning"] = mail_result["warning"]
            except Exception as exc:
                result["warning"] = f"Planning was removed, but Outlook notification could not be prepared: {exc}"

        return result
    except Exception as exc:
        return {"ok": False, "message": str(exc)}
