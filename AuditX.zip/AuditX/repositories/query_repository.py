"""
    Módulo: connection
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:        
            Gestiona la ejecución de consultas sobre las listas de datos del cliente, incluyendo la obtención de columnas, construcción de
            filtros dinámicos y consulta de registros para la visualización de información.

            get_table_columns() → obtiene la estructura de columnas de una tabla.
            run_dynamic_query() → ejecuta consultas dinámicas sobre la tabla configurada.
            build_where() → genera condiciones SQL según los filtros enviados por el usuario.
            format_value() → normaliza los valores retornados para su consumo en la aplicación.

"""

from database.connection import get_dynamic_connection
from config.session import get_current_client_db
from repositories.data_list_repository import get_data_list_by_id
 
def get_table_columns(data_list_id: int):

    server, database = get_current_client_db() 
    data_list = get_data_list_by_id(data_list_id)
 
    if not data_list:
        raise Exception("DataList not found")
 
    server = data_list.get("server") or data_list.get("SQL_Server")
    database = data_list.get("database") or data_list.get("SQL_Database")
    table_name = (
        data_list.get("tableName")
        or data_list.get("SQL_TableName")
        or data_list.get("LinkedTableName")
    )
 
    if not server or not database or not table_name:
        raise Exception("DataList metadata incomplete")
 
    conn = get_dynamic_connection(server, database)
    cursor = conn.cursor()
 
    try:
        query = """
            SELECT COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = ?
            ORDER BY ORDINAL_POSITION
        """
 
        cursor.execute(query, (table_name,))
        rows = cursor.fetchall()
 
        return [row.COLUMN_NAME for row in rows]
 
    finally:
        conn.close()
 
 
def run_dynamic_query(data_list_id: int, filters=None, top=None):
    filters = filters or []
 
    data_list = get_data_list_by_id(data_list_id)
 
    if not data_list:
        raise Exception("DataList not found")
 
    server = data_list.get("server") or data_list.get("SQL_Server")
    database = data_list.get("database") or data_list.get("SQL_Database")
 
    table_name = (
        data_list.get("tableName")
        or data_list.get("SQL_TableName")
        or data_list.get("LinkedTableName")
    )
 
    if not server or not database or not table_name:
        raise Exception("DataList metadata incomplete")
 
    if top is None or str(top).strip() == "":
        sql = f"SELECT * FROM [{table_name}]"
    else:
        sql = f"SELECT TOP {int(top)} * FROM [{table_name}]"
 
    where_sql, params = build_where(filters)
 
    if where_sql:
        sql += f" WHERE {where_sql}"
 
    conn = get_dynamic_connection(server, database)
    cursor = conn.cursor()
 
    try:
        cursor.execute(sql, params)
 
        columns = [col[0] for col in cursor.description]
        rows = cursor.fetchall()
 
        clean_rows = []
 
        for row in rows:
            clean_rows.append([format_value(value) for value in row])
 
        return {
            "ok": True,
            "columns": columns,
            "rows": clean_rows,
            "server": server,
            "database": database,
            "tableName": table_name,
            "sql": sql
        }
 
    finally:
        conn.close()
 
 
def build_where(filters):
    parts = []
    params = []
 
    for index, f in enumerate(filters or []):
        field = f.get("field")
        operator = (f.get("operator") or f.get("mode") or "").upper()
        value = f.get("value")
        value2 = f.get("value2")
        connector = f.get("connector") or "AND"
 
        if not field or not operator:
            continue
 
        prefix = "" if index == 0 else f" {connector} "
 
        safe_field = f"[{field}]"
 
        if operator in ["=", "<>", ">", "<", ">=", "<="]:
            parts.append(f"{prefix}{safe_field} {operator} ?")
            params.append(value)
 
        elif operator == "LIKE" or operator == "CONTAINS":
            parts.append(f"{prefix}{safe_field} LIKE ?")
            params.append(f"%{value}%")
 
        elif operator == "BETWEEN":
            parts.append(f"{prefix}{safe_field} BETWEEN ? AND ?")
            params.append(value)
            params.append(value2)
 
        elif operator == "IN":
            values = [v.strip() for v in str(value).split(",") if v.strip()]
            if values:
                placeholders = ",".join(["?"] * len(values))
                parts.append(f"{prefix}{safe_field} IN ({placeholders})")
                params.extend(values)
 
        elif operator in ["IS NULL", "IS_NULL"]:
            parts.append(f"{prefix}{safe_field} IS NULL")
 
        elif operator in ["IS NOT NULL", "IS_NOT_NULL"]:
            parts.append(f"{prefix}{safe_field} IS NOT NULL")
 
    return "".join(parts), params
 
 
def format_value(value):
    if value is None:
        return ""
 
    if hasattr(value, "strftime"):
        return value.strftime("%d/%m/%Y")
 
    return str(value)