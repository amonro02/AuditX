from __future__ import annotations 

import json

from typing import Any, Iterable

from database.connection import Database
from database.db_config import DB_CONFIG_AUDITFOLLOWUP


class LayoutRepository:
    """
    Repositorio de configuraciones visuales por usuario.

    Permite guardar preferencias como:

        - Columnas visibles.
        - Orden de columnas.
        - Ancho de columnas.
        - Ordenamiento.
        - Filtros.
        - Tamaño de página.
        - Otras preferencias de la tabla.

    La combinación única lógica es:

        LayoutKey + UserEmail + ClientKey
    """

    TABLE_NAME = "dbo.UserColumnLayouts"

    def __init__(
        self,
        db: Database | None = None,
    ):
        self.db = db or Database(
            DB_CONFIG_AUDITFOLLOWUP
        )

    # =========================================================
    # CONSULTA
    # =========================================================

    def get_layout(
        self,
        user_email: str,
        client_id: int,
        key: str,
    ) -> dict[str, Any] | None:
        """
        Recupera el layout guardado.

        En SQL se utiliza ClientKey.
        En Python se conserva client_id.
        """

        normalized_email = self._normalize_email(
            user_email
        )

        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )

        normalized_key = self._normalize_key(
            key
        )

        if not normalized_email:
            return None

        row = self.db.fetch_one(
            f"""
                SELECT TOP 1
                    LayoutID,
                    LayoutKey,
                    UserEmail,
                    ClientKey AS ClientID,
                    ColumnsJson,
                    CreatedAt,
                    UpdatedAt
                FROM {self.TABLE_NAME}
                WHERE LOWER(UserEmail) = LOWER(?)
                  AND ClientKey = ?
                  AND LayoutKey = ?
                ORDER BY
                    UpdatedAt DESC,
                    LayoutID DESC;
            """,
            (
                normalized_email,
                normalized_client_id,
                normalized_key,
            ),
        )

        if not row:
            return None

        layout_data = self._deserialize_layout(
            row.get("ColumnsJson")
        )

        if layout_data is None:
            return None

        return {
            "layout_id": row.get("LayoutID"),
            "layout_key": row.get("LayoutKey"),
            "user_email": row.get("UserEmail"),
            "client_id": row.get("ClientID"),
            "created_at": row.get("CreatedAt"),
            "updated_at": row.get("UpdatedAt"),
            "layout": layout_data,

            # Compatibilidad con el código anterior
            **layout_data,
        }

    def get_visible_columns(
        self,
        user_email: str,
        client_id: int,
        key: str,
    ) -> list[str] | None:
        """
        Devuelve solamente las columnas visibles.
        """

        result = self.get_layout(
            user_email=user_email,
            client_id=client_id,
            key=key,
        )

        if not result:
            return None

        layout = result.get("layout") or {}

        columns = (
            layout.get("default_visible_columns")
            or layout.get("visible_columns")
            or layout.get("columns")
        )

        if not isinstance(columns, list):
            return None

        return [
            str(column).strip()
            for column in columns
            if str(column or "").strip()
        ]

    def get_user_layouts(
        self,
        user_email: str,
        client_id: int | None = None,
    ) -> list[dict[str, Any]]:
        """
        Recupera todos los layouts de un usuario.
        """

        normalized_email = self._normalize_email(
            user_email
        )

        if not normalized_email:
            return []

        sql = f"""
            SELECT
                LayoutID,
                LayoutKey,
                UserEmail,
                ClientKey AS ClientID,
                ColumnsJson,
                CreatedAt,
                UpdatedAt
            FROM {self.TABLE_NAME}
            WHERE LOWER(UserEmail) = LOWER(?)
        """

        params: list[Any] = [
            normalized_email
        ]

        if client_id not in (None, ""):
            sql += """
                AND ClientKey = ?
            """
            params.append(
                int(client_id)
            )

        sql += """
            ORDER BY
                ClientKey,
                LayoutKey;
        """

        rows = self.db.fetch_all(
            sql,
            tuple(params),
        )

        result: list[dict[str, Any]] = []

        for row in rows:
            layout = self._deserialize_layout(
                row.get("ColumnsJson")
            )

            result.append({
                "layout_id": row.get("LayoutID"),
                "layout_key": row.get("LayoutKey"),
                "user_email": row.get("UserEmail"),
                "client_id": row.get("ClientID"),
                "layout": layout or {},
                "created_at": row.get("CreatedAt"),
                "updated_at": row.get("UpdatedAt"),
            })

        return result

    # =========================================================
    # GUARDAR
    # =========================================================

    def save_layout(
        self,
        key: str,
        user_email: str,
        client_id: int,
        columns: Iterable[str] | None = None,
        *,
        layout_data: dict[str, Any] | None = None,
        column_order: Iterable[str] | None = None,
        column_widths: dict[str, Any] | None = None,
        filters: dict[str, Any] | None = None,
        sort: dict[str, Any] | None = None,
        page_size: int | None = None,
    ) -> int:
        """
        Inserta o actualiza el layout.

        Puede utilizarse en modo simple:

            save_layout(
                key="FOLLOWUP_CASES",
                user_email=email,
                client_id=1,
                columns=["CaseID", "VendorName"]
            )

        O en modo completo:

            save_layout(
                key="FOLLOWUP_CASES",
                user_email=email,
                client_id=1,
                layout_data={
                    "default_visible_columns": [...],
                    "column_widths": {...}
                }
            )
        """

        normalized_key = self._normalize_key(
            key
        )

        normalized_email = self._normalize_email(
            user_email
        )

        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )

        if not normalized_email:
            raise ValueError(
                "UserEmail es obligatorio."
            )

        prepared_layout = self._build_layout_data(
            columns=columns,
            layout_data=layout_data,
            column_order=column_order,
            column_widths=column_widths,
            filters=filters,
            sort=sort,
            page_size=page_size,
        )

        layout_json = json.dumps(
            prepared_layout,
            ensure_ascii=False,
            separators=(",", ":"),
            default=str,
        )

        sql = f"""
            MERGE {self.TABLE_NAME} WITH (HOLDLOCK) AS Target
            USING
            (
                SELECT
                    ? AS LayoutKey,
                    ? AS UserEmail,
                    ? AS ClientKey
            ) AS Source
                ON Target.LayoutKey = Source.LayoutKey
               AND LOWER(Target.UserEmail)
                    = LOWER(Source.UserEmail)
               AND Target.ClientKey = Source.ClientKey

            WHEN MATCHED THEN
                UPDATE SET
                    ColumnsJson = ?,
                    UpdatedAt = SYSDATETIME()

            WHEN NOT MATCHED THEN
                INSERT
                (
                    LayoutKey,
                    UserEmail,
                    ClientKey,
                    ColumnsJson,
                    CreatedAt,
                    UpdatedAt
                )
                VALUES
                (
                    Source.LayoutKey,
                    Source.UserEmail,
                    Source.ClientKey,
                    ?,
                    SYSDATETIME(),
                    SYSDATETIME()
                )

            OUTPUT INSERTED.LayoutID;
        """

        layout_id = self.db.scalar(
            sql,
            (
                normalized_key,
                normalized_email,
                normalized_client_id,
                layout_json,
                layout_json,
            ),
        )

        if layout_id is None:
            raise RuntimeError(
                "No fue posible guardar el layout."
            )

        return int(layout_id)

    def save_visible_columns(
        self,
        key: str,
        user_email: str,
        client_id: int,
        columns: Iterable[str],
    ) -> int:
        """
        Método corto para guardar únicamente columnas visibles.
        """

        return self.save_layout(
            key=key,
            user_email=user_email,
            client_id=client_id,
            columns=columns,
        )

    # =========================================================
    # ELIMINAR O RESTABLECER
    # =========================================================

    def delete_layout(
        self,
        key: str,
        user_email: str,
        client_id: int,
    ) -> int:
        """
        Elimina la configuración personalizada.
        """

        normalized_key = self._normalize_key(
            key
        )

        normalized_email = self._normalize_email(
            user_email
        )

        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )

        if not normalized_email:
            return 0

        sql = f"""
            DELETE FROM {self.TABLE_NAME}
            WHERE LayoutKey = ?
              AND LOWER(UserEmail) = LOWER(?)
              AND ClientKey = ?;
        """

        return self.db.execute(
            sql,
            (
                normalized_key,
                normalized_email,
                normalized_client_id,
            ),
        )

    def delete_all_for_user(
        self,
        user_email: str,
        client_id: int | None = None,
    ) -> int:
        """
        Elimina todos los layouts del usuario.

        Puede limitarse a un cliente.
        """

        normalized_email = self._normalize_email(
            user_email
        )

        if not normalized_email:
            return 0

        sql = f"""
            DELETE FROM {self.TABLE_NAME}
            WHERE LOWER(UserEmail) = LOWER(?)
        """

        params: list[Any] = [
            normalized_email
        ]

        if client_id not in (None, ""):
            sql += """
                AND ClientKey = ?
            """
            params.append(
                int(client_id)
            )

        return self.db.execute(
            sql,
            tuple(params),
        )

    def layout_exists(
        self,
        key: str,
        user_email: str,
        client_id: int,
    ) -> bool:
        """
        Verifica si existe una configuración.
        """

        normalized_email = self._normalize_email(
            user_email
        )

        if not normalized_email:
            return False

        count = self.db.scalar(
            f"""
                SELECT COUNT(1)
                FROM {self.TABLE_NAME}
                WHERE LayoutKey = ?
                  AND LOWER(UserEmail) = LOWER(?)
                  AND ClientKey = ?;
            """,
            (
                self._normalize_key(key),
                normalized_email,
                self._required_int(
                    client_id,
                    "ClientID",
                ),
            ),
        )

        return int(count or 0) > 0

    # =========================================================
    # CONSTRUCCIÓN DEL JSON
    # =========================================================

    def _build_layout_data(
        self,
        columns: Iterable[str] | None,
        layout_data: dict[str, Any] | None,
        column_order: Iterable[str] | None,
        column_widths: dict[str, Any] | None,
        filters: dict[str, Any] | None,
        sort: dict[str, Any] | None,
        page_size: int | None,
    ) -> dict[str, Any]:
        """
        Genera una estructura JSON consistente.
        """

        result = dict(
            layout_data or {}
        )

        normalized_columns = self._normalize_columns(
            columns
        )

        normalized_order = self._normalize_columns(
            column_order
        )

        if normalized_columns:
            result["default_visible_columns"] = (
                normalized_columns
            )

            # Compatibilidad con versiones anteriores.
            result["visible_columns"] = (
                normalized_columns
            )

        if normalized_order:
            result["column_order"] = (
                normalized_order
            )

        if isinstance(column_widths, dict):
            result["column_widths"] = {
                str(key): value
                for key, value
                in column_widths.items()
                if str(key or "").strip()
            }

        if isinstance(filters, dict):
            result["filters"] = filters

        if isinstance(sort, dict):
            result["sort"] = sort

        if page_size is not None:
            result["page_size"] = (
                self._normalize_page_size(
                    page_size
                )
            )

        if not result:
            result = {
                "default_visible_columns": []
            }

        result["version"] = 1

        return result

    # =========================================================
    # AUXILIARES
    # =========================================================

    @staticmethod
    def _deserialize_layout(
        value: Any,
    ) -> dict[str, Any] | None:
        if value in (None, ""):
            return None

        if isinstance(value, dict):
            return value

        try:
            parsed = json.loads(
                str(value)
            )
        except (
            TypeError,
            ValueError,
            json.JSONDecodeError,
        ):
            return None

        if not isinstance(parsed, dict):
            return None

        return parsed

    @staticmethod
    def _normalize_columns(
        columns: Iterable[str] | None,
    ) -> list[str]:
        if columns is None:
            return []

        result: list[str] = []

        for column in columns:
            normalized = str(
                column or ""
            ).strip()

            if (
                normalized
                and normalized not in result
            ):
                result.append(normalized)

        return result

    @staticmethod
    def _normalize_email(
        value: Any,
    ) -> str | None:
        email = str(
            value or ""
        ).strip().lower()

        return email or None

    @staticmethod
    def _normalize_key(
        value: Any,
    ) -> str:
        key = str(
            value or ""
        ).strip().upper()

        if not key:
            raise ValueError(
                "LayoutKey es obligatorio."
            )

        if len(key) > 100:
            raise ValueError(
                "LayoutKey no puede exceder 100 caracteres."
            )

        return key

    @staticmethod
    def _required_int(
        value: Any,
        field_name: str,
    ) -> int:
        if value in (None, ""):
            raise ValueError(
                f"{field_name} es obligatorio."
            )

        try:
            return int(value)
        except (
            TypeError,
            ValueError,
        ) as error:
            raise ValueError(
                f"{field_name} debe ser numérico."
            ) from error

    @staticmethod
    def _normalize_page_size(
        value: Any,
    ) -> int:
        try:
            page_size = int(value)
        except (
            TypeError,
            ValueError,
        ):
            page_size = 25

        if page_size < 5:
            return 5

        if page_size > 500:
            return 500

        return page_size

    