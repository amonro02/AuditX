from __future__ import annotations 

from datetime import date, datetime
from decimal import Decimal
from typing import Any, Iterable

from database.connection import Database
from database.db_config import DB_CONFIG_AUDITFOLLOWUP


class CaseRepository:
    """
    Repositorio principal de casos de Audit Follow-up.

    Responsabilidades:
        - Consultar clientes disponibles por usuario.
        - Consultar proyectos.
        - Consultar uno o varios casos.
        - Crear casos.
        - Crear múltiples claims por caso.
        - Actualizar campos permitidos.
        - Registrar respuestas.
        - Actualizar información de seguimiento.
        - Realizar eliminación lógica.
        - Obtener estadísticas.
        - Obtener casos pendientes de seguimiento.

    Base utilizada:
        PRGX_AUDITFOLLOWUP
    """

    CASE_VIEW = "dbo.VW_FollowUpCases"
    CASE_TABLE = "dbo.FollowUpCases"
    CLAIM_TABLE = "dbo.FollowUpClaims"

    ALLOWED_UPDATE_FIELDS = {
        "VendorID",
        "CampaignID",
        "ContactID",
        "ClaimNumber", # Compatibilidad legacy
        "SubjectInitial",
        "EmailTo",
        "EmailCC",
        "EmailBCC",
        "Status",
        "Priority",
        "AssignedUserEmail",
        "Amount", # Compatibilidad legacy
        "Currency",
        "DueDate",
        "AutomationStatus",
        "LastActionResult",
        "CurrentStep",
        "RequiresManualReview",
        "ManualResponseType",
        "LanguageCode",
        "NextFollowUpDate",
        "LastSendDate",
        "LastReplyDate",
        "LastReplyFrom",
        "DaysToReply",
        "FollowUpCount",
        "OutlookEntryID",
        "ConversationID",
    }

    ALLOWED_SELECTED_COLUMNS = {
        "CaseID",
        "ClientID",
        "ClientCode",
        "ClientName",
        "ProjectID",
        "ProjectName",
        "VendorID",
        "VendorNumber",
        "VendorName",
        "CampaignID",
        "CampaignName",
        "ContactID",
        "ContactName",
        "ContactGender",
        "ClaimNumber",
        "SubjectInitial",
        "EmailTo",
        "EmailCC",
        "EmailBCC",
        "Status",
        "Priority",
        "AssignedUserEmail",
        "Amount",
        "Currency",
        "DueDate",
        "AutomationStatus",
        "LastActionResult",
        "CurrentStep",
        "RequiresManualReview",
        "ManualResponseType",
        "LanguageCode",
        "FollowUpCount",
        "LastSendDate",
        "NextFollowUpDate",
        "LastReplyDate",
        "LastReplyFrom",
        "DaysToReply",
        "OutlookEntryID",
        "ConversationID",
        "CreatedBy",
        "CreatedAt",
        "UpdatedBy",
        "UpdatedAt",
        "IsActive",
    }

    def __init__(
        self,
        db: Database | None = None,
    ):
        self.db = db or Database(
            DB_CONFIG_AUDITFOLLOWUP
        )

    # =========================================================
    # CLIENTES Y PROYECTOS
    # =========================================================

    def get_clients(
        self,
        user_email: str,
    ) -> list[dict[str, Any]]:
        """
        Devuelve los clientes permitidos para el usuario.
        """

        normalized_email = self._normalize_email(
            user_email
        )

        if not normalized_email:
            return []

        sql = """
            SELECT
                ClientID,
                ClientCode,
                ClientName
            FROM dbo.F_UserClients(?)
            ORDER BY ClientName;
        """

        return self.db.fetch_all(
            sql,
            (normalized_email,),
        )

    def get_projects(
        self,
        client_id: int,
    ) -> list[dict[str, Any]]:
        """
        Devuelve proyectos activos de un cliente.
        """

        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )

        sql = """
            SELECT
                ProjectID,
                ClientID,
                ProjectName
            FROM dbo.Projects
            WHERE ClientID = ?
              AND ISNULL(IsActive, 1) = 1
            ORDER BY ProjectName;
        """

        return self.db.fetch_all(
            sql,
            (normalized_client_id,),
        )

    # =========================================================
    # CONSULTA DE CASOS
    # =========================================================

    def get_case(
        self,
        case_id: int,
        include_claims: bool = True,
    ) -> dict[str, Any] | None:
        """
        Devuelve un caso.

        Cuando include_claims=True agrega:
            case["Claims"]
            case["claims"]
        """

        normalized_case_id = self._required_int(
            case_id,
            "CaseID",
        )

        sql = f"""
            SELECT TOP 1 *
            FROM {self.CASE_VIEW}
            WHERE CaseID = ?;
        """

        case = self.db.fetch_one(
            sql,
            (normalized_case_id,),
        )

        if not case:
            return None

        if include_claims:
            claims = self.get_claims(
                normalized_case_id
            )

            case["Claims"] = claims
            case["claims"] = claims

        return case

    def get_case_for_email(
        self,
        case_id: int,
    ) -> dict[str, Any] | None:
        """
        Devuelve el caso listo para TemplateService y EmailService.
        """

        case = self.get_case(
            case_id=case_id,
            include_claims=True,
        )

        if not case:
            return None

        claims = case.get("Claims") or []

        claim_numbers = [
            str(
                claim.get("ClaimNumber")
                or claim.get("ClaimCode")
                or ""
            ).strip()
            for claim in claims
            if (
                claim.get("ClaimNumber")
                or claim.get("ClaimCode")
            )
        ]

        project_names: list[str] = []

        for claim in claims:
            project_name = str(
                claim.get("ProjectName")
                or ""
            ).strip()

            if (
                project_name
                and project_name not in project_names
            ):
                project_names.append(project_name)

        if len(project_names) > 1:
            case["ProjectName"] = "Multiple projects"
            case["IsMultipleProjects"] = True

        elif len(project_names) == 1:
            case["ProjectName"] = project_names[0]
            case["IsMultipleProjects"] = False

        else:
            case["IsMultipleProjects"] = False

        case["ClaimNumbers"] = ", ".join(
            claim_numbers
        )

        case["ClaimCount"] = len(claims)

        return case

    def get_cases(
        self,
        user_email: str | None = None,
        can_view_all: bool = False,
        selected_columns: Iterable[str] | None = None,
        client_id: int | None = None,
        project_id: int | None = None,
        status: str | None = None,
        include_inactive: bool = False,
    ) -> tuple[list[str], list[dict[str, Any]]]:
        """
        Consulta casos con filtros.

        Devuelve:
            columns, rows
        """

        columns_sql = self._build_columns_sql(
            selected_columns
        )

        sql = f"""
            SELECT {columns_sql}
            FROM {self.CASE_VIEW}
            WHERE 1 = 1
        """

        params: list[Any] = []

        if client_id not in (None, ""):
            sql += " AND ClientID = ?"
            params.append(
                int(client_id)
            )

        if project_id not in (None, ""):
            sql += " AND ProjectID = ?"
            params.append(
                int(project_id)
            )

        if status not in (None, ""):
            sql += " AND Status = ?"
            params.append(
                str(status).strip()
            )

        if not include_inactive:
            sql += " AND ISNULL(IsActive, 1) = 1"

        if not can_view_all:
            normalized_email = self._normalize_email(
                user_email
            )

            if not normalized_email:
                return [], []

            sql += " AND LOWER(AssignedUserEmail) = LOWER(?)"
            params.append(normalized_email)

        sql += """
            ORDER BY
                CreatedAt DESC,
                CaseID DESC;
        """

        rows = self.db.fetch_all(
            sql,
            tuple(params),
        )

        if not rows:
            return [], []

        columns = list(rows[0].keys())

        return columns, rows

    # =========================================================
    # CREACIÓN DEL CASO
    # =========================================================

    def add_case(
        self,
        data: dict[str, Any],
        user_email: str,
    ) -> int:
        """
        Crea solamente el encabezado del caso.

        Para crear caso y múltiples claims en una transacción,
        utiliza add_case_with_claims().
        """

        self._validate_case_data(data)

        normalized_user_email = (
            self._normalize_email(user_email)
        )

        assigned_user_email = (
            self._normalize_email(
                data.get("AssignedUserEmail")
            )
            or normalized_user_email
        )

        # Compatibilidad con la estructura anterior.
        # Si existen claims, se usa el primero únicamente para
        # ClaimNumber y Amount del encabezado.
        claims = self._normalize_claims(
            data.get("Claims")
            or data.get("claims")
            or []
        )

        first_claim = (
            claims[0]
            if claims
            else {}
        )

        legacy_claim_number = (
            data.get("ClaimNumber")
            or first_claim.get("ClaimNumber")
            or first_claim.get("ClaimCode")
        )

        legacy_amount = (
            data.get("Amount")
            if data.get("Amount") is not None
            else first_claim.get("ClaimAmount")
        )

        sql = f"""
            INSERT INTO {self.CASE_TABLE}
            (
                ClientID,
                ProjectID,
                VendorID,
                CampaignID,
                ContactID,
                ClaimNumber,
                SubjectInitial,
                EmailTo,
                EmailCC,
                EmailBCC,
                Status,
                Priority,
                AssignedUserEmail,
                Amount,
                Currency,
                DueDate,
                LanguageCode,
                CreatedBy,
                CreatedAt,
                UpdatedBy,
                UpdatedAt,
                IsActive
            )
            OUTPUT INSERTED.CaseID
            VALUES
            (
                ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?,
                SYSDATETIME(),
                ?, SYSDATETIME(),
                1
            );
        """

        case_id = self.db.scalar(
            sql,
            (
                self._required_int(
                    data.get("ClientID"),
                    "ClientID",
                ),
                self._optional_int(
                    data.get("ProjectID")
                ),
                self._optional_int(
                    data.get("VendorID")
                ),
                self._optional_int(
                    data.get("CampaignID")
                ),
                self._optional_int(
                    data.get("ContactID")
                ),
                self._optional_text(
                    legacy_claim_number
                ),
                self._optional_text(
                    data.get("SubjectInitial")
                ),
                self._optional_text(
                    data.get("EmailTo")
                ),
                self._optional_text(
                    data.get("EmailCC")
                ),
                self._optional_text(
                    data.get("EmailBCC")
                ),
                self._optional_text(
                    data.get("Status")
                ) or "Pending",
                self._optional_text(
                    data.get("Priority")
                ) or "Normal",
                assigned_user_email,
                self._optional_decimal(
                    legacy_amount
                ),
                self._optional_text(
                    data.get("Currency")
                    or first_claim.get("Currency")
                ),
                data.get("DueDate"),
                self._normalize_language(
                    data.get("LanguageCode")
                    or data.get("Language")
                ),
                normalized_user_email,
                normalized_user_email,
            ),
        )

        if case_id is None:
            raise RuntimeError(
                "No fue posible obtener el CaseID."
            )

        return int(case_id)

    def add_case_with_claims(
        self,
        data: dict[str, Any],
        claims: list[dict[str, Any]] | None,
        user_email: str,
    ) -> int:
        """
        Crea el caso y todos sus claims en una sola transacción.

        Si falla cualquier claim:
            - No guarda el caso.
            - Realiza rollback.
        """

        self._validate_case_data(data)

        normalized_claims = self._normalize_claims(
            claims
            or data.get("Claims")
            or data.get("claims")
            or []
        )

        if not normalized_claims:
            raise ValueError(
                "Debe registrarse al menos un claim."
            )

        normalized_user_email = (
            self._normalize_email(user_email)
        )

        assigned_user_email = (
            self._normalize_email(
                data.get("AssignedUserEmail")
            )
            or normalized_user_email
        )

        first_claim = normalized_claims[0]

        connection = self.db.connect()

        try:
            cursor = connection.cursor()

            case_sql = f"""
                INSERT INTO {self.CASE_TABLE}
                (
                    ClientID,
                    ProjectID,
                    VendorID,
                    CampaignID,
                    ContactID,
                    ClaimNumber,
                    SubjectInitial,
                    EmailTo,
                    EmailCC,
                    EmailBCC,
                    Status,
                    Priority,
                    AssignedUserEmail,
                    Amount,
                    Currency,
                    DueDate,
                    LanguageCode,
                    CreatedBy,
                    CreatedAt,
                    UpdatedBy,
                    UpdatedAt,
                    IsActive
                )
                OUTPUT INSERTED.CaseID
                VALUES
                (
                    ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, ?,
                    SYSDATETIME(),
                    ?, SYSDATETIME(),
                    1
                );
            """

            cursor.execute(
                case_sql,
                (
                    self._required_int(
                        data.get("ClientID"),
                        "ClientID",
                    ),
                    self._optional_int(
                        data.get("ProjectID")
                    ),
                    self._optional_int(
                        data.get("VendorID")
                    ),
                    self._optional_int(
                        data.get("CampaignID")
                    ),
                    self._optional_int(
                        data.get("ContactID")
                    ),
                    self._optional_text(
                        first_claim.get("ClaimNumber")
                        or first_claim.get("ClaimCode")
                    ),
                    self._optional_text(
                        data.get("SubjectInitial")
                    ),
                    self._optional_text(
                        data.get("EmailTo")
                    ),
                    self._optional_text(
                        data.get("EmailCC")
                    ),
                    self._optional_text(
                        data.get("EmailBCC")
                    ),
                    self._optional_text(
                        data.get("Status")
                    ) or "Pending",
                    self._optional_text(
                        data.get("Priority")
                    ) or "Normal",
                    assigned_user_email,
                    self._optional_decimal(
                        first_claim.get("ClaimAmount")
                        or first_claim.get("Amount")
                    ),
                    self._optional_text(
                        data.get("Currency")
                        or first_claim.get("Currency")
                    ),
                    data.get("DueDate"),
                    self._normalize_language(
                        data.get("LanguageCode")
                        or data.get("Language")
                    ),
                    normalized_user_email,
                    normalized_user_email,
                ),
            )

            row = cursor.fetchone()

            if not row:
                raise RuntimeError(
                    "No fue posible obtener el CaseID."
                )

            case_id = int(row[0])

            self._insert_claims_with_cursor(
                cursor=cursor,
                case_id=case_id,
                claims=normalized_claims,
                user_email=normalized_user_email,
            )

            connection.commit()

            return case_id

        except Exception:
            connection.rollback()
            raise

        finally:
            connection.close()

    # =========================================================
    # CLAIMS MÚLTIPLES
    # =========================================================

    def get_claims(
        self,
        case_id: int,
    ) -> list[dict[str, Any]]:
        """
        Devuelve todos los claims activos del caso.
        """

        normalized_case_id = self._required_int(
            case_id,
            "CaseID",
        )

        sql = f"""
            SELECT
                FC.FollowUpClaimID,
                FC.CaseID,
                FC.ProjectID,
                P.ProjectName,
                FC.ClaimNumber,
                FC.ClaimAmount,
                FC.Currency,
                FC.Description,
                FC.Status,
                FC.CreatedBy,
                FC.CreatedAt,
                FC.UpdatedBy,
                FC.UpdatedAt,
                FC.IsActive
            FROM {self.CLAIM_TABLE} AS FC
            LEFT JOIN dbo.Projects AS P
                ON P.ProjectID = FC.ProjectID
            WHERE FC.CaseID = ?
              AND ISNULL(FC.IsActive, 1) = 1
            ORDER BY
                FC.FollowUpClaimID;
        """

        return self.db.fetch_all(
            sql,
            (normalized_case_id,),
        )

    def add_claims(
        self,
        case_id: int,
        claims: list[dict[str, Any]],
        user_email: str,
    ) -> int:
        """
        Agrega uno o varios claims a un caso existente.
        """

        normalized_case_id = self._required_int(
            case_id,
            "CaseID",
        )

        normalized_claims = self._normalize_claims(
            claims
        )

        if not normalized_claims:
            return 0

        normalized_user_email = (
            self._normalize_email(user_email)
        )

        connection = self.db.connect()

        try:
            cursor = connection.cursor()

            inserted = self._insert_claims_with_cursor(
                cursor=cursor,
                case_id=normalized_case_id,
                claims=normalized_claims,
                user_email=normalized_user_email,
            )

            connection.commit()

            return inserted

        except Exception:
            connection.rollback()
            raise

        finally:
            connection.close()

    def replace_claims(
        self,
        case_id: int,
        claims: list[dict[str, Any]],
        user_email: str,
    ) -> int:
        """
        Desactiva los claims actuales y registra la nueva lista.
        """

        normalized_case_id = self._required_int(
            case_id,
            "CaseID",
        )

        normalized_claims = self._normalize_claims(
            claims
        )

        normalized_user_email = (
            self._normalize_email(user_email)
        )

        connection = self.db.connect()

        try:
            cursor = connection.cursor()

            cursor.execute(
                f"""
                    UPDATE {self.CLAIM_TABLE}
                    SET
                        IsActive = 0,
                        UpdatedBy = ?,
                        UpdatedAt = SYSDATETIME()
                    WHERE CaseID = ?
                      AND ISNULL(IsActive, 1) = 1;
                """,
                (
                    normalized_user_email,
                    normalized_case_id,
                ),
            )

            inserted = self._insert_claims_with_cursor(
                cursor=cursor,
                case_id=normalized_case_id,
                claims=normalized_claims,
                user_email=normalized_user_email,
            )

            connection.commit()

            return inserted

        except Exception:
            connection.rollback()
            raise

        finally:
            connection.close()

    def soft_delete_claim(
        self,
        follow_up_claim_id: int,
        user_email: str,
    ) -> int:
        """
        Eliminación lógica de un claim.
        """

        sql = f"""
            UPDATE {self.CLAIM_TABLE}
            SET
                IsActive = 0,
                UpdatedBy = ?,
                UpdatedAt = SYSDATETIME()
            WHERE FollowUpClaimID = ?;
        """

        return self.db.execute(
            sql,
            (
                self._normalize_email(user_email),
                self._required_int(
                    follow_up_claim_id,
                    "FollowUpClaimID",
                ),
            ),
        )

    # =========================================================
    # ACTUALIZACIÓN Y ELIMINACIÓN DEL CASO
    # =========================================================

    def soft_delete(
        self,
        case_id: int,
        user_email: str,
    ) -> int:
        """
        Eliminación lógica del caso y sus claims.
        """

        normalized_case_id = self._required_int(
            case_id,
            "CaseID",
        )

        normalized_email = self._normalize_email(
            user_email
        )

        connection = self.db.connect()

        try:
            cursor = connection.cursor()

            cursor.execute(
                f"""
                    UPDATE {self.CASE_TABLE}
                    SET
                        IsActive = 0,
                        UpdatedBy = ?,
                        UpdatedAt = SYSDATETIME()
                    WHERE CaseID = ?;
                """,
                (
                    normalized_email,
                    normalized_case_id,
                ),
            )

            affected = cursor.rowcount

            cursor.execute(
                f"""
                    UPDATE {self.CLAIM_TABLE}
                    SET
                        IsActive = 0,
                        UpdatedBy = ?,
                        UpdatedAt = SYSDATETIME()
                    WHERE CaseID = ?;
                """,
                (
                    normalized_email,
                    normalized_case_id,
                ),
            )

            connection.commit()

            return affected

        except Exception:
            connection.rollback()
            raise

        finally:
            connection.close()

    def update_field(
        self,
        case_id: int,
        field: str,
        value: Any,
        user_email: str,
    ) -> int:
        """
        Actualiza únicamente campos autorizados.

        El nombre de columna no viene directamente del usuario:
        primero se valida contra ALLOWED_UPDATE_FIELDS.
        """

        normalized_field = str(
            field or ""
        ).strip()

        if normalized_field not in self.ALLOWED_UPDATE_FIELDS:
            raise ValueError(
                f"El campo '{normalized_field}' no puede actualizarse."
            )

        sql = f"""
            UPDATE {self.CASE_TABLE}
            SET
                [{normalized_field}] = ?,
                UpdatedBy = ?,
                UpdatedAt = SYSDATETIME()
            WHERE CaseID = ?
              AND ISNULL(IsActive, 1) = 1;
        """

        return self.db.execute(
            sql,
            (
                value,
                self._normalize_email(user_email),
                self._required_int(
                    case_id,
                    "CaseID",
                ),
            ),
        )

    def update_case_status(
        self,
        case_id: int,
        status: str,
        user_email: str | None = None,
    ) -> int:
        """
        Actualiza el estatus del caso.
        """

        normalized_status = self._optional_text(
            status
        )

        if not normalized_status:
            raise ValueError(
                "Status es obligatorio."
            )

        sql = f"""
            UPDATE {self.CASE_TABLE}
            SET
                Status = ?,
                UpdatedBy = COALESCE(?, UpdatedBy),
                UpdatedAt = SYSDATETIME()
            WHERE CaseID = ?;
        """

        return self.db.execute(
            sql,
            (
                normalized_status,
                self._normalize_email(user_email),
                self._required_int(
                    case_id,
                    "CaseID",
                ),
            ),
        )

    # =========================================================
    # RESPUESTA Y SEGUIMIENTO
    # =========================================================

    def update_reply_info(
        self,
        case_id: int,
        reply_date: datetime | date | None,
        reply_from: str | None,
        days: int | None,
        user_email: str | None = None,
    ) -> int:
        """
        Registra que se encontró una respuesta.
        """

        sql = f"""
            UPDATE {self.CASE_TABLE}
            SET
                LastReplyDate = ?,
                LastReplyFrom = ?,
                DaysToReply = ?,
                AutomationStatus = 'Reply Found',
                Status =
                    CASE
                        WHEN Status IN (
                            'Closed',
                            'Cancelled'
                        )
                            THEN Status
                        ELSE 'Responded'
                    END,
                UpdatedBy = COALESCE(?, UpdatedBy),
                UpdatedAt = SYSDATETIME()
            WHERE CaseID = ?;
        """

        return self.db.execute(
            sql,
            (
                reply_date,
                self._optional_text(reply_from),
                self._optional_int(days),
                self._normalize_email(user_email),
                self._required_int(
                    case_id,
                    "CaseID",
                ),
            ),
        )

    def update_followup(
        self,
        case_id: int,
        count: int,
        sent_date: datetime | date | None,
        next_date: datetime | date | None,
        status: str | None,
        result: str | None,
        outlook_entry_id: str | None = None,
        user_email: str | None = None,
    ) -> int:
        """
        Actualiza información después de crear o enviar un correo.
        """

        sql = f"""
            UPDATE {self.CASE_TABLE}
            SET
                FollowUpCount = ?,
                LastSendDate = ?,
                NextFollowUpDate = ?,
                AutomationStatus = ?,
                LastActionResult = ?,
                OutlookEntryID =
                    COALESCE(?, OutlookEntryID),
                UpdatedBy =
                    COALESCE(?, UpdatedBy),
                UpdatedAt = SYSDATETIME()
            WHERE CaseID = ?;
        """

        return self.db.execute(
            sql,
            (
                max(int(count or 0), 0),
                sent_date,
                next_date,
                self._optional_text(status),
                self._optional_text(result),
                self._optional_text(
                    outlook_entry_id
                ),
                self._normalize_email(user_email),
                self._required_int(
                    case_id,
                    "CaseID",
                ),
            ),
        )

    # =========================================================
    # ESTADÍSTICAS
    # =========================================================

    def stats(
        self,
        user_email: str | None,
        can_view_all: bool = False,
        client_id: int | None = None,
        project_id: int | None = None,
    ) -> dict[str, Any]:
        """
        Devuelve estadísticas de casos por estado.
        """

        sql = """
            SELECT
                COUNT(1) AS TotalCases,

                SUM(
                    CASE
                        WHEN Status = 'Draft'
                            THEN 1
                        ELSE 0
                    END
                ) AS DraftCases,

                SUM(
                    CASE
                        WHEN Status = 'Pending'
                            THEN 1
                        ELSE 0
                    END
                ) AS PendingCases,

                SUM(
                    CASE
                        WHEN Status = 'Responded'
                            THEN 1
                        ELSE 0
                    END
                ) AS RespondedCases,

                SUM(
                    CASE
                        WHEN Status = 'Closed'
                            THEN 1
                        ELSE 0
                    END
                ) AS ClosedCases,

                SUM(
                    CASE
                        WHEN Status = 'Special Case'
                            THEN 1
                        ELSE 0
                    END
                ) AS SpecialCases

            FROM dbo.VW_FollowUpCases
            WHERE ISNULL(IsActive, 1) = 1
        """

        params: list[Any] = []

        if not can_view_all:
            normalized_email = self._normalize_email(
                user_email
            )

            if not normalized_email:
                return self._empty_stats()

            sql += """
                AND LOWER(AssignedUserEmail) = LOWER(?)
            """
            params.append(normalized_email)

        if client_id not in (None, ""):
            sql += " AND ClientID = ?"
            params.append(int(client_id))

        if project_id not in (None, ""):
            sql += " AND ProjectID = ?"
            params.append(int(project_id))

        result = self.db.fetch_one(
            sql,
            tuple(params),
        )

        return result or self._empty_stats()

    def get_pending_cases(
        self,
        client_id: int | None = None,
        project_id: int | None = None,
        user_email: str | None = None,
        can_view_all: bool = True,
    ) -> list[dict[str, Any]]:
        """
        Devuelve casos que ya requieren seguimiento.
        """

        sql = f"""
            SELECT *
            FROM {self.CASE_VIEW}
            WHERE ISNULL(IsActive, 1) = 1
              AND ISNULL(Status, '') NOT IN (
                    'Closed',
                    'Cancelled'
                  )
        """

        params: list[Any] = []

        if client_id not in (None, ""):
            sql += " AND ClientID = ?"
            params.append(int(client_id))

        if project_id not in (None, ""):
            sql += " AND ProjectID = ?"
            params.append(int(project_id))

        if not can_view_all:
            normalized_email = self._normalize_email(
                user_email
            )

            if not normalized_email:
                return []

            sql += """
                AND LOWER(AssignedUserEmail) = LOWER(?)
            """
            params.append(normalized_email)

        sql += """
            AND (
                NextFollowUpDate IS NULL
                OR NextFollowUpDate <= SYSDATETIME()
            )
            ORDER BY
                ISNULL(NextFollowUpDate, DueDate) ASC,
                Priority DESC,
                CreatedAt ASC;
        """

        return self.db.fetch_all(
            sql,
            tuple(params),
        )

    # =========================================================
    # FUNCIONES INTERNAS
    # =========================================================

    def _insert_claims_with_cursor(
        self,
        cursor,
        case_id: int,
        claims: list[dict[str, Any]],
        user_email: str,
    ) -> int:
        """
        Inserta claims usando una transacción ya abierta.
        """

        if not claims:
            return 0

        sql = f"""
            INSERT INTO {self.CLAIM_TABLE}
            (
                CaseID,
                ProjectID,
                ClaimNumber,
                ClaimAmount,
                Currency,
                Description,
                Status,
                CreatedBy,
                CreatedAt,
                UpdatedBy,
                UpdatedAt,
                IsActive
            )
            VALUES
            (
                ?, ?, ?, ?, ?, ?, ?,
                ?, SYSDATETIME(),
                ?, SYSDATETIME(),
                1
            );
        """

        inserted = 0

        for claim in claims:
            claim_number = self._optional_text(
                claim.get("ClaimNumber")
                or claim.get("ClaimCode")
            )

            if not claim_number:
                raise ValueError(
                    "Cada claim debe contener ClaimNumber."
                )

            cursor.execute(
                sql,
                (
                    case_id,
                    self._optional_int(
                        claim.get("ProjectID")
                    ),
                    claim_number,
                    self._optional_decimal(
                        claim.get("ClaimAmount")
                        if claim.get("ClaimAmount")
                        is not None
                        else claim.get("Amount")
                    ),
                    self._optional_text(
                        claim.get("Currency")
                    ),
                    self._optional_text(
                        claim.get("Description")
                    ),
                    self._optional_text(
                        claim.get("Status")
                    ) or "Pending",
                    user_email,
                    user_email,
                ),
            )

            inserted += 1

        return inserted

    def _build_columns_sql(
        self,
        selected_columns: Iterable[str] | None,
    ) -> str:
        """
        Evita inyección SQL en el listado de columnas.
        """

        if not selected_columns:
            return "*"

        safe_columns: list[str] = []

        for column in selected_columns:
            normalized = str(
                column or ""
            ).strip()

            if (
                normalized
                in self.ALLOWED_SELECTED_COLUMNS
            ):
                safe_columns.append(
                    f"[{normalized}]"
                )

        if not safe_columns:
            return "*"

        return ", ".join(safe_columns)

    def _validate_case_data(
        self,
        data: dict[str, Any],
    ) -> None:
        if not isinstance(data, dict):
            raise TypeError(
                "data debe ser un diccionario."
            )

        self._required_int(
            data.get("ClientID"),
            "ClientID",
        )

        if not self._optional_text(
            data.get("EmailTo")
        ):
            raise ValueError(
                "EmailTo es obligatorio."
            )

    @staticmethod
    def _normalize_claims(
        claims: Any,
    ) -> list[dict[str, Any]]:
        if not isinstance(claims, list):
            return []

        return [
            dict(claim)
            for claim in claims
            if isinstance(claim, dict)
        ]

    @staticmethod
    def _required_int(
        value: Any,
        field_name: str,
    ) -> int:
        if value in (None, ""):
            raise ValueError(
                f"{field_name} es obligatorio."
            )

        try:
            return int(value)
        except (TypeError, ValueError) as error:
            raise ValueError(
                f"{field_name} debe ser numérico."
            ) from error

    @staticmethod
    def _optional_int(
        value: Any,
    ) -> int | None:
        if value in (None, ""):
            return None

        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _optional_decimal(
        value: Any,
    ) -> Decimal | None:
        if value in (None, ""):
            return None

        try:
            return Decimal(
                str(value).replace(",", "")
            )
        except Exception:
            return None

    @staticmethod
    def _optional_text(
        value: Any,
    ) -> str | None:
        text = str(
            value or ""
        ).strip()

        return text or None

    @staticmethod
    def _normalize_email(
        value: Any,
    ) -> str | None:
        email = str(
            value or ""
        ).strip().lower()

        return email or None

    @staticmethod
    def _normalize_language(
        value: Any,
    ) -> str:
        language = str(
            value or "en"
        ).strip().lower()

        if language.startswith("es"):
            return "es"

        return "en"

    @staticmethod
    def _empty_stats() -> dict[str, int]:
        return {
            "TotalCases": 0,
            "DraftCases": 0,
            "PendingCases": 0,
            "RespondedCases": 0,
            "ClosedCases": 0,
            "SpecialCases": 0,
        }



