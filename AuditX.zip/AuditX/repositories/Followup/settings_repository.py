from __future__ import annotations 

from datetime import time
from typing import Any

from database.connection import Database
from database.db_config import DB_CONFIG_AUDITFOLLOWUP


class SettingsRepository:
    """
    Repositorio de configuración de automatización de Follow-up.

    La configuración puede existir en dos niveles:

        1. Cliente + proyecto.
        2. Cliente general, con ProjectID NULL.

    Cuando se consulta un proyecto, la configuración específica
    tiene prioridad sobre la configuración general del cliente.

    En SQL se utiliza ClientKey.
    En Python se mantiene el nombre client_id.
    """

    TABLE_NAME = "dbo.AutomationSettings"

    VALID_AUTOMATION_MODES = {
        "DRAFT",
        "SEND",
        "MANUAL",
        "DISABLED",
    }

    DEFAULT_SETTINGS = {
        "SettingID": None,
        "ClientID": None,
        "ProjectID": None,
        "AutomationEnabled": False,
        "AutomationMode": "DRAFT",
        "RunEveryMinutes": 30,
        "OnlyBusinessHours": True,
        "StartHour": "08:00",
        "EndHour": "18:00",
        "MinimumDaysBetweenFollowups": 5,
        "TeamsAlertsEnabled": False,
        "TeamsWebhookUrl": None,
        "UpdatedBy": None,
        "UpdatedAt": None,
    }

    def __init__(
        self,
        db: Database | None = None,
    ):
        self.db = db or Database(
            DB_CONFIG_AUDITFOLLOWUP
        )

    # =========================================================
    # CONSULTAS
    # =========================================================

    def all(
        self,
        client_id: int | None = None,
        include_disabled: bool = True,
    ) -> list[dict[str, Any]]:
        """
        Devuelve las configuraciones registradas.

        Args:
            client_id:
                Filtro opcional por cliente.

            include_disabled:
                Si es False, devuelve únicamente configuraciones
                con AutomationEnabled = 1.
        """

        sql = f"""
            SELECT
                SettingID,
                ClientKey AS ClientID,
                ProjectID,
                AutomationEnabled,
                AutomationMode,
                RunEveryMinutes,
                OnlyBusinessHours,
                StartHour,
                EndHour,
                MinimumDaysBetweenFollowups,
                TeamsAlertsEnabled,
                TeamsWebhookUrl,
                UpdatedBy,
                UpdatedAt
            FROM {self.TABLE_NAME}
            WHERE 1 = 1
        """

        params: list[Any] = []

        if client_id not in (None, ""):
            sql += """
                AND ClientKey = ?
            """
            params.append(
                self._required_int(
                    client_id,
                    "ClientID",
                )
            )

        if not include_disabled:
            sql += """
                AND AutomationEnabled = 1
            """

        sql += """
            ORDER BY
                ClientKey,
                CASE
                    WHEN ProjectID IS NULL THEN 0
                    ELSE 1
                END,
                ProjectID;
        """

        rows = self.db.fetch_all(
            sql,
            tuple(params),
        )

        return [
            self._map_row(row)
            for row in rows
        ]

    def get_automation_settings(
        self,
        client_id: int,
        project_id: int | None = None,
    ) -> dict[str, Any]:
        """
        Recupera la configuración efectiva.

        Prioridad:
            1. Configuración específica del proyecto.
            2. Configuración general del cliente.
            3. Configuración predeterminada en Python.
        """

        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )

        normalized_project_id = self._optional_int(
            project_id
        )

        sql = f"""
            SELECT TOP 1
                SettingID,
                ClientKey AS ClientID,
                ProjectID,
                AutomationEnabled,
                AutomationMode,
                RunEveryMinutes,
                OnlyBusinessHours,
                StartHour,
                EndHour,
                MinimumDaysBetweenFollowups,
                TeamsAlertsEnabled,
                TeamsWebhookUrl,
                UpdatedBy,
                UpdatedAt
            FROM {self.TABLE_NAME}
            WHERE ClientKey = ?
              AND
              (
                    ProjectID = ?
                    OR ProjectID IS NULL
              )
            ORDER BY
                CASE
                    WHEN ProjectID = ? THEN 0
                    WHEN ProjectID IS NULL THEN 1
                    ELSE 2
                END,
                UpdatedAt DESC,
                SettingID DESC;
        """

        row = self.db.fetch_one(
            sql,
            (
                normalized_client_id,
                normalized_project_id,
                normalized_project_id,
            ),
        )

        if not row:
            defaults = dict(
                self.DEFAULT_SETTINGS
            )

            defaults["ClientID"] = (
                normalized_client_id
            )

            defaults["ProjectID"] = (
                normalized_project_id
            )

            return defaults

        return self._map_row(row)

    def get_exact_settings(
        self,
        client_id: int,
        project_id: int | None = None,
    ) -> dict[str, Any] | None:
        """
        Recupera únicamente la configuración exacta.

        No utiliza fallback hacia ProjectID NULL.
        """

        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )

        normalized_project_id = self._optional_int(
            project_id
        )

        if normalized_project_id is None:
            project_filter = """
                ProjectID IS NULL
            """

            params = (
                normalized_client_id,
            )

        else:
            project_filter = """
                ProjectID = ?
            """

            params = (
                normalized_client_id,
                normalized_project_id,
            )

        sql = f"""
            SELECT TOP 1
                SettingID,
                ClientKey AS ClientID,
                ProjectID,
                AutomationEnabled,
                AutomationMode,
                RunEveryMinutes,
                OnlyBusinessHours,
                StartHour,
                EndHour,
                MinimumDaysBetweenFollowups,
                TeamsAlertsEnabled,
                TeamsWebhookUrl,
                UpdatedBy,
                UpdatedAt
            FROM {self.TABLE_NAME}
            WHERE ClientKey = ?
              AND {project_filter}
            ORDER BY
                UpdatedAt DESC,
                SettingID DESC;
        """

        row = self.db.fetch_one(
            sql,
            params,
        )

        if not row:
            return None

        return self._map_row(row)

    # =========================================================
    # GUARDAR CONFIGURACIÓN
    # =========================================================

    def save_automation_settings(
        self,
        client_id: int,
        project_id: int | None,
        automation_enabled: bool,
        automation_mode: str,
        run_every_minutes: int,
        only_business_hours: bool,
        start_hour: str | time,
        end_hour: str | time,
        minimum_days_between_followups: int,
        teams_alerts_enabled: bool,
        teams_webhook_url: str | None,
        updated_by: str | int | None,
    ) -> int:
        """
        Inserta o actualiza la configuración.

        Returns:
            SettingID insertado o actualizado.
        """

        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )

        normalized_project_id = self._optional_int(
            project_id
        )

        normalized_mode = self._normalize_mode(
            automation_mode
        )

        normalized_run_every = (
            self._normalize_run_every_minutes(
                run_every_minutes
            )
        )

        normalized_start_hour = (
            self._normalize_hour(
                start_hour,
                default="08:00",
            )
        )

        normalized_end_hour = (
            self._normalize_hour(
                end_hour,
                default="18:00",
            )
        )

        self._validate_business_hours(
            start_hour=normalized_start_hour,
            end_hour=normalized_end_hour,
        )

        normalized_minimum_days = (
            self._normalize_minimum_days(
                minimum_days_between_followups
            )
        )

        normalized_webhook = self._optional_text(
            teams_webhook_url
        )

        if (
            teams_alerts_enabled
            and not normalized_webhook
        ):
            raise ValueError(
                "TeamsWebhookUrl es obligatorio cuando "
                "TeamsAlertsEnabled está habilitado."
            )

        sql = f"""
            MERGE {self.TABLE_NAME} WITH (HOLDLOCK) AS Target
            USING
            (
                SELECT
                    ? AS ClientKey,
                    ? AS ProjectID
            ) AS Source
                ON Target.ClientKey = Source.ClientKey
               AND
               (
                    Target.ProjectID = Source.ProjectID
                    OR
                    (
                        Target.ProjectID IS NULL
                        AND Source.ProjectID IS NULL
                    )
               )

            WHEN MATCHED THEN
                UPDATE SET
                    AutomationEnabled = ?,
                    AutomationMode = ?,
                    RunEveryMinutes = ?,
                    OnlyBusinessHours = ?,
                    StartHour = ?,
                    EndHour = ?,
                    MinimumDaysBetweenFollowups = ?,
                    TeamsAlertsEnabled = ?,
                    TeamsWebhookUrl = ?,
                    UpdatedBy = ?,
                    UpdatedAt = SYSDATETIME()

            WHEN NOT MATCHED THEN
                INSERT
                (
                    ClientKey,
                    ProjectID,
                    AutomationEnabled,
                    AutomationMode,
                    RunEveryMinutes,
                    OnlyBusinessHours,
                    StartHour,
                    EndHour,
                    MinimumDaysBetweenFollowups,
                    TeamsAlertsEnabled,
                    TeamsWebhookUrl,
                    UpdatedBy,
                    UpdatedAt
                )
                VALUES
                (
                    Source.ClientKey,
                    Source.ProjectID,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    SYSDATETIME()
                )

            OUTPUT INSERTED.SettingID;
        """

        setting_id = self.db.scalar(
            sql,
            (
                # Source
                normalized_client_id,
                normalized_project_id,

                # Update
                1 if automation_enabled else 0,
                normalized_mode,
                normalized_run_every,
                1 if only_business_hours else 0,
                normalized_start_hour,
                normalized_end_hour,
                normalized_minimum_days,
                1 if teams_alerts_enabled else 0,
                normalized_webhook,
                updated_by,

                # Insert
                1 if automation_enabled else 0,
                normalized_mode,
                normalized_run_every,
                1 if only_business_hours else 0,
                normalized_start_hour,
                normalized_end_hour,
                normalized_minimum_days,
                1 if teams_alerts_enabled else 0,
                normalized_webhook,
                updated_by,
            ),
        )

        if setting_id is None:
            raise RuntimeError(
                "No fue posible guardar AutomationSettings."
            )

        return int(setting_id)

    def save_from_dict(
        self,
        data: dict[str, Any],
        updated_by: str | int | None = None,
    ) -> int:
        """
        Guarda configuración desde un diccionario recibido
        por Flask o por otro servicio.
        """

        if not isinstance(data, dict):
            raise TypeError(
                "data debe ser un diccionario."
            )

        return self.save_automation_settings(
            client_id=data.get(
                "ClientID",
                data.get("ClientKey"),
            ),
            project_id=data.get("ProjectID"),
            automation_enabled=self._to_bool(
                data.get(
                    "AutomationEnabled",
                    False,
                )
            ),
            automation_mode=data.get(
                "AutomationMode",
                "DRAFT",
            ),
            run_every_minutes=data.get(
                "RunEveryMinutes",
                30,
            ),
            only_business_hours=self._to_bool(
                data.get(
                    "OnlyBusinessHours",
                    True,
                )
            ),
            start_hour=data.get(
                "StartHour",
                "08:00",
            ),
            end_hour=data.get(
                "EndHour",
                "18:00",
            ),
            minimum_days_between_followups=data.get(
                "MinimumDaysBetweenFollowups",
                5,
            ),
            teams_alerts_enabled=self._to_bool(
                data.get(
                    "TeamsAlertsEnabled",
                    False,
                )
            ),
            teams_webhook_url=data.get(
                "TeamsWebhookUrl"
            ),
            updated_by=(
                updated_by
                if updated_by is not None
                else data.get("UpdatedBy")
            ),
        )

    # =========================================================
    # ACTIVAR / DESACTIVAR
    # =========================================================

    def set_automation_enabled(
        self,
        client_id: int,
        project_id: int | None,
        enabled: bool,
        updated_by: str | int | None = None,
    ) -> int:
        """
        Activa o desactiva una configuración exacta.

        Si no existe, crea una configuración con valores default.
        """

        current = self.get_exact_settings(
            client_id=client_id,
            project_id=project_id,
        )

        if current:
            return self.save_automation_settings(
                client_id=client_id,
                project_id=project_id,
                automation_enabled=enabled,
                automation_mode=current.get(
                    "AutomationMode",
                    "DRAFT",
                ),
                run_every_minutes=current.get(
                    "RunEveryMinutes",
                    30,
                ),
                only_business_hours=current.get(
                    "OnlyBusinessHours",
                    True,
                ),
                start_hour=current.get(
                    "StartHour",
                    "08:00",
                ),
                end_hour=current.get(
                    "EndHour",
                    "18:00",
                ),
                minimum_days_between_followups=current.get(
                    "MinimumDaysBetweenFollowups",
                    5,
                ),
                teams_alerts_enabled=current.get(
                    "TeamsAlertsEnabled",
                    False,
                ),
                teams_webhook_url=current.get(
                    "TeamsWebhookUrl"
                ),
                updated_by=updated_by,
            )

        return self.save_automation_settings(
            client_id=client_id,
            project_id=project_id,
            automation_enabled=enabled,
            automation_mode="DRAFT",
            run_every_minutes=30,
            only_business_hours=True,
            start_hour="08:00",
            end_hour="18:00",
            minimum_days_between_followups=5,
            teams_alerts_enabled=False,
            teams_webhook_url=None,
            updated_by=updated_by,
        )

    def delete_settings(
        self,
        client_id: int,
        project_id: int | None = None,
    ) -> int:
        """
        Elimina la configuración exacta.

        Si se elimina una configuración de proyecto, la consulta
        volverá a utilizar la configuración general del cliente.
        """

        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )

        normalized_project_id = self._optional_int(
            project_id
        )

        if normalized_project_id is None:
            sql = f"""
                DELETE FROM {self.TABLE_NAME}
                WHERE ClientKey = ?
                  AND ProjectID IS NULL;
            """

            params = (
                normalized_client_id,
            )

        else:
            sql = f"""
                DELETE FROM {self.TABLE_NAME}
                WHERE ClientKey = ?
                  AND ProjectID = ?;
            """

            params = (
                normalized_client_id,
                normalized_project_id,
            )

        return self.db.execute(
            sql,
            params,
        )

    # =========================================================
    # QUICK GETTERS
    # =========================================================

    def is_automation_enabled(
        self,
        client_id: int,
        project_id: int | None = None,
    ) -> bool:
        settings = self.get_automation_settings(
            client_id=client_id,
            project_id=project_id,
        )

        return bool(
            settings.get(
                "AutomationEnabled",
                False,
            )
        )

    def get_run_every_minutes(
        self,
        client_id: int,
        project_id: int | None = None,
    ) -> int:
        settings = self.get_automation_settings(
            client_id=client_id,
            project_id=project_id,
        )

        return int(
            settings.get(
                "RunEveryMinutes",
                30,
            )
        )

    def get_automation_mode(
        self,
        client_id: int,
        project_id: int | None = None,
    ) -> str:
        settings = self.get_automation_settings(
            client_id=client_id,
            project_id=project_id,
        )

        return str(
            settings.get(
                "AutomationMode",
                "DRAFT",
            )
        ).upper()

    def get_minimum_days_between_followups(
        self,
        client_id: int,
        project_id: int | None = None,
    ) -> int:
        settings = self.get_automation_settings(
            client_id=client_id,
            project_id=project_id,
        )

        return int(
            settings.get(
                "MinimumDaysBetweenFollowups",
                5,
            )
        )

    def is_within_business_hours(
        self,
        client_id: int,
        project_id: int | None = None,
        current_time: time | None = None,
    ) -> bool:
        """
        Valida si la hora actual está dentro del horario permitido.

        Si OnlyBusinessHours=False, devuelve True.
        """

        settings = self.get_automation_settings(
            client_id=client_id,
            project_id=project_id,
        )

        if not settings.get(
            "OnlyBusinessHours",
            True,
        ):
            return True

        now_time = current_time or time.now()

        start_value = self._parse_time(
            settings.get(
                "StartHour",
                "08:00",
            )
        )

        end_value = self._parse_time(
            settings.get(
                "EndHour",
                "18:00",
            )
        )

        if start_value <= end_value:
            return (
                start_value
                <= now_time
                <= end_value
            )

        # Permite horarios nocturnos, por ejemplo:
        # 22:00 a 06:00.
        return (
            now_time >= start_value
            or now_time <= end_value
        )

    # =========================================================
    # MAPEO
    # =========================================================

    def _map_row(
        self,
        row: dict[str, Any],
    ) -> dict[str, Any]:
        return {
            "SettingID": row.get("SettingID"),
            "ClientID": row.get("ClientID"),
            "ProjectID": row.get("ProjectID"),

            "AutomationEnabled": self._to_bool(
                row.get("AutomationEnabled")
            ),

            "AutomationMode": self._normalize_mode(
                row.get("AutomationMode")
                or "DRAFT"
            ),

            "RunEveryMinutes":
                self._normalize_run_every_minutes(
                    row.get("RunEveryMinutes")
                    or 30
                ),

            "OnlyBusinessHours": self._to_bool(
                row.get("OnlyBusinessHours")
            ),

            "StartHour": self._format_hour(
                row.get("StartHour"),
                default="08:00",
            ),

            "EndHour": self._format_hour(
                row.get("EndHour"),
                default="18:00",
            ),

            "MinimumDaysBetweenFollowups":
                self._normalize_minimum_days(
                    row.get(
                        "MinimumDaysBetweenFollowups"
                    )
                    or 5
                ),

            "TeamsAlertsEnabled": self._to_bool(
                row.get("TeamsAlertsEnabled")
            ),

            "TeamsWebhookUrl": row.get(
                "TeamsWebhookUrl"
            ),

            "UpdatedBy": row.get("UpdatedBy"),
            "UpdatedAt": row.get("UpdatedAt"),
        }

    # =========================================================
    # VALIDACIONES
    # =========================================================

    @classmethod
    def _normalize_mode(
        cls,
        value: Any,
    ) -> str:
        mode = str(
            value or "DRAFT"
        ).strip().upper()

        aliases = {
            "AUTO": "SEND",
            "AUTOMATIC": "SEND",
            "AUTOMATICO": "SEND",
            "AUTOMÁTICO": "SEND",
            "BORRADOR": "DRAFT",
        }

        mode = aliases.get(
            mode,
            mode,
        )

        if mode not in cls.VALID_AUTOMATION_MODES:
            raise ValueError(
                "AutomationMode no válido. "
                "Valores permitidos: "
                + ", ".join(
                    sorted(
                        cls.VALID_AUTOMATION_MODES
                    )
                )
            )

        return mode

    @staticmethod
    def _normalize_run_every_minutes(
        value: Any,
    ) -> int:
        try:
            minutes = int(value)
        except (
            TypeError,
            ValueError,
        ):
            minutes = 30

        if minutes < 1:
            return 1

        if minutes > 1440:
            return 1440

        return minutes

    @staticmethod
    def _normalize_minimum_days(
        value: Any,
    ) -> int:
        try:
            days = int(value)
        except (
            TypeError,
            ValueError,
        ):
            days = 5

        if days < 0:
            return 0

        if days > 365:
            return 365

        return days

    @classmethod
    def _normalize_hour(
        cls,
        value: Any,
        default: str,
    ) -> str:
        parsed = cls._parse_time(
            value,
            default=default,
        )

        return parsed.strftime(
            "%H:%M"
        )

    @classmethod
    def _format_hour(
        cls,
        value: Any,
        default: str,
    ) -> str:
        return cls._normalize_hour(
            value,
            default,
        )

    @staticmethod
    def _parse_time(
        value: Any,
        default: str = "00:00",
    ) -> time:
        if isinstance(value, time):
            return value.replace(
                second=0,
                microsecond=0,
            )

        text = str(
            value or default
        ).strip()

        if "." in text:
            text = text.split(".")[0]

        formats = (
            "%H:%M:%S",
            "%H:%M",
        )

        from datetime import datetime

        for format_text in formats:
            try:
                return datetime.strptime(
                    text,
                    format_text,
                ).time()
            except ValueError:
                continue

        try:
            return datetime.strptime(
                default,
                "%H:%M",
            ).time()
        except ValueError:
            return time(0, 0)

    @classmethod
    def _validate_business_hours(
        cls,
        start_hour: Any,
        end_hour: Any,
    ) -> None:
        start_value = cls._parse_time(
            start_hour
        )

        end_value = cls._parse_time(
            end_hour
        )

        if start_value == end_value:
            raise ValueError(
                "StartHour y EndHour no pueden ser iguales."
            )

    @staticmethod
    def _required_int(
        value: Any,
        field_name: str,
    ) -> int:
        if value in (None, ""):
            raise ValueError(
                f"{field_name} es obligatorio."
            )

        try:
            return int(value)
        except (
            TypeError,
            ValueError,
        ) as error:
            raise ValueError(
                f"{field_name} debe ser numérico."
            ) from error

    @staticmethod
    def _optional_int(
        value: Any,
    ) -> int | None:
        if value in (None, ""):
            return None

        try:
            return int(value)
        except (
            TypeError,
            ValueError,
        ):
            return None

    @staticmethod
    def _optional_text(
        value: Any,
    ) -> str | None:
        text = str(
            value or ""
        ).strip()

        return text or None

    @staticmethod
    def _to_bool(
        value: Any,
    ) -> bool:
        if isinstance(value, bool):
            return value

        if isinstance(value, (int, float)):
            return value != 0

        normalized = str(
            value or ""
        ).strip().lower()

        return normalized in {
            "1",
            "true",
            "yes",
            "y",
            "si",
            "sí",
            "on",
            "enabled",
        }

