from __future__ import annotations 

import platform
import socket
import sys

from datetime import datetime
from typing import Any

from database.connection import Database
from database.db_config import DB_CONFIG_AUDITFOLLOWUP


class AutomationLogRepository:
    """
    Repositorio para registrar ejecuciones completas
    de la automatización de Follow-up.

    Registra:

        - Cliente.
        - Proyecto.
        - Modo de ejecución.
        - Tipo de ejecución.
        - Usuario que inició el proceso.
        - SessionID.
        - Equipo.
        - Host.
        - Versión de Python.
        - Casos totales.
        - Casos procesados.
        - Casos con error.
        - Drafts creados.
        - Correos enviados.
        - Casos omitidos.
        - Duración.
        - Estado.
        - Mensaje de error.
    """

    VALID_STATUSES = {
        "RUNNING",
        "COMPLETED",
        "COMPLETED_WITH_ERRORS",
        "FAILED",
        "CANCELLED",
    }

    def __init__(
        self,
        db: Database | None = None,
    ):
        self.db = db or Database(
            DB_CONFIG_AUDITFOLLOWUP
        )

    # =========================================================
    # INICIO DE EJECUCIÓN
    # =========================================================

    def start_execution(
        self,
        client_id: int,
        project_id: int | None = None,
        execution_mode: str = "MANUAL",
        execution_type: str = "FOLLOWUP",
        triggered_by: int | str | None = None,
        session_id: str | None = None,
        host_name: str | None = None,
        machine_name: str | None = None,
        python_version: str | None = None,
    ) -> int:
        """
        Inicia una ejecución y devuelve el ExecutionID.
        """

        if client_id in (None, ""):
            raise ValueError(
                "ClientID es obligatorio para iniciar la ejecución."
            )

        normalized_execution_mode = self._normalize_text(
            execution_mode,
            default="MANUAL",
        ).upper()

        normalized_execution_type = self._normalize_text(
            execution_type,
            default="FOLLOWUP",
        ).upper()

        normalized_session_id = self._normalize_optional_text(
            session_id
        )

        resolved_host_name = (
            self._normalize_optional_text(host_name)
            or self._get_host_name()
        )

        resolved_machine_name = (
            self._normalize_optional_text(machine_name)
            or self._get_machine_name()
        )

        resolved_python_version = (
            self._normalize_optional_text(python_version)
            or self._get_python_version()
        )

        sql = """
            INSERT INTO dbo.AutomationExecutionLog
            (
                ClientID,
                ProjectID,
                ExecutionMode,
                ExecutionType,
                Status,
                TriggeredBy,
                StartedAt,
                TotalCases,
                ProcessedCases,
                ErrorCases,
                DraftCases,
                SentCases,
                SkippedCases,
                ErrorMessage,
                DurationSeconds,
                HostName,
                MachineName,
                PythonVersion,
                SessionID
            )
            OUTPUT INSERTED.ExecutionID
            VALUES
            (
                ?, ?, ?, ?, 'RUNNING', ?, SYSDATETIME(),
                0, 0, 0, 0, 0, 0,
                NULL, NULL, ?, ?, ?, ?
            );
        """

        execution_id = self.db.scalar(
            sql,
            (
                int(client_id),
                project_id,
                normalized_execution_mode,
                normalized_execution_type,
                triggered_by,
                resolved_host_name,
                resolved_machine_name,
                resolved_python_version,
                normalized_session_id,
            ),
        )

        if execution_id is None:
            raise RuntimeError(
                "No fue posible obtener el ExecutionID."
            )

        return int(execution_id)

    # =========================================================
    # ACTUALIZACIÓN GENERAL
    # =========================================================

    def update_execution(
        self,
        execution_id: int,
        status: str,
        total_cases: int = 0,
        processed_cases: int = 0,
        error_cases: int = 0,
        draft_cases: int = 0,
        sent_cases: int = 0,
        skipped_cases: int = 0,
        error_message: str | None = None,
        finished_at: bool = True,
    ) -> int:
        """
        Actualiza el resultado de una ejecución.
        """

        if execution_id in (None, ""):
            raise ValueError(
                "ExecutionID es obligatorio."
            )

        normalized_status = self._normalize_status(
            status
        )

        normalized_total = self._normalize_count(
            total_cases
        )

        normalized_processed = self._normalize_count(
            processed_cases
        )

        normalized_errors = self._normalize_count(
            error_cases
        )

        normalized_drafts = self._normalize_count(
            draft_cases
        )

        normalized_sent = self._normalize_count(
            sent_cases
        )

        normalized_skipped = self._normalize_count(
            skipped_cases
        )

        normalized_error_message = (
            self._normalize_optional_text(
                error_message
            )
        )

        sql = """
            UPDATE dbo.AutomationExecutionLog
            SET
                Status = ?,
                TotalCases = ?,
                ProcessedCases = ?,
                ErrorCases = ?,
                DraftCases = ?,
                SentCases = ?,
                SkippedCases = ?,
                ErrorMessage = ?,
                FinishedAt =
                    CASE
                        WHEN ? = 1
                            THEN SYSDATETIME()
                        ELSE FinishedAt
                    END,
                DurationSeconds =
                    CASE
                        WHEN ? = 1
                            THEN DATEDIFF(
                                SECOND,
                                StartedAt,
                                SYSDATETIME()
                            )
                        ELSE DurationSeconds
                    END
            WHERE ExecutionID = ?;
        """

        return self.db.execute(
            sql,
            (
                normalized_status,
                normalized_total,
                normalized_processed,
                normalized_errors,
                normalized_drafts,
                normalized_sent,
                normalized_skipped,
                normalized_error_message,
                1 if finished_at else 0,
                1 if finished_at else 0,
                int(execution_id),
            ),
        )

    # =========================================================
    # ESTADOS DE EJECUCIÓN
    # =========================================================

    def mark_running(
        self,
        execution_id: int,
        total_cases: int = 0,
        processed_cases: int = 0,
        error_cases: int = 0,
        draft_cases: int = 0,
        sent_cases: int = 0,
        skipped_cases: int = 0,
        error_message: str | None = None,
    ) -> int:
        """
        Actualiza una ejecución sin finalizarla.
        """

        return self.update_execution(
            execution_id=execution_id,
            status="RUNNING",
            total_cases=total_cases,
            processed_cases=processed_cases,
            error_cases=error_cases,
            draft_cases=draft_cases,
            sent_cases=sent_cases,
            skipped_cases=skipped_cases,
            error_message=error_message,
            finished_at=False,
        )

    def mark_completed(
        self,
        execution_id: int,
        total_cases: int,
        processed_cases: int,
        draft_cases: int = 0,
        sent_cases: int = 0,
        skipped_cases: int = 0,
    ) -> int:
        """
        Marca la ejecución como completada sin errores.
        """

        return self.update_execution(
            execution_id=execution_id,
            status="COMPLETED",
            total_cases=total_cases,
            processed_cases=processed_cases,
            error_cases=0,
            draft_cases=draft_cases,
            sent_cases=sent_cases,
            skipped_cases=skipped_cases,
            error_message=None,
            finished_at=True,
        )

    def mark_completed_with_errors(
        self,
        execution_id: int,
        total_cases: int,
        processed_cases: int,
        error_cases: int,
        draft_cases: int = 0,
        sent_cases: int = 0,
        skipped_cases: int = 0,
        error_message: str | None = None,
    ) -> int:
        """
        Marca una ejecución terminada parcialmente.
        """

        return self.update_execution(
            execution_id=execution_id,
            status="COMPLETED_WITH_ERRORS",
            total_cases=total_cases,
            processed_cases=processed_cases,
            error_cases=error_cases,
            draft_cases=draft_cases,
            sent_cases=sent_cases,
            skipped_cases=skipped_cases,
            error_message=error_message,
            finished_at=True,
        )

    def mark_failed(
        self,
        execution_id: int,
        error_message: str,
        total_cases: int = 0,
        processed_cases: int = 0,
        error_cases: int = 1,
        draft_cases: int = 0,
        sent_cases: int = 0,
        skipped_cases: int = 0,
    ) -> int:
        """
        Marca una ejecución como fallida.
        """

        return self.update_execution(
            execution_id=execution_id,
            status="FAILED",
            total_cases=total_cases,
            processed_cases=processed_cases,
            error_cases=error_cases,
            draft_cases=draft_cases,
            sent_cases=sent_cases,
            skipped_cases=skipped_cases,
            error_message=error_message,
            finished_at=True,
        )

    def mark_cancelled(
        self,
        execution_id: int,
        total_cases: int = 0,
        processed_cases: int = 0,
        error_cases: int = 0,
        draft_cases: int = 0,
        sent_cases: int = 0,
        skipped_cases: int = 0,
        error_message: str | None = None,
    ) -> int:
        """
        Marca una ejecución como cancelada.
        """

        return self.update_execution(
            execution_id=execution_id,
            status="CANCELLED",
            total_cases=total_cases,
            processed_cases=processed_cases,
            error_cases=error_cases,
            draft_cases=draft_cases,
            sent_cases=sent_cases,
            skipped_cases=skipped_cases,
            error_message=error_message,
            finished_at=True,
        )

    # =========================================================
    # CONSULTAS
    # =========================================================

    def get_execution(
        self,
        execution_id: int,
    ) -> dict[str, Any] | None:
        """
        Devuelve una ejecución por ID.
        """

        if execution_id in (None, ""):
            raise ValueError(
                "ExecutionID es obligatorio."
            )

        sql = """
            SELECT
                ExecutionID,
                ClientID,
                ProjectID,
                StartedAt,
                FinishedAt,
                DurationSeconds,
                TotalCases,
                ProcessedCases,
                ErrorCases,
                DraftCases,
                SentCases,
                SkippedCases,
                ExecutionMode,
                ExecutionType,
                Status,
                TriggeredBy,
                ErrorMessage,
                HostName,
                MachineName,
                PythonVersion,
                SessionID,
                CreatedAt
            FROM dbo.AutomationExecutionLog
            WHERE ExecutionID = ?;
        """

        return self.db.fetch_one(
            sql,
            (
                int(execution_id),
            ),
        )

    def get_last_execution(
        self,
        client_id: int | None = None,
        project_id: int | None = None,
    ) -> dict[str, Any] | None:
        """
        Devuelve la última ejecución según filtros opcionales.
        """

        sql = """
            SELECT TOP 1
                ExecutionID,
                ClientID,
                ProjectID,
                StartedAt,
                FinishedAt,
                DurationSeconds,
                TotalCases,
                ProcessedCases,
                ErrorCases,
                DraftCases,
                SentCases,
                SkippedCases,
                ExecutionMode,
                ExecutionType,
                Status,
                TriggeredBy,
                ErrorMessage,
                HostName,
                MachineName,
                PythonVersion,
                SessionID,
                CreatedAt
            FROM dbo.AutomationExecutionLog
            WHERE 1 = 1
        """

        params: list[Any] = []

        if client_id not in (None, ""):
            sql += """
                AND ClientID = ?
            """
            params.append(
                int(client_id)
            )

        if project_id not in (None, ""):
            sql += """
                AND ProjectID = ?
            """
            params.append(
                int(project_id)
            )

        sql += """
            ORDER BY
                StartedAt DESC,
                ExecutionID DESC;
        """

        return self.db.fetch_one(
            sql,
            tuple(params),
        )

    def get_recent_logs(
        self,
        client_id: int | None = None,
        project_id: int | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """
        Devuelve ejecuciones recientes.
        """

        safe_limit = self._normalize_limit(
            limit
        )

        sql = f"""
            SELECT TOP ({safe_limit})
                ExecutionID,
                ClientID,
                ProjectID,
                StartedAt,
                FinishedAt,
                DurationSeconds,
                TotalCases,
                ProcessedCases,
                ErrorCases,
                DraftCases,
                SentCases,
                SkippedCases,
                ExecutionMode,
                ExecutionType,
                Status,
                TriggeredBy,
                ErrorMessage,
                HostName,
                MachineName,
                PythonVersion,
                SessionID,
                CreatedAt
            FROM dbo.AutomationExecutionLog
            WHERE 1 = 1
        """

        params: list[Any] = []

        if client_id not in (None, ""):
            sql += """
                AND ClientID = ?
            """
            params.append(
                int(client_id)
            )

        if project_id not in (None, ""):
            sql += """
                AND ProjectID = ?
            """
            params.append(
                int(project_id)
            )

        if status not in (None, ""):
            sql += """
                AND Status = ?
            """
            params.append(
                self._normalize_status(status)
            )

        sql += """
            ORDER BY
                StartedAt DESC,
                ExecutionID DESC;
        """

        return self.db.fetch_all(
            sql,
            tuple(params),
        )

    def get_running(
        self,
        client_id: int | None = None,
        project_id: int | None = None,
    ) -> list[dict[str, Any]]:
        """
        Devuelve ejecuciones activas.
        """

        sql = """
            SELECT
                ExecutionID,
                ClientID,
                ProjectID,
                StartedAt,
                FinishedAt,
                DurationSeconds,
                TotalCases,
                ProcessedCases,
                ErrorCases,
                DraftCases,
                SentCases,
                SkippedCases,
                ExecutionMode,
                ExecutionType,
                Status,
                TriggeredBy,
                ErrorMessage,
                HostName,
                MachineName,
                PythonVersion,
                SessionID,
                CreatedAt
            FROM dbo.AutomationExecutionLog
            WHERE Status = 'RUNNING'
        """

        params: list[Any] = []

        if client_id not in (None, ""):
            sql += """
                AND ClientID = ?
            """
            params.append(
                int(client_id)
            )

        if project_id not in (None, ""):
            sql += """
                AND ProjectID = ?
            """
            params.append(
                int(project_id)
            )

        sql += """
            ORDER BY
                StartedAt ASC,
                ExecutionID ASC;
        """

        return self.db.fetch_all(
            sql,
            tuple(params),
        )

    def get_today(
        self,
        client_id: int | None = None,
        project_id: int | None = None,
    ) -> list[dict[str, Any]]:
        """
        Devuelve todas las ejecuciones iniciadas hoy.
        """

        sql = """
            SELECT
                ExecutionID,
                ClientID,
                ProjectID,
                StartedAt,
                FinishedAt,
                DurationSeconds,
                TotalCases,
                ProcessedCases,
                ErrorCases,
                DraftCases,
                SentCases,
                SkippedCases,
                ExecutionMode,
                ExecutionType,
                Status,
                TriggeredBy,
                ErrorMessage,
                HostName,
                MachineName,
                PythonVersion,
                SessionID,
                CreatedAt
            FROM dbo.AutomationExecutionLog
            WHERE StartedAt >= CONVERT(date, SYSDATETIME())
              AND StartedAt < DATEADD(
                    DAY,
                    1,
                    CONVERT(date, SYSDATETIME())
                  )
        """

        params: list[Any] = []

        if client_id not in (None, ""):
            sql += """
                AND ClientID = ?
            """
            params.append(
                int(client_id)
            )

        if project_id not in (None, ""):
            sql += """
                AND ProjectID = ?
            """
            params.append(
                int(project_id)
            )

        sql += """
            ORDER BY
                StartedAt DESC,
                ExecutionID DESC;
        """

        return self.db.fetch_all(
            sql,
            tuple(params),
        )

    # =========================================================
    # ESTADÍSTICAS
    # =========================================================

    def get_statistics(
        self,
        client_id: int | None = None,
        project_id: int | None = None,
        date_from: datetime | str | None = None,
        date_to: datetime | str | None = None,
    ) -> dict[str, Any]:
        """
        Devuelve un resumen agregado de ejecuciones.
        """

        sql = """
            SELECT
                COUNT(1) AS TotalExecutions,

                SUM(
                    CASE
                        WHEN Status = 'RUNNING'
                            THEN 1
                        ELSE 0
                    END
                ) AS RunningExecutions,

                SUM(
                    CASE
                        WHEN Status = 'COMPLETED'
                            THEN 1
                        ELSE 0
                    END
                ) AS CompletedExecutions,

                SUM(
                    CASE
                        WHEN Status = 'COMPLETED_WITH_ERRORS'
                            THEN 1
                        ELSE 0
                    END
                ) AS CompletedWithErrorsExecutions,

                SUM(
                    CASE
                        WHEN Status = 'FAILED'
                            THEN 1
                        ELSE 0
                    END
                ) AS FailedExecutions,

                SUM(
                    CASE
                        WHEN Status = 'CANCELLED'
                            THEN 1
                        ELSE 0
                    END
                ) AS CancelledExecutions,

                ISNULL(SUM(TotalCases), 0) AS TotalCases,
                ISNULL(SUM(ProcessedCases), 0) AS ProcessedCases,
                ISNULL(SUM(ErrorCases), 0) AS ErrorCases,
                ISNULL(SUM(DraftCases), 0) AS DraftCases,
                ISNULL(SUM(SentCases), 0) AS SentCases,
                ISNULL(SUM(SkippedCases), 0) AS SkippedCases,

                ISNULL(
                    AVG(
                        CAST(DurationSeconds AS DECIMAL(18,2))
                    ),
                    0
                ) AS AverageDurationSeconds,

                ISNULL(
                    MAX(DurationSeconds),
                    0
                ) AS MaximumDurationSeconds,

                ISNULL(
                    MIN(DurationSeconds),
                    0
                ) AS MinimumDurationSeconds

            FROM dbo.AutomationExecutionLog
            WHERE 1 = 1
        """

        params: list[Any] = []

        if client_id not in (None, ""):
            sql += """
                AND ClientID = ?
            """
            params.append(
                int(client_id)
            )

        if project_id not in (None, ""):
            sql += """
                AND ProjectID = ?
            """
            params.append(
                int(project_id)
            )

        if date_from not in (None, ""):
            sql += """
                AND StartedAt >= ?
            """
            params.append(
                date_from
            )

        if date_to not in (None, ""):
            sql += """
                AND StartedAt < DATEADD(DAY, 1, ?)
            """
            params.append(
                date_to
            )

        result = self.db.fetch_one(
            sql,
            tuple(params),
        )

        return result or {
            "TotalExecutions": 0,
            "RunningExecutions": 0,
            "CompletedExecutions": 0,
            "CompletedWithErrorsExecutions": 0,
            "FailedExecutions": 0,
            "CancelledExecutions": 0,
            "TotalCases": 0,
            "ProcessedCases": 0,
            "ErrorCases": 0,
            "DraftCases": 0,
            "SentCases": 0,
            "SkippedCases": 0,
            "AverageDurationSeconds": 0,
            "MaximumDurationSeconds": 0,
            "MinimumDurationSeconds": 0,
        }

    # =========================================================
    # FUNCIONES AUXILIARES
    # =========================================================

    @classmethod
    def _normalize_status(
        cls,
        value: Any,
    ) -> str:
        status = str(
            value or ""
        ).strip().upper()

        if status not in cls.VALID_STATUSES:
            raise ValueError(
                f"Status no válido: {status}"
            )

        return status

    @staticmethod
    def _normalize_count(
        value: Any,
    ) -> int:
        try:
            normalized = int(value or 0)
        except (
            TypeError,
            ValueError,
        ):
            normalized = 0

        return max(
            normalized,
            0,
        )

    @staticmethod
    def _normalize_limit(
        value: Any,
    ) -> int:
        try:
            normalized = int(value or 50)
        except (
            TypeError,
            ValueError,
        ):
            normalized = 50

        if normalized < 1:
            return 1

        if normalized > 1000:
            return 1000

        return normalized

    @staticmethod
    def _normalize_text(
        value: Any,
        default: str = "",
    ) -> str:
        text = str(
            value or default
        ).strip()

        return text or default

    @staticmethod
    def _normalize_optional_text(
        value: Any,
    ) -> str | None:
        text = str(
            value or ""
        ).strip()

        return text or None

    @staticmethod
    def _get_host_name() -> str:
        try:
            return socket.gethostname()
        except Exception:
            return ""

    @staticmethod
    def _get_machine_name() -> str:
        try:
            return platform.node()
        except Exception:
            return ""

    @staticmethod
    def _get_python_version() -> str:
        try:
            return sys.version.split()[0]
        except Exception:
            return ""
