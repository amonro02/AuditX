from __future__ import annotations
 
from datetime import datetime
from typing import Any
 
from database.connection import Database
from database.db_config import DB_CONFIG_AUDITFOLLOWUP
 
 
class HistoryRepository:
    """
    Repositorio del historial operativo de Follow-up.
 
    Registra cada acción realizada sobre un caso:
 
        - Draft generado.
        - Correo mostrado.
        - Correo enviado.
        - Respuesta generada.
        - Error.
        - Acción manual o automática.
 
    También conserva información de Outlook para poder
    localizar posteriormente el correo o la conversación.
    """
 
    VALID_RESULTS = {
        "DRAFT",
        "DISPLAYED",
        "SENT",
        "REPLIED",
        "CANCELLED",
        "SKIPPED",
        "ERROR",
        "SUCCESS",
    }
 
    VALID_SEND_MODES = {
        "DRAFT",
        "SEND",
        "AUTO",
        "MANUAL",
        "REPLY",
        "ERROR",
    }
 
    def __init__(
        self,
        db: Database | None = None,
    ):
        self.db = db or Database(
            DB_CONFIG_AUDITFOLLOWUP
        )
 
    # =========================================================
    # INSERTAR HISTORIAL
    # =========================================================
 
    def insert_history(
        self,
        case_id: int,
        client_id: int,
        project_id: int | None = None,
        rule_id: int | None = None,
        template_code: str | None = None,
        session_id: str | None = None,
        send_mode: str | None = None,
        result: str | None = None,
        subject: str | None = None,
        email_to: str | None = None,
        email_cc: str | None = None,
        email_bcc: str | None = None,
        outlook_entry_id: str | None = None,
        message_id: str | None = None,
        conversation_id: str | None = None,
        sent_date: datetime | None = None,
        error_message: str | None = None,
        created_by: int | str | None = None,
    ) -> int:
        """
        Inserta un registro en dbo.FollowUpHistory.
 
        Nota:
            En la base se utiliza ClientKey.
            En Python se mantiene el nombre client_id.
        """
 
        normalized_case_id = self._required_int(
            case_id,
            "CaseID",
        )
 
        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )
 
        normalized_send_mode = self._normalize_send_mode(
            send_mode
        )
 
        normalized_result = self._normalize_result(
            result
        )
 
        sql = """
            INSERT INTO dbo.FollowUpHistory
            (
                CaseID,
                ClientKey,
                ProjectID,
                RuleID,
                TemplateCode,
                SessionID,
                SendMode,
                Result,
                Subject,
                EmailTo,
                EmailCC,
                EmailBCC,
                OutlookEntryID,
                MessageID,
                ConversationID,
                SentDate,
                ErrorMessage,
                CreatedBy,
                CreatedAt
            )
            OUTPUT INSERTED.HistoryID
            VALUES
            (
                ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?,
                SYSDATETIME()
            );
        """
 
        history_id = self.db.scalar(
            sql,
            (
                normalized_case_id,
                normalized_client_id,
                self._optional_int(project_id),
                self._optional_int(rule_id),
                self._optional_text(template_code),
                self._optional_text(session_id),
                normalized_send_mode,
                normalized_result,
                self._optional_text(subject),
                self._optional_text(email_to),
                self._optional_text(email_cc),
                self._optional_text(email_bcc),
                self._optional_text(outlook_entry_id),
                self._optional_text(message_id),
                self._optional_text(conversation_id),
                sent_date,
                self._optional_text(error_message),
                created_by,
            ),
        )
 
        if history_id is None:
            raise RuntimeError(
                "No fue posible obtener el HistoryID."
            )
 
        return int(history_id)
 
    # =========================================================
    # MÉTODOS DE CONVENIENCIA
    # =========================================================
 
    def add_draft(
        self,
        case_id: int,
        client_id: int,
        project_id: int | None = None,
        rule_id: int | None = None,
        template_code: str | None = None,
        session_id: str | None = None,
        subject: str | None = None,
        email_to: str | None = None,
        email_cc: str | None = None,
        email_bcc: str | None = None,
        outlook_entry_id: str | None = None,
        conversation_id: str | None = None,
        created_by: int | str | None = None,
    ) -> int:
        """
        Registra un draft creado correctamente.
        """
 
        return self.insert_history(
            case_id=case_id,
            client_id=client_id,
            project_id=project_id,
            rule_id=rule_id,
            template_code=template_code,
            session_id=session_id,
            send_mode="DRAFT",
            result="DRAFT",
            subject=subject,
            email_to=email_to,
            email_cc=email_cc,
            email_bcc=email_bcc,
            outlook_entry_id=outlook_entry_id,
            message_id=None,
            conversation_id=conversation_id,
            sent_date=None,
            error_message=None,
            created_by=created_by,
        )
 
    def add_sent(
        self,
        case_id: int,
        client_id: int,
        project_id: int | None = None,
        rule_id: int | None = None,
        template_code: str | None = None,
        session_id: str | None = None,
        send_mode: str = "SEND",
        subject: str | None = None,
        email_to: str | None = None,
        email_cc: str | None = None,
        email_bcc: str | None = None,
        outlook_entry_id: str | None = None,
        message_id: str | None = None,
        conversation_id: str | None = None,
        sent_date: datetime | None = None,
        created_by: int | str | None = None,
    ) -> int:
        """
        Registra un correo enviado.
        """
 
        return self.insert_history(
            case_id=case_id,
            client_id=client_id,
            project_id=project_id,
            rule_id=rule_id,
            template_code=template_code,
            session_id=session_id,
            send_mode=send_mode,
            result="SENT",
            subject=subject,
            email_to=email_to,
            email_cc=email_cc,
            email_bcc=email_bcc,
            outlook_entry_id=outlook_entry_id,
            message_id=message_id,
            conversation_id=conversation_id,
            sent_date=sent_date or datetime.now(),
            error_message=None,
            created_by=created_by,
        )
 
    def add_reply(
        self,
        case_id: int,
        client_id: int,
        project_id: int | None = None,
        rule_id: int | None = None,
        template_code: str | None = None,
        session_id: str | None = None,
        subject: str | None = None,
        email_to: str | None = None,
        email_cc: str | None = None,
        email_bcc: str | None = None,
        outlook_entry_id: str | None = None,
        message_id: str | None = None,
        conversation_id: str | None = None,
        sent_date: datetime | None = None,
        created_by: int | str | None = None,
    ) -> int:
        """
        Registra un Reply All generado o enviado.
        """
 
        return self.insert_history(
            case_id=case_id,
            client_id=client_id,
            project_id=project_id,
            rule_id=rule_id,
            template_code=template_code,
            session_id=session_id,
            send_mode="REPLY",
            result="REPLIED",
            subject=subject,
            email_to=email_to,
            email_cc=email_cc,
            email_bcc=email_bcc,
            outlook_entry_id=outlook_entry_id,
            message_id=message_id,
            conversation_id=conversation_id,
            sent_date=sent_date,
            error_message=None,
            created_by=created_by,
        )
 
    def add_error(
        self,
        case_id: int,
        client_id: int,
        error_message: str,
        project_id: int | None = None,
        rule_id: int | None = None,
        template_code: str | None = None,
        session_id: str | None = None,
        send_mode: str = "ERROR",
        subject: str | None = None,
        email_to: str | None = None,
        email_cc: str | None = None,
        email_bcc: str | None = None,
        outlook_entry_id: str | None = None,
        conversation_id: str | None = None,
        created_by: int | str | None = None,
    ) -> int:
        """
        Registra un error de generación o envío.
        """
 
        return self.insert_history(
            case_id=case_id,
            client_id=client_id,
            project_id=project_id,
            rule_id=rule_id,
            template_code=template_code,
            session_id=session_id,
            send_mode=send_mode,
            result="ERROR",
            subject=subject,
            email_to=email_to,
            email_cc=email_cc,
            email_bcc=email_bcc,
            outlook_entry_id=outlook_entry_id,
            message_id=None,
            conversation_id=conversation_id,
            sent_date=None,
            error_message=error_message,
            created_by=created_by,
        )
 
    
 
    # =========================================================
    # CONSULTAS
    # =========================================================
 
    def list_for_case(
        self,
        case_id: int,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """
        Devuelve el historial de un caso.
        """
 
        normalized_case_id = self._required_int(
            case_id,
            "CaseID",
        )
 
        safe_limit = self._normalize_limit(
            limit
        )
 
        sql = f"""
            SELECT TOP ({safe_limit})
                HistoryID,
                CaseID,
                ClientKey AS ClientID,
                ProjectID,
                RuleID,
                TemplateCode,
                SessionID,
                SendMode,
                Result,
                Subject,
                EmailTo,
                EmailCC,
                EmailBCC,
                OutlookEntryID,
                MessageID,
                ConversationID,
                SentDate,
                ErrorMessage,
                CreatedBy,
                CreatedAt
            FROM dbo.FollowUpHistory
            WHERE CaseID = ?
            ORDER BY
                CreatedAt DESC,
                HistoryID DESC;
        """
 
        return self.db.fetch_all(
            sql,
            (normalized_case_id,),
        )

    def get_latest_for_case(
        self,
        case_id: int,
    ) -> dict[str, Any] | None:
        """
        Devuelve el último registro de un caso.
        """
 
        normalized_case_id = self._required_int(
            case_id,
            "CaseID",
        )
 
        sql = """
            SELECT TOP 1
                HistoryID,
                CaseID,
                ClientKey AS ClientID,
                ProjectID,
                RuleID,
                TemplateCode,
                SessionID,
                SendMode,
                Result,
                Subject,
                EmailTo,
                EmailCC,
                EmailBCC,
                OutlookEntryID,
                MessageID,
                ConversationID,
                SentDate,
                ErrorMessage,
                CreatedBy,
                CreatedAt
            FROM dbo.FollowUpHistory
            WHERE CaseID = ?
            ORDER BY
                CreatedAt DESC,
                HistoryID DESC;
        """
 
        return self.db.fetch_one(
            sql,
            (normalized_case_id,),
        )
 
    def get_by_history_id(
        self,
        history_id: int,
    ) -> dict[str, Any] | None:
        """
        Devuelve un registro por HistoryID.
        """
 
        normalized_history_id = self._required_int(
            history_id,
            "HistoryID",
        )
 
        sql = """
            SELECT
                HistoryID,
                CaseID,
                ClientKey AS ClientID,
                ProjectID,
                RuleID,
                TemplateCode,
                SessionID,
                SendMode,
                Result,
                Subject,
                EmailTo,
                EmailCC,
                EmailBCC,
                OutlookEntryID,
                MessageID,
                ConversationID,
                SentDate,
                ErrorMessage,
                CreatedBy,
                CreatedAt
            FROM dbo.FollowUpHistory
            WHERE HistoryID = ?;
        """
 
        return self.db.fetch_one(
            sql,
            (normalized_history_id,),
        )
 
    def get_recent(
        self,
        client_id: int | None = None,
        project_id: int | None = None,
        result: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """
        Devuelve el historial reciente con filtros opcionales.
        """
 
        safe_limit = self._normalize_limit(
            limit
        )    

    
        sql = f"""
            SELECT TOP ({safe_limit})
                HistoryID,
                CaseID,
                ClientKey AS ClientID,
                ProjectID,
                RuleID,
                TemplateCode,
                SessionID,
                SendMode,
                Result,
                Subject,
                EmailTo,
                EmailCC,
                EmailBCC,
                OutlookEntryID,
                MessageID,
                ConversationID,
                SentDate,
                ErrorMessage,
                CreatedBy,
                CreatedAt
            FROM dbo.FollowUpHistory
            WHERE 1 = 1
        """
 
        params: list[Any] = []
 
        if client_id not in (None, ""):
            sql += """
                AND ClientKey = ?
            """
            params.append(
                int(client_id)
            )
 
        if project_id not in (None, ""):
            sql += """
                AND ProjectID = ?
            """
            params.append(
                int(project_id)
            )
 
        if result not in (None, ""):
            sql += """
                AND Result = ?
            """
            params.append(
                self._normalize_result(result)
            )
 
        sql += """
            ORDER BY
                CreatedAt DESC,
                HistoryID DESC;
        """
 
        return self.db.fetch_all(
            sql,
            tuple(params),
        )
 
    def get_by_session(
        self,
        session_id: str,
    ) -> list[dict[str, Any]]:
        """
        Devuelve los movimientos vinculados con una sesión.
        """
 
        normalized_session_id = self._optional_text(
            session_id
        )
 
        if not normalized_session_id:
            return []
 
        sql = """
            SELECT
                HistoryID,
                CaseID,
                ClientKey AS ClientID,
                ProjectID,
                RuleID,
                TemplateCode,
                SessionID,
                SendMode,
                Result,
                Subject,
                EmailTo,
                EmailCC,
                EmailBCC,
                OutlookEntryID,
                MessageID,
                ConversationID,
                SentDate,
                ErrorMessage,
                CreatedBy,
                CreatedAt
            FROM dbo.FollowUpHistory
            WHERE SessionID = ?
            ORDER BY
                CreatedAt ASC,
                HistoryID ASC;
        """
 
        return self.db.fetch_all(
            sql,
            (normalized_session_id,),
        )
 
    def exists_outlook_entry_id(
        self,
        outlook_entry_id: str,
    ) -> bool:
        """
        Verifica si un EntryID ya fue registrado.
        """
 
        normalized_entry_id = self._optional_text(
            outlook_entry_id
        )
 
        if not normalized_entry_id:
            return False
 
        count = self.db.scalar(
            """
                SELECT COUNT(1)
                FROM dbo.FollowUpHistory
                WHERE OutlookEntryID = ?;
            """,
            (normalized_entry_id,),
        )
 
        return int(count or 0) > 0
 
    def exists_message_id(
        self,
        message_id: str,
    ) -> bool:
        """
        Verifica si un MessageID ya fue registrado.
        """
 
        normalized_message_id = self._optional_text(
            message_id
        )
 
        if not normalized_message_id:
            return False
 
        count = self.db.scalar(
            """
                SELECT COUNT(1)
                FROM dbo.FollowUpHistory
                WHERE MessageID = ?;
            """,
            (normalized_message_id,),
        )
 
        return int(count or 0) > 0
 
    # =========================================================
    # AUXILIARES
    # =========================================================
 
    @classmethod
    def _normalize_result(
        cls,
        value: Any,
    ) -> str:
        result = str(
            value or "SUCCESS"
        ).strip().upper()
 
        if result not in cls.VALID_RESULTS:
            raise ValueError(
                f"Result no válido: {result}"
            )
 
        return result
 
    @classmethod
    def _normalize_send_mode(
        cls,
        value: Any,
    ) -> str:
        send_mode = str(
            value or "DRAFT"
        ).strip().upper()
 
        if send_mode not in cls.VALID_SEND_MODES:
            raise ValueError(
                f"SendMode no válido: {send_mode}"
            )
 
        return send_mode
 
    @staticmethod
    def _required_int(
        value: Any,
        field_name: str,
    ) -> int:
        if value in (None, ""):
            raise ValueError(
                f"{field_name} es obligatorio."
            )
 
        try:
            return int(value)
        except (TypeError, ValueError) as error:
            raise ValueError(
                f"{field_name} debe ser numérico."
            ) from error
 
    @staticmethod
    def _optional_int(
        value: Any,
    ) -> int | None:
        if value in (None, ""):
            return None
 
        try:
            return int(value)
        except (TypeError, ValueError):
            return None
 
    @staticmethod
    def _optional_text(
        value: Any,
    ) -> str | None:
        text = str(
            value or ""
        ).strip()
 
        return text or None
 
    @staticmethod
    def _normalize_limit(
        value: Any,
    ) -> int:
        try:
            normalized = int(value or 100)
        except (TypeError, ValueError):
            normalized = 100
 
        if normalized < 1:
            return 1
 
        if normalized > 1000:
            return 1000
 
        return normalized
 