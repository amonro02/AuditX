from __future__ import annotations 

from typing import Any

from database.connection import Database
from database.db_config import DB_CONFIG_AUDITFOLLOWUP


class UserRepository:
    """
    Repositorio de usuarios, roles y permisos del módulo Follow-up.

    Tablas utilizadas:

        dbo.AppUsers
        dbo.AppRoles
        dbo.AppPermissions
        dbo.AppRolePermissions

    La seguridad se determina mediante:

        Usuario
            -> Rol
                -> Permisos del rol
    """

    VALID_USER_FIELDS = {
        "FullName",
        "Email",
        "WindowsUser",
        "RoleID",
        "IsActive",
    }

    def __init__(
        self,
        db: Database | None = None,
    ):
        self.db = db or Database(
            DB_CONFIG_AUDITFOLLOWUP
        )

    # =========================================================
    # USUARIO ACTUAL
    # =========================================================

    def get_current_user(
        self,
        windows_user: str | None = None,
        email: str | None = None,
    ) -> dict[str, Any] | None:
        """
        Busca el usuario activo por WindowsUser o Email.

        Prioridad:
            1. WindowsUser.
            2. Email.

        No utiliza cuentas administrativas de respaldo.
        """

        normalized_windows_user = self._normalize_windows_user(
            windows_user
        )

        normalized_email = self._normalize_email(
            email
        )

        if not normalized_windows_user and not normalized_email:
            return None

        sql = """
            SELECT TOP 1
                U.UserID,
                U.FullName,
                U.Email,
                U.WindowsUser,
                U.RoleID,
                R.RoleName,
                U.IsActive
            FROM dbo.AppUsers AS U
            INNER JOIN dbo.AppRoles AS R
                ON R.RoleID = U.RoleID
            WHERE ISNULL(U.IsActive, 1) = 1
              AND ISNULL(R.IsActive, 1) = 1
              AND
              (
                    (
                        ? IS NOT NULL
                        AND LOWER(
                            ISNULL(U.WindowsUser, '')
                        ) = LOWER(?)
                    )
                    OR
                    (
                        ? IS NOT NULL
                        AND LOWER(
                            ISNULL(U.Email, '')
                        ) = LOWER(?)
                    )
              )
            ORDER BY
                CASE
                    WHEN
                        ? IS NOT NULL
                        AND LOWER(
                            ISNULL(U.WindowsUser, '')
                        ) = LOWER(?)
                    THEN 0
                    ELSE 1
                END,
                U.UserID;
        """

        return self.db.fetch_one(
            sql,
            (
                normalized_windows_user,
                normalized_windows_user,
                normalized_email,
                normalized_email,
                normalized_windows_user,
                normalized_windows_user,
            ),
        )

    def find_by_email(
        self,
        email: str,
        active_only: bool = True,
    ) -> dict[str, Any] | None:
        """
        Busca un usuario por correo.
        """

        normalized_email = self._normalize_email(
            email
        )

        if not normalized_email:
            return None

        sql = """
            SELECT TOP 1
                U.UserID,
                U.FullName,
                U.Email,
                U.WindowsUser,
                U.RoleID,
                R.RoleName,
                U.IsActive
            FROM dbo.AppUsers AS U
            LEFT JOIN dbo.AppRoles AS R
                ON R.RoleID = U.RoleID
            WHERE LOWER(U.Email) = LOWER(?)
        """

        params: list[Any] = [
            normalized_email
        ]

        if active_only:
            sql += """
                AND ISNULL(U.IsActive, 1) = 1
            """

        sql += """
            ORDER BY U.UserID;
        """

        return self.db.fetch_one(
            sql,
            tuple(params),
        )

    def find_by_windows_user(
        self,
        windows_user: str,
        active_only: bool = True,
    ) -> dict[str, Any] | None:
        """
        Busca un usuario por nombre de red.
        """

        normalized_windows_user = (
            self._normalize_windows_user(
                windows_user
            )
        )

        if not normalized_windows_user:
            return None

        sql = """
            SELECT TOP 1
                U.UserID,
                U.FullName,
                U.Email,
                U.WindowsUser,
                U.RoleID,
                R.RoleName,
                U.IsActive
            FROM dbo.AppUsers AS U
            LEFT JOIN dbo.AppRoles AS R
                ON R.RoleID = U.RoleID
            WHERE LOWER(
                ISNULL(U.WindowsUser, '')
            ) = LOWER(?)
        """

        params: list[Any] = [
            normalized_windows_user
        ]

        if active_only:
            sql += """
                AND ISNULL(U.IsActive, 1) = 1
            """

        sql += """
            ORDER BY U.UserID;
        """

        return self.db.fetch_one(
            sql,
            tuple(params),
        )

    def get_by_id(
        self,
        user_id: int,
    ) -> dict[str, Any] | None:
        """
        Recupera un usuario por UserID.
        """

        normalized_user_id = self._required_int(
            user_id,
            "UserID",
        )

        sql = """
            SELECT
                U.UserID,
                U.FullName,
                U.Email,
                U.WindowsUser,
                U.RoleID,
                R.RoleName,
                U.IsActive
            FROM dbo.AppUsers AS U
            LEFT JOIN dbo.AppRoles AS R
                ON R.RoleID = U.RoleID
            WHERE U.UserID = ?;
        """

        return self.db.fetch_one(
            sql,
            (normalized_user_id,),
        )

    # =========================================================
    # PERMISOS
    # =========================================================

    def permissions(
        self,
        user_id: int,
    ) -> list[str]:
        """
        Devuelve las PermissionKey permitidas al usuario.

        Los permisos negados o no configurados no se incluyen.
        """

        normalized_user_id = self._required_int(
            user_id,
            "UserID",
        )

        sql = """
            SELECT DISTINCT
                P.PermissionKey
            FROM dbo.AppUsers AS U
            INNER JOIN dbo.AppRoles AS R
                ON R.RoleID = U.RoleID
               AND ISNULL(R.IsActive, 1) = 1
            INNER JOIN dbo.AppRolePermissions AS RP
                ON RP.RoleID = U.RoleID
               AND ISNULL(RP.IsAllowed, 0) = 1
            INNER JOIN dbo.AppPermissions AS P
                ON P.PermissionID = RP.PermissionID
               AND ISNULL(P.IsActive, 1) = 1
            WHERE U.UserID = ?
              AND ISNULL(U.IsActive, 1) = 1
            ORDER BY P.PermissionKey;
        """

        rows = self.db.fetch_all(
            sql,
            (normalized_user_id,),
        )

        return [
            str(
                row.get("PermissionKey") or ""
            ).strip()
            for row in rows
            if str(
                row.get("PermissionKey") or ""
            ).strip()
        ]

    def permission_set(
        self,
        user_id: int,
    ) -> set[str]:
        """
        Devuelve los permisos como conjunto.
        """

        return {
            permission.lower()
            for permission in self.permissions(
                user_id
            )
        }

    def has_permission(
        self,
        user_id: int,
        permission_key: str,
    ) -> bool:
        """
        Valida si el usuario posee un permiso.
        """

        normalized_permission = str(
            permission_key or ""
        ).strip().lower()

        if not normalized_permission:
            return False

        return (
            normalized_permission
            in self.permission_set(user_id)
        )

    def has_any_permission(
        self,
        user_id: int,
        permission_keys: list[str] | tuple[str, ...] | set[str],
    ) -> bool:
        """
        Devuelve True cuando posee al menos uno de los permisos.
        """

        current_permissions = self.permission_set(
            user_id
        )

        required = {
            str(item or "").strip().lower()
            for item in permission_keys
            if str(item or "").strip()
        }

        return bool(
            current_permissions.intersection(
                required
            )
        )

    def has_all_permissions(
        self,
        user_id: int,
        permission_keys: list[str] | tuple[str, ...] | set[str],
    ) -> bool:
        """
        Devuelve True cuando posee todos los permisos.
        """

        current_permissions = self.permission_set(
            user_id
        )

        required = {
            str(item or "").strip().lower()
            for item in permission_keys
            if str(item or "").strip()
        }

        return required.issubset(
            current_permissions
        )

    # =========================================================
    # USUARIOS
    # =========================================================

    def users(
        self,
        active_only: bool = False,
        role_id: int | None = None,
    ) -> list[dict[str, Any]]:
        """
        Devuelve la lista de usuarios.
        """

        sql = """
            SELECT
                U.UserID,
                U.FullName,
                U.Email,
                U.WindowsUser,
                U.RoleID,
                R.RoleName,
                U.IsActive
            FROM dbo.AppUsers AS U
            LEFT JOIN dbo.AppRoles AS R
                ON R.RoleID = U.RoleID
            WHERE 1 = 1
        """

        params: list[Any] = []

        if active_only:
            sql += """
                AND ISNULL(U.IsActive, 1) = 1
            """

        if role_id not in (None, ""):
            sql += """
                AND U.RoleID = ?
            """
            params.append(
                self._required_int(
                    role_id,
                    "RoleID",
                )
            )

        sql += """
            ORDER BY
                U.FullName,
                U.Email;
        """

        return self.db.fetch_all(
            sql,
            tuple(params),
        )

    def create_user(
        self,
        full_name: str,
        email: str,
        windows_user: str | None,
        role_id: int,
        is_active: bool = True,
    ) -> int:
        """
        Crea un usuario y devuelve UserID.
        """

        normalized_name = self._required_text(
            full_name,
            "FullName",
        )

        normalized_email = self._normalize_email(
            email
        )

        if not normalized_email:
            raise ValueError(
                "Email es obligatorio."
            )

        normalized_windows_user = (
            self._normalize_windows_user(
                windows_user
            )
        )

        normalized_role_id = self._required_int(
            role_id,
            "RoleID",
        )

        if self.find_by_email(
            normalized_email,
            active_only=False,
        ):
            raise ValueError(
                "Ya existe un usuario con ese correo."
            )

        if (
            normalized_windows_user
            and self.find_by_windows_user(
                normalized_windows_user,
                active_only=False,
            )
        ):
            raise ValueError(
                "Ya existe un usuario con ese WindowsUser."
            )

        sql = """
            INSERT INTO dbo.AppUsers
            (
                FullName,
                Email,
                WindowsUser,
                RoleID,
                IsActive
            )
            OUTPUT INSERTED.UserID
            VALUES
            (
                ?, ?, ?, ?, ?
            );
        """

        user_id = self.db.scalar(
            sql,
            (
                normalized_name,
                normalized_email,
                normalized_windows_user,
                normalized_role_id,
                1 if is_active else 0,
            ),
        )

        if user_id is None:
            raise RuntimeError(
                "No fue posible crear el usuario."
            )

        return int(user_id)

    def update_user(
        self,
        user_id: int,
        full_name: str,
        email: str,
        windows_user: str | None,
        role_id: int,
        is_active: bool,
    ) -> int:
        """
        Actualiza la información completa de un usuario.
        """

        normalized_user_id = self._required_int(
            user_id,
            "UserID",
        )

        normalized_name = self._required_text(
            full_name,
            "FullName",
        )

        normalized_email = self._normalize_email(
            email
        )

        if not normalized_email:
            raise ValueError(
                "Email es obligatorio."
            )

        normalized_windows_user = (
            self._normalize_windows_user(
                windows_user
            )
        )

        normalized_role_id = self._required_int(
            role_id,
            "RoleID",
        )

        duplicate_email = self.db.scalar(
            """
                SELECT COUNT(1)
                FROM dbo.AppUsers
                WHERE LOWER(Email) = LOWER(?)
                  AND UserID <> ?;
            """,
            (
                normalized_email,
                normalized_user_id,
            ),
        )

        if int(duplicate_email or 0) > 0:
            raise ValueError(
                "Ya existe otro usuario con ese correo."
            )

        if normalized_windows_user:
            duplicate_windows_user = self.db.scalar(
                """
                    SELECT COUNT(1)
                    FROM dbo.AppUsers
                    WHERE LOWER(
                        ISNULL(WindowsUser, '')
                    ) = LOWER(?)
                      AND UserID <> ?;
                """,
                (
                    normalized_windows_user,
                    normalized_user_id,
                ),
            )

            if int(
                duplicate_windows_user or 0
            ) > 0:
                raise ValueError(
                    "Ya existe otro usuario con ese WindowsUser."
                )

        sql = """
            UPDATE dbo.AppUsers
            SET
                FullName = ?,
                Email = ?,
                WindowsUser = ?,
                RoleID = ?,
                IsActive = ?
            WHERE UserID = ?;
        """

        return self.db.execute(
            sql,
            (
                normalized_name,
                normalized_email,
                normalized_windows_user,
                normalized_role_id,
                1 if is_active else 0,
                normalized_user_id,
            ),
        )

    def update_field(
        self,
        user_id: int,
        field: str,
        value: Any,
    ) -> int:
        """
        Actualiza un campo autorizado del usuario.
        """

        normalized_field = str(
            field or ""
        ).strip()

        if (
            normalized_field
            not in self.VALID_USER_FIELDS
        ):
            raise ValueError(
                f"No se permite actualizar el campo "
                f"'{normalized_field}'."
            )

        sql = f"""
            UPDATE dbo.AppUsers
            SET [{normalized_field}] = ?
            WHERE UserID = ?;
        """

        return self.db.execute(
            sql,
            (
                value,
                self._required_int(
                    user_id,
                    "UserID",
                ),
            ),
        )

    def set_active(
        self,
        user_id: int,
        is_active: bool,
    ) -> int:
        """
        Activa o desactiva un usuario.
        """

        return self.update_field(
            user_id=user_id,
            field="IsActive",
            value=1 if is_active else 0,
        )

    # =========================================================
    # ROLES
    # =========================================================

    def roles(
        self,
        active_only: bool = True,
    ) -> list[dict[str, Any]]:
        """
        Devuelve los roles.
        """

        sql = """
            SELECT
                RoleID,
                RoleName,
                IsActive
            FROM dbo.AppRoles
            WHERE 1 = 1
        """

        if active_only:
            sql += """
                AND ISNULL(IsActive, 1) = 1
            """

        sql += """
            ORDER BY RoleName;
        """

        return self.db.fetch_all(sql)

    def role_permissions(
        self,
        role_id: int,
    ) -> list[dict[str, Any]]:
        """
        Devuelve todos los permisos y señala cuáles están
        habilitados para el rol.
        """

        normalized_role_id = self._required_int(
            role_id,
            "RoleID",
        )

        sql = """
            SELECT
                P.PermissionID,
                P.PermissionKey,
                P.PermissionName,
                CAST(
                    ISNULL(RP.IsAllowed, 0)
                    AS BIT
                ) AS IsAllowed
            FROM dbo.AppPermissions AS P
            LEFT JOIN dbo.AppRolePermissions AS RP
                ON RP.PermissionID = P.PermissionID
               AND RP.RoleID = ?
            WHERE ISNULL(P.IsActive, 1) = 1
            ORDER BY
                P.PermissionKey;
        """

        return self.db.fetch_all(
            sql,
            (normalized_role_id,),
        )

    def set_role_permission(
        self,
        role_id: int,
        permission_id: int,
        allowed: bool,
    ) -> int:
        """
        Inserta o actualiza un permiso de rol.
        """

        normalized_role_id = self._required_int(
            role_id,
            "RoleID",
        )

        normalized_permission_id = (
            self._required_int(
                permission_id,
                "PermissionID",
            )
        )

        sql = """
            MERGE dbo.AppRolePermissions
                WITH (HOLDLOCK) AS Target
            USING
            (
                SELECT
                    ? AS RoleID,
                    ? AS PermissionID
            ) AS Source
                ON Target.RoleID = Source.RoleID
               AND Target.PermissionID =
                    Source.PermissionID

            WHEN MATCHED THEN
                UPDATE SET
                    IsAllowed = ?

            WHEN NOT MATCHED THEN
                INSERT
                (
                    RoleID,
                    PermissionID,
                    IsAllowed
                )
                VALUES
                (
                    Source.RoleID,
                    Source.PermissionID,
                    ?
                );
        """

        return self.db.execute(
            sql,
            (
                normalized_role_id,
                normalized_permission_id,
                1 if allowed else 0,
                1 if allowed else 0,
            ),
        )

    def set_multiple_role_permissions(
        self,
        role_id: int,
        permissions: dict[int, bool],
    ) -> int:
        """
        Guarda varios permisos para un rol.

        Ejemplo:
            {
                1: True,
                2: False,
                3: True
            }
        """

        if not isinstance(permissions, dict):
            raise TypeError(
                "permissions debe ser un diccionario."
            )

        affected = 0

        for permission_id, allowed in (
            permissions.items()
        ):
            affected += self.set_role_permission(
                role_id=role_id,
                permission_id=permission_id,
                allowed=bool(allowed),
            )

        return affected

    # =========================================================
    # AUXILIARES
    # =========================================================

    @staticmethod
    def _required_int(
        value: Any,
        field_name: str,
    ) -> int:
        if value in (None, ""):
            raise ValueError(
                f"{field_name} es obligatorio."
            )

        try:
            return int(value)
        except (
            TypeError,
            ValueError,
        ) as error:
            raise ValueError(
                f"{field_name} debe ser numérico."
            ) from error

    @staticmethod
    def _required_text(
        value: Any,
        field_name: str,
    ) -> str:
        text = str(
            value or ""
        ).strip()

        if not text:
            raise ValueError(
                f"{field_name} es obligatorio."
            )

        return text

    @staticmethod
    def _normalize_email(
        value: Any,
    ) -> str | None:
        email = str(
            value or ""
        ).strip().lower()

        return email or None

    @staticmethod
    def _normalize_windows_user(
        value: Any,
    ) -> str | None:
        windows_user = str(
            value or ""
        ).strip().lower()

        if not windows_user:
            return None

        # Si llega DOMINIO\\usuario, conserva únicamente usuario.
        if "\\" in windows_user:
            windows_user = (
                windows_user
                .split("\\")[-1]
                .strip()
            )

        # También admite usuario@dominio.
        if "@" in windows_user:
            windows_user = (
                windows_user
                .split("@")[0]
                .strip()
            )

        return windows_user or None
