from __future__ import annotations 

import re

from typing import Any

from database.connection import Database
from database.db_config import DB_CONFIG_AUDITFOLLOWUP


class VendorContactRepository:
    """
    Repositorio de contactos de proveedores.

    Permite:

        - Consultar contactos por cliente y proveedor.
        - Buscar un contacto por ID.
        - Buscar por correo.
        - Crear el contacto si todavía no existe.
        - Actualizar contactos.
        - Activar o desactivar contactos.
        - Marcar un contacto como principal.
        - Obtener el contacto principal del proveedor.

    Nota:
        En la tabla ContactCatalog de tus imágenes se utiliza ClientID.

        Si físicamente la columna se llama ClientKey, solamente cambia:

            CLIENT_COLUMN = "ClientID"

        por:

            CLIENT_COLUMN = "ClientKey"

        En Python se mantiene siempre client_id.
    """

    TABLE_NAME = "dbo.ContactCatalog"

    # Según tus imágenes, ContactCatalog utiliza ClientID.
    CLIENT_COLUMN = "ClientID"

    VALID_CONTACT_TYPES = {
        "PRIMARY",
        "TO",
        "CC",
        "BCC",
        "FINANCE",
        "LEGAL",
        "AUDIT",
        "VENDOR",
        "OTHER",
    }

    VALID_GENDERS = {
        "F",
        "M",
        "UNKNOWN",
    }

    ALLOWED_UPDATE_FIELDS = {
        "ContactName",
        "EmailAddress",
        "ContactType",
        "ContactGender",
        "LanguageCode",
        "PhoneNumber",
        "JobTitle",
        "IsPrimary",
        "IsActive",
    }

    def __init__(
        self,
        db: Database | None = None,
    ):
        self.db = db or Database(
            DB_CONFIG_AUDITFOLLOWUP
        )

    # =========================================================
    # CONSULTAS
    # =========================================================

    def get_contacts(
        self,
        client_id: int,
        vendor_id: int,
        active_only: bool = True,
    ) -> list[dict[str, Any]]:
        """
        Devuelve los contactos de un proveedor.

        Orden:
            1. Contacto principal.
            2. Tipo TO.
            3. Resto de contactos.
            4. Nombre.
        """

        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )

        normalized_vendor_id = self._required_int(
            vendor_id,
            "VendorID",
        )

        sql = f"""
            SELECT
                ContactID,
                {self.CLIENT_COLUMN} AS ClientID,
                VendorID,
                ContactName,
                EmailAddress,
                ContactType,
                ContactGender,
                LanguageCode,
                PhoneNumber,
                JobTitle,
                IsPrimary,
                IsActive,
                CreatedBy,
                CreatedAt,
                UpdatedBy,
                UpdatedAt
            FROM {self.TABLE_NAME}
            WHERE {self.CLIENT_COLUMN} = ?
              AND VendorID = ?
        """

        params: list[Any] = [
            normalized_client_id,
            normalized_vendor_id,
        ]

        if active_only:
            sql += """
                AND ISNULL(IsActive, 1) = 1
            """

        sql += """
            ORDER BY
                ISNULL(IsPrimary, 0) DESC,
                CASE
                    WHEN UPPER(
                        ISNULL(ContactType, '')
                    ) = 'PRIMARY'
                        THEN 0

                    WHEN UPPER(
                        ISNULL(ContactType, '')
                    ) = 'TO'
                        THEN 1

                    WHEN UPPER(
                        ISNULL(ContactType, '')
                    ) = 'CC'
                        THEN 2

                    ELSE 3
                END,
                ContactName,
                EmailAddress;
        """

        return self.db.fetch_all(
            sql,
            tuple(params),
        )

    def get_contact(
        self,
        contact_id: int,
        active_only: bool = False,
    ) -> dict[str, Any] | None:
        """
        Recupera un contacto por ContactID.
        """

        normalized_contact_id = self._required_int(
            contact_id,
            "ContactID",
        )

        sql = f"""
            SELECT TOP 1
                ContactID,
                {self.CLIENT_COLUMN} AS ClientID,
                VendorID,
                ContactName,
                EmailAddress,
                ContactType,
                ContactGender,
                LanguageCode,
                PhoneNumber,
                JobTitle,
                IsPrimary,
                IsActive,
                CreatedBy,
                CreatedAt,
                UpdatedBy,
                UpdatedAt
            FROM {self.TABLE_NAME}
            WHERE ContactID = ?
        """

        if active_only:
            sql += """
                AND ISNULL(IsActive, 1) = 1
            """

        sql += ";"

        return self.db.fetch_one(
            sql,
            (normalized_contact_id,),
        )

    def find_by_email(
        self,
        client_id: int,
        vendor_id: int,
        email_address: str,
        active_only: bool = False,
    ) -> dict[str, Any] | None:
        """
        Busca un contacto por cliente, proveedor y correo.
        """

        normalized_email = self._normalize_email(
            email_address
        )

        if not normalized_email:
            return None

        sql = f"""
            SELECT TOP 1
                ContactID,
                {self.CLIENT_COLUMN} AS ClientID,
                VendorID,
                ContactName,
                EmailAddress,
                ContactType,
                ContactGender,
                LanguageCode,
                PhoneNumber,
                JobTitle,
                IsPrimary,
                IsActive,
                CreatedBy,
                CreatedAt,
                UpdatedBy,
                UpdatedAt
            FROM {self.TABLE_NAME}
            WHERE {self.CLIENT_COLUMN} = ?
              AND VendorID = ?
              AND LOWER(
                    LTRIM(
                        RTRIM(EmailAddress)
                    )
                  ) = LOWER(?)
        """

        if active_only:
            sql += """
                AND ISNULL(IsActive, 1) = 1
            """

        sql += """
            ORDER BY
                ISNULL(IsActive, 1) DESC,
                ISNULL(IsPrimary, 0) DESC,
                ContactID;
        """

        return self.db.fetch_one(
            sql,
            (
                self._required_int(
                    client_id,
                    "ClientID",
                ),
                self._required_int(
                    vendor_id,
                    "VendorID",
                ),
                normalized_email,
            ),
        )

    def get_primary_contact(
        self,
        client_id: int,
        vendor_id: int,
    ) -> dict[str, Any] | None:
        """
        Devuelve el contacto principal.

        Si no existe IsPrimary=1, intenta:
            PRIMARY -> TO -> primer contacto activo.
        """

        sql = f"""
            SELECT TOP 1
                ContactID,
                {self.CLIENT_COLUMN} AS ClientID,
                VendorID,
                ContactName,
                EmailAddress,
                ContactType,
                ContactGender,
                LanguageCode,
                PhoneNumber,
                JobTitle,
                IsPrimary,
                IsActive,
                CreatedBy,
                CreatedAt,
                UpdatedBy,
                UpdatedAt
            FROM {self.TABLE_NAME}
            WHERE {self.CLIENT_COLUMN} = ?
              AND VendorID = ?
              AND ISNULL(IsActive, 1) = 1
            ORDER BY
                ISNULL(IsPrimary, 0) DESC,

                CASE
                    WHEN UPPER(
                        ISNULL(ContactType, '')
                    ) = 'PRIMARY'
                        THEN 0

                    WHEN UPPER(
                        ISNULL(ContactType, '')
                    ) = 'TO'
                        THEN 1

                    ELSE 2
                END,

                ContactID;
        """

        return self.db.fetch_one(
            sql,
            (
                self._required_int(
                    client_id,
                    "ClientID",
                ),
                self._required_int(
                    vendor_id,
                    "VendorID",
                ),
            ),
        )

    def get_email_defaults(
        self,
        client_id: int,
        vendor_id: int,
    ) -> dict[str, Any]:
        """
        Construye los destinatarios predeterminados para el formulario.

        Devuelve:
            ContactID
            ContactName
            ContactGender
            LanguageCode
            EmailTo
            EmailCC
            EmailBCC
        """

        contacts = self.get_contacts(
            client_id=client_id,
            vendor_id=vendor_id,
            active_only=True,
        )

        if not contacts:
            return {
                "ContactID": None,
                "ContactName": "",
                "ContactGender": "UNKNOWN",
                "LanguageCode": "en",
                "EmailTo": "",
                "EmailCC": "",
                "EmailBCC": "",
            }

        primary = self.get_primary_contact(
            client_id=client_id,
            vendor_id=vendor_id,
        )

        to_addresses: list[str] = []
        cc_addresses: list[str] = []
        bcc_addresses: list[str] = []

        for contact in contacts:
            email = self._normalize_email(
                contact.get("EmailAddress")
            )

            if not email:
                continue

            contact_type = self._normalize_contact_type(
                contact.get("ContactType")
            )

            is_primary = self._to_bool(
                contact.get("IsPrimary")
            )

            if (
                is_primary
                or contact_type in {
                    "PRIMARY",
                    "TO",
                }
            ):
                self._append_unique(
                    to_addresses,
                    email,
                )

            elif contact_type == "CC":
                self._append_unique(
                    cc_addresses,
                    email,
                )

            elif contact_type == "BCC":
                self._append_unique(
                    bcc_addresses,
                    email,
                )

        if (
            not to_addresses
            and primary
            and primary.get("EmailAddress")
        ):
            self._append_unique(
                to_addresses,
                self._normalize_email(
                    primary.get("EmailAddress")
                ),
            )

        selected_contact = (
            primary
            or contacts[0]
        )

        return {
            "ContactID": selected_contact.get(
                "ContactID"
            ),

            "ContactName": selected_contact.get(
                "ContactName"
            ) or "",

            "ContactGender": self._normalize_gender(
                selected_contact.get(
                    "ContactGender"
                )
            ),

            "LanguageCode": self._normalize_language(
                selected_contact.get(
                    "LanguageCode"
                )
            ),

            "EmailTo": "; ".join(
                to_addresses
            ),

            "EmailCC": "; ".join(
                cc_addresses
            ),

            "EmailBCC": "; ".join(
                bcc_addresses
            ),
        }

    # =========================================================
    # CREAR O RECUPERAR CONTACTO
    # =========================================================

    def ensure_contact(
        self,
        client_id: int,
        vendor_id: int,
        contact_name: str | None,
        email_address: str,
        contact_type: str | None,
        user_email: str | None,
        contact_gender: str | None = None,
        language_code: str | None = None,
        phone_number: str | None = None,
        job_title: str | None = None,
        is_primary: bool = False,
    ) -> int:
        """
        Devuelve ContactID.

        Si el contacto ya existe:
            - Reactiva el registro cuando estaba inactivo.
            - Actualiza nombre, tipo, género e idioma si se reciben.
            - Devuelve el ContactID existente.

        Si no existe:
            - Inserta un contacto nuevo.
        """

        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )

        normalized_vendor_id = self._required_int(
            vendor_id,
            "VendorID",
        )

        normalized_email = self._normalize_email(
            email_address
        )

        if not normalized_email:
            raise ValueError(
                "EmailAddress es obligatorio."
            )

        if not self._is_valid_email(
            normalized_email
        ):
            raise ValueError(
                f"EmailAddress no es válido: "
                f"{normalized_email}"
            )

        normalized_name = (
            self._optional_text(contact_name)
            or normalized_email.split("@")[0]
        )

        normalized_type = (
            self._normalize_contact_type(
                contact_type
            )
        )

        normalized_gender = (
            self._normalize_gender(
                contact_gender
            )
        )

        normalized_language = (
            self._normalize_language(
                language_code
            )
        )

        normalized_user_email = (
            self._normalize_email(user_email)
        )

        connection = self.db.connect()

        try:
            cursor = connection.cursor()

            cursor.execute(
                f"""
                    SELECT TOP 1
                        ContactID,
                        IsActive
                    FROM {self.TABLE_NAME}
                    WHERE {self.CLIENT_COLUMN} = ?
                      AND VendorID = ?
                      AND LOWER(
                            LTRIM(
                                RTRIM(EmailAddress)
                            )
                          ) = LOWER(?)
                    ORDER BY
                        ISNULL(IsActive, 1) DESC,
                        ContactID;
                """,
                (
                    normalized_client_id,
                    normalized_vendor_id,
                    normalized_email,
                ),
            )

            existing = cursor.fetchone()

            if existing:
                contact_id = int(
                    existing[0]
                )

                if is_primary:
                    self._clear_primary_with_cursor(
                        cursor=cursor,
                        client_id=normalized_client_id,
                        vendor_id=normalized_vendor_id,
                        except_contact_id=contact_id,
                        user_email=normalized_user_email,
                    )

                cursor.execute(
                    f"""
                        UPDATE {self.TABLE_NAME}
                        SET
                            ContactName =
                                COALESCE(
                                    NULLIF(?, ''),
                                    ContactName
                                ),

                            ContactType =
                                COALESCE(
                                    NULLIF(?, ''),
                                    ContactType
                                ),

                            ContactGender =
                                COALESCE(
                                    NULLIF(?, ''),
                                    ContactGender
                                ),

                            LanguageCode =
                                COALESCE(
                                    NULLIF(?, ''),
                                    LanguageCode
                                ),

                            PhoneNumber =
                                COALESCE(
                                    NULLIF(?, ''),
                                    PhoneNumber
                                ),

                            JobTitle =
                                COALESCE(
                                    NULLIF(?, ''),
                                    JobTitle
                                ),

                            IsPrimary = ?,
                            IsActive = 1,
                            UpdatedBy = ?,
                            UpdatedAt = SYSDATETIME()

                        WHERE ContactID = ?;
                    """,
                    (
                        normalized_name,
                        normalized_type,
                        normalized_gender,
                        normalized_language,
                        self._optional_text(
                            phone_number
                        ),
                        self._optional_text(
                            job_title
                        ),
                        1 if is_primary else 0,
                        normalized_user_email,
                        contact_id,
                    ),
                )

                connection.commit()

                return contact_id

            if is_primary:
                self._clear_primary_with_cursor(
                    cursor=cursor,
                    client_id=normalized_client_id,
                    vendor_id=normalized_vendor_id,
                    except_contact_id=None,
                    user_email=normalized_user_email,
                )

            cursor.execute(
                f"""
                    INSERT INTO {self.TABLE_NAME}
                    (
                        {self.CLIENT_COLUMN},
                        VendorID,
                        ContactName,
                        EmailAddress,
                        ContactType,
                        ContactGender,
                        LanguageCode,
                        PhoneNumber,
                        JobTitle,
                        IsPrimary,
                        IsActive,
                        CreatedBy,
                        CreatedAt,
                        UpdatedBy,
                        UpdatedAt
                    )
                    OUTPUT INSERTED.ContactID
                    VALUES
                    (
                        ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, 1,
                        ?, SYSDATETIME(),
                        ?, SYSDATETIME()
                    );
                """,
                (
                    normalized_client_id,
                    normalized_vendor_id,
                    normalized_name,
                    normalized_email,
                    normalized_type,
                    normalized_gender,
                    normalized_language,
                    self._optional_text(
                        phone_number
                    ),
                    self._optional_text(
                        job_title
                    ),
                    1 if is_primary else 0,
                    normalized_user_email,
                    normalized_user_email,
                ),
            )

            row = cursor.fetchone()

            if not row:
                raise RuntimeError(
                    "No fue posible obtener el ContactID."
                )

            contact_id = int(
                row[0]
            )

            connection.commit()

            return contact_id

        except Exception:
            connection.rollback()
            raise

        finally:
            connection.close()

    # =========================================================
    # ACTUALIZACIÓN
    # =========================================================

    def update_contact(
        self,
        contact_id: int,
        contact_name: str,
        email_address: str,
        contact_type: str | None,
        contact_gender: str | None,
        language_code: str | None,
        phone_number: str | None,
        job_title: str | None,
        is_primary: bool,
        is_active: bool,
        updated_by: str | None,
    ) -> int:
        """
        Actualiza un contacto completo.
        """

        current = self.get_contact(
            contact_id=contact_id,
            active_only=False,
        )

        if not current:
            raise ValueError(
                "El contacto no existe."
            )

        normalized_email = self._normalize_email(
            email_address
        )

        if not normalized_email:
            raise ValueError(
                "EmailAddress es obligatorio."
            )

        if not self._is_valid_email(
            normalized_email
        ):
            raise ValueError(
                "EmailAddress no tiene un formato válido."
            )

        duplicate = self.db.scalar(
            f"""
                SELECT COUNT(1)
                FROM {self.TABLE_NAME}
                WHERE {self.CLIENT_COLUMN} = ?
                  AND VendorID = ?
                  AND LOWER(
                        LTRIM(
                            RTRIM(EmailAddress)
                        )
                      ) = LOWER(?)
                  AND ContactID <> ?;
            """,
            (
                current.get("ClientID"),
                current.get("VendorID"),
                normalized_email,
                self._required_int(
                    contact_id,
                    "ContactID",
                ),
            ),
        )

        if int(duplicate or 0) > 0:
            raise ValueError(
                "Ya existe otro contacto con ese correo "
                "para el mismo proveedor."
            )

        connection = self.db.connect()

        try:
            cursor = connection.cursor()

            if is_primary:
                self._clear_primary_with_cursor(
                    cursor=cursor,
                    client_id=current.get("ClientID"),
                    vendor_id=current.get("VendorID"),
                    except_contact_id=contact_id,
                    user_email=updated_by,
                )

            cursor.execute(
                f"""
                    UPDATE {self.TABLE_NAME}
                    SET
                        ContactName = ?,
                        EmailAddress = ?,
                        ContactType = ?,
                        ContactGender = ?,
                        LanguageCode = ?,
                        PhoneNumber = ?,
                        JobTitle = ?,
                        IsPrimary = ?,
                        IsActive = ?,
                        UpdatedBy = ?,
                        UpdatedAt = SYSDATETIME()
                    WHERE ContactID = ?;
                """,
                (
                    self._required_text(
                        contact_name,
                        "ContactName",
                    ),
                    normalized_email,
                    self._normalize_contact_type(
                        contact_type
                    ),
                    self._normalize_gender(
                        contact_gender
                    ),
                    self._normalize_language(
                        language_code
                    ),
                    self._optional_text(
                        phone_number
                    ),
                    self._optional_text(
                        job_title
                    ),
                    1 if is_primary else 0,
                    1 if is_active else 0,
                    self._normalize_email(
                        updated_by
                    ),
                    self._required_int(
                        contact_id,
                        "ContactID",
                    ),
                ),
            )

            affected = cursor.rowcount

            connection.commit()

            return affected

        except Exception:
            connection.rollback()
            raise

        finally:
            connection.close()

    def update_field(
        self,
        contact_id: int,
        field: str,
        value: Any,
        updated_by: str | None,
    ) -> int:
        """
        Actualiza únicamente un campo permitido.
        """

        normalized_field = str(
            field or ""
        ).strip()

        if (
            normalized_field
            not in self.ALLOWED_UPDATE_FIELDS
        ):
            raise ValueError(
                f"No se permite actualizar el campo "
                f"'{normalized_field}'."
            )

        if normalized_field == "EmailAddress":
            value = self._normalize_email(
                value
            )

            if not value or not self._is_valid_email(
                value
            ):
                raise ValueError(
                    "EmailAddress no es válido."
                )

        elif normalized_field == "ContactType":
            value = self._normalize_contact_type(
                value
            )

        elif normalized_field == "ContactGender":
            value = self._normalize_gender(
                value
            )

        elif normalized_field == "LanguageCode":
            value = self._normalize_language(
                value
            )

        elif normalized_field in {
            "IsPrimary",
            "IsActive",
        }:
            value = 1 if self._to_bool(value) else 0

        sql = f"""
            UPDATE {self.TABLE_NAME}
            SET
                [{normalized_field}] = ?,
                UpdatedBy = ?,
                UpdatedAt = SYSDATETIME()
            WHERE ContactID = ?;
        """

        return self.db.execute(
            sql,
            (
                value,
                self._normalize_email(
                    updated_by
                ),
                self._required_int(
                    contact_id,
                    "ContactID",
                ),
            ),
        )

    def set_primary(
        self,
        contact_id: int,
        updated_by: str | None,
    ) -> int:
        """
        Marca el contacto como principal y desmarca los demás
        contactos del mismo cliente y proveedor.
        """

        contact = self.get_contact(
            contact_id=contact_id,
            active_only=False,
        )

        if not contact:
            raise ValueError(
                "El contacto no existe."
            )

        connection = self.db.connect()

        try:
            cursor = connection.cursor()

            self._clear_primary_with_cursor(
                cursor=cursor,
                client_id=contact.get("ClientID"),
                vendor_id=contact.get("VendorID"),
                except_contact_id=contact_id,
                user_email=updated_by,
            )

            cursor.execute(
                f"""
                    UPDATE {self.TABLE_NAME}
                    SET
                        IsPrimary = 1,
                        IsActive = 1,
                        UpdatedBy = ?,
                        UpdatedAt = SYSDATETIME()
                    WHERE ContactID = ?;
                """,
                (
                    self._normalize_email(
                        updated_by
                    ),
                    self._required_int(
                        contact_id,
                        "ContactID",
                    ),
                ),
            )

            affected = cursor.rowcount

            connection.commit()

            return affected

        except Exception:
            connection.rollback()
            raise

        finally:
            connection.close()

    def set_active(
        self,
        contact_id: int,
        is_active: bool,
        updated_by: str | None,
    ) -> int:
        """
        Activa o desactiva un contacto.
        """

        sql = f"""
            UPDATE {self.TABLE_NAME}
            SET
                IsActive = ?,

                IsPrimary =
                    CASE
                        WHEN ? = 0
                            THEN 0
                        ELSE IsPrimary
                    END,

                UpdatedBy = ?,
                UpdatedAt = SYSDATETIME()

            WHERE ContactID = ?;
        """

        active_value = (
            1 if is_active else 0
        )

        return self.db.execute(
            sql,
            (
                active_value,
                active_value,
                self._normalize_email(
                    updated_by
                ),
                self._required_int(
                    contact_id,
                    "ContactID",
                ),
            ),
        )

    def soft_delete(
        self,
        contact_id: int,
        updated_by: str | None,
    ) -> int:
        """
        Eliminación lógica.
        """

        return self.set_active(
            contact_id=contact_id,
            is_active=False,
            updated_by=updated_by,
        )

    # =========================================================
    # FUNCIONES INTERNAS
    # =========================================================

    def _clear_primary_with_cursor(
        self,
        cursor,
        client_id: int,
        vendor_id: int,
        except_contact_id: int | None,
        user_email: str | None,
    ) -> None:
        """
        Desmarca contactos principales usando una transacción abierta.
        """

        sql = f"""
            UPDATE {self.TABLE_NAME}
            SET
                IsPrimary = 0,
                UpdatedBy = ?,
                UpdatedAt = SYSDATETIME()
            WHERE {self.CLIENT_COLUMN} = ?
              AND VendorID = ?
              AND ISNULL(IsPrimary, 0) = 1
        """

        params: list[Any] = [
            self._normalize_email(
                user_email
            ),
            self._required_int(
                client_id,
                "ClientID",
            ),
            self._required_int(
                vendor_id,
                "VendorID",
            ),
        ]

        if except_contact_id not in (
            None,
            "",
        ):
            sql += """
                AND ContactID <> ?
            """

            params.append(
                self._required_int(
                    except_contact_id,
                    "ContactID",
                )
            )

        cursor.execute(
            sql,
            tuple(params),
        )

    @classmethod
    def _normalize_contact_type(
        cls,
        value: Any,
    ) -> str:
        contact_type = str(
            value or "TO"
        ).strip().upper()

        aliases = {
            "MAIN": "PRIMARY",
            "PRINCIPAL": "PRIMARY",
            "DESTINATARIO": "TO",
            "COPIA": "CC",
            "COPY": "CC",
            "OCULTA": "BCC",
            "FINANZAS": "FINANCE",
            "FINANCIAL": "FINANCE",
            "AUDITORIA": "AUDIT",
            "AUDITORÍA": "AUDIT",
            "PROVEEDOR": "VENDOR",
            "OTRO": "OTHER",
        }

        contact_type = aliases.get(
            contact_type,
            contact_type,
        )

        if (
            contact_type
            not in cls.VALID_CONTACT_TYPES
        ):
            return "OTHER"

        return contact_type

    @classmethod
    def _normalize_gender(
        cls,
        value: Any,
    ) -> str:
        gender = str(
            value or "UNKNOWN"
        ).strip().upper()

        aliases = {
            "FEMALE": "F",
            "FEMENINO": "F",
            "MUJER": "F",
            "MS": "F",
            "MRS": "F",
            "MALE": "M",
            "MASCULINO": "M",
            "HOMBRE": "M",
            "MR": "M",
            "U": "UNKNOWN",
            "N/A": "UNKNOWN",
            "NONE": "UNKNOWN",
        }

        gender = aliases.get(
            gender,
            gender,
        )

        if gender not in cls.VALID_GENDERS:
            return "UNKNOWN"

        return gender

    @staticmethod
    def _normalize_language(
        value: Any,
    ) -> str:
        language = str(
            value or "en"
        ).strip().lower()

        if language.startswith("es"):
            return "es"

        return "en"

    @staticmethod
    def _normalize_email(
        value: Any,
    ) -> str | None:
        email = str(
            value or ""
        ).strip().lower()

        return email or None

    @staticmethod
    def _is_valid_email(
        value: str,
    ) -> bool:
        pattern = (
            r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+"
            r"@[A-Za-z0-9-]+"
            r"(?:\.[A-Za-z0-9-]+)+$"
        )

        return bool(
            re.match(
                pattern,
                value,
            )
        )

    @staticmethod
    def _required_int(
        value: Any,
        field_name: str,
    ) -> int:
        if value in (
            None,
            "",
        ):
            raise ValueError(
                f"{field_name} es obligatorio."
            )

        try:
            return int(value)

        except (
            TypeError,
            ValueError,
        ) as error:
            raise ValueError(
                f"{field_name} debe ser numérico."
            ) from error

    @staticmethod
    def _required_text(
        value: Any,
        field_name: str,
    ) -> str:
        text = str(
            value or ""
        ).strip()

        if not text:
            raise ValueError(
                f"{field_name} es obligatorio."
            )

        return text

    @staticmethod
    def _optional_text(
        value: Any,
    ) -> str | None:
        text = str(
            value or ""
        ).strip()

        return text or None

    @staticmethod
    def _to_bool(
        value: Any,
    ) -> bool:
        if isinstance(
            value,
            bool,
        ):
            return value

        if isinstance(
            value,
            (
                int,
                float,
            ),
        ):
            return value != 0

        normalized = str(
            value or ""
        ).strip().lower()

        return normalized in {
            "1",
            "true",
            "yes",
            "y",
            "si",
            "sí",
            "on",
        }

    @staticmethod
    def _append_unique(
        target: list[str],
        value: str | None,
    ) -> None:
        if (
            value
            and value not in target
        ):
            target.append(value)
