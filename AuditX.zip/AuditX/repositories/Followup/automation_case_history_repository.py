from __future__ import annotations
 
from typing import Any
 
from database.connection import Database
from database.db_config import DB_CONFIG_AUDITFOLLOWUP
 
 
class AutomationCaseHistoryRepository:
    """
    Repositorio para registrar y consultar el historial
    de ejecución de los casos de Follow-up.
 
    Guarda:
        - Cliente y proyecto.
        - Caso.
        - Regla aplicada.
        - Template utilizado.
        - Estado anterior y nuevo.
        - Destinatario.
        - Subject.
        - EntryID de Outlook.
        - Modo de envío.
        - Resultado.
        - Mensaje de error.
        - Usuario ejecutor.
    """
 
    def __init__(
        self,
        db: Database | None = None
    ):
        self.db = db or Database(
            DB_CONFIG_AUDITFOLLOWUP
        )
 
    def add_history(
        self,
        client_id: int,
        project_id: int | None,
        case_id: int,
        rule_id: int | None = None,
        template_code: str | None = None,
        previous_status: str | None = None,
        new_status: str | None = None,
        email_to: str | None = None,
        email_subject: str | None = None,
        email_entry_id: str | None = None,
        sent_mode: str | None = None,
        was_successful: bool = False,
        error_message: str | None = None,
        executed_by: int | str | None = None,
    ) -> int:
        """
        Inserta un registro en AutomationCaseHistory.
 
        Returns:
            Número de filas afectadas.
        """
 
        if client_id in (None, ""):
            raise ValueError(
                "ClientID es obligatorio para registrar el historial."
            )
 
        if case_id in (None, ""):
            raise ValueError(
                "CaseID es obligatorio para registrar el historial."
            )
 
        normalized_sent_mode = str(
            sent_mode or ""
        ).strip().upper()
 
        normalized_previous_status = str(
            previous_status or ""
        ).strip() or None
 
        normalized_new_status = str(
            new_status or ""
        ).strip() or None
 
        normalized_template_code = str(
            template_code or ""
        ).strip() or None
 
        normalized_email_to = str(
            email_to or ""
        ).strip() or None
 
        normalized_email_subject = str(
            email_subject or ""
        ).strip() or None
 
        normalized_email_entry_id = str(
            email_entry_id or ""
        ).strip() or None
 
        normalized_error_message = str(
            error_message or ""
        ).strip() or None
 
        sql = """
            INSERT INTO dbo.AutomationCaseHistory
            (
                ClientID,
                ProjectID,
                CaseID,
                RuleID,
                TemplateCode,
                PreviousStatus,
                NewStatus,
                EmailTo,
                EmailSubject,
                EmailEntryID,
                SentMode,
                WasSuccessful,
                ErrorMessage,
                ExecutedBy,
                ExecutedAt
            )
            VALUES
            (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, GETDATE()
            );
        """
 
        return self.db.execute(
            sql,
            (
                int(client_id),
                project_id,
                int(case_id),
                rule_id,
                normalized_template_code,
                normalized_previous_status,
                normalized_new_status,
                normalized_email_to,
                normalized_email_subject,
                normalized_email_entry_id,
                normalized_sent_mode or None,
                1 if was_successful else 0,
                normalized_error_message,
                executed_by,
            ),
        )
 
    def add_success(
        self,
        client_id: int,
        project_id: int | None,
        case_id: int,
        rule_id: int | None = None,
        template_code: str | None = None,
        previous_status: str | None = None,
        new_status: str | None = None,
        email_to: str | None = None,
        email_subject: str | None = None,
        email_entry_id: str | None = None,
        sent_mode: str = "DRAFT",
        executed_by: int | str | None = None,
    ) -> int:
        """
        Registra una ejecución exitosa.
        """
 
        return self.add_history(
            client_id=client_id,
            project_id=project_id,
            case_id=case_id,
            rule_id=rule_id,
            template_code=template_code,
            previous_status=previous_status,
            new_status=new_status,
            email_to=email_to,
            email_subject=email_subject,
            email_entry_id=email_entry_id,
            sent_mode=sent_mode,
            was_successful=True,
            error_message=None,
            executed_by=executed_by,
        )
 
    def add_error(
        self,
        client_id: int,
        project_id: int | None,
        case_id: int,
        error_message: str,
        rule_id: int | None = None,
        template_code: str | None = None,
        previous_status: str | None = None,
        new_status: str | None = None,
        email_to: str | None = None,
        email_subject: str | None = None,
        sent_mode: str = "ERROR",
        executed_by: int | str | None = None,
    ) -> int:
        """
        Registra una ejecución con error.
        """
 
        return self.add_history(
            client_id=client_id,
            project_id=project_id,
            case_id=case_id,
            rule_id=rule_id,
            template_code=template_code,
            previous_status=previous_status,
            new_status=new_status,
            email_to=email_to,
            email_subject=email_subject,
            email_entry_id=None,
            sent_mode=sent_mode,
            was_successful=False,
            error_message=error_message,
            executed_by=executed_by,
        )
 
    def get_by_case(
        self,
        case_id: int
    ) -> list[dict[str, Any]]:
        """
        Devuelve todo el historial de un caso.
        """
 
        if case_id in (None, ""):
            raise ValueError(
                "CaseID es obligatorio."
            )
 
        sql = """
            SELECT
                HistoryID,
                ClientID,
                ProjectID,
                CaseID,
                RuleID,
                TemplateCode,
                PreviousStatus,
                NewStatus,
                EmailTo,
                EmailSubject,
                EmailEntryID,
                SentMode,
                WasSuccessful,
                ErrorMessage,
                ExecutedBy,
                ExecutedAt
            FROM dbo.AutomationCaseHistory
            WHERE CaseID = ?
            ORDER BY ExecutedAt DESC, HistoryID DESC;
        """
 
        return self.db.fetch_all(
            sql,
            (
                int(case_id),
            ),
        )
 
    def get_latest_by_case(
        self,
        case_id: int
    ) -> dict[str, Any] | None:
        """
        Devuelve el último movimiento registrado para un caso.
        """
 
        if case_id in (None, ""):
            raise ValueError(
                "CaseID es obligatorio."
            )
 
        sql = """
            SELECT TOP 1
                HistoryID,
                ClientID,
                ProjectID,
                CaseID,
                RuleID,
                TemplateCode,
                PreviousStatus,
                NewStatus,
                EmailTo,
                EmailSubject,
                EmailEntryID,
                SentMode,
                WasSuccessful,
                ErrorMessage,
                ExecutedBy,
                ExecutedAt
            FROM dbo.AutomationCaseHistory
            WHERE CaseID = ?
            ORDER BY ExecutedAt DESC, HistoryID DESC;
        """
 
        return self.db.fetch_one(
            sql,
            (
                int(case_id),
            ),
        )
 
    def get_recent(
        self,
        client_id: int | None = None,
        project_id: int | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """
        Devuelve los registros más recientes.
 
        Los filtros de cliente y proyecto son opcionales.
        """
 
        safe_limit = self._normalize_limit(
            limit
        )
 
        sql = f"""
            SELECT TOP ({safe_limit})
                HistoryID,
                ClientID,
                ProjectID,
                CaseID,
                RuleID,
                TemplateCode,
                PreviousStatus,
                NewStatus,
                EmailTo,
                EmailSubject,
                EmailEntryID,
                SentMode,
                WasSuccessful,
                ErrorMessage,
                ExecutedBy,
                ExecutedAt
            FROM dbo.AutomationCaseHistory
            WHERE 1 = 1
        """
 
        params: list[Any] = []
 
        if client_id not in (None, ""):
            sql += """
                AND ClientID = ?
            """
            params.append(
                int(client_id)
            )
 
        if project_id not in (None, ""):
            sql += """
                AND ProjectID = ?
            """
            params.append(
                int(project_id)
            )
 
        sql += """
            ORDER BY ExecutedAt DESC, HistoryID DESC;
        """
 
        return self.db.fetch_all(
            sql,
            tuple(params),
        )
 
    def get_successful_by_case(
        self,
        case_id: int
    ) -> list[dict[str, Any]]:
        """
        Devuelve únicamente ejecuciones exitosas del caso.
        """
 
        if case_id in (None, ""):
            raise ValueError(
                "CaseID es obligatorio."
            )
 
        sql = """
            SELECT
                HistoryID,
                ClientID,
                ProjectID,
                CaseID,
                RuleID,
                TemplateCode,
                PreviousStatus,
                NewStatus,
                EmailTo,
                EmailSubject,
                EmailEntryID,
                SentMode,
                WasSuccessful,
                ErrorMessage,
                ExecutedBy,
                ExecutedAt
            FROM dbo.AutomationCaseHistory
            WHERE CaseID = ?
              AND WasSuccessful = 1
            ORDER BY ExecutedAt DESC, HistoryID DESC;
        """
 
        return self.db.fetch_all(
            sql,
            (
                int(case_id),
            ),
        )
 
    
 
    def get_failed_by_case(
        self,
        case_id: int
    ) -> list[dict[str, Any]]:
        """
        Devuelve únicamente ejecuciones fallidas del caso.
        """
 
        if case_id in (None, ""):
            raise ValueError(
                "CaseID es obligatorio."
            )
 
        sql = """
            SELECT
                HistoryID,
                ClientID,
                ProjectID,
                CaseID,
                RuleID,
                TemplateCode,
                PreviousStatus,
                NewStatus,
                EmailTo,
                EmailSubject,
                EmailEntryID,
                SentMode,
                WasSuccessful,
                ErrorMessage,
                ExecutedBy,
                ExecutedAt
            FROM dbo.AutomationCaseHistory
            WHERE CaseID = ?
              AND WasSuccessful = 0
            ORDER BY ExecutedAt DESC, HistoryID DESC;
        """
 
        return self.db.fetch_all(
            sql,
            (
                int(case_id),
            ),
        )
 
    def exists_email_entry_id(
        self,
        email_entry_id: str
    ) -> bool:
        """
        Verifica si un EntryID de Outlook ya está registrado.
        """
 
        normalized_entry_id = str(
            email_entry_id or ""
        ).strip()
 
        if not normalized_entry_id:
            return False
 
        sql = """
            SELECT COUNT(1)
            FROM dbo.AutomationCaseHistory
            WHERE EmailEntryID = ?;
        """
 
        count = self.db.scalar(
            sql,
            (
                normalized_entry_id,
            ),
        )
 
        return int(count or 0) > 0
 
    @staticmethod
    def _normalize_limit(
        limit: int
    ) -> int:
        """
        Evita insertar un TOP inválido en la consulta.
        """
 
        try:
            normalized = int(limit)
        except (
            TypeError,
            ValueError,
        ):
            normalized = 100
 
        if normalized < 1:
            return 1
 
        if normalized > 1000:
            return 1000
 
        return normalized
 