from database.connection import Database
 
 
class CampaignRepository:
 
    def __init__(self):
        self.db = Database()
 
    def get_campaigns(self, client_id, project_id):
 
        sql = """
        SELECT
            CampaignID,
            CampaignCode,
            CampaignName,
            AuditYear
        FROM dbo.Campaigns
        WHERE ClientID = ?
          AND ProjectID = ?
          AND IsActive = 1
        ORDER BY CampaignName
        """
 
        return self.db.fetch_all(sql, [
            client_id,
            project_id
        ])
 
    def ensure_campaign(
        self,
        client_id,
        project_id,
        campaign_name,
        audit_year,
        user_email
    ):
 
        sql_exists = """
        SELECT TOP 1 CampaignID
        FROM dbo.Campaigns
        WHERE ClientID = ?
          AND ProjectID = ?
          AND CampaignName = ?
        """
 
        exists = self.db.fetch_one(sql_exists, [
            client_id,
            project_id,
            campaign_name
        ])
 
        if exists:
            return exists["CampaignID"]
 
        sql_insert = """
        INSERT INTO dbo.Campaigns (
            ClientID,
            ProjectID,
            CampaignName,
            AuditYear,
            CreatedBy
        )
        OUTPUT INSERTED.CampaignID
        VALUES (?, ?, ?, ?, ?)
        """
 
        return self.db.scalar(sql_insert, [
            client_id,
            project_id,
            campaign_name,
            audit_year,
            user_email
        ])