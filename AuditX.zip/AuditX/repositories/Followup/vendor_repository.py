from __future__ import annotations 

from typing import Any

from database.connection import Database
from database.db_config import DB_CONFIG_AUDITFOLLOWUP


class VendorRepository:
    """
    Repositorio de proveedores del módulo Follow-up.

    Permite:

        - Listar proveedores por cliente.
        - Obtener un proveedor por VendorID.
        - Buscar por número de proveedor.
        - Buscar por nombre.
        - Crear un proveedor si no existe.
        - Reactivar un proveedor existente.
        - Actualizar los datos del proveedor.
        - Activar o desactivar proveedores.

    Estructura esperada:

        dbo.Vendors
            VendorID
            ClientID
            VendorNumber
            VendorName
            IsActive
            CreatedBy
            CreatedAt
            UpdatedBy
            UpdatedAt
    """

    TABLE_NAME = "dbo.Vendors"

    # En tus imágenes la columna se llama ClientID.
    CLIENT_COLUMN = "ClientID"

    ALLOWED_UPDATE_FIELDS = {
        "VendorNumber",
        "VendorName",
        "IsActive",
    }

    def __init__(
        self,
        db: Database | None = None,
    ):
        self.db = db or Database(
            DB_CONFIG_AUDITFOLLOWUP
        )

    # =========================================================
    # CONSULTAS
    # =========================================================

    def get_vendors(
        self,
        client_id: int,
        active_only: bool = True,
        search: str | None = None,
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        """
        Devuelve los proveedores del cliente.

        search:
            Busca coincidencias en VendorNumber o VendorName.

        limit:
            Máximo 5000 registros.
        """

        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )

        safe_limit = self._normalize_limit(
            limit
        )

        sql = f"""
            SELECT TOP ({safe_limit})
                VendorID,
                {self.CLIENT_COLUMN} AS ClientID,
                VendorNumber,
                VendorName,
                IsActive,
                CreatedBy,
                CreatedAt,
                UpdatedBy,
                UpdatedAt
            FROM {self.TABLE_NAME}
            WHERE {self.CLIENT_COLUMN} = ?
        """

        params: list[Any] = [
            normalized_client_id
        ]

        if active_only:
            sql += """
                AND ISNULL(IsActive, 1) = 1
            """

        normalized_search = self._optional_text(
            search
        )

        if normalized_search:
            sql += """
                AND
                (
                    LOWER(
                        ISNULL(VendorNumber, '')
                    ) LIKE LOWER(?)

                    OR

                    LOWER(
                        ISNULL(VendorName, '')
                    ) LIKE LOWER(?)
                )
            """

            search_value = (
                f"%{normalized_search}%"
            )

            params.extend([
                search_value,
                search_value,
            ])

        sql += """
            ORDER BY
                VendorNumber,
                VendorName;
        """

        return self.db.fetch_all(
            sql,
            tuple(params),
        )

    def get_vendor(
        self,
        vendor_id: int,
        active_only: bool = False,
    ) -> dict[str, Any] | None:
        """
        Devuelve un proveedor por VendorID.
        """

        normalized_vendor_id = self._required_int(
            vendor_id,
            "VendorID",
        )

        sql = f"""
            SELECT TOP 1
                VendorID,
                {self.CLIENT_COLUMN} AS ClientID,
                VendorNumber,
                VendorName,
                IsActive,
                CreatedBy,
                CreatedAt,
                UpdatedBy,
                UpdatedAt
            FROM {self.TABLE_NAME}
            WHERE VendorID = ?
        """

        if active_only:
            sql += """
                AND ISNULL(IsActive, 1) = 1
            """

        sql += ";"

        return self.db.fetch_one(
            sql,
            (normalized_vendor_id,),
        )

    def find_by_number(
        self,
        client_id: int,
        vendor_number: str,
        active_only: bool = False,
    ) -> dict[str, Any] | None:
        """
        Busca un proveedor por cliente y VendorNumber.
        """

        normalized_number = self._normalize_vendor_number(
            vendor_number
        )

        if not normalized_number:
            return None

        sql = f"""
            SELECT TOP 1
                VendorID,
                {self.CLIENT_COLUMN} AS ClientID,
                VendorNumber,
                VendorName,
                IsActive,
                CreatedBy,
                CreatedAt,
                UpdatedBy,
                UpdatedAt
            FROM {self.TABLE_NAME}
            WHERE {self.CLIENT_COLUMN} = ?
              AND LOWER(
                    LTRIM(
                        RTRIM(VendorNumber)
                    )
                  ) = LOWER(?)
        """

        if active_only:
            sql += """
                AND ISNULL(IsActive, 1) = 1
            """

        sql += """
            ORDER BY
                ISNULL(IsActive, 1) DESC,
                VendorID;
        """

        return self.db.fetch_one(
            sql,
            (
                self._required_int(
                    client_id,
                    "ClientID",
                ),
                normalized_number,
            ),
        )

    def find_by_name(
        self,
        client_id: int,
        vendor_name: str,
        active_only: bool = True,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """
        Busca proveedores cuyo nombre contenga el texto indicado.
        """

        normalized_name = self._optional_text(
            vendor_name
        )

        if not normalized_name:
            return []

        safe_limit = self._normalize_limit(
            limit,
            maximum=500,
        )

        sql = f"""
            SELECT TOP ({safe_limit})
                VendorID,
                {self.CLIENT_COLUMN} AS ClientID,
                VendorNumber,
                VendorName,
                IsActive,
                CreatedBy,
                CreatedAt,
                UpdatedBy,
                UpdatedAt
            FROM {self.TABLE_NAME}
            WHERE {self.CLIENT_COLUMN} = ?
              AND LOWER(
                    ISNULL(VendorName, '')
                  ) LIKE LOWER(?)
        """

        if active_only:
            sql += """
                AND ISNULL(IsActive, 1) = 1
            """

        sql += """
            ORDER BY
                VendorName,
                VendorNumber;
        """

        return self.db.fetch_all(
            sql,
            (
                self._required_int(
                    client_id,
                    "ClientID",
                ),
                f"%{normalized_name}%",
            ),
        )

    # =========================================================
    # CREAR O RECUPERAR
    # =========================================================

    def ensure_vendor(
        self,
        client_id: int,
        vendor_number: str,
        vendor_name: str | None,
        user_email: str | None,
    ) -> int:
        """
        Obtiene o crea el proveedor.

        Si ya existe por ClientID + VendorNumber:

            - devuelve el VendorID;
            - reactiva el proveedor si estaba inactivo;
            - actualiza VendorName cuando recibe un nombre válido.

        Si no existe:

            - inserta el proveedor;
            - devuelve el nuevo VendorID.
        """

        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )

        normalized_number = self._normalize_vendor_number(
            vendor_number
        )

        if not normalized_number:
            raise ValueError(
                "VendorNumber es obligatorio."
            )

        normalized_name = (
            self._optional_text(vendor_name)
            or normalized_number
        )

        normalized_user = self._normalize_email(
            user_email
        )

        connection = self.db.connect()

        try:
            cursor = connection.cursor()

            cursor.execute(
                f"""
                    SELECT TOP 1
                        VendorID,
                        VendorName,
                        IsActive
                    FROM {self.TABLE_NAME}
                    WHERE {self.CLIENT_COLUMN} = ?
                      AND LOWER(
                            LTRIM(
                                RTRIM(VendorNumber)
                            )
                          ) = LOWER(?)
                    ORDER BY
                        ISNULL(IsActive, 1) DESC,
                        VendorID;
                """,
                (
                    normalized_client_id,
                    normalized_number,
                ),
            )

            existing = cursor.fetchone()

            if existing:
                vendor_id = int(
                    existing[0]
                )

                cursor.execute(
                    f"""
                        UPDATE {self.TABLE_NAME}
                        SET
                            VendorName =
                                COALESCE(
                                    NULLIF(?, ''),
                                    VendorName
                                ),

                            IsActive = 1,
                            UpdatedBy = ?,
                            UpdatedAt = SYSDATETIME()

                        WHERE VendorID = ?;
                    """,
                    (
                        normalized_name,
                        normalized_user,
                        vendor_id,
                    ),
                )

                connection.commit()

                return vendor_id

            cursor.execute(
                f"""
                    INSERT INTO {self.TABLE_NAME}
                    (
                        {self.CLIENT_COLUMN},
                        VendorNumber,
                        VendorName,
                        IsActive,
                        CreatedBy,
                        CreatedAt,
                        UpdatedBy,
                        UpdatedAt
                    )
                    OUTPUT INSERTED.VendorID
                    VALUES
                    (
                        ?, ?, ?, 1,
                        ?, SYSDATETIME(),
                        ?, SYSDATETIME()
                    );
                """,
                (
                    normalized_client_id,
                    normalized_number,
                    normalized_name,
                    normalized_user,
                    normalized_user,
                ),
            )

            row = cursor.fetchone()

            if not row:
                raise RuntimeError(
                    "No fue posible obtener el VendorID."
                )

            vendor_id = int(
                row[0]
            )

            connection.commit()

            return vendor_id

        except Exception:
            connection.rollback()
            raise

        finally:
            connection.close()

    # =========================================================
    # CREAR DIRECTAMENTE
    # =========================================================

    def create_vendor(
        self,
        client_id: int,
        vendor_number: str,
        vendor_name: str,
        created_by: str | None,
        is_active: bool = True,
    ) -> int:
        """
        Crea un proveedor nuevo.

        A diferencia de ensure_vendor, genera error si ya existe.
        """

        normalized_client_id = self._required_int(
            client_id,
            "ClientID",
        )

        normalized_number = self._normalize_vendor_number(
            vendor_number
        )

        if not normalized_number:
            raise ValueError(
                "VendorNumber es obligatorio."
            )

        normalized_name = self._required_text(
            vendor_name,
            "VendorName",
        )

        existing = self.find_by_number(
            client_id=normalized_client_id,
            vendor_number=normalized_number,
            active_only=False,
        )

        if existing:
            raise ValueError(
                "Ya existe un proveedor con ese VendorNumber "
                "para el cliente seleccionado."
            )

        sql = f"""
            INSERT INTO {self.TABLE_NAME}
            (
                {self.CLIENT_COLUMN},
                VendorNumber,
                VendorName,
                IsActive,
                CreatedBy,
                CreatedAt,
                UpdatedBy,
                UpdatedAt
            )
            OUTPUT INSERTED.VendorID
            VALUES
            (
                ?, ?, ?, ?,
                ?, SYSDATETIME(),
                ?, SYSDATETIME()
            );
        """

        normalized_user = self._normalize_email(
            created_by
        )

        vendor_id = self.db.scalar(
            sql,
            (
                normalized_client_id,
                normalized_number,
                normalized_name,
                1 if is_active else 0,
                normalized_user,
                normalized_user,
            ),
        )

        if vendor_id is None:
            raise RuntimeError(
                "No fue posible crear el proveedor."
            )

        return int(vendor_id)

    # =========================================================
    # ACTUALIZACIÓN
    # =========================================================

    def update_vendor(
        self,
        vendor_id: int,
        vendor_number: str,
        vendor_name: str,
        is_active: bool,
        updated_by: str | None,
    ) -> int:
        """
        Actualiza un proveedor completo.
        """

        normalized_vendor_id = self._required_int(
            vendor_id,
            "VendorID",
        )

        current = self.get_vendor(
            vendor_id=normalized_vendor_id,
            active_only=False,
        )

        if not current:
            raise ValueError(
                "El proveedor no existe."
            )

        normalized_number = self._normalize_vendor_number(
            vendor_number
        )

        if not normalized_number:
            raise ValueError(
                "VendorNumber es obligatorio."
            )

        normalized_name = self._required_text(
            vendor_name,
            "VendorName",
        )

        duplicate = self.db.scalar(
            f"""
                SELECT COUNT(1)
                FROM {self.TABLE_NAME}
                WHERE {self.CLIENT_COLUMN} = ?
                  AND LOWER(
                        LTRIM(
                            RTRIM(VendorNumber)
                        )
                      ) = LOWER(?)
                  AND VendorID <> ?;
            """,
            (
                current.get("ClientID"),
                normalized_number,
                normalized_vendor_id,
            ),
        )

        if int(duplicate or 0) > 0:
            raise ValueError(
                "Ya existe otro proveedor con ese VendorNumber "
                "para el mismo cliente."
            )

        sql = f"""
            UPDATE {self.TABLE_NAME}
            SET
                VendorNumber = ?,
                VendorName = ?,
                IsActive = ?,
                UpdatedBy = ?,
                UpdatedAt = SYSDATETIME()
            WHERE VendorID = ?;
        """

        return self.db.execute(
            sql,
            (
                normalized_number,
                normalized_name,
                1 if is_active else 0,
                self._normalize_email(
                    updated_by
                ),
                normalized_vendor_id,
            ),
        )

    def update_field(
        self,
        vendor_id: int,
        field: str,
        value: Any,
        updated_by: str | None,
    ) -> int:
        """
        Actualiza únicamente un campo permitido.
        """

        normalized_field = str(
            field or ""
        ).strip()

        if (
            normalized_field
            not in self.ALLOWED_UPDATE_FIELDS
        ):
            raise ValueError(
                f"No se permite actualizar el campo "
                f"'{normalized_field}'."
            )

        normalized_vendor_id = self._required_int(
            vendor_id,
            "VendorID",
        )

        if normalized_field == "VendorNumber":
            value = self._normalize_vendor_number(
                value
            )

            if not value:
                raise ValueError(
                    "VendorNumber es obligatorio."
                )

            current = self.get_vendor(
                normalized_vendor_id,
                active_only=False,
            )

            if not current:
                raise ValueError(
                    "El proveedor no existe."
                )

            duplicate = self.db.scalar(
                f"""
                    SELECT COUNT(1)
                    FROM {self.TABLE_NAME}
                    WHERE {self.CLIENT_COLUMN} = ?
                      AND LOWER(
                            LTRIM(
                                RTRIM(VendorNumber)
                            )
                          ) = LOWER(?)
                      AND VendorID <> ?;
                """,
                (
                    current.get("ClientID"),
                    value,
                    normalized_vendor_id,
                ),
            )

            if int(duplicate or 0) > 0:
                raise ValueError(
                    "Ya existe otro proveedor con ese número."
                )

        elif normalized_field == "VendorName":
            value = self._required_text(
                value,
                "VendorName",
            )

        elif normalized_field == "IsActive":
            value = (
                1
                if self._to_bool(value)
                else 0
            )

        sql = f"""
            UPDATE {self.TABLE_NAME}
            SET
                [{normalized_field}] = ?,
                UpdatedBy = ?,
                UpdatedAt = SYSDATETIME()
            WHERE VendorID = ?;
        """

        return self.db.execute(
            sql,
            (
                value,
                self._normalize_email(
                    updated_by
                ),
                normalized_vendor_id,
            ),
        )

    def set_active(
        self,
        vendor_id: int,
        is_active: bool,
        updated_by: str | None,
    ) -> int:
        """
        Activa o desactiva un proveedor.
        """

        return self.update_field(
            vendor_id=vendor_id,
            field="IsActive",
            value=is_active,
            updated_by=updated_by,
        )

    def soft_delete(
        self,
        vendor_id: int,
        updated_by: str | None,
    ) -> int:
        """
        Eliminación lógica.
        """

        return self.set_active(
            vendor_id=vendor_id,
            is_active=False,
            updated_by=updated_by,
        )

    # =========================================================
    # VALIDACIONES AUXILIARES
    # =========================================================

    @staticmethod
    def _normalize_vendor_number(
        value: Any,
    ) -> str | None:
        """
        Normaliza VendorNumber sin convertirlo a número.

        Esto conserva ceros a la izquierda, por ejemplo:

            000125
        """

        vendor_number = str(
            value or ""
        ).strip()

        return vendor_number or None

    @staticmethod
    def _normalize_email(
        value: Any,
    ) -> str | None:
        email = str(
            value or ""
        ).strip().lower()

        return email or None

    @staticmethod
    def _required_int(
        value: Any,
        field_name: str,
    ) -> int:
        if value in (
            None,
            "",
        ):
            raise ValueError(
                f"{field_name} es obligatorio."
            )

        try:
            return int(value)

        except (
            TypeError,
            ValueError,
        ) as error:
            raise ValueError(
                f"{field_name} debe ser numérico."
            ) from error

    @staticmethod
    def _required_text(
        value: Any,
        field_name: str,
    ) -> str:
        text = str(
            value or ""
        ).strip()

        if not text:
            raise ValueError(
                f"{field_name} es obligatorio."
            )

        return text

    @staticmethod
    def _optional_text(
        value: Any,
    ) -> str | None:
        text = str(
            value or ""
        ).strip()

        return text or None

    @staticmethod
    def _to_bool(
        value: Any,
    ) -> bool:
        if isinstance(
            value,
            bool,
        ):
            return value

        if isinstance(
            value,
            (
                int,
                float,
            ),
        ):
            return value != 0

        normalized = str(
            value or ""
        ).strip().lower()

        return normalized in {
            "1",
            "true",
            "yes",
            "y",
            "si",
            "sí",
            "on",
            "active",
        }

    @staticmethod
    def _normalize_limit(
        value: Any,
        maximum: int = 5000,
    ) -> int:
        try:
            normalized = int(
                value or 1000
            )
        except (
            TypeError,
            ValueError,
        ):
            normalized = 1000

        if normalized < 1:
            return 1

        if normalized > maximum:
            return maximum

        return normalized
