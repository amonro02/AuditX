"""
    Módulo: connection
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:        
            Gestiona las consultas de información de usuarios, permitiendo obtener los datos de un usuario a partir de su dirección de
            correo electrónico.
"""

from database.connection import get_connection 
 
def find_user_by_email(email: str):
    query = """
        SELECT TOP 1
            [AuditorID],
            [AuditorFullName],
            [AuditorEmail01]
        FROM dbo.[tblAuditors]
        WHERE [AuditorEmail01] = ?
    """
 
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(query, (email,))
    row = cursor.fetchone()
    conn.close()
 
    if not row:
        return None
 
    return {
        "user_id": row[0],
        "user_name": row[1],
        "user_email": row[2]
    }