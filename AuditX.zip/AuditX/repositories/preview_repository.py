"""
    Módulo: connection
    Autor: Armando Monroy
    Fecha: 30/06/2026
    Descripción:        
            Gestiona la obtención de una muestra de registros de las tablas asociadas a una lista de datos, proporcionando la
            información necesaria para la previsualización de los datos.
"""

from database.connection import get_dynamic_connection
from repositories.data_list_repository import get_data_list_by_id
 
 
def get_preview_data(data_list_id: int, top: int = 100):
    meta = get_data_list_by_id(data_list_id)
 
    if not meta:
        return []
 
    conn = get_dynamic_connection(
        driver=None,
        server=meta["server"],
        database=meta["database"]
    )
 
    cursor = conn.cursor()
 
    query = f"""
        SELECT TOP {top} *
        FROM {meta["tableName"]}
    """
 
    cursor.execute(query)
    columns = [col[0] for col in cursor.description]
    rows = cursor.fetchall()
 
    conn.close()
 
    return {
        "columns": columns,
        "rows": [list(r) for r in rows]
    }
 