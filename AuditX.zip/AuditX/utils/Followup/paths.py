from pathlib import Path
import sys

def app_root():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parents[2]

def resource_path(relative_path):
    return app_root() / relative_path
