import json
from utils.Followup.paths import resource_path

def load_json_config(relative_path, default=None):
    path = resource_path(relative_path)
    if not path.exists():
        return default or {}
    return json.loads(path.read_text(encoding="utf-8"))
