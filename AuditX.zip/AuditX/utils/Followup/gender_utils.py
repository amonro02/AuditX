from __future__ import annotations
 
from typing import Any
 
import gender_guesser.detector as gender
 
 
_detector = gender.Detector(
    case_sensitive=False
)
 
 
def normalize_gender(
    gender_value: Any
) -> str:
    """
    Normaliza distintos valores de género.
 
    Devuelve:
        F
        M
        UNKNOWN
    """
 
    value = str(
        gender_value or ""
    ).strip().lower()
 
    female_values = {
        "f",
        "female",
        "femenino",
        "mujer",
        "woman",
        "ms",
        "ms.",
        "mrs",
        "mrs.",
        "miss",
    }
 
    male_values = {
        "m",
        "male",
        "masculino",
        "hombre",
        "man",
        "mr",
        "mr.",
    }
 
    if value in female_values:
        return "F"
 
    if value in male_values:
        return "M"
 
    return "UNKNOWN"
 
 
def infer_gender(
    contact_name: Any
) -> str:
    """
    Intenta identificar el género a partir del primer nombre.
 
    Esta función solamente debe utilizarse cuando el género
    no fue proporcionado explícitamente.
    """
 
    name = str(
        contact_name or ""
    ).strip()
 
    if not name:
        return "UNKNOWN"
 
    first_name = name.split()[0]
 
    try:
        result = _detector.get_gender(
            first_name
        )
    except Exception:
        return "UNKNOWN"
 
    if result in {
        "female",
        "mostly_female",
    }:
        return "F"
 
    if result in {
        "male",
        "mostly_male",
    }:
        return "M"
 
    return "UNKNOWN"
 
 
def get_first_name(
    contact_name: Any
) -> str:
    name = str(
        contact_name or ""
    ).strip()
 
    if not name:
        return ""
 
    return name.split()[0]
 
 
def get_last_name(
    contact_name: Any
) -> str:
    name = str(
        contact_name or ""
    ).strip()
 
    if not name:
        return ""
 
    parts = name.split()
 
    return parts[-1]
 
 
def get_greeting(
    contact_name: Any,
    contact_gender: Any = None,
    language: str = "en",
) -> str:
    """
    Genera el saludo completo.
 
    Ejemplos en inglés:
        Dear Ms. Johnson,
        Dear Mr. Smith,
        Dear Laura,
        Dear Sir or Madam,
 
    Ejemplos en español:
        Estimada Sra. Johnson:
        Estimado Sr. Smith:
        Estimada Laura:
        Estimado(a):
    """
 
    name = str(
        contact_name or ""
    ).strip()
 
    normalized_gender = normalize_gender(
        contact_gender
    )
 
    if normalized_gender == "UNKNOWN":
        normalized_gender = infer_gender(
            name
        )
 
    first_name = get_first_name(name)
    last_name = get_last_name(name)
 
    selected_language = str(
        language or "en"
    ).strip().lower()
 
    if selected_language.startswith("es"):
        if normalized_gender == "F":
            if last_name:
                return f"Estimada Sra. {last_name}:"
 
            if first_name:
                return f"Estimada {first_name}:"
 
            return "Estimada:"
 
        if normalized_gender == "M":
            if last_name:
                return f"Estimado Sr. {last_name}:"
 
            if first_name:
                return f"Estimado {first_name}:"
 
            return "Estimado:"
 
        if first_name:
            return f"Estimado(a) {first_name}:"
 
        return "Estimado(a):"
 
    # Inglés
    if normalized_gender == "F":
        if last_name:
            return f"Dear Ms. {last_name},"
 
        if first_name:
            return f"Dear {first_name},"
 
    if normalized_gender == "M":
        if last_name:
            return f"Dear Mr. {last_name},"
 
        if first_name:
            return f"Dear {first_name},"
 
    if first_name:
        return f"Dear {first_name},"
 
    return "Dear Sir or Madam,"