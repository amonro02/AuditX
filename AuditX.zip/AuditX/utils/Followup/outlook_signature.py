from pathlib import Path
 
 
def load_outlook_signature(signature_name=None):
    sig_dir = Path.home() / "AppData" / "Roaming" / "Microsoft" / "Signatures"
 
    if not sig_dir.exists():
        return ""
 
    if signature_name:
        files = list(sig_dir.glob(f"{signature_name}.htm"))
    else:
        files = list(sig_dir.glob("*.htm"))
 
    if not files:
        return ""
 
    sig_file = files[0]
 
    return sig_file.read_text(
        encoding="utf-8",
        errors="ignore"
    )