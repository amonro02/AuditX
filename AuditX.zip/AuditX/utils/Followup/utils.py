import re
 
 
def email_to_name(email):
    if not email:
        return ""
 
    # antes del @
    name = email.split("@")[0]
 
    # reemplazar . _ -
    name = re.sub(r"[._\-]+", " ", name)
 
    # quitar espacios múltiples
    name = re.sub(r"\s+", " ", name).strip()
 
    # Capitalizar
    return name.title()